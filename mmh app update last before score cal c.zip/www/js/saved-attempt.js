// ══════════════════════════════════════════════════════════════════════════
//  saved-attempt.js — Stage 4
//  "Attempt test" for the saved-questions library.
//
//  A bottom dock offers a local, self-contained test built from whatever
//  scope you are looking at. Settings are collected in a modal, the question
//  set is assembled here from the tree already in memory, and the runner lives
//  on its own page (saved/test.html) reached through the same one-time
//  sessionStorage handoff the PDF export uses.
//
//  The runner deliberately does NOT reuse test.html's engine. test.html is a
//  server-backed exam: it fetches a quiz, posts attempts, and ranks you
//  against other candidates. None of that applies here — this is a private
//  practice run over questions you saved yourself, so it must not post an
//  attempt, must not appear in any topper list, and must not compute a rank
//  or percentile. Keeping it separate is what makes that structurally true
//  rather than a promise.
//
//  Reads: allQuestions (through saved.js's own batched loader) in addition to
//  the tree already in memory. Writes: NOTHING. Attempting a test is entirely
//  local — no attempt is recorded, no answer is uploaded, nothing is mutated.
// ══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const C = () => window.SavedCore;
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// The generated paper is stored under a per-paper key and the test page is
// opened as test.html?id=<key> — the same URL shape a live mock uses, so
// saved/test.html can read it through the very same loadQuizData() path.
const PAPER_KEY_PREFIX = "mmh-saved-paper:";
const TEST_PAGE   = "test.html";                   // relative to /saved/
// sessionStorage is ~5MB everywhere we care about. Past this the write throws,
// so refuse early with a useful message instead of a QuotaExceededError.
const MAX_PAYLOAD = 4 * 1024 * 1024;

let busy = false;
let chosen = null;                                 // the scope id the user picked (legacy compatibility)
let minutesTouched = false;                        // stop auto-timing fighting the user
let order = "topic";                               // "topic" | "random" — a setting, chosen before generating

// ── Hierarchical Scope State ──────────────────────────────────────────────
let currentContext = { level: "root", sub: null, topic: null };
let scopeMode = "library";                         // "library" | "subjects" | "topics"
let activeStep = "subjects";                       // "subjects" | "topics"
let selectedSubjects = [];                         // Array of subject names
let selectedTopics = [];                           // Array of { sub, topic }

// ── Question Range State ──────────────────────────────────────────────────
let rangeMode = "all";                             // "all" | "custom"
let rangeTouched = false;
let showItemizedSettings = false;                  // Toggled by 3-dots / settings icon
let itemizedRanges = {};                           // unitId -> { from: number, to: number }

// ══════════════════════════════════════════════════════════════════════════
//  SCOPE RESOLUTION (Legacy / Deck contract)
// ══════════════════════════════════════════════════════════════════════════
function countFor(spec) {
  const items = C().treeItems(spec);
  const subs = new Set(), tops = new Set();
  items.forEach(i => { subs.add(i.sub); tops.add(i.sub + "\u0000" + i.topic); });
  return { questions: items.length, subjects: subs.size, topics: tops.size };
}

function scopesFor(route) {
  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const out = [];
  const onQuestions = route.page === "questions";
  const realSub = onQuestions && route.sub !== AS ? route.sub : (route.page === "topics" ? route.sub : null);
  const realTop = onQuestions && route.topic !== AT ? route.topic : null;

  if (realSub && realTop) {
    out.push({ id: "topic", name: realTop, sub: realSub,
               label: realTop, hint: "This folder only",
               spec: { sub: realSub, topic: realTop } });
  }
  if (realSub) {
    out.push({ id: "subject", name: realSub, sub: realSub,
               label: realSub, hint: realTop ? "The whole subject this folder is in" : "This subject",
               spec: { sub: realSub, topic: AT } });
  }
  out.push({ id: "library", name: null, sub: null,
             label: "Whole library", hint: "Every subject and folder you have saved",
             spec: { sub: AS, topic: AT } });

  return out.map(s => Object.assign(s, countFor(s.spec))).filter(s => s.questions > 0);
}

function scopeTitle(s) {
  if (s.id === "topic") return s.sub + " \u2192 " + s.name;
  if (s.id === "subject") return s.name;
  return "Whole library";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE MODE DECK
// ══════════════════════════════════════════════════════════════════════════
function refreshDock() {
  const core = C();
  const scopes = (core && core.tree) ? scopesFor(core.route) : [];
  const ctx = scopes[0] || null;

  document.body.classList.remove("has-attempt-dock");

  const nav = $("savedTestNav");
  if (nav) {
    nav.disabled = !ctx || busy;
    nav.title = ctx
      ? "Attempt " + scopeTitle(ctx) + " (" + ctx.questions +
        (ctx.questions === 1 ? " question)" : " questions)")
      : "Nothing saved here to attempt yet";
  }
  const legacy = $("attemptBtn");
  if (legacy) legacy.disabled = !ctx || busy;
}

// ══════════════════════════════════════════════════════════════════════════
//  CONTEXT & ACTIVE UNITS
// ══════════════════════════════════════════════════════════════════════════
function getContextLevel() {
  const core = C();
  const route = core.route;
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const onQuestions = route.page === "questions";
  const realSub = onQuestions && route.sub !== AS ? route.sub : (route.page === "topics" ? route.sub : null);
  const realTop = onQuestions && route.topic !== AT ? route.topic : null;

  if (realSub && realTop) return { level: "topic", sub: realSub, topic: realTop };
  if (realSub) return { level: "subject", sub: realSub, topic: null };
  return { level: "root", sub: null, topic: null };
}

function getActiveUnits() {
  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const units = [];

  if (scopeMode === "library") {
    const items = core.treeItems({ sub: AS, topic: AT });
    if (items.length) {
      units.push({
        id: "library",
        type: "library",
        label: "Whole Library",
        fullLabel: "Whole Library",
        sub: null,
        topic: null,
        count: items.length,
        items: items
      });
    }
  } else if (scopeMode === "subjects") {
    selectedSubjects.forEach(sName => {
      const items = core.treeItems({ sub: sName, topic: AT });
      if (items.length) {
        units.push({
          id: "sub:" + sName,
          type: "subject",
          label: sName,
          fullLabel: sName,
          sub: sName,
          topic: null,
          count: items.length,
          items: items
        });
      }
    });
  } else if (scopeMode === "topics") {
    selectedTopics.forEach(st => {
      const items = core.treeItems({ sub: st.sub, topic: st.topic });
      if (items.length) {
        units.push({
          id: "top:" + st.sub + ":" + st.topic,
          type: "topic",
          label: st.topic,
          fullLabel: (selectedSubjects.length > 1 ? st.sub + " \u2192 " : "") + st.topic,
          sub: st.sub,
          topic: st.topic,
          count: items.length,
          items: items
        });
      }
    });
  }

  return units;
}

// ══════════════════════════════════════════════════════════════════════════
//  THE MODAL INITIALIZATION & RENDERING
// ══════════════════════════════════════════════════════════════════════════
function openModal() {
  if (busy) return;
  const core = C();
  const scopes = scopesFor(core.route);
  if (!scopes.length) { core.toast("There is nothing to attempt yet."); return; }

  currentContext = getContextLevel();
  showItemizedSettings = false;
  itemizedRanges = {};
  rangeMode = "all";
  rangeTouched = false;
  minutesTouched = false;

  // Initialize scope state based on where user opened the modal from
  if (currentContext.level === "root") {
    scopeMode = "library";
    activeStep = "subjects";
    selectedSubjects = core.subjectNames();
    selectedTopics = [];
  } else if (currentContext.level === "subject") {
    scopeMode = "subjects";
    activeStep = "topics";
    selectedSubjects = [currentContext.sub];
    // Default selected topics are all topics of this subject
    selectedTopics = core.topicNames(currentContext.sub).map(t => ({ sub: currentContext.sub, topic: t }));
  } else {
    // Single topic
    scopeMode = "topics";
    activeStep = "topics";
    selectedSubjects = [currentContext.sub];
    selectedTopics = [{ sub: currentContext.sub, topic: currentContext.topic }];
  }

  const name = $("atName");
  name.value = core.username || "";
  $("atLang").value = core.lang || "en";
  $("atCorrect").value = "2";
  $("atNegative").value = "0.5";

  renderScopeSelector();
  applyScopeLimits();

  const m = $("attemptModal");
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
  order = "topic";
  paintOrderChoice();
  setGenerating(false);
  const gen = $("atGenerate");
  if (gen) gen.disabled = false;
}

// ── Dynamic Scope Tree Rendering ──────────────────────────────────────────
function renderScopeSelector() {
  const host = $("atScopes");
  if (!host) return;
  host.innerHTML = "";

  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;

  // Context line update
  const ctx = currentContext;
  const lineEl = $("atScopeLine");
  if (lineEl) {
    if (ctx.level === "root") lineEl.textContent = "Whole Library";
    else if (ctx.level === "subject") lineEl.textContent = ctx.sub;
    else lineEl.textContent = ctx.sub + " \u2192 " + ctx.topic;
  }

  // 1. SCREEN 1: ROOT / LIBRARY VIEW
  if (ctx.level === "root") {
    const libItems = core.treeItems({ sub: AS, topic: AT });
    const libCount = libItems.length;

    // Card 1: Whole Library
    const labLib = document.createElement("label");
    labLib.className = "pdf-scope" + (scopeMode === "library" ? " is-checked" : "");
    labLib.innerHTML =
      '<input type="radio" name="atScopeChoice" value="library"' + (scopeMode === "library" ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid fa-book-bookmark"></i> Whole Library</span>' +
        '<span class="pdf-scope-hint">Every subject and folder you have saved</span>' +
      '</span>' +
      '<span class="pdf-scope-count">' + libCount + '</span>';
    labLib.onclick = () => {
      if (scopeMode !== "library") {
        scopeMode = "library";
        rangeMode = "all";
        rangeTouched = false;
        minutesTouched = false;
        renderScopeSelector();
        applyScopeLimits();
      }
    };
    host.appendChild(labLib);

    // Card 2: Select Specific Subject(s)
    const isSpecific = (scopeMode !== "library");
    const labSpec = document.createElement("label");
    labSpec.className = "pdf-scope" + (isSpecific ? " is-checked" : "");
    labSpec.innerHTML =
      '<input type="radio" name="atScopeChoice" value="specific"' + (isSpecific ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid fa-folder-tree"></i> Select Specific Subject(s)</span>' +
        '<span class="pdf-scope-hint">Choose one or more subjects or specific topics</span>' +
      '</span>';
    labSpec.onclick = () => {
      if (scopeMode === "library") {
        scopeMode = "subjects";
        activeStep = "subjects";
        if (!selectedSubjects.length) selectedSubjects = core.subjectNames();
        rangeMode = "all";
        rangeTouched = false;
        minutesTouched = false;
        renderScopeSelector();
        applyScopeLimits();
      }
    };
    host.appendChild(labSpec);

    // If Specific Subjects is chosen:
    if (isSpecific) {
      if (activeStep === "subjects") {
        // Step 1 Expanded: Choose Subjects
        const panel = document.createElement("div");
        panel.className = "at-panel-box";
        
        const allSubs = core.subjectNames();
        const head = document.createElement("div");
        head.className = "at-panel-head";
        head.innerHTML =
          '<span>Choose Subjects:</span>' +
          '<div class="at-panel-actions">' +
            '<button type="button" class="at-link-btn" data-act="all">All</button>' +
            '<button type="button" class="at-link-btn" data-act="clear">Clear</button>' +
          '</div>';
        panel.appendChild(head);

        const grid = document.createElement("div");
        grid.className = "at-chips-grid";
        panel.appendChild(grid);

        const drillBtn = document.createElement("button");
        drillBtn.type = "button";
        drillBtn.className = "at-drill-btn";
        drillBtn.innerHTML = '<i class="fa-solid fa-layer-group"></i> Select Specific Topics &rarr;';
        panel.appendChild(drillBtn);
        host.appendChild(panel);

        allSubs.forEach(sName => {
          const sCount = core.treeItems({ sub: sName, topic: AT }).length;
          const checked = selectedSubjects.includes(sName);
          const chip = document.createElement("label");
          chip.className = "at-chip" + (checked ? " is-checked" : "");

          const chk = document.createElement("input");
          chk.type = "checkbox";
          chk.checked = checked;

          const lbl = document.createElement("span");
          lbl.className = "at-chip-label";
          lbl.textContent = sName;

          const cnt = document.createElement("span");
          cnt.className = "at-chip-count";
          cnt.textContent = String(sCount);

          chip.appendChild(chk);
          chip.appendChild(lbl);
          chip.appendChild(cnt);

          chk.onchange = (ev) => {
            if (ev.target.checked) {
              if (!selectedSubjects.includes(sName)) selectedSubjects.push(sName);
            } else {
              selectedSubjects = selectedSubjects.filter(x => x !== sName);
            }
            chip.classList.toggle("is-checked", ev.target.checked);
            applyScopeLimits();
          };
          grid.appendChild(chip);
        });

        head.querySelector('[data-act="all"]').onclick = () => {
          selectedSubjects = allSubs.slice();
          grid.querySelectorAll(".at-chip").forEach(c => {
            c.classList.add("is-checked");
            const inp = c.querySelector("input");
            if (inp) inp.checked = true;
          });
          applyScopeLimits();
        };
        head.querySelector('[data-act="clear"]').onclick = () => {
          selectedSubjects = [];
          grid.querySelectorAll(".at-chip").forEach(c => {
            c.classList.remove("is-checked");
            const inp = c.querySelector("input");
            if (inp) inp.checked = false;
          });
          applyScopeLimits();
        };
        drillBtn.onclick = () => {
          if (!selectedSubjects.length) { core.toast("Please select at least one subject."); return; }
          activeStep = "topics";
          scopeMode = "topics";
          // Populate topics from selected subjects if not already chosen
          const validSubs = new Set(selectedSubjects);
          selectedTopics = selectedTopics.filter(t => validSubs.has(t.sub));
          if (!selectedTopics.length) {
            selectedSubjects.forEach(s => {
              core.topicNames(s).forEach(top => selectedTopics.push({ sub: s, topic: top }));
            });
          }
          renderScopeSelector();
          applyScopeLimits();
        };
      } else {
        // Step 1 Collapsed into Progress Bar: Subjects
        const bar = document.createElement("div");
        bar.className = "at-step-bar";

        const barMain = document.createElement("div");
        barMain.className = "at-step-bar-main";
        barMain.innerHTML =
          '<div class="at-step-bar-icon"><i class="fa-solid fa-folder-tree"></i></div>' +
          '<div class="at-step-bar-text">' +
            '<span class="at-step-bar-label">Subjects (' + selectedSubjects.length + ' Selected)</span>' +
            '<span class="at-step-bar-val">' + esc(selectedSubjects.join(", ") || "None") + '</span>' +
          '</div>';
        bar.appendChild(barMain);

        const editBtn = document.createElement("button");
        editBtn.type = "button";
        editBtn.className = "at-step-bar-edit";
        editBtn.id = "atEditSubsBtn";
        editBtn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit';
        editBtn.onclick = () => {
          activeStep = "subjects";
          scopeMode = "subjects";
          renderScopeSelector();
          applyScopeLimits();
        };
        bar.appendChild(editBtn);
        host.appendChild(bar);

        // Step 2 Expanded: Choose Topics
        renderTopicsPicker(host);
      }
    }
  }
  // 2. SCREEN 2: INSIDE A SUBJECT VIEW (e.g. Inside Math)
  else if (ctx.level === "subject") {
    const subItems = core.treeItems({ sub: ctx.sub, topic: AT });
    const subCount = subItems.length;

    // Card 1: All of Subject
    const isAllSub = (scopeMode === "subjects");
    const labAll = document.createElement("label");
    labAll.className = "pdf-scope" + (isAllSub ? " is-checked" : "");
    labAll.innerHTML =
      '<input type="radio" name="atSubScopeChoice" value="subject"' + (isAllSub ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid fa-folder-tree"></i> All of ' + esc(ctx.sub) + '</span>' +
        '<span class="pdf-scope-hint">All topics and saved questions in this subject</span>' +
      '</span>' +
      '<span class="pdf-scope-count">' + subCount + '</span>';
    labAll.onclick = () => {
      if (scopeMode !== "subjects") {
        scopeMode = "subjects";
        selectedSubjects = [ctx.sub];
        rangeMode = "all";
        rangeTouched = false;
        minutesTouched = false;
        renderScopeSelector();
        applyScopeLimits();
      }
    };
    host.appendChild(labAll);

    // Card 2: Select Specific Topic(s)
    const isTopicScope = (scopeMode === "topics");
    const labTops = document.createElement("label");
    labTops.className = "pdf-scope" + (isTopicScope ? " is-checked" : "");
    labTops.innerHTML =
      '<input type="radio" name="atSubScopeChoice" value="topics"' + (isTopicScope ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid fa-folder-open"></i> Select Specific Topic(s)</span>' +
        '<span class="pdf-scope-hint">Choose one or more topics inside ' + esc(ctx.sub) + '</span>' +
      '</span>';
    labTops.onclick = () => {
      if (scopeMode !== "topics") {
        scopeMode = "topics";
        selectedSubjects = [ctx.sub];
        if (!selectedTopics.length) {
          selectedTopics = core.topicNames(ctx.sub).map(t => ({ sub: ctx.sub, topic: t }));
        }
        rangeMode = "all";
        rangeTouched = false;
        minutesTouched = false;
        renderScopeSelector();
        applyScopeLimits();
      }
    };
    host.appendChild(labTops);

    if (isTopicScope) {
      // Collapsed Subject progress bar
      const bar = document.createElement("div");
      bar.className = "at-step-bar";

      const barMain = document.createElement("div");
      barMain.className = "at-step-bar-main";
      barMain.innerHTML =
        '<div class="at-step-bar-icon"><i class="fa-solid fa-folder-tree"></i></div>' +
        '<div class="at-step-bar-text">' +
          '<span class="at-step-bar-label">Subject</span>' +
          '<span class="at-step-bar-val">' + esc(ctx.sub) + '</span>' +
        '</div>';
      bar.appendChild(barMain);

      const allSubBtn = document.createElement("button");
      allSubBtn.type = "button";
      allSubBtn.className = "at-step-bar-edit";
      allSubBtn.id = "atAllSubBtn";
      allSubBtn.innerHTML = '<i class="fa-solid fa-rotate-left"></i> All of ' + esc(ctx.sub);
      allSubBtn.onclick = () => {
        scopeMode = "subjects";
        selectedSubjects = [ctx.sub];
        rangeMode = "all";
        rangeTouched = false;
        minutesTouched = false;
        renderScopeSelector();
        applyScopeLimits();
      };
      bar.appendChild(allSubBtn);
      host.appendChild(bar);

      renderTopicsPicker(host);
    }
  }
  // 3. SCREEN 3: INSIDE A SINGLE TOPIC
  else {
    const topItems = core.treeItems({ sub: ctx.sub, topic: ctx.topic });
    const bar = document.createElement("div");
    bar.className = "at-step-bar at-step-bar-static";
    bar.innerHTML =
      '<div class="at-step-bar-main">' +
        '<div class="at-step-bar-icon"><i class="fa-solid fa-folder-open"></i></div>' +
        '<div class="at-step-bar-text">' +
          '<span class="at-step-bar-label">Topic</span>' +
          '<span class="at-step-bar-val">' + esc(ctx.topic) + ' <span style="font-weight:500; opacity:.75;">(in ' + esc(ctx.sub) + ')</span></span>' +
        '</div>' +
      '</div>' +
      '<span class="pdf-scope-count">' + topItems.length + '</span>';
    host.appendChild(bar);
  }
}

// ── Render Topics Picker ──────────────────────────────────────────────────
function renderTopicsPicker(container) {
  const core = C();
  const panel = document.createElement("div");
  panel.className = "at-panel-box";

  const head = document.createElement("div");
  head.className = "at-panel-head";
  head.innerHTML =
    '<span>Choose Topics:</span>' +
    '<div class="at-panel-actions">' +
      '<button type="button" class="at-link-btn" data-act="all">All</button>' +
      '<button type="button" class="at-link-btn" data-act="clear">Clear</button>' +
    '</div>';
  panel.appendChild(head);

  const grid = document.createElement("div");
  grid.className = "at-chips-grid";
  panel.appendChild(grid);
  container.appendChild(panel);

  const subs = selectedSubjects.length ? selectedSubjects : [currentContext.sub].filter(Boolean);

  const allAvailableTopics = [];
  subs.forEach(sName => {
    const tNames = core.topicNames(sName);
    tNames.forEach(tName => allAvailableTopics.push({ sub: sName, topic: tName }));
  });

  subs.forEach(sName => {
    const tNames = core.topicNames(sName);
    if (subs.length > 1 && tNames.length) {
      const gTitle = document.createElement("div");
      gTitle.className = "at-group-title";
      gTitle.textContent = sName;
      grid.appendChild(gTitle);
    }

    tNames.forEach(tName => {
      const tCount = core.treeItems({ sub: sName, topic: tName }).length;
      const checked = selectedTopics.some(x => x.sub === sName && x.topic === tName);
      const chip = document.createElement("label");
      chip.className = "at-chip" + (checked ? " is-checked" : "");

      const chk = document.createElement("input");
      chk.type = "checkbox";
      chk.checked = checked;

      const lbl = document.createElement("span");
      lbl.className = "at-chip-label";
      lbl.textContent = tName;

      const cnt = document.createElement("span");
      cnt.className = "at-chip-count";
      cnt.textContent = String(tCount);

      chip.appendChild(chk);
      chip.appendChild(lbl);
      chip.appendChild(cnt);

      chk.onchange = (ev) => {
        if (ev.target.checked) {
          if (!selectedTopics.some(x => x.sub === sName && x.topic === tName)) {
            selectedTopics.push({ sub: sName, topic: tName });
          }
        } else {
          selectedTopics = selectedTopics.filter(x => !(x.sub === sName && x.topic === tName));
        }
        chip.classList.toggle("is-checked", ev.target.checked);
        applyScopeLimits();
      };
      grid.appendChild(chip);
    });
  });

  head.querySelector('[data-act="all"]').onclick = () => {
    selectedTopics = allAvailableTopics.slice();
    grid.querySelectorAll(".at-chip").forEach(c => {
      c.classList.add("is-checked");
      const inp = c.querySelector("input");
      if (inp) inp.checked = true;
    });
    applyScopeLimits();
  };
  head.querySelector('[data-act="clear"]').onclick = () => {
    selectedTopics = [];
    grid.querySelectorAll(".at-chip").forEach(c => {
      c.classList.remove("is-checked");
      const inp = c.querySelector("input");
      if (inp) inp.checked = false;
    });
    applyScopeLimits();
  };
}

// ══════════════════════════════════════════════════════════════════════════
//  RANGE CALCULATIONS & DISPLAY
// ══════════════════════════════════════════════════════════════════════════
function applyScopeLimits() {
  const units = getActiveUnits();
  const totalAvailable = units.reduce((sum, u) => sum + u.count, 0);

  const totalInput = $("atTotal");
  totalInput.max = String(totalAvailable || 1);
  totalInput.min = "1";

  const rangeBox = $("atRangeBox");
  if (!rangeBox) {
    totalInput.value = String(totalAvailable);
    paintSummary();
    return;
  }

  if (totalAvailable <= 0) {
    rangeBox.style.display = "none";
    totalInput.value = "0";
    paintSummary();
    return;
  }

  rangeBox.style.display = "block";
  renderRangeBox(units, totalAvailable);
}

function renderRangeBox(units, totalAvailable) {
  const presetsHost = $("atRangePresets");
  if (presetsHost) {
    presetsHost.innerHTML = "";

    // Preset 1: All Questions
    const btnAll = document.createElement("button");
    btnAll.type = "button";
    btnAll.className = "at-range-pill" + (rangeMode === "all" ? " is-active" : "");
    btnAll.textContent = "All Questions";
    btnAll.onclick = () => {
      if (busy) return;
      rangeMode = "all";
      rangeTouched = false;
      showItemizedSettings = false;
      applyScopeLimits();
    };
    presetsHost.appendChild(btnAll);

    // Preset 2: Custom Range
    const btnCustom = document.createElement("button");
    btnCustom.type = "button";
    btnCustom.className = "at-range-pill" + (rangeMode === "custom" ? " is-active" : "");
    btnCustom.textContent = "Custom Range";
    btnCustom.onclick = () => {
      if (busy) return;
      rangeMode = "custom";
      rangeTouched = true;
      applyScopeLimits();
    };
    presetsHost.appendChild(btnCustom);

    // If single unit and >= 25 questions, add convenient chunk pills
    if (units.length === 1 && totalAvailable >= 25) {
      const step = 25;
      for (let s = 1; s <= totalAvailable; s += step) {
        const e = Math.min(totalAvailable, s + step - 1);
        const pill = document.createElement("button");
        pill.type = "button";
        const isCurrentChunk = (rangeMode === "custom" &&
          parseInt($("atRangeFrom").value, 10) === s &&
          parseInt($("atRangeTo").value, 10) === e);
        pill.className = "at-range-pill" + (isCurrentChunk ? " is-active" : "");
        pill.textContent = s + "\u2013" + e;
        pill.onclick = () => {
          if (busy) return;
          rangeMode = "custom";
          rangeTouched = true;
          $("atRangeFrom").value = String(s);
          $("atRangeTo").value = String(e);
          applyScopeLimits();
        };
        presetsHost.appendChild(pill);
      }
    }
  }

  const fromEl = $("atRangeFrom");
  const toEl = $("atRangeTo");
  const advBtn = $("atRangeAdvBtn");
  const itemizedBox = $("atItemizedBox");
  const inputsRow = $("atRangeBox").querySelector(".at-range-inputs");

  if (rangeMode === "all") {
    if (inputsRow) inputsRow.style.display = "none";
    if (itemizedBox) itemizedBox.style.display = "none";
    if (advBtn) advBtn.style.display = "none";

    $("atRangeBadge").textContent = "All (" + totalAvailable + " qs)";
    $("atTotal").value = String(totalAvailable);
    if (!minutesTouched) $("atMinutes").value = String(suggestedMinutes(totalAvailable));
    paintSummary();
    return;
  }

  // Range Mode === "custom"
  if (inputsRow) inputsRow.style.display = "flex";

  const maxUnitCount = units.reduce((m, u) => Math.max(m, u.count), 0);
  fromEl.min = "1";
  fromEl.max = String(maxUnitCount);
  toEl.min = "1";
  toEl.max = String(maxUnitCount);

  if (!rangeTouched) {
    fromEl.value = "1";
    toEl.value = String(Math.min(maxUnitCount, 25));
  }

  let f = parseInt(fromEl.value, 10) || 1;
  let t = parseInt(toEl.value, 10) || maxUnitCount;
  if (f < 1) f = 1;
  if (t < f) t = f;

  // Settings / Three-dots icon for Itemized Range Breakdown
  if (advBtn) {
    if (units.length > 1) {
      advBtn.style.display = "flex";
      advBtn.classList.toggle("is-active", showItemizedSettings);
      advBtn.onclick = () => {
        showItemizedSettings = !showItemizedSettings;
        applyScopeLimits();
      };
    } else {
      advBtn.style.display = "none";
      showItemizedSettings = false;
    }
  }

  if (showItemizedSettings && units.length > 1 && itemizedBox) {
    itemizedBox.style.display = "block";
    const titleEl = $("atItemizedTitle");
    if (titleEl) {
      titleEl.textContent = (units[0].type === "topic")
        ? "Custom Range per Topic:"
        : "Custom Range per Subject:";
    }

    const listHost = $("atItemizedList");
    listHost.innerHTML = "";

    units.forEach(u => {
      if (!itemizedRanges[u.id]) {
        itemizedRanges[u.id] = {
          from: Math.min(u.count, f),
          to: Math.min(u.count, t)
        };
      }
      const cur = itemizedRanges[u.id];

      const row = document.createElement("div");
      row.className = "at-itemized-row";

      const meta = document.createElement("div");
      meta.className = "at-itemized-meta";
      meta.innerHTML =
        '<span class="at-itemized-name">' + esc(u.fullLabel || u.label) + '</span>' +
        '<span class="at-itemized-count">' + u.count + ' qs available</span>';
      row.appendChild(meta);

      const inWrap = document.createElement("div");
      inWrap.className = "at-itemized-inputs";

      const inFrom = document.createElement("input");
      inFrom.type = "number";
      inFrom.className = "at-item-from";
      inFrom.min = "1";
      inFrom.max = String(u.count);
      inFrom.value = String(cur.from);

      const sep = document.createElement("span");
      sep.innerHTML = "&rarr;";

      const inTo = document.createElement("input");
      inTo.type = "number";
      inTo.className = "at-item-to";
      inTo.min = "1";
      inTo.max = String(u.count);
      inTo.value = String(cur.to);

      inWrap.appendChild(inFrom);
      inWrap.appendChild(sep);
      inWrap.appendChild(inTo);
      row.appendChild(inWrap);

      inFrom.oninput = () => {
        let v = parseInt(inFrom.value, 10);
        if (!isFinite(v) || v < 1) v = 1;
        if (v > u.count) v = u.count;
        cur.from = v;
        if (cur.to < cur.from) { cur.to = cur.from; inTo.value = String(cur.to); }
        calculateTotalsFromPool();
      };

      inTo.oninput = () => {
        let v = parseInt(inTo.value, 10);
        if (!isFinite(v)) v = u.count;
        if (v > u.count) v = u.count;
        if (v < cur.from) v = cur.from;
        cur.to = v;
        calculateTotalsFromPool();
      };

      listHost.appendChild(row);
    });
  } else if (itemizedBox) {
    itemizedBox.style.display = "none";
  }

  calculateTotalsFromPool();
}

function calculateTotalsFromPool() {
  const units = getActiveUnits();
  const pool = collectPoolItems(units);
  const count = pool.length;

  $("atTotal").value = String(count);
  if (!minutesTouched) $("atMinutes").value = String(suggestedMinutes(count));

  const badge = $("atRangeBadge");
  if (badge) {
    if (rangeMode === "all") {
      badge.textContent = "All (" + count + " qs)";
    } else if (showItemizedSettings && units.length > 1) {
      badge.textContent = "Itemized (" + count + " qs)";
    } else {
      const f = $("atRangeFrom") ? $("atRangeFrom").value : 1;
      const t = $("atRangeTo") ? $("atRangeTo").value : count;
      badge.textContent = "Q" + f + "\u2013Q" + t + " (" + count + " qs)";
    }
  }

  paintSummary();
}

// ── Collect Questions Pool with Safe Range Slicing ─────────────────────────
function collectPoolItems(units) {
  let pool = [];

  if (rangeMode === "all") {
    units.forEach(u => pool.push(...u.items));
    return pool;
  }

  // Custom Range Mode
  if (showItemizedSettings && units.length > 1) {
    units.forEach(u => {
      const custom = itemizedRanges[u.id] || {};
      let f = parseInt(custom.from, 10);
      let t = parseInt(custom.to, 10);
      if (!isFinite(f) || f < 1) f = 1;
      if (!isFinite(t) || t > u.items.length) t = u.items.length;
      if (t < f) t = f;

      if (f <= u.items.length) {
        pool.push(...u.items.slice(f - 1, t));
      }
    });
  } else {
    // Common Range: applies across all units
    // "AND IF ANY TOPIC HAS LESS QS THEN RANGE IT GENERATE TEST NO ERROR GENERATE WITH HOW MANY EXISTS OK"
    let f = parseInt($("atRangeFrom") ? $("atRangeFrom").value : 1, 10);
    let t = parseInt($("atRangeTo") ? $("atRangeTo").value : 999999, 10);
    if (!isFinite(f) || f < 1) f = 1;
    if (!isFinite(t)) t = 999999;

    units.forEach(u => {
      let unitTo = Math.min(u.items.length, t);
      if (f <= u.items.length) {
        pool.push(...u.items.slice(f - 1, unitTo));
      }
    });
  }

  return pool;
}

function handleRangeInput() {
  rangeTouched = true;
  calculateTotalsFromPool();
}

function suggestedMinutes(n) {
  if (!isFinite(n) || n <= 0) return 1;
  return Math.min(600, Math.max(1, Math.round(n)));
}

function computeScopeTitle(units) {
  if (!units || !units.length) return "Saved questions";
  if (scopeMode === "library") return "Whole library";
  if (scopeMode === "subjects") {
    if (units.length === 1) return units[0].label;
    if (units.length <= 3) return units.map(u => u.label).join(", ");
    return units.length + " Subjects";
  }
  if (scopeMode === "topics") {
    if (units.length === 1) return units[0].label + (units[0].sub ? " (" + units[0].sub + ")" : "");
    if (units.length <= 3) return units.map(u => u.label).join(", ");
    return units.length + " Topics";
  }
  return "Saved questions";
}

function readSettings() {
  const units = getActiveUnits();
  if (!units.length) return null;

  const pool = collectPoolItems(units);
  if (!pool.length) return null;

  const totalQs = pool.length;
  const num = (id, lo, hi, dflt) => {
    const raw = parseFloat($(id).value);
    if (!isFinite(raw)) return dflt;
    return Math.min(hi, Math.max(lo, raw));
  };
  const name = ($("atName").value || "").trim() || C().username || "Candidate";

  return {
    units: units,
    pool: pool,
    name: name.slice(0, 60),
    total: Math.round(num("atTotal", 1, totalQs, totalQs)),
    minutes: Math.round(num("atMinutes", 1, 600, suggestedMinutes(totalQs))),
    correct: num("atCorrect", 0, 100, 2),
    negative: num("atNegative", 0, 100, 0.5),
    lang: $("atLang").value || C().lang || "en",
    scopeTitle: computeScopeTitle(units),
    order: order,
    rangeMode: rangeMode
  };
}

function paintSummary() {
  const st = readSettings();
  const el = $("atSummary");
  if (!el || !st) {
    if (el) el.textContent = "Please select subjects or topics with saved questions.";
    return;
  }
  const parts = [];
  parts.push(st.total + (st.total === 1 ? " question" : " questions"));
  parts.push(st.minutes + (st.minutes === 1 ? " minute" : " minutes"));
  parts.push("+" + st.correct + " / \u2212" + st.negative);
  parts.push(st.order === "random" ? "Shuffled" : "Topic-wise");
  el.textContent = parts.join("  \u00b7  ");

  const warn = $("atBigWarn");
  if (warn) {
    warn.hidden = st.total < 120;
    if (!warn.hidden) warn.querySelector("b").textContent = String(st.total);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  ASSEMBLING THE PAPER & STARTING TEST
// ══════════════════════════════════════════════════════════════════════════
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}

function pickItems(items, total, order) {
  const tagged = items.map((it, i) => ({ it: it, i: i }));
  let pool = tagged;
  if (total > 0 && total < pool.length) pool = shuffle(pool).slice(0, total);
  if (order === "random") return shuffle(pool).map(x => x.it);
  return pool.slice().sort((a, b) => a.i - b.i).map(x => x.it);
}

function paintOrderChoice() {
  ["atOrderTopic", "atOrderShuffle"].forEach(id => {
    const b = $(id);
    if (!b) return;
    const on = b.getAttribute("data-order") === order;
    b.classList.toggle("is-on", on);
    b.setAttribute("aria-checked", on ? "true" : "false");
  });
}

function setGenerating(on) {
  const btn = $("atGenerate");
  if (!btn) return;
  btn.disabled = !!on;
  btn.classList.toggle("is-busy", !!on);
}

function closeModal() { if (!busy) $("attemptModal").style.display = "none"; }
function closeModalForce() {
  const m = $("attemptModal");
  if (m) { m.style.display = "none"; m.classList.remove("sv-in"); }
}

async function startAttempt() {
  if (busy) return;
  const core = C();
  const st = readSettings();
  if (!st || !st.pool.length) { core.toast("Please select at least one subject or topic with questions."); return; }

  busy = true;
  setGenerating(true);
  const fail = msg => { setGenerating(false); busy = false; refreshDock(); core.toast(msg); };

  const picked = pickItems(st.pool, st.total, order);
  const pairs = picked.map(it => ({ quizKey: it.quizKey, qid: it.qid }));

  let loaded;
  try {
    loaded = await core.loadQuestions(pairs);
  } catch (err) {
    console.error("saved-attempt: load failed", err);
    return fail("Could not load the questions. Check your connection and try again.");
  }

  if (!loaded || !loaded.length) return fail("Could not load those questions. Check your connection and try again.");

  try {
    const byKey = new Map();
    loaded.forEach(l => byKey.set(l.quizKey + "|" + l.qid, l.q));

    const questions = [];
    picked.forEach(it => {
      const q = byKey.get(it.quizKey + "|" + it.qid);
      if (!q || typeof q !== "object") return;
      questions.push({ it: it, q: q, quizId: q.quiz_id || it.quizKey });
    });
    if (!questions.length) return fail("None of those questions have content stored yet.");

    const quiz = buildQuizData(questions, st, core);
    const json = JSON.stringify(quiz.data);
    if (json.length > MAX_PAYLOAD) {
      return fail("That is too many questions to hand to the test page. Reduce the total and try again.");
    }
    try {
      sessionStorage.setItem(paperKey(quiz.id), json);
    } catch (err) {
      console.error("saved-attempt: handoff failed", err);
      return fail("Could not start the test on this device. Try a smaller total.");
    }

    closeModalForce();
    window.location.href = TEST_PAGE + "?id=" + encodeURIComponent(quiz.id);
  } catch (err) {
    console.error("saved-attempt: build failed", err);
    fail("Could not start the test. Please try again.");
  }
}

function paperKey(id) { return PAPER_KEY_PREFIX + id; }

function buildQuizData(questions, st, core) {
  const id = "saved-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  const seen = new Set();
  let collide = false;
  questions.forEach(x => {
    const qid = String(x.q.id);
    if (seen.has(qid)) collide = true;
    seen.add(qid);
  });

  const section = questions.map(x => {
    const q = Object.assign({}, x.q);
    if (collide) q.id = x.quizId + "-" + String(x.q.id);
    q.correct_score = st.correct;
    q.negative_score = st.negative;
    return q;
  });

  return {
    id: id,
    data: {
      meta: {
        id: id,
        title: (st.scopeTitle || "Saved questions") + " \u2014 Practice set",
        correct_score: st.correct,
        negative_score: st.negative,
        timer_minutes: st.minutes,
        timer_seconds: st.minutes * 60,
        local_paper: true,
        candidate: st.name,
        order: order,
        generated: Date.now()
      },
      sections: { "General": section }
    }
  };
}

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initAttempt() {
  const btn = $("attemptBtn");
  if (btn) btn.onclick = openModal;

  const m = $("attemptModal");
  if (!m) { refreshDock(); return; }
  const x = m.querySelector(".sv-x");       if (x) x.onclick = closeModal;
  const c = m.querySelector(".sv-cancel");  if (c) c.onclick = closeModal;
  m.addEventListener("click", ev => { if (ev.target === m) closeModal(); });

  $("atTotal").addEventListener("input", () => {
    minutesTouched = false;
    paintSummary();
  });

  const fromEl = $("atRangeFrom");
  if (fromEl) fromEl.addEventListener("input", handleRangeInput);
  const toEl = $("atRangeTo");
  if (toEl) toEl.addEventListener("input", handleRangeInput);

  $("atMinutes").addEventListener("input", () => { minutesTouched = true; paintSummary(); });
  ["atCorrect", "atNegative", "atLang"].forEach(id =>
    $(id).addEventListener("change", paintSummary));
  $("atName").addEventListener("input", paintSummary);

  ["atOrderTopic", "atOrderShuffle"].forEach(id => {
    const b = $(id);
    if (!b) return;
    b.onclick = () => {
      if (busy) return;
      order = b.getAttribute("data-order") || "topic";
      paintOrderChoice();
      paintSummary();
    };
  });

  const gen = $("atGenerate");
  if (gen) gen.onclick = () => startAttempt();

  document.addEventListener("keydown", ev => {
    if (ev.key === "Escape" && $("attemptModal").style.display !== "none") closeModal();
  });

  const prev = window.__savedDecorate || function () {};
  window.__savedDecorate = function () { prev(); refreshDock(); };
  refreshDock();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initAttempt);
else initAttempt();

// ── exported for the test suite ─────────────────────────────────────────────
Object.assign(window, {
  savedOpenAttemptModal: openModal,
  savedCloseAttemptModal: closeModal,
  savedStartAttempt: startAttempt,
  savedAttemptScopes: scopesFor,
  savedAttemptChosen: () => chosen,
  savedAttemptSetChosen: id => { chosen = id; minutesTouched = false; applyScopeLimits(); },
  savedAttemptSettings: readSettings,
  savedAttemptPick: pickItems,
  savedAttemptSuggestedMinutes: suggestedMinutes,
  savedAttemptBusy: () => busy,
  savedAttemptPaperKey: paperKey,
  savedAttemptOrder: () => order,
  savedAttemptBuildQuizData: buildQuizData,
  savedAttemptTestPage: TEST_PAGE,
  savedAttemptMaxPayload: MAX_PAYLOAD
});
})();

// ══════════════════════════════════════════════════════════════════════════
//  Mock Matrix Hub — Saved Questions  (Stage 1: shell, folders, cards)
//
//  DATA CONTRACT — the three nodes written by test.html's save modal:
//
//    userSaved/{u}/{subject}/{topic}/{quizId}/{qid} = true
//        the per-user library TREE. Holds no question content. ONE read of
//        userSaved/{u} yields every subject, topic, quizId and qid the user
//        has — which is all the folder screens need, including their counts.
//
//    allQuestions/{quizId}/{qid} = {full question JSON, quiz_id, subject, topic}
//        the shared bank. Read ONLY when the user actually opens a topic, and
//        only for the qids inside it. Never written to from this page.
//
//    userSavedByQuiz/{u}/{quizId}/{qid} = {s, t, at}
//        flat index used by the test page's palette. Stage 2 (delete/move)
//        keeps it in step. Never read on first load — the tree is enough.
//
//  The legacy saved_questions/{u} node is deliberately NOT read and NOT
//  written: questions saved before that structure changed simply do not
//  appear here.
//
//  Everything about a subject or topic name is taken from what Firebase
//  actually returns. Nothing is normalised into a fixed taxonomy, so a custom
//  subject a user typed shows up exactly as they typed it.
// ══════════════════════════════════════════════════════════════════════════

// ── Firebase ────────────────────────────────────────────────────────────────
if (!firebase.apps.length) { firebase.initializeApp(FIREBASE_PROJECTS.common); }
const savedDb = firebase.database();

// ── Sentinels for the two "everything" folders ──────────────────────────────
// fbKey() (test.html's path sanitizer) strips only . # $ [ ] / and caps at 60
// chars, so underscores survive — these match the __CUSTOM__ sentinel already
// used by the save modal. A real folder with one of these exact names is
// filtered out of the grid by isSentinel() so it can never be ambiguous.
const ALL_SUBJECTS = "__ALL_SUBJECTS__";
const ALL_TOPICS   = "__ALL_TOPICS__";
function isSentinel(name) { return name === ALL_SUBJECTS || name === ALL_TOPICS; }

// ── The colourful subject palette, same defs as the save modal ──────────────
// A subject that is not in this list (anything custom the user typed) gets the
// neutral folder icon instead — there is no fallback that pretends to know it.
const SUBJECT_LOOK = {
  "MATHS":     { icon: "fa-square-root-variable", color: "#2563eb" },
  "MATH":      { icon: "fa-square-root-variable", color: "#2563eb" },
  "REASONING": { icon: "fa-brain",                color: "#7c3aed" },
  "GK":        { icon: "fa-earth-asia",           color: "#d97706" },
  "GS":        { icon: "fa-earth-asia",           color: "#d97706" },
  "ENGLISH":   { icon: "fa-language",             color: "#059669" },
  "HINDI":     { icon: "fa-om",                   color: "#dc2626" },
  "COMPUTER":  { icon: "fa-laptop-code",          color: "#0891b2" }
};
const FALLBACK_LOOK   = { icon: "fa-folder",       color: "#64748b" };
const TOPIC_LOOK      = { icon: "fa-folder-open",  color: "#0b5ed7" };
const ALLSUB_LOOK     = { icon: "fa-layer-group",  color: "#198754" };
const ALLTOPIC_LOOK   = { icon: "fa-folder-tree",  color: "#198754" };
function lookForSubject(name) { return SUBJECT_LOOK[String(name).toUpperCase()] || FALLBACK_LOOK; }

// ── State ───────────────────────────────────────────────────────────────────
let USER_EMAIL_KEY = "";     // raw username from the profile
let USER_KEY       = "";     // fbKey()'d — what actually appears in paths
let TREE           = null;   // parsed library: { subjects:[...] }
let QCACHE         = {};     // "quizPathKey|qid" -> question object
let currentLang    = "en";
let viewMode       = "list"; // 'list' | 'focus'
let focusIdx       = 0;
let VIEW_QUESTIONS = [];     // [{quizKey, qid, q}] for the open topic
let REVEALED = {};           // v29 Reattempt Mode: "quizKey|qid" -> option picked
let navPushes      = 0;      // how many states THIS page pushed (back logic)
let loadingToken   = 0;      // cancels a superseded question load
let REATTEMPT_MODE = false;

try { currentLang = localStorage.getItem("quiz_lang") || "en"; } catch (e) {}
try { REATTEMPT_MODE = localStorage.getItem("mmh_saved_reattempt") === "1"; } catch (e) {}

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// fbKey() is lifted verbatim into q-render.js — the SAME sanitizer test.html
// uses to build its save paths, so this page reads exactly what was written.
function fbKeyLocal(raw) {
  if (typeof fbKey === "function") return fbKey(raw);
  let s = String(raw == null ? "" : raw).trim().replace(/\s+/g, " ");
  for (const ch of ".#$[]/") s = s.split(ch).join("-");
  return s.slice(0, 60);
}

// ══════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════
async function bootSaved() {
  // Wait for auth.js to hand over the profile, exactly as before.
  if (typeof getLocalProfile !== "function") { setTimeout(bootSaved, 100); return; }
  const profile = getLocalProfile();
  if (!profile || (profile.username === "User" && !profile.id)) {
    window.location.replace("/login.html");
    return;
  }
  USER_EMAIL_KEY = profile.username;
  USER_KEY = fbKeyLocal(USER_EMAIL_KEY);

  // v29: no #globalLangSelect any more — the language lives behind the globe
  // icon / hamburger entry and is reflected by paintLangState().
  paintLangState();
  const palUser = $("palUsername");
  if (palUser) palUser.textContent = USER_EMAIL_KEY;

  // Deep links (?sub=&topic=) are honoured on first paint, so a shared or
  // refreshed URL lands exactly where it says. Routing only happens once the
  // tree actually arrived — renderRoute() clears the fatal panel, so routing
  // after a failure would wipe the retry screen the user needs.
  const okTree = await loadTree();
  if (okTree) routeFromUrl({ initial: true });
}

// One read. The whole folder structure — subjects, topics, quiz ids, question
// ids and therefore every count — comes from this single call.
async function loadTree() {
  showLoader("Loading your library…");
  try {
    const snap = await savedDb.ref("userSaved/" + USER_KEY).once("value");
    TREE = buildTree(snap.val() || {});
  } catch (err) {
    console.error("saved: tree load failed", err);
    TREE = { subjects: [] };
    showFatal("Could not reach your library. Check your connection and retry.",
              () => { loadTree().then(wasOk => { if (wasOk) routeFromUrl({ initial: true }); }); });
    return false;
  }
  return true;
}

// raw = { SUBJECT: { TOPIC: { QUIZID: { QID: true } } } }
// -> sorted, counted, ready to render. Alphabetical everywhere, as specified.
function buildTree(raw) {
  const subjects = [];
  for (const subKey in raw) {
    const topicsRaw = raw[subKey];
    if (!topicsRaw || typeof topicsRaw !== "object") continue;
    if (isSentinel(subKey)) continue;               // never collide with a pseudo-folder

    const topics = [];
    let subCount = 0;
    for (const topKey in topicsRaw) {
      const quizzesRaw = topicsRaw[topKey];
      if (!quizzesRaw || typeof quizzesRaw !== "object") continue;
      if (isSentinel(topKey)) continue;

      const quizMap = {};                            // quizPathKey -> [qid]
      let count = 0;
      for (const quizKey in quizzesRaw) {
        const qidsRaw = quizzesRaw[quizKey];
        const qids = [];
        if (qidsRaw && typeof qidsRaw === "object") {
          for (const qid in qidsRaw) qids.push(qid);
        } else if (qidsRaw === true || typeof qidsRaw === "string" || typeof qidsRaw === "number") {
          // Defensive: a leaf written straight under the topic (older shape).
          qids.push(String(quizKey));
        }
        if (!qids.length) continue;
        qids.sort(compareQuestionIds);
        quizMap[quizKey] = qids;
        count += qids.length;
      }
      if (!count) continue;
      topics.push({ name: topKey, quizMap, count });
      subCount += count;
    }
    if (!topics.length) continue;
    topics.sort((a, b) => a.name.localeCompare(b.name));
    subjects.push({ name: subKey, topics, topicCount: topics.length, count: subCount });
  }
  subjects.sort((a, b) => a.name.localeCompare(b.name));
  return { subjects };
}

// Q1, Q2, Q10 must sort as 1, 2, 10 — not alphabetically as 1, 10, 2.
function compareQuestionIds(a, b) {
  const na = parseInt(String(a).replace(/\D/g, ""), 10);
  const nb = parseInt(String(b).replace(/\D/g, ""), 10);
  if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
  return String(a).localeCompare(String(b));
}

// ══════════════════════════════════════════════════════════════════════════
//  ROUTING  —  the address bar is the source of truth
// ══════════════════════════════════════════════════════════════════════════
function parseRoute(search) {
  const p = new URLSearchParams(search == null ? window.location.search : search);
  const sub = p.get("sub") || "";
  const topic = p.get("topic") || "";
  const view = p.get("view") || "";
  if (sub === ALL_SUBJECTS) return { page: "questions", sub: ALL_SUBJECTS, topic: ALL_TOPICS, view };
  if (sub && topic)         return { page: "questions", sub, topic, view };
  if (sub)                  return { page: "topics", sub };
  return { page: "subjects" };
}

function buildSearch(r) {
  const p = new URLSearchParams();
  if (r.page === "topics")    p.set("sub", r.sub);
  if (r.page === "questions") { p.set("sub", r.sub); p.set("topic", r.topic); if (r.view) p.set("view", r.view); }
  const s = p.toString();
  return s ? "?" + s : window.location.pathname;
}

// Every navigation pushes a real history entry, so the device/browser back
// button walks subjects -> topics -> questions one step at a time on its own.
// buildSearch() only writes sub/topic to the URL when page says to, so a route
// that arrives without a page would push a URL that no longer describes it —
// the screen would show a folder the address bar knew nothing about, and a
// refresh would land somewhere else entirely. Fill the page in from the same
// hierarchy parseRoute() uses, so the URL and the render always agree.
function normaliseRoute(r) {
  r = Object.assign({}, r || {});
  if (!r.page) {
    if (r.sub && r.topic) r.page = "questions";
    else if (r.sub)       r.page = "topics";
    else                  r.page = "subjects";
  }
  return r;
}

function navigateTo(r, opts) {
  opts = opts || {};
  r = normaliseRoute(r);
  const url = buildSearch(r);
  if (opts.replace) history.replaceState(r, "", url);
  else { history.pushState(r, "", url); navPushes++; }
  renderRoute(r);
}

function routeFromUrl(opts) {
  opts = opts || {};
  const r = parseRoute();
  if (!opts.initial) navPushes = Math.max(0, navPushes - 1);   // a pop, not a push
  renderRoute(r);
}

window.addEventListener("popstate", () => routeFromUrl({}));

// In-page back is structural, not browser-history based. It always follows
// the same hierarchy as the exam and SSC-sub engines:
// questions → topic → subjects → Home. A stale page the user visited before
// opening Saved Questions can never hijack this arrow.
function updateSavedModeDeck() {
  const deck = $("savedBottomNav");
  if (!deck) return;
  const r = parseRoute();
  const show = !!(TREE && TREE.subjects && TREE.subjects.length && r.page !== "questions" ||
                  TREE && TREE.subjects && TREE.subjects.length && r.page === "questions" && viewMode === "list");
  deck.hidden = !show;
  document.body.classList.toggle("saved-deck-visible", show);
  // v29: the deck is the home page's .ex-dock, whose selected state is the
  // `.active` class (colour + the 4px dot underneath), not the old `.is-active`.
  // "Attempt mode" opens the settings modal rather than being a destination, so
  // it never holds the active state — Normal mode is where you actually are.
  const normal = $("savedNormalNav"), test = $("savedTestNav");
  if (normal) normal.classList.toggle("active", true);
  if (test) test.classList.toggle("active", false);
}
function savedNormalMode() {
  const r = parseRoute();
  if (r.page === "questions" && viewMode !== "list") {
    viewMode = "list";
    navigateTo({ page: "questions", sub: r.sub, topic: r.topic, view: "list" }, { replace: true });
  }
  updateSavedModeDeck();
}
function savedTestMode() {
  if (typeof window.savedOpenAttemptModal === "function") window.savedOpenAttemptModal();
  else { const btn = $("attemptBtn"); if (btn) btn.click(); }
}

function savedBack() {
  const r = parseRoute();
  if (r.page === "questions") {
    // The all-library view has no real subject/topic parent. Go straight back
    // to Saved's subject screen instead of manufacturing a sentinel topic URL.
    navigateTo(r.sub === ALL_SUBJECTS
      ? { page: "subjects" }
      : { page: "topics", sub: r.sub }, { replace: true });
  } else if (r.page === "topics") {
    navigateTo({ page: "subjects" }, { replace: true });
  } else {
    window.location.href = "/index.html";
  }
}

function renderRoute(r, keepScroll) {
  hideFatal();
  updateSavedModeDeck();
  hideLoader();                 // loadTree() raises the loader; every screen must lower it
  // v29: the fixed focus bar belongs to focus mode alone. Hiding it here —
  // before any screen is painted, and only paintFocus() puts it back — covers
  // every exit in one place: back to folders, list mode, an empty folder, and
  // the view-mode modal's early return.
  setFocusNavVisible(false);
  const inner = $("screenInner");
  if (!inner) return;
  if (!(keepScroll && r.page === "questions")) $("screenScroll").scrollTop = 0;

  // Folder screens own no questions, so the palette (and its FAB) must go —
  // otherwise navigating BACK out of a topic left it floating over the folders.
  if (r.page !== "questions") {
    setPaletteVisible(false); VIEW_QUESTIONS = []; SEEN = {}; REVEALED = {};
    document.body.classList.remove("mode-solution");
    // CSS hides the dock under body.saved-focus, and that class was only ever
    // toggled inside paintQuestions(). Leaving focus mode for a folder screen
    // therefore never cleared it, so the dock stayed hidden on the subject,
    // topic and list screens until a full reload. Cleared here — the one place
    // every route passes through — so the dock is back on every screen that
    // should have it, and only ?view=focus keeps it away.
    document.body.classList.remove("saved-focus", "saved-list");
  }

  // Only three screens exist. Anything else — a route object that never got a
  // page, a hand-edited URL, a stale history entry — is resolved through
  // parseRoute(), which is the same authority the deck and popstate already use
  // and which always returns one of the three. Without this the fallthrough
  // below treated an unrecognised page as "questions" and painted an empty
  // folder over whatever the user was actually looking at.
  if (r.page !== "subjects" && r.page !== "topics" && r.page !== "questions") {
    r = parseRoute();
  }
  if (r.page === "subjects") { renderSubjects(inner); return; }
  if (r.page === "topics") {
    const sub = findSubject(r.sub);
    if (!sub) { renderSubjects(inner); return; }        // stale link: fall back
    renderTopics(inner, sub); return;
  }
  renderQuestionsRoute(r);
}

function findSubject(name) {
  return TREE ? TREE.subjects.find(s => s.name === name) : null;
}
function findTopic(sub, name) {
  return sub ? sub.topics.find(t => t.name === name) : null;
}

// ══════════════════════════════════════════════════════════════════════════
//  BREADCRUMB  (in the fixed header, so it never scrolls away)
// ══════════════════════════════════════════════════════════════════════════
function renderCrumb(r) {
  const bar = $("crumbBar");
  if (!bar) return;
  const parts = [];
  // Every segment is an actual route control, including the current segment.
  // This keeps the progress row useful on touch devices instead of leaving a
  // visually identical but inert final label.
  parts.push({ label: "Saved", go: { page: "subjects" } });
  if (r.page !== "subjects") {
    parts.push({
      label: r.sub === ALL_SUBJECTS ? "All Subjects" : r.sub,
      go: r.sub === ALL_SUBJECTS
        ? { page: "subjects" }
        : { page: "topics", sub: r.sub }
    });
  }
  if (r.page === "questions") {
    parts.push({
      label: r.topic === ALL_TOPICS ? "All Topics" : r.topic,
      go: { page: "questions", sub: r.sub, topic: r.topic, view: viewMode }
    });
  }
  bar.innerHTML = parts.map((p, i) => {
    const sep = i ? '<i class="fa-solid fa-angle-right crumb-sep"></i>' : "";
    const label = '<span class="crumb-label">' + esc(p.label) + '</span>';
    return sep + '<button type="button" class="crumb-btn" data-i="' + i + '">' + label + "</button>";
  }).join("");
  bar.querySelectorAll(".crumb-btn").forEach(b => {
    b.onclick = () => { const p = parts[Number(b.dataset.i)]; if (p && p.go) navigateTo(p.go); };
  });
  const title = $("headerTitle");
  if (title) {
    title.textContent = r.page === "subjects" ? "Saved Questions"
      : r.page === "topics" ? (r.sub === ALL_SUBJECTS ? "All Subjects" : r.sub)
      : (r.topic === ALL_TOPICS ? "All Topics" : r.topic);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  FOLDER SCREENS
// ══════════════════════════════════════════════════════════════════════════
function folderCard(o) {
  // One folder tile: icon, name, and the counts that describe what is inside.
  // v29: the trailing chevron is GONE. It sat on the same right edge as the
  // three-dot menu that saved-manage.js appends, so the tile showed two stacked
  // affordances and the chevron read as the menu's own arrow. The three-dot is
  // now the only control there, vertically centred by CSS.
  const b = document.createElement("button");
  b.type = "button";
  b.className = "folder-card" + (o.wide ? " folder-wide" : "");
  b.innerHTML =
    '<span class="folder-ico" style="background:' + o.color + '22;color:' + o.color + '">' +
      '<i class="fa-solid ' + o.icon + '"></i></span>' +
    '<span class="folder-body">' +
      '<span class="folder-name">' + esc(o.name) + '</span>' +
      '<span class="folder-meta">' + o.meta.map(m =>
        '<span class="folder-stat"><i class="fa-solid ' + m.icon + '"></i>' + esc(m.text) + '</span>'
      ).join("") + '</span>' +
    '</span>';
  b.onclick = o.onclick;
  // The topic search filters on this rather than re-reading the rendered text,
  // so it keeps working whatever the tile's markup looks like.
  b.setAttribute("data-name", String(o.name == null ? "" : o.name).toLowerCase());
  return b;
}

function plural(n, one, many) { return n + " " + (n === 1 ? one : (many || one + "s")); }

function renderSubjects(host) {
  renderCrumb({ page: "subjects" });
  host.innerHTML = "";
  const subs = TREE ? TREE.subjects : [];

  host.appendChild(sectionHeading("Your Subjects",
    subs.length ? plural(subs.length, "subject") + " · " +
      plural(subs.reduce((a, s) => a + s.count, 0), "question") : ""));

  const grid = document.createElement("div");
  grid.className = "folder-grid";

  // "All subjects together" — opens every saved question in one list.
  const total = subs.reduce((a, s) => a + s.count, 0);
  if (total) {
    grid.appendChild(folderCard({
      wide: true, name: "All Subjects", icon: ALLSUB_LOOK.icon, color: ALLSUB_LOOK.color,
      meta: [{ icon: "fa-layer-group", text: plural(subs.length, "subject") },
             { icon: "fa-circle-question", text: plural(total, "question") }],
      onclick: () => openQuestions({ page: "questions", sub: ALL_SUBJECTS, topic: ALL_TOPICS })
    }));
  }

  subs.forEach(s => {
    grid.appendChild(folderCard({
      name: s.name, icon: lookForSubject(s.name).icon, color: lookForSubject(s.name).color,
      meta: [{ icon: "fa-folder-open", text: plural(s.topicCount, "topic") },
             { icon: "fa-circle-question", text: plural(s.count, "question") }],
      onclick: () => navigateTo({ page: "topics", sub: s.name })
    }));
  });
  host.appendChild(grid);

  if (!subs.length) host.appendChild(emptyState(
    "fa-bookmark", "Your library is empty",
    "Save a question from any test and it will appear here, filed under the subject and topic you chose."));
  window.__savedDecorate();
}

function renderTopics(host, sub) {
  renderCrumb({ page: "topics", sub: sub.name });
  host.innerHTML = "";

  host.appendChild(sectionHeading(sub.name,
    plural(sub.topicCount, "topic") + " · " + plural(sub.count, "question")));

  // A subject can hold dozens of topics, and scrolling is a poor way to find one
  // you already know the name of. The filter is client-side over tiles that are
  // already rendered — no re-read, no re-route, and it survives the three-dot
  // menus because decorateFolders() binds by element, not by position.
  const search = document.createElement("div");
  search.className = "folder-search";
  search.innerHTML =
    '<i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>' +
    '<input type="search" id="topicSearch" autocomplete="off" spellcheck="false"' +
      ' placeholder="Search topics in ' + esc(sub.name) + '"' +
      ' aria-label="Search topics in ' + esc(sub.name) + '">' +
    '<button type="button" class="folder-search-x" id="topicSearchX" hidden aria-label="Clear search">' +
      '<i class="fa-solid fa-times"></i></button>';
  host.appendChild(search);

  const grid = document.createElement("div");
  grid.className = "folder-grid";

  const allCard = folderCard({
    wide: true, name: "All Topics", icon: ALLTOPIC_LOOK.icon, color: ALLTOPIC_LOOK.color,
    meta: [{ icon: "fa-folder-tree", text: plural(sub.topicCount, "topic") },
           { icon: "fa-circle-question", text: plural(sub.count, "question") }],
    onclick: () => openQuestions({ page: "questions", sub: sub.name, topic: ALL_TOPICS })
  });
  grid.appendChild(allCard);

  sub.topics.forEach(t => {
    grid.appendChild(folderCard({
      name: t.name, icon: TOPIC_LOOK.icon, color: TOPIC_LOOK.color,
      meta: [{ icon: "fa-circle-question", text: plural(t.count, "question") },
             { icon: "fa-file-lines", text: plural(Object.keys(t.quizMap).length, "paper") }],
      onclick: () => openQuestions({ page: "questions", sub: sub.name, topic: t.name })
    }));
  });
  host.appendChild(grid);

  const none = emptyState("fa-magnifying-glass", "No topic matches that", "");
  none.hidden = true;
  host.appendChild(none);

  const input = search.querySelector("#topicSearch");
  const clearBtn = search.querySelector("#topicSearchX");
  const applyFilter = () => {
    const q = input.value.trim().toLowerCase();
    clearBtn.hidden = !q;
    let shown = 0;
    // "All Topics" is a shortcut into everything, not a topic — it only belongs
    // on an unfiltered screen, where it reads as the header of the list.
    allCard.hidden = !!q;
    grid.querySelectorAll(".folder-card:not(.folder-wide)").forEach(card => {
      const hit = !q || String(card.getAttribute("data-name") || "").indexOf(q) >= 0;
      card.hidden = !hit;
      if (hit) shown++;
    });
    none.hidden = shown > 0 || !q;
  };
  input.addEventListener("input", applyFilter);
  clearBtn.addEventListener("click", () => { input.value = ""; applyFilter(); input.focus(); });

  window.__savedDecorate();
}

function sectionHeading(title, sub) {
  const d = document.createElement("div");
  d.className = "sec-head";
  d.innerHTML = '<h2 class="sec-title">' + esc(title) + '</h2>' +
                (sub ? '<span class="sec-sub">' + esc(sub) + '</span>' : '');
  return d;
}

function emptyState(icon, title, body) {
  const d = document.createElement("div");
  d.className = "empty-state";
  d.innerHTML = '<i class="fa-solid ' + icon + ' empty-ico"></i>' +
                '<h3>' + esc(title) + '</h3><p>' + esc(body) + '</p>';
  return d;
}

// ══════════════════════════════════════════════════════════════════════════
//  OPENING A FOLDER OF QUESTIONS
// ══════════════════════════════════════════════════════════════════════════
// The view-mode choice is asked EVERY time a folder of questions is opened,
// and there is deliberately no in-page toggle afterwards — the choice is made
// once, at the door, and the page commits to it.
function openQuestions(r) {
  const pairs = collectPairs(r);
  if (!pairs.length) {
    showToast("Nothing to open — that folder is empty.");
    return;
  }
  askViewMode(function (mode) {
    viewMode = mode;
    r.view = mode;
    navigateTo(r);                    // pushes history, then renders
  }, pairs.length);
}

function collectPairs(r) {
  // Gather the (quizKey, qid) pairs a route needs — straight from the tree
  // already in memory. No Firebase read happens here.
  const out = [];
  // Carry the real subject/topic with every pair. Aggregate routes use sentinel
  // names in the URL, but delete/move must later address the actual deep path.
  const push = (s, t) => {
    for (const quizKey in t.quizMap) {
      t.quizMap[quizKey].forEach(qid => out.push({ sub: s.name, topic: t.name, quizKey, qid }));
    }
  };
  if (r.sub === ALL_SUBJECTS) {
    (TREE ? TREE.subjects : []).forEach(s => s.topics.forEach(t => push(s, t)));
  } else {
    const s = findSubject(r.sub);
    if (!s) return out;
    if (r.topic === ALL_TOPICS) s.topics.forEach(t => push(s, t));
    else { const t = findTopic(s, r.topic); if (t) push(s, t); }
  }
  return out;
}

async function renderQuestionsRoute(r) {
  const host = $("screenInner");
  renderCrumb(r);

  const pairs = collectPairs(r);
  // An explicit ?view= is a decision already made (a shared link, a refresh, a
  // back-navigation) and is honoured without asking again. A URL that names a
  // folder but no view has no decision in it, so ask — exactly as a click does.
  if (!r.view) {
    if (!pairs.length) { host.innerHTML = ""; renderEmptyQuestions(host); setPaletteVisible(false); return; }
    askViewMode(function (mode) {
      navigateTo({ page: "questions", sub: r.sub, topic: r.topic, view: mode }, { replace: true });
    }, pairs.length, function () {
      // Cancelled with nowhere chosen: fall back to the parent folder rather
      // than leaving a blank screen behind.
      navigateTo(r.sub === ALL_SUBJECTS ? { page: "subjects" } : { page: "topics", sub: r.sub },
                 { replace: true });
    });
    host.innerHTML = "";
    return;
  }
  viewMode = (r.view === "focus") ? "focus" : "list";
  // renderRoute() asks for the deck BEFORE it knows which view this folder is
  // opening, so on a direct ?view=focus link the deck was still computed from
  // the previous screen's viewMode: body.saved-focus hid it with CSS while the
  // element kept hidden=false and body kept saved-deck-visible. Re-ask now that
  // viewMode is settled so the attribute, the body class and the CSS all agree
  // — which is what makes the dock reliably come BACK on the way out of focus.
  updateSavedModeDeck();

  // v45 — REPAINT PRESERVATION. When every question is already in memory this
  // is a repaint of the same folder (after delete / move / merge) — the screen
  // must keep its place: the removed question's successor slides into the same
  // spot in focus view, and the list keeps its scroll instead of jumping back
  // to question one. Captured BEFORE the host is cleared.
  const repaint = VIEW_QUESTIONS.length > 0 && !pairs.some(p => !QCACHE[p.quizKey + "|" + p.qid]);
  const keepTop = repaint && $("screenScroll") ? $("screenScroll").scrollTop : 0;
  const keepIdx = repaint ? focusIdx : 0;

  host.innerHTML = "";

  if (!pairs.length) { renderEmptyQuestions(host); setPaletteVisible(false); return; }

  const token = ++loadingToken;
  // When every question is already in memory — revisiting a folder, or
  // re-painting after a move / merge / delete — there is nothing to wait for,
  // so no skeleton is raised and the change lands instantly instead of
  // flashing an overlay over a screen that is already correct.
  const needsFetch = pairs.some(p => !QCACHE[p.quizKey + "|" + p.qid]);
  if (needsFetch) showQuestionSkeleton(host, pairs.length);
  let loaded;
  try {
    // v29: no progress callback at all. The old one drove a "37 / 240" counter
    // under the spinner; the skeleton IS the progress now.
    loaded = await loadQuestions(pairs);
  } catch (err) {
    console.error("saved: question load failed", err);
    if (token !== loadingToken) return;
    showFatal("Some questions could not be loaded. Check your connection and retry.",
              () => renderQuestionsRoute(r));
    return;
  }
  if (token !== loadingToken) return;          // the user navigated away mid-load
  hideLoader();

  VIEW_QUESTIONS = loaded;
  // Stay on the same slot: after a delete the successor question takes the
  // removed one's place (clamped when the LAST question was removed).
  focusIdx = repaint ? Math.min(keepIdx, Math.max(0, loaded.length - 1)) : 0;
  paintQuestions(host, r);
  // v48 — list view only: re-assert the captured position while the layout
  // settles (see restoreListScroll below). Focus view needs none of this —
  // it is one card, painted at the top by design.
  if (repaint && viewMode === "list") {
    const tok = token;
    restoreListScroll($("screenScroll"), keepTop,
                      () => tok !== loadingToken || viewMode !== "list");
  }
}

// v48 — LIST-VIEW SCROLL RESTORE THAT SURVIVES LAYOUT SETTLE.
// The single scrollTop write right after paintQuestions was not enough:
// freshly painted cards are still SHORT — dynamic images sit display:none
// until onload fires and MathJax has not typeset yet — so the browser CLAMPS
// the write to the shrunken scrollHeight and the list lands back on question
// one. (Focus view never showed this: one card, top by design.) The position
// is therefore re-asserted at a few beats over the next ~2s, growing content
// can no longer swallow it, and it stands down the instant the user touches
// the list (touch / wheel / pointerdown) or the screen changes underneath.
function restoreListScroll(sc, keepTop, isStale) {
  if (!sc || !(keepTop > 0)) return;
  let cancelled = false;
  const stop = function () { cancelled = true; };
  ["touchstart", "wheel", "pointerdown"].forEach(function (ev) {
    sc.addEventListener(ev, stop, { once: true, passive: true });
  });
  const restore = function () {
    if (cancelled || isStale()) return;
    if (sc.scrollTop !== keepTop) sc.scrollTop = keepTop;
  };
  restore();
  [80, 250, 600, 1100, 1800].forEach(function (t) { setTimeout(restore, t); });
}

// v29 — SKELETON LOADING for a folder of questions.
// Card-shaped shimmer in the same slot the cards will land in, so the screen
// keeps its shape while the reads run. The count is deliberately NOT shown:
// "Loading questions… 37 / 240" told the user nothing they could act on and
// made a slow folder feel slower than it was. Focus mode shows one card, list
// mode shows up to three (CSS hides the rest under body.saved-focus).
function questionSkeletonCard() {
  const c = document.createElement("div");
  c.className = "q-skeleton-card";
  c.setAttribute("aria-hidden", "true");
  c.innerHTML =
    '<div class="q-skeleton-head"><b></b><i></i><i></i></div>' +
    '<div class="q-skeleton-body">' +
      '<i></i><i></i><i></i>' +
      '<div class="q-skeleton-opts">' +
        '<div class="q-skeleton-opt"><b></b><span></span></div>' +
        '<div class="q-skeleton-opt"><b></b><span></span></div>' +
        '<div class="q-skeleton-opt"><b></b><span></span></div>' +
        '<div class="q-skeleton-opt"><b></b><span></span></div>' +
      '</div>' +
    '</div>';
  return c;
}

function showQuestionSkeleton(host, count) {
  host.innerHTML = "";
  document.body.classList.toggle("saved-focus", viewMode === "focus");
  document.body.classList.toggle("saved-list",  viewMode === "list");
  const wrap = document.createElement("div");
  wrap.className = "q-skeleton";
  wrap.setAttribute("role", "status");
  wrap.setAttribute("aria-label", "Loading saved questions");
  const n = viewMode === "focus" ? 1 : Math.min(3, Math.max(1, count || 1));
  for (let i = 0; i < n; i++) wrap.appendChild(questionSkeletonCard());
  host.appendChild(wrap);
}

function renderEmptyQuestions(host) {
  host.innerHTML = "";
  host.appendChild(emptyState("fa-folder-open", "This folder is empty", "Nothing is saved here yet."));
  window.__savedDecorate();
}

// ── reading the question bank ───────────────────────────────────────────────
// Reads are grouped per quiz: when four or more questions are needed from the
// same quiz it is cheaper to take the whole quiz node in one read than to make
// four separate ones. Below that, individual reads avoid dragging down
// questions the user never asked for. Concurrency is capped so a 300-question
// "All Subjects" folder does not fire 300 sockets at once.
const QUIZ_WHOLE_THRESHOLD = 4;
const MAX_PARALLEL = 8;

async function loadQuestions(pairs, onProgress) {
  const need = [];
  pairs.forEach(p => {
    const k = p.quizKey + "|" + p.qid;
    if (QCACHE[k]) return;
    need.push(p);
  });

  const byQuiz = {};
  need.forEach(p => { (byQuiz[p.quizKey] = byQuiz[p.quizKey] || []).push(p.qid); });

  const jobs = [];
  for (const quizKey in byQuiz) {
    const qids = byQuiz[quizKey];
    if (qids.length >= QUIZ_WHOLE_THRESHOLD) {
      jobs.push({ kind: "quiz", quizKey, qids });
    } else {
      qids.forEach(qid => jobs.push({ kind: "one", quizKey, qid }));
    }
  }

  let done = 0;
  const total = pairs.length;
  const tick = n => { done += n; if (onProgress) onProgress(Math.min(done, total), total); };
  // Already-cached questions count towards progress immediately.
  tick(pairs.length - need.length);

  let cursor = 0;
  async function worker() {
    while (cursor < jobs.length) {
      const job = jobs[cursor++];
      try {
        if (job.kind === "quiz") {
          const snap = await savedDb.ref("allQuestions/" + job.quizKey).once("value");
          const all = snap.val() || {};
          let hit = 0;
          job.qids.forEach(qid => {
            const q = all[qid];
            if (q && typeof q === "object") { QCACHE[job.quizKey + "|" + qid] = q; hit++; }
          });
          tick(hit);
        } else {
          const snap = await savedDb.ref("allQuestions/" + job.quizKey + "/" + job.qid).once("value");
          const q = snap.val();
          if (q && typeof q === "object") { QCACHE[job.quizKey + "|" + job.qid] = q; tick(1); }
        }
      } catch (err) {
        console.warn("saved: read failed", job, err);   // keep going; gaps are reported below
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(MAX_PARALLEL, jobs.length || 1) }, worker));

  // Preserve the tree order (alphabetical subject/topic, numeric question id)
  const out = [];
  const missing = [];
  pairs.forEach(p => {
    const q = QCACHE[p.quizKey + "|" + p.qid];
    if (q) out.push({ sub: p.sub, topic: p.topic, quizKey: p.quizKey, qid: p.qid, q });
    else missing.push(p);
  });
  if (missing.length) {
    console.warn("saved: %d question(s) have no content in allQuestions", missing.length);
    showToast(missing.length + " saved item" + (missing.length === 1 ? "" : "s") +
              " could not be opened (no stored content).");
  }
  return out;
}

// ══════════════════════════════════════════════════════════════════════════
//  PAINTING QUESTIONS
// ══════════════════════════════════════════════════════════════════════════
// q-render.css paints .opt.correct / .opt.wrong ONLY under body.mode-solution
// (both the light and the dark-theme rules), so any view that shows answers has
// to carry that class. test.html sets it in enterSolutionMode(); this is the
// same flag, set from the view state instead.
function syncSolutionBodyClass() {
  const revealing =
    VIEW_QUESTIONS.length > 0 &&
    (viewMode === "list" ||
     (viewMode === "focus" &&
      (!REATTEMPT_MODE || REVEALED[focusKey()] != null)));
  document.body.classList.toggle("mode-solution", !!revealing);
}
function focusKey() {
  const it = VIEW_QUESTIONS[focusIdx];
  return it ? it.quizKey + "|" + it.qid : "";
}

function paintQuestions(host, r) {
  host.innerHTML = "";
  document.body.classList.toggle("saved-focus", viewMode === "focus");
  document.body.classList.toggle("saved-list",  viewMode === "list");
  syncSolutionBodyClass();

  const wrap = document.createElement("div");
  wrap.className = "qview";
  const main = document.createElement("div");
  main.className = "qmain";
  wrap.appendChild(main);

  const palCol = document.createElement("div");
  palCol.className = "qpal-col";
  palCol.appendChild(buildPalettePanel());
  wrap.appendChild(palCol);
  host.appendChild(wrap);

  if (viewMode === "focus") paintFocus(main, r);
  else paintList(main, r);

  renderPalette();
  setPaletteVisible(true);
  renderMath();                                  // lifted from test.html
  window.__savedDecorate();
  maybeSavedGuide();                             // v45: first-run guide, once
}

// ── v45 — FIRST-RUN GUIDE ────────────────────────────────────────────────────
// New users only, shown once (localStorage mmhSavedGuideV1).
// v47 targeting: SMALL screens → a single step on the three-line hamburger
// ("More settings here — PDF, language and dark mode"). BIG screens → two
// steps one after another: the always-visible palette column ("jump to any
// question directly"), then the PDF/language/theme cluster. The ring is a
// pure box-shadow: the target NEVER moves, the bubble just floats near it.
// No dark overlay anywhere.
let guideRunning = false;
function sgVisible(el) {
  if (!el) return false;
  const cs = getComputedStyle(el);
  if (cs.display === "none" || cs.visibility === "hidden") return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 &&
         r.right > 0 && r.left < window.innerWidth &&
         r.bottom > 0 && r.top < window.innerHeight;   // off-screen sheets don't count
}
function maybeSavedGuide() {
  if (guideRunning) return;
  try { if (localStorage.getItem("mmhSavedGuideV1")) return; } catch (e) { return; }
  setTimeout(function () {
    try { if (localStorage.getItem("mmhSavedGuideV1")) return; } catch (e) {}
    if (guideRunning) return;
    // clean any stale bubble/ring from an earlier paint
    document.querySelectorAll(".sv-guide").forEach(b => b.remove());
    document.querySelectorAll(".sg-target").forEach(el => el.classList.remove("sg-target"));
    const steps = [];
    const SETTINGS = { en: "More settings here — PDF, language and dark mode.",
                       hi: "यहाँ और सेटिंग्स — PDF, भाषा और डार्क मोड।" };
    const burger = $("hdrMenuBtn");
    if (sgVisible(burger)) {
      // v47 — SMALL screens: guide ONLY the three-line toggle. One step.
      steps.push({ el: burger, en: SETTINGS.en, hi: SETTINGS.hi });
    } else {
      // Big screens: the palette column (bubble floats near it WITHOUT moving
      // it — the ring is a box-shadow, the element keeps its fixed position),
      // then the PDF/language/theme cluster.
      const palCol = document.querySelector(".palette-wrap");
      if (sgVisible(palCol)) steps.push({ el: palCol,
        en: "Use this palette to jump directly to any question.",
        hi: "किसी भी प्रश्न पर सीधे जाने के लिए इस पैलेट का इस्तेमाल करें।" });
      const actions = $("appbarActions");
      if (sgVisible(actions)) steps.push({ el: actions, en: SETTINGS.en, hi: SETTINGS.hi });
    }
    if (!steps.length) return;
    guideRunning = true;
    const bubble = document.createElement("div");
    bubble.className = "sv-guide";
    document.body.appendChild(bubble);
    let i = 0;
    function place() {
      document.querySelectorAll(".sg-target").forEach(el => el.classList.remove("sg-target"));
      const st = steps[i];
      st.el.classList.add("sg-target");
      const last = i === steps.length - 1;
      bubble.innerHTML = '<span class="sg-arrow"></span><div>' + st.en +
        '<span class="sg-hi">' + st.hi + "</span></div>" +
        '<button type="button" class="sg-btn">' + (last ? "Got it ✓" : "Next →") + "</button>";
      const r = st.el.getBoundingClientRect();
      const bw = bubble.offsetWidth, bh = bubble.offsetHeight;
      let top = r.bottom + 12;
      const left = Math.min(Math.max(8, r.left + r.width / 2 - bw / 2), window.innerWidth - bw - 8);
      const arrow = bubble.querySelector(".sg-arrow");
      if (top + bh > window.innerHeight - 8) { top = Math.max(8, r.top - bh - 12); arrow.classList.add("sg-down"); }
      bubble.style.top = top + "px";
      bubble.style.left = left + "px";
      arrow.style.left = Math.min(Math.max(14, r.left + r.width / 2 - left), bw - 26) + "px";
      bubble.querySelector(".sg-btn").onclick = function () {
        if (last) {
          try { localStorage.setItem("mmhSavedGuideV1", "1"); } catch (e) {}
          bubble.remove();
          st.el.classList.remove("sg-target");
          guideRunning = false;
        } else { i++; place(); }
      };
    }
    place();
  }, 450);
}

function cardOpts(item, index, total) {
  const base = {
    lang: currentLang,
    // The IMAGE path needs the RAW quiz id (?id= from the original test URL),
    // which travels inside the stored payload as quiz_id. The path key is only
    // sanitised for Firebase, so using it for images would 404 every picture.
    quizId: item.q.quiz_id || item.quizKey,
    index: index + 1,
    total: total
  };

  // ── LIST MODE — the solution is ALWAYS on screen under the question. ──────
  // No bulb button at all (allowSolution:false suppresses it), and the
  // explanation is built and opened eagerly. This is a revision page: hiding
  // 300 solutions behind 300 taps was the complaint.
  if (viewMode !== "focus") {
    return Object.assign(base, {
      mode: "solution",
      allowSolution: false,
      solutionOpen: true,
      showPercent: false,
      onPick: null
    });
  }

  // ── FOCUS MODE, Reattempt OFF — same as list: solution shown, options inert,
  //    correct/wrong marked. This is exams/test.html's Solution Mode branch
  //    (!isQuiz && !isPracticeToggle). ───────────────────────────────────────
  if (!REATTEMPT_MODE) {
    return Object.assign(base, {
      mode: "solution",
      allowSolution: false,
      solutionOpen: true,
      showPercent: false,
      onPick: null
    });
  }

  // ── FOCUS MODE, Reattempt ON ──────────────────────────────────────────────
  // Already picked  -> painted revealed: correct/wrong marked, solution open,
  //                    options inert.
  // Not picked yet  -> solution HIDDEN, options SELECTABLE; the first pick is
  //                    recorded and this card is repainted in the state above.
  // This is exams/test.html's isPracticeToggle branch (handlePracticeSelect ->
  // answers[q.id] -> renderQuestion), where the reveal is a re-render driven by
  // a recorded answer rather than an in-place DOM mutation.
  const key = item.quizKey + "|" + item.qid;
  const picked = REVEALED[key];
  if (picked != null) {
    return Object.assign(base, {
      mode: "browse",
      allowSolution: false,
      solutionOpen: true,
      revealedPick: picked,
      showPercent: false,
      onPick: null
    });
  }
  return Object.assign(base, {
    mode: "browse",
    allowSolution: false,
    solutionOpen: false,
    revealOnPick: true,
    showPercent: false,
    onPick: function (n) {
      REVEALED[key] = n;                 // only the first pick is ever stored
      paintFocusCard();
    }
  });
}

function paintList(host, r) {
  host.appendChild(sectionHeading(
    r.topic === ALL_TOPICS ? (r.sub === ALL_SUBJECTS ? "All Subjects" : "All Topics") : r.topic,
    plural(VIEW_QUESTIONS.length, "question") + " · " + viewLabel()));

  const list = document.createElement("div");
  list.className = "q-list";
  list.id = "qList";
  VIEW_QUESTIONS.forEach((item, i) => {
    const cell = document.createElement("div");
    cell.className = "q-cell";
    cell.id = "qcell-" + i;
    cell.appendChild(mmhRenderCard(item.q, cardOpts(item, i, VIEW_QUESTIONS.length)));
    list.appendChild(cell);
  });
  host.appendChild(list);
}

function paintFocus(host, r) {
  host.appendChild(sectionHeading(
    r.topic === ALL_TOPICS ? (r.sub === ALL_SUBJECTS ? "All Subjects" : "All Topics") : r.topic,
    plural(VIEW_QUESTIONS.length, "question") + " · " + viewLabel()));

  const stage = document.createElement("div");
  stage.className = "q-focus-stage";
  stage.id = "qFocusStage";
  host.appendChild(stage);
  // v29: the bar is the static #focusNav in the markup, fixed to the bottom of
  // the viewport. Appending it after the card (as before) made it travel with
  // the question and collide with the palette on wide screens.
  buildFocusNav();
  setFocusNavVisible(true);
  paintFocusCard();
}

function setFocusNavVisible(on) {
  const bar = $("focusNav");
  if (bar) bar.hidden = !on;
}

function paintFocusCard() {
  const stage = $("qFocusStage");
  if (!stage) return;
  const item = VIEW_QUESTIONS[focusIdx];
  stage.innerHTML = "";
  if (!item) { stage.appendChild(emptyState("fa-inbox", "Nothing here", "")); return; }
  syncSolutionBodyClass();
  stage.appendChild(mmhRenderCard(item.q, cardOpts(item, focusIdx, VIEW_QUESTIONS.length)));
  updateFocusNav();
  renderMath();
  // Every repaint of the focus card is a brand-new node, so the Delete / Move /
  // three-dot controls that saved-manage.js appends have to be re-attached each
  // time — otherwise PREV, NEXT and the Reattempt toggle all stripped them.
  window.__savedDecorate();
  const sc = $("screenScroll");
  if (sc) sc.scrollTop = 0;
}

function viewLabel() { return viewMode === "focus" ? "Focus view" : "List view"; }

// v29 — the focus bar: PREV at the left edge, NEXT at the right edge, and the
// Reattempt switch centred between them. The switch is exams/test.html's
// togglePracticeMode() control — same 42x24 track, same 20px knob travel, same
// #ccc -> #0b5ed7 — built as a real <button role="switch"> so it is focusable
// and announced, and driven by aria-checked instead of inline styles so the CSS
// and the state can never drift apart.
//
// OFF (default) -> solution shown, options inert           (study / solution mode)
// ON             -> solution hidden, options selectable, and picking one reveals
//                   correct/wrong + the explanation        (re-attempt the paper)
function buildFocusNav() {
  const bar = $("focusNav");
  if (!bar) return;
  bar.innerHTML =
    '<button type="button" class="focus-nav-btn" id="focusPrev"><i class="fa-solid fa-arrow-left"></i><span>PREV</span></button>' +
    '<button type="button" class="reattempt-toggle" id="reattemptToggle" role="switch" aria-checked="' +
      (REATTEMPT_MODE ? "true" : "false") + '" ' +
      'title="Reattempt Mode: hide the solution and make the options selectable">' +
      '<span class="reattempt-label">Reattempt</span>' +
      '<span class="reattempt-track"><span class="reattempt-knob"></span></span>' +
    '</button>' +
    '<button type="button" class="focus-nav-btn" id="focusNext"><span>NEXT</span><i class="fa-solid fa-arrow-right"></i></button>';

  bar.querySelector("#focusPrev").onclick = () => navFocus(-1);
  bar.querySelector("#focusNext").onclick = () => navFocus(1);

  const toggle = bar.querySelector("#reattemptToggle");
  toggle.onclick = () => {
    REATTEMPT_MODE = !REATTEMPT_MODE;
    toggle.setAttribute("aria-checked", REATTEMPT_MODE ? "true" : "false");
    try { localStorage.setItem("mmh_saved_reattempt", REATTEMPT_MODE ? "1" : "0"); } catch (e) {}
    // The position is preserved: flipping the switch re-renders the SAME
    // question in the other mode, exactly like test.html's renderQuestion(current).
    paintFocusCard();
  };
}

// Reflect the persisted flag on the switch whenever a card is repainted, so a
// value restored from localStorage can never disagree with what is displayed.
function syncReattemptToggle() {
  const t = $("reattemptToggle");
  if (t) t.setAttribute("aria-checked", REATTEMPT_MODE ? "true" : "false");
}

function navFocus(d) {
  const n = VIEW_QUESTIONS.length;
  if (!n) return;
  const next = focusIdx + d;
  if (next < 0 || next >= n) return;
  focusIdx = next;
  paintFocusCard();
  renderPalette();
}

function updateFocusNav() {
  // The bar is PREV · Reattempt · NEXT only, so the "3 / 40" readout moved into
  // the NEXT button's own title — it is the one place that stays legible on a
  // phone without adding a fourth element to a three-slot bar.
  const p = $("focusPrev"), n = $("focusNext");
  if (p) p.disabled = focusIdx <= 0;
  if (n) {
    n.disabled = focusIdx >= VIEW_QUESTIONS.length - 1;
    n.title = (focusIdx + 1) + " of " + VIEW_QUESTIONS.length;
  }
  syncReattemptToggle();
}

function jumpTo(i) {
  if (i < 0 || i >= VIEW_QUESTIONS.length) return;
  closePaletteSheet();
  if (viewMode === "focus") { focusIdx = i; paintFocusCard(); renderPalette(); return; }
  const cell = $("qcell-" + i);
  if (cell) {
    cell.scrollIntoView({ behavior: "smooth", block: "start" });
    cell.classList.add("q-cell-flash");
    setTimeout(() => cell.classList.remove("q-cell-flash"), 1200);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  PALETTE  —  a real column on desktop, a slide-over sheet on mobile
// ══════════════════════════════════════════════════════════════════════════
function buildPalettePanel() {
  const p = $("paletteWrap");
  if (p) return p;                                  // reuse the single instance
  const wrap = document.createElement("div");
  wrap.className = "palette-wrap";
  wrap.id = "paletteWrap";
  wrap.innerHTML =
    '<div class="pal-head">' +
      '<span class="pal-title">Questions</span>' +
      '<button type="button" class="icon-circle-btn pal-close" id="palClose" aria-label="Close palette">' +
        '<i class="fa-solid fa-times"></i></button>' +
    '</div>' +
    '<div class="pal-user" id="palUsername"></div>' +
    '<div class="palette-grid" id="paletteGrid"></div>' +
    '<div class="pal-legend"><span><i class="lg-dot lg-seen"></i>Viewed</span>' +
      '<span><i class="lg-dot lg-now"></i>Current</span></div>';
  wrap.querySelector("#palClose").onclick = closePaletteSheet;
  const u = wrap.querySelector("#palUsername");
  if (u) u.textContent = USER_EMAIL_KEY;
  return wrap;
}

let SEEN = {};
function renderPalette() {
  const grid = $("paletteGrid");
  if (!grid) return;
  grid.innerHTML = "";
  VIEW_QUESTIONS.forEach((item, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "qbtn" + (SEEN[i] ? " seen" : "") + (i === focusIdx ? " current" : "");
    b.textContent = String(i + 1);
    b.onclick = () => jumpTo(i);
    grid.appendChild(b);
  });
  if (viewMode === "list") markSeenFromScroll();
}

function setPaletteVisible(on) {
  document.body.classList.toggle("palette-on", !!on);
  const fab = $("paletteFab");
  if (fab) fab.style.display = on ? "" : "none";
  if (!on) closePaletteSheet();
}

// Any open .sv-modal owns the screen, so the palette FAB must not float on top
// of it — which is what it was doing over the Attempt test and PDF sheets.
// Watching the style attribute catches every opener in every module (attempt,
// PDF, manage, language, view-mode, confirm, transfer) without each one having
// to remember to announce itself, including any added later.
function watchModalsForFab() {
  const sync = () => {
    const open = Array.prototype.some.call(
      document.querySelectorAll(".sv-modal"), m => m.style.display === "flex");
    document.body.classList.toggle("modal-open", open);
  };
  const mo = new MutationObserver(sync);
  document.querySelectorAll(".sv-modal").forEach(m =>
    mo.observe(m, { attributes: true, attributeFilter: ["style", "class"] }));
  sync();
}

function togglePaletteSheet() {
  const open = document.body.classList.contains("palette-open");
  open ? closePaletteSheet() : openPaletteSheet();
}
// The palette's desktop/mobile split. ONE constant, because saved.css keys the
// fixed-column layout off min-width:992px and this used to say 1024 — which
// left 992..1023px in a state where CSS had already turned the palette into a
// permanent column but the sheet logic still thought it was a phone, so the FAB
// was a button that did nothing.
const PALETTE_DESKTOP = 992;
function openPaletteSheet() {
  if (window.innerWidth >= PALETTE_DESKTOP) return;  // desktop: always a column
  document.body.classList.add("palette-open");
  const bd = $("paletteBackdrop");
  if (bd) bd.style.display = "block";
}
function closePaletteSheet() {
  document.body.classList.remove("palette-open");
  const bd = $("paletteBackdrop");
  if (bd) bd.style.display = "none";
}

// In list view every card is on screen, so "viewed" follows the scroll.
let scrollRaf = 0;
function markSeenFromScroll() {
  if (scrollRaf) return;
  scrollRaf = requestAnimationFrame(() => {
    scrollRaf = 0;
    const mid = window.innerHeight * 0.55;
    VIEW_QUESTIONS.forEach((_, i) => {
      const cell = $("qcell-" + i);
      if (!cell) return;
      const r = cell.getBoundingClientRect();
      if (r.top < mid && r.bottom > 60) {
        if (!SEEN[i]) { SEEN[i] = true; }
      }
    });
    const grid = $("paletteGrid");
    if (grid) grid.querySelectorAll(".qbtn").forEach((b, i) => {
      b.classList.toggle("seen", !!SEEN[i]);
    });
  });
}

// ══════════════════════════════════════════════════════════════════════════
//  VIEW-MODE MODAL  (asked every time a folder is opened)
// ══════════════════════════════════════════════════════════════════════════
let viewModeCb = null;
let viewModeCancel = null;
function askViewMode(cb, count, onCancel) {
  viewModeCb = cb;
  viewModeCancel = onCancel || null;
  const m = $("viewModeModal");
  $("vmCount").textContent = plural(count, "question") + " in this folder";
  m.style.display = "flex";
  m.classList.remove("vm-in");
  requestAnimationFrame(() => m.classList.add("vm-in"));
}
function chooseViewMode(mode) {
  const m = $("viewModeModal");
  m.style.display = "none";
  const cb = viewModeCb; viewModeCb = null; viewModeCancel = null;
  if (cb) cb(mode);
}
function cancelViewMode() {
  const m = $("viewModeModal");
  m.style.display = "none";
  const cb = viewModeCancel;
  viewModeCb = null; viewModeCancel = null;
  // From a folder click there is simply nothing to open. From a URL with no
  // view chosen, the caller supplied a way back so the screen is never blank.
  if (cb) cb();
}

// ══════════════════════════════════════════════════════════════════════════
//  LANGUAGE
// ══════════════════════════════════════════════════════════════════════════
function changeGlobalLang(v) {
  currentLang = (v === "hi" || v === "bilingual") ? v : "en";
  try { localStorage.setItem("quiz_lang", currentLang); } catch (e) {}
  paintLangState();
  closeLangModal();
  // Re-render in place: the questions are already in memory, so this is free.
  const r = parseRoute();
  if (r.page === "questions" && VIEW_QUESTIONS.length) {
    const host = $("screenInner");
    paintQuestions(host, r);
  }
}

// ── v29: the language CARD ─────────────────────────────────────────────────
// v45: the modal now serves the small-screen hamburger only — the desktop
// entry point is the header <select> toggle (current language visible at a
// glance, one click to change, no dialog).
const LANG_GLYPH = { en: "A", hi: "\u0905", bilingual: "A/\u0905" };

function paintLangState() {
  const sel = $("langSelect");                       // v45: desktop select toggle
  if (sel) {
    sel.value = currentLang;
    sel.title = "Language: " + (currentLang === "hi" ? "Hindi"
              : currentLang === "bilingual" ? "English + Hindi" : "English");
    sel.setAttribute("aria-label", sel.title);
  }
  const row = $("hdrMenuLang");
  if (row) {
    const label = currentLang === "hi" ? "Hindi"
                : currentLang === "bilingual" ? "English + Hindi" : "English";
    row.querySelector("span").textContent = "Language: " + label;
  }
  document.querySelectorAll("#langChoices .lang-choice").forEach(function (b) {
    b.classList.toggle("is-on", b.getAttribute("data-lang") === currentLang);
  });
}

function openLangModal() {
  const m = $("langModal");
  if (!m) return;
  paintLangState();
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
}
function closeLangModal() {
  const m = $("langModal");
  if (m) { m.style.display = "none"; m.classList.remove("sv-in"); }
}

// ── v29: the small-screen hamburger ────────────────────────────────────────
// One control carrying all three actions the desktop bar shows separately.
// Mirrors login.html's toggleHamburgerMenu() pattern, but the entries are wired
// as real listeners rather than inline onclick so they are testable, and the
// PDF entry tracks saved-pdf.js's own hidden/disabled state.
function toggleHdrMenu(force) {
  const dd = $("hdrMenu"), btn = $("hdrMenuBtn");
  if (!dd || !btn) return;
  const open = force == null ? !dd.classList.contains("open") : !!force;
  dd.classList.toggle("open", open);
  btn.setAttribute("aria-expanded", open ? "true" : "false");
  if (open) syncHdrMenuState();
}
function syncHdrMenuState() {
  const pdf = $("pdfBtn"), item = $("hdrMenuPdf");
  if (pdf && item) {
    // The header button is the source of truth for "is there anything to
    // export"; the menu entry must never offer a dead action.
    item.disabled = pdf.hidden || pdf.disabled;
  }
  const theme = $("hdrMenuTheme");
  if (theme) {
    const dark = document.body.classList.contains("dark-mode");
    theme.querySelector("span").textContent = dark ? "Light mode" : "Dark mode";
    theme.setAttribute("aria-pressed", dark ? "true" : "false");
  }
  paintLangState();
}

// ══════════════════════════════════════════════════════════════════════════
//  LOADER / FATAL / TOAST
// ══════════════════════════════════════════════════════════════════════════
function showLoader(msg, done, total) {
  const l = $("loader");
  if (!l) return;
  l.style.display = "flex";
  $("loaderText").textContent = msg || "Loading…";
  const bar = $("loaderBar");
  const pct = $("loaderPct");
  if (typeof done === "number" && typeof total === "number" && total > 0) {
    const p = Math.round(done * 100 / total);
    bar.style.display = "block";
    bar.firstElementChild.style.width = p + "%";
    pct.textContent = done + " / " + total;
  } else {
    bar.style.display = "none";
    pct.textContent = "";
  }
}
function hideLoader() { const l = $("loader"); if (l) l.style.display = "none"; }

let fatalRetry = null;
function showFatal(msg, retry) {
  hideLoader();
  fatalRetry = retry || null;
  const f = $("fatalBox");
  if (!f) return;
  $("fatalMsg").textContent = msg;
  $("fatalRetry").style.display = fatalRetry ? "" : "none";
  f.style.display = "flex";
}
function hideFatal() { const f = $("fatalBox"); if (f) f.style.display = "none"; }
function doFatalRetry() { hideFatal(); if (fatalRetry) fatalRetry(); }

let toastTimer = 0;
function showToast(msg) {
  let t = $("mmhToast");
  if (!t) {
    t = document.createElement("div");
    t.id = "mmhToast";
    t.className = "mmh-toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
}

// ══════════════════════════════════════════════════════════════════════════
//  TREE SURGERY
//  Every mutation hits Firebase FIRST and this in-memory tree SECOND, so the
//  screen is correct the instant the write resolves — no re-read, no flicker,
//  and no chance of showing something the database does not agree with.
//  Empty parents are pruned here exactly as Firebase prunes them on the server.
// ══════════════════════════════════════════════════════════════════════════
function treeSubject(name) { return TREE ? TREE.subjects.find(s => s.name === name) : null; }

function treeAddQuestion(subKey, topKey, quizKey, qid) {
  if (!TREE) return;
  let s = treeSubject(subKey);
  if (!s) { s = { name: subKey, topics: [], topicCount: 0, count: 0 }; TREE.subjects.push(s); }
  let t = s.topics.find(x => x.name === topKey);
  if (!t) { t = { name: topKey, quizMap: {}, count: 0 }; s.topics.push(t); }
  if (!t.quizMap[quizKey]) t.quizMap[quizKey] = [];
  if (t.quizMap[quizKey].indexOf(qid) < 0) t.quizMap[quizKey].push(qid);
}

function treeRemoveQuestion(subKey, topKey, quizKey, qid) {
  const s = treeSubject(subKey);
  if (!s) return;
  const t = s.topics.find(x => x.name === topKey);
  if (!t || !t.quizMap[quizKey]) return;
  t.quizMap[quizKey] = t.quizMap[quizKey].filter(x => x !== qid);
  if (!t.quizMap[quizKey].length) delete t.quizMap[quizKey];
}

// Drop empty quizzes, topics and subjects, recompute every count, re-sort.
function treeRecount() {
  if (!TREE) return;
  TREE.subjects.forEach(s => {
    s.topics.forEach(t => {
      Object.keys(t.quizMap).forEach(qk => {
        t.quizMap[qk] = t.quizMap[qk].filter(Boolean);
        t.quizMap[qk].sort(compareQuestionIds);
        if (!t.quizMap[qk].length) delete t.quizMap[qk];
      });
      t.count = Object.keys(t.quizMap).reduce((a, k) => a + t.quizMap[k].length, 0);
    });
    s.topics = s.topics.filter(t => t.count > 0);
    s.topics.sort((a, b) => a.name.localeCompare(b.name));
    s.topicCount = s.topics.length;
    s.count = s.topics.reduce((a, t) => a + t.count, 0);
  });
  TREE.subjects = TREE.subjects.filter(s => s.count > 0);
  TREE.subjects.sort((a, b) => a.name.localeCompare(b.name));
}

// Everything a folder holds, as {sub, topic, quizKey, qid} tuples.
function treeItems(spec) {
  const out = [];
  const take = (s, t) => Object.keys(t.quizMap).forEach(qk =>
    t.quizMap[qk].forEach(qid => out.push({ sub: s.name, topic: t.name, quizKey: qk, qid: qid })));
  if (spec.sub === ALL_SUBJECTS) {
    (TREE ? TREE.subjects : []).forEach(s => s.topics.forEach(t => take(s, t)));
  } else {
    const s = treeSubject(spec.sub);
    if (!s) return out;
    if (spec.topic === ALL_TOPICS) s.topics.forEach(t => take(s, t));
    else { const t = s.topics.find(x => x.name === spec.topic); if (t) take(s, t); }
  }
  return out;
}

// ── the API the management module (js/saved-manage.js) drives ──────────────
// Exposed deliberately rather than reached for through globals, so the two files
// have a contract instead of an accident.
window.SavedCore = {
  get tree()      { return TREE; },
  get user()      { return USER_KEY; },
  get username()  { return USER_EMAIL_KEY; },
  get route()     { return parseRoute(); },
  get questions() { return VIEW_QUESTIONS; },
  get viewMode()  { return viewMode; },
  get lang()      { return currentLang; },
  ALL_SUBJECTS: ALL_SUBJECTS,
  ALL_TOPICS:   ALL_TOPICS,
  // The live database handle. Mutations live in saved-manage.js, so the handle
  // travels through the contract rather than being fished off window.
  get db()      { return savedDb; },
  fbKey:       raw => fbKeyLocal(raw),
  badKeyChars: raw => ".#$[]/".split("").filter(ch => String(raw == null ? "" : raw).indexOf(ch) >= 0),
  subjectNames: () => (TREE ? TREE.subjects.map(s => s.name) : []),
  topicNames:   sub => { const s = treeSubject(sub); return s ? s.topics.map(t => t.name) : []; },
  treeItems, treeAddQuestion, treeRemoveQuestion, treeRecount, collectPairs,
  // Stage 3 exports the batched question loader and the progress UI so the PDF
  // builder can fetch a whole subject (or the whole library) with the same
  // per-quiz batching, the same parallelism cap and the same progress bar the
  // topic view already uses — rather than growing a second loader.
  loadQuestions, showLoader, hideLoader,
  rerender:   () => { const r = parseRoute(); renderRoute(r, true); return r; },
  navigateTo,
  toast:      showToast,
  typeset:    () => { if (typeof renderMath === "function") renderMath(); }
};

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initSavedPage() {
  const sc = $("screenScroll");
  if (sc) sc.addEventListener("scroll", function () {
    if (viewMode === "list" && document.body.classList.contains("palette-on")) markSeenFromScroll();
  }, { passive: true });

  // Swipe between questions in focus mode — same feel as the test page.
  let sx = 0, sy = 0;
  const stageHost = $("screenScroll");
  if (stageHost) {
    stageHost.addEventListener("touchstart", e => {
      if (viewMode !== "focus") return;
      sx = e.touches[0].clientX; sy = e.touches[0].clientY;
    }, { passive: true });
    stageHost.addEventListener("touchend", e => {
      if (viewMode !== "focus") return;
      const dx = e.changedTouches[0].clientX - sx;
      const dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.6) navFocus(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  // 992px, not 1024px: that is the breakpoint at which css/saved.css turns the
  // palette into the fixed desktop column, so the sheet state has to be dropped
  // at the same width or a 1000px window keeps a slide-over that no longer has
  // a FAB to close it.
  window.addEventListener("resize", function () {
    if (window.innerWidth >= PALETTE_DESKTOP) closePaletteSheet();
  });

  // ── v29 header controls ───────────────────────────────────────────────────
  const langSel = $("langSelect");                   // v45: select toggle, no modal
  if (langSel) langSel.onchange = function () { changeGlobalLang(langSel.value); };

  const menuBtn = $("hdrMenuBtn");
  if (menuBtn) menuBtn.onclick = ev => { ev.stopPropagation(); toggleHdrMenu(); };

  const menuPdf = $("hdrMenuPdf");
  if (menuPdf) menuPdf.onclick = () => {
    toggleHdrMenu(false);
    const pdf = $("pdfBtn");
    if (pdf && !pdf.disabled) pdf.click();     // reuse saved-pdf.js's own path
  };
  const menuLang = $("hdrMenuLang");
  if (menuLang) menuLang.onclick = () => { toggleHdrMenu(false); openLangModal(); };
  const menuTheme = $("hdrMenuTheme");
  if (menuTheme) menuTheme.onclick = () => {
    // app-core.js owns the theme and binds .theme-btn itself; clicking the real
    // button keeps one source of truth instead of a second toggle path.
    const t = $("darkModeToggle");
    if (t) t.click();
    syncHdrMenuState();
  };

  // language card: choice rows, ✕, backdrop, and an outside tap on the hamburger
  document.querySelectorAll("#langChoices .lang-choice").forEach(function (b) {
    b.onclick = () => changeGlobalLang(b.getAttribute("data-lang"));
  });
  const langModal = $("langModal");
  if (langModal) {
    const lx = langModal.querySelector(".sv-x");
    if (lx) lx.onclick = closeLangModal;
    langModal.addEventListener("click", ev => { if (ev.target === langModal) closeLangModal(); });
  }
  document.addEventListener("click", function (ev) {
    const wrap = $("hdrMenuWrap");
    if (wrap && !wrap.contains(ev.target)) toggleHdrMenu(false);
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key !== "Escape") return;
    if ($("langModal") && $("langModal").style.display === "flex") { closeLangModal(); return; }
    toggleHdrMenu(false);
  });

  watchModalsForFab();

  // The theme button is created/bound by app-core.js, which loads AFTER this
  // file; re-sync the hamburger's label once the theme has actually been applied.
  setTimeout(syncHdrMenuState, 0);
  window.addEventListener("load", syncHdrMenuState);

  bootSaved();
}

// The scripts sit at the end of <body>, so depending on caching the document
// may already be past "loading" by the time this runs — a bare DOMContentLoaded
// listener would then never fire and the page would never boot at all.
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initSavedPage);
else initSavedPage();

// Exposed for inline handlers in the markup.
Object.assign(window, {
  savedBack, navigateTo, openQuestions, chooseViewMode, cancelViewMode, changeGlobalLang,
  savedNormalMode, savedTestMode, updateSavedModeDeck,
  togglePaletteSheet, closePaletteSheet, openPaletteSheet, jumpTo, navFocus,
  doFatalRetry, showToast,
  // v29 header + focus bar
  openLangModal, closeLangModal, paintLangState, toggleHdrMenu, syncHdrMenuState,
  buildFocusNav, setFocusNavVisible, syncReattemptToggle, showQuestionSkeleton,
  savedLang: () => currentLang,
  savedReattempt: () => REATTEMPT_MODE
});

// Called after every screen is painted so the management module can attach its
// three-dot menus, selection controls and per-card hooks. Late-bound on purpose:
// saved.js carries no load-time dependency on saved-manage.js.
window.__savedDecorate = window.__savedDecorate || function () {};

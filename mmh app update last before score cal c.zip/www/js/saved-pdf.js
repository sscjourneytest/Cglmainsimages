// ══════════════════════════════════════════════════════════════════════════
//  saved-pdf.js — Saved Questions → PDF Studio handoff
//
//  Flow:
//    1. User taps the PDF button → a modal offers the contextual scopes
//       (this topic / this subject / whole library) with live question counts.
//    2. Hard ceiling: MAX_PDF_QUESTIONS per render. Bigger scopes are blocked
//       in the modal with a "print subject-wise / topic-wise" message.
//    3. On "Generate PDF" the selected questions are loaded and grouped into
//       the JSON tree the standalone PDF studio consumes:
//           { SUBJECT: { TOPIC: [question, …] } }
//       Subject and topic come from the LIBRARY TREE (where the question is
//       saved) — never from fields inside the question JSON. Every question
//       object keeps its own quiz_id + id, so the studio can build exam tags
//       and resolve dynamic images itself.
//    4. The tree is handed over through sessionStorage under a one-time key
//       (sessionStorage ONLY — the JSON is never cached in localStorage or
//       anywhere else), and the page navigates to the studio (print.html).
//
//  No HTML is built here and nothing is copied from the list view: the studio
//  renders everything itself — the same way test.html feeds its own questions.
//  Exporting a PDF never writes to the database.
// ══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const C = () => window.SavedCore;
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const HANDOFF_KEY = "mmh-saved-pdf-handoff";   // one-time sessionStorage key
const PRINT_PAGE  = "print.html";              // the PDF studio, relative to /saved/
// One render, hard ceiling: the PDF studio renders at most this many questions
// at once. Wider scopes must be printed subject-wise / topic-wise.
const MAX_PDF_QUESTIONS = 500;

let busy = false;
let chosen = null;                             // the scope id the user picked

// ══════════════════════════════════════════════════════════════════════════
//  SCOPE — what "contextual" means
//  The button exports what you are looking at, and the modal offers the wider
//  scopes that contain it. Printing from a topic keeps that topic's subject
//  as the tree's subject key — the tree knows where the folder lives.
// ══════════════════════════════════════════════════════════════════════════
function countFor(spec) {
  const items = C().treeItems(spec);
  const subs = new Set(), tops = new Set();
  items.forEach(i => { subs.add(i.sub); tops.add(i.sub + "\u0000" + i.topic); });
  return { questions: items.length, subjects: subs.size, topics: tops.size };
}

function scopesFor(route) {
  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const out = [];
  const onQuestions = route.page === "questions";
  const realSub = onQuestions && route.sub !== AS ? route.sub : (route.page === "topics" ? route.sub : null);
  const realTop = onQuestions && route.topic !== AT ? route.topic : null;

  if (realSub && realTop) {
    out.push({ id: "topic", name: realTop, sub: realSub,
               label: realTop, hint: "This folder only",
               spec: { sub: realSub, topic: realTop } });
  }
  if (realSub) {
    out.push({ id: "subject", name: realSub, sub: realSub,
               label: realSub, hint: realTop ? "The whole subject this folder is in" : "This subject",
               spec: { sub: realSub, topic: AT } });
  }
  out.push({ id: "library", name: null, sub: null,
             label: "Whole library", hint: "Every subject and folder you have saved",
             spec: { sub: AS, topic: AT } });

  // A scope with nothing in it is not a choice, it is a dead button.
  return out.map(s => Object.assign(s, countFor(s.spec))).filter(s => s.questions > 0);
}

function scopeTitle(s) {
  if (s.id === "topic") return s.sub + " \u2192 " + s.name;
  if (s.id === "subject") return s.name;
  return "Whole library";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE BUTTON
// ══════════════════════════════════════════════════════════════════════════
function refreshPdfButton() {
  const btn = $("pdfBtn");
  if (!btn) return;
  const core = C();
  if (!core) { btn.hidden = true; return; }
  const ready = !!core.tree && countFor({ sub: core.ALL_SUBJECTS, topic: core.ALL_TOPICS }).questions > 0;
  btn.hidden = !ready;
  const scopes = ready ? scopesFor(core.route) : [];
  btn.disabled = scopes.length === 0;
  btn.title = scopes.length ? "Generate PDF — " + scopeTitle(scopes[0]) : "Nothing to save yet";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE MODAL
// ══════════════════════════════════════════════════════════════════════════
function openPdfModal() {
  if (busy) return;
  const core = C();
  const scopes = scopesFor(core.route);
  if (!scopes.length) { core.toast("There is nothing to save as a PDF yet."); return; }

  const host = $("pdfScopes");
  host.innerHTML = "";
  scopes.forEach((s, i) => {
    const lab = document.createElement("label");
    lab.className = "pdf-scope" + (i === 0 ? " is-checked" : "");
    lab.innerHTML =
      '<input type="radio" name="pdfScope" value="' + esc(s.id) + '"' + (i === 0 ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid ' +
          (s.id === "topic" ? "fa-folder-open" : s.id === "subject" ? "fa-folder-tree" : "fa-book-bookmark") +
          '"></i>' + esc(s.label) + '</span>' +
        '<span class="pdf-scope-hint">' + esc(s.hint) + '</span>' +
      '</span>' +
      '<span class="pdf-scope-count">' + s.questions + '</span>';
    host.appendChild(lab);
  });
  chosen = scopes[0].id;

  // Language defaults to whatever the page is showing, so the PDF matches what
  // the user was just reading rather than silently reverting to English.
  const lang = $("pdfLang");
  lang.value = core.lang || "en";
  $("pdfSolutions").checked = true;

  paintSummary();
  const m = $("pdfModal");
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
  $("pdfGo").disabled = false;
}

function closePdfModal() { if (!busy) $("pdfModal").style.display = "none"; }

function currentScopes() { return scopesFor(C().route); }
function chosenScope() {
  const list = currentScopes();
  return list.find(s => s.id === chosen) || list[0];
}

function paintSummary() {
  const s = chosenScope();
  if (!s) return;
  const parts = [];
  if (s.subjects > 1 || s.id === "library") parts.push(s.subjects + (s.subjects === 1 ? " subject" : " subjects"));
  parts.push(s.topics + (s.topics === 1 ? " folder" : " folders"));
  parts.push(s.questions + (s.questions === 1 ? " question" : " questions"));
  $("pdfSummary").textContent = parts.join(" · ");
  const list = currentScopes();
  $("pdfScopeLine").textContent = list.length ? scopeTitle(list[0]) : "—";
  const warn = $("pdfBigWarn");
  warn.hidden = s.questions < 120;
  if (!warn.hidden) warn.querySelector("b").textContent = String(s.questions);

  // 500-question ceiling: block the Generate button and say why, in the modal.
  const over = s.questions > MAX_PDF_QUESTIONS;
  const go = $("pdfGo");
  if (go) go.disabled = over;
  let cap = $("pdfCapWarn");
  if (!cap) {
    cap = document.createElement("div");
    cap.id = "pdfCapWarn";
    cap.style.cssText = "margin:10px 2px 0;padding:10px 12px;border:1px solid #f3c1c1;background:#fdecec;border-radius:10px;color:#a11c1c;font-size:12.5px;font-weight:700;line-height:1.5";
    warn.parentNode.insertBefore(cap, warn.nextSibling);
  }
  cap.hidden = !over;
  if (over) cap.innerHTML = "Questions are more than " + MAX_PDF_QUESTIONS + " (" + s.questions +
    ") — they can not be rendered at once. Please print a <b>subject-wise</b> or <b>topic-wise</b> PDF.";
}

// ══════════════════════════════════════════════════════════════════════════
//  BUILD — generate the JSON tree, hand it over, open the studio
// ══════════════════════════════════════════════════════════════════════════
async function buildPdf() {
  if (busy) return;
  const core = C();
  const scope = chosenScope();
  if (!scope) return;
  if (scope.questions > MAX_PDF_QUESTIONS) {
    C().toast("More than " + MAX_PDF_QUESTIONS + " questions can not be rendered at once — print subject-wise or topic-wise.");
    return;
  }

  const lang = $("pdfLang").value || "en";
  const withSolutions = $("pdfSolutions").checked;

  busy = true;
  closePdfModalForce();
  const items = core.treeItems(scope.spec);
  const pairs = items.map(i => ({ quizKey: i.quizKey, qid: i.qid }));

  core.showLoader("Preparing your PDF…", 0, pairs.length);
  let loaded;
  try {
    loaded = await core.loadQuestions(pairs, (done, total) =>
      core.showLoader("Preparing your PDF…", done, total));
  } catch (err) {
    console.error("saved-pdf: load failed", err);
    core.hideLoader(); busy = false;
    core.toast("Could not load the questions. Check your connection and try again.");
    return;
  }

  // loadQuestions swallows per-read errors and returns what it got, so an
  // empty result across a whole scope is a connection failure, not missing
  // data. A partial result is fine and proceeds.
  if (!loaded || !loaded.length) {
    core.hideLoader(); busy = false;
    core.toast("Could not load those questions. Check your connection and try again.");
    return;
  }

  try {
    const byKey = new Map();
    loaded.forEach(l => byKey.set(l.quizKey + "|" + l.qid, l.q));
    const model = groupItems(items, byKey);
    if (!model.length) {
      core.hideLoader(); busy = false;
      core.toast("None of those questions have content stored yet.");
      return;
    }
    core.showLoader("Opening the PDF studio…", pairs.length, pairs.length);

    // JSON tree { SUBJECT: { TOPIC: [question,…] } } — the exact shape the
    // standalone PDF studio requires. Subject/topic come from the library
    // tree (so a topic printed on its own still carries its subject); each
    // question object travels untouched with its own quiz_id + id intact,
    // which is what the studio's exam-tag + dynamic-image engines read.
    const tree = {};
    let topicCount = 0, qCount = 0;
    model.forEach(s => {
      tree[s.name] = tree[s.name] || {};
      s.topics.forEach(t => {
        tree[s.name][t.name] = t.questions.map(i => i.q);
        topicCount++; qCount += t.questions.length;
      });
    });
    const payload = {
      v: 2,
      tree: tree,
      meta: {
        scope: scopeTitle(scope),
        title: "Saved Questions — " + scopeTitle(scope),
        lang: lang,
        withSolutions: withSolutions,
        username: core.username || "",
        generated: new Date().toISOString(),
        totals: { subjects: model.length, topics: topicCount, questions: qCount }
      }
    };

    if (!handoff(payload)) return;             // handoff reports its own error
    window.location.href = PRINT_PAGE;
  } catch (err) {
    console.error("saved-pdf: build failed", err);
    core.toast("Could not build the PDF. Please try again.");
  } finally {
    core.hideLoader();
    busy = false;
  }
}

function closePdfModalForce() {
  const m = $("pdfModal");
  if (m) { m.style.display = "none"; m.classList.remove("sv-in"); }
}

// treeItems() yields the tree's own order — alphabetical subject, alphabetical
// folder, then numeric question id — so grouping is a single pass over
// consecutive runs. Nothing is re-sorted and nothing is assumed.
function groupItems(items, byKey) {
  const subjects = [];
  let curS = null, curT = null;
  items.forEach(it => {
    const q = byKey.get(it.quizKey + "|" + it.qid);
    if (!q || typeof q !== "object") return;   // gaps were already reported
    if (!curS || curS.name !== it.sub) { curS = { name: it.sub, topics: [] }; subjects.push(curS); curT = null; }
    if (!curT || curT.name !== it.topic) { curT = { name: it.topic, questions: [] }; curS.topics.push(curT); }
    curT.questions.push({ q: q, quizKey: it.quizKey, qid: it.qid });
  });
  return subjects;
}

// One-time handoff — sessionStorage ONLY, per spec: the JSON tree is never
// written to localStorage, IndexedDB or any other persistent cache. The
// studio consumes and deletes the key the moment it opens.
function handoff(payload) {
  try {
    sessionStorage.setItem(HANDOFF_KEY, JSON.stringify(payload));
    return true;
  } catch (err) {
    console.error("saved-pdf: sessionStorage handoff failed", err);
    C().toast("This browser could not hold the document temporarily. Please choose a smaller scope (topic-wise) and try again.");
    return false;
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initPdf() {
  const btn = $("pdfBtn");
  if (btn) { btn.onclick = openPdfModal; btn.hidden = true; }

  const m = $("pdfModal");
  if (!m) return;
  m.querySelector(".sv-x").onclick = closePdfModal;
  m.querySelector(".sv-cancel").onclick = closePdfModal;
  $("pdfGo").onclick = buildPdf;

  // No backdrop-click close: an accidental tap on the dim area must not throw
  // away a set of choices the user just made.
  $("pdfScopes").addEventListener("change", ev => {
    if (ev.target && ev.target.name === "pdfScope") {
      chosen = ev.target.value;
      $("pdfScopes").querySelectorAll(".pdf-scope").forEach(l =>
        l.classList.toggle("is-checked", !!l.querySelector("input:checked")));
      paintSummary();
    }
  });
  document.addEventListener("keydown", ev => {
    if (ev.key === "Escape" && !busy && m.style.display === "flex") closePdfModal();
  });

  // Chain onto the paint hook rather than replacing it: saved-manage.js owns
  // the menus and selection, and both need to run after every screen.
  const prev = window.__savedDecorate || function () {};
  window.__savedDecorate = function () { prev(); refreshPdfButton(); };
  refreshPdfButton();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initPdf);
else initPdf();

// ── exported for the test suite ─────────────────────────────────────────────
Object.assign(window, {
  savedOpenPdfModal: openPdfModal,
  savedClosePdfModal: closePdfModal,
  savedBuildPdf: buildPdf,
  savedPdfScopes: scopesFor,
  savedPdfChosen: () => chosen,
  savedPdfSetChosen: id => { chosen = id; paintSummary(); },
  savedPdfCount: countFor,
  savedPdfGroup: groupItems,
  savedPdfBusy: () => busy,
  savedPdfHandoffKey: HANDOFF_KEY,
  savedPdfPrintPage: PRINT_PAGE,
  savedPdfMax: MAX_PDF_QUESTIONS
});
})();

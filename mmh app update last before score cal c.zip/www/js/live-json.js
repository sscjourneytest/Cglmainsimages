/* ═══════════════════════════════════════════════════════════════════════════
   MMH LIVE-JSON LAYER — BUNDLED FIRST, LIVE IN BACKGROUND
   ───────────────────────────────────────────────────────────────────────────
   THE PROBLEM THIS REPLACES
     The old fetchLiveFirst() awaited the LIVE url (https://mockmatrixhub.in/…)
     and only fell back to the bundled copy if that failed:

         try { const res = await fetch(liveUrl); if (res.ok) return res; }
         catch (e) {}
         return await fetch(localUrl);

     Every page therefore blocked first paint on a network round-trip for a
     file that is ALREADY inside the APK. On a slow connection the home page
     sat on its skeleton for seconds; offline it paid the full timeout before
     falling back. Seven copies of that helper existed (six engines plus an
     inline block in series/index.html), all guarded by
     `if (typeof window.fetchLiveFirst !== 'function')`, so whichever loaded
     first won.

   THE NEW RULE
     1. Bundled copy is ALWAYS what paints first — online or offline. There is
        no network wait anywhere in the first-paint path.
     2. The live copy is fetched in the BACKGROUND, never awaited.
     3. When it lands, and only if it actually differs, we dispatch
        'mmh-live-json-updated' { path, url, data }. Engines subscribe with
        mmhOnLiveJson(url, handler) and RE-RENDER IN PLACE. The page is never
        reloaded and no scroll position, screen or selection is lost.
     4. Offline  → a persistent bottom-centred notice: "Offline — no network
        connection". It disappears by itself the moment connectivity returns,
        and every background refresh is retried at that point.
     5. Slow     → if a background fetch is still running after MMH_LIVE_SLOW_MS
        a small notice of the same design appears: "Internet is slow — showing
        saved content". It is transient; the user is never blocked by it.

   Because this file installs window.fetchLiveFirst BEFORE the engines load,
   the seven guarded inline copies simply never run — they stay in place as a
   automatic fallback for any page that does not include this file, so a
   missing script tag degrades to the old behaviour instead of breaking.

   Load order matters: this file must come before the engine script.
     <script src="/js/live-json.js?v=…"></script>
     <script src="/js/home-engine.js?v=…"></script>
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.__MMH_LIVE_JSON__) return;          // install exactly once
    window.__MMH_LIVE_JSON__ = true;

    var LIVE_BASE = String(window.MMH_LIVE_BASE || 'https://mockmatrixhub.in').replace(/\/+$/, '');
    window.MMH_LIVE_BASE = LIVE_BASE;

    var SLOW_MS      = Number(window.MMH_LIVE_SLOW_MS || 4000);   // → "internet is slow"
    var LIVE_TIMEOUT = Number(window.MMH_LIVE_TIMEOUT_MS || 15000); // hard cap, background only
    var SLOW_SHOW_MS = 2600;                                      // how long the slow notice stays

    var MSG_OFFLINE = 'Offline — no network connection';
    var MSG_SLOW    = 'Internet is slow — showing saved content';

    var inflight = {};      // rel → true          (a background fetch is running)
    var known    = {};      // rel → true          (this page has asked for it)
    var lastSig  = {};      // rel → JSON string   (dedupe identical payloads)

    function relOf(url) {
        return String(url || '').replace(/^\/+/, '').split('?')[0];
    }
    function liveUrlFor(rel) {
        return LIVE_BASE + '/' + rel;
    }
    function isOffline() {
        return window.navigator && window.navigator.onLine === false;
    }

    /* ── The notice ───────────────────────────────────────────────────────
       Bottom-centred pill, same geometry as design.css #toastRoot so it sits
       in the place users already expect transient messages. Styles are
       injected here so the notice works on every page, including ones that
       never load design.css.                                                        */
    var NOTICE_CSS =
        '#mmhNetNotice{position:fixed;left:50%;transform:translateX(-50%) translateY(14px);' +
        'bottom:calc(18px + env(safe-area-inset-bottom));z-index:3200;' +
        'display:flex;align-items:center;gap:8px;max-width:min(92vw,420px);' +
        'padding:10px 16px;border-radius:999px;' +
        'background:rgba(15,23,42,.94);color:#fff;' +
        'font:700 12.5px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;' +
        'letter-spacing:.1px;box-shadow:0 10px 28px rgba(2,6,23,.34);' +
        'opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease;}' +
        '#mmhNetNotice.on{opacity:1;transform:translateX(-50%) translateY(0);}' +
        '#mmhNetNotice svg{width:16px;height:16px;flex:0 0 16px;}' +
        '#mmhNetNotice.slow{background:rgba(146,64,14,.95);}';

    var ICON_OFFLINE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" ' +
        'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<path d="M1 1l22 22"/><path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"/>' +
        '<path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"/><path d="M10.71 5.05A16 16 0 0 1 22.58 9"/>' +
        '<path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/>' +
        '<line x1="12" y1="20" x2="12.01" y2="20"/></svg>';
    var ICON_SLOW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" ' +
        'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 13.5"/></svg>';

    var noticeEl = null, slowTimer = null;

    function ensureNotice() {
        if (noticeEl && noticeEl.isConnected) return noticeEl;
        if (!document.getElementById('mmhNetNoticeStyle')) {
            var st = document.createElement('style');
            st.id = 'mmhNetNoticeStyle';
            st.textContent = NOTICE_CSS;
            (document.head || document.documentElement).appendChild(st);
        }
        noticeEl = document.getElementById('mmhNetNotice');
        if (!noticeEl) {
            noticeEl = document.createElement('div');
            noticeEl.id = 'mmhNetNotice';
            noticeEl.setAttribute('role', 'status');
            noticeEl.setAttribute('aria-live', 'polite');
            (document.body || document.documentElement).appendChild(noticeEl);
        }
        return noticeEl;
    }

    // sticky=true  → stays until hideNotice() (offline)
    // sticky=false → auto-dismisses after SLOW_SHOW_MS (slow)
    function showNotice(msg, icon, sticky, slowStyle) {
        var el = ensureNotice();
        if (!el) return;
        // A persistent offline notice always wins over a transient slow one.
        if (el.dataset.sticky === '1' && !sticky) return;
        clearTimeout(slowTimer);
        el.classList.toggle('slow', !!slowStyle);
        el.innerHTML = icon + '<span>' + String(msg).replace(/[<>&]/g, function (c) {
            return c === '<' ? '&lt;' : c === '>' ? '&gt;' : '&amp;';
        }) + '</span>';
        el.dataset.sticky = sticky ? '1' : '0';
        // force a reflow so the transition replays when the text changes
        void el.offsetWidth;
        el.classList.add('on');
        if (!sticky) slowTimer = setTimeout(hideNotice, SLOW_SHOW_MS);
    }
    function hideNotice() {
        clearTimeout(slowTimer);
        if (!noticeEl) return;
        noticeEl.dataset.sticky = '0';
        noticeEl.classList.remove('on');
    }
    function showOffline() { showNotice(MSG_OFFLINE, ICON_OFFLINE, true, false); }
    function showSlow()    { showNotice(MSG_SLOW,    ICON_SLOW,    false, true); }

    /* ── Background live refresh ──────────────────────────────────────────
       Never awaited by the caller. Failures are silent: the bundled copy is
       already on screen, so a failed refresh is not an error state.          */
    function refresh(rel) {
        rel = relOf(rel);
        if (!rel) return;
        known[rel] = true;
        if (inflight[rel]) return;                 // one at a time per file
        if (isOffline()) return;                   // nothing to try; bundled is painted

        inflight[rel] = true;
        var url = liveUrlFor(rel) + '?mmh_live=' + Date.now();
        var settled = false;

        var slow = setTimeout(function () {
            if (inflight[rel] && !isOffline()) showSlow();
        }, SLOW_MS);

        var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        var hard = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, LIVE_TIMEOUT) : null;

        var opts = { cache: 'no-store' };
        if (ctrl) opts.signal = ctrl.signal;

        function done() {
            if (settled) return;
            settled = true;
            clearTimeout(slow);
            if (hard) clearTimeout(hard);
            delete inflight[rel];
        }

        fetch(url, opts).then(function (r) {
            if (!r || !r.ok) throw new Error('HTTP ' + (r ? r.status : 'no response'));
            return r.json();
        }).then(function (data) {
            done();
            var sig;
            try { sig = JSON.stringify(data); } catch (e) { sig = '@' + Date.now(); }
            if (lastSig[rel] === sig) return;      // identical → skip the re-render entirely
            lastSig[rel] = sig;
            window.dispatchEvent(new CustomEvent('mmh-live-json-updated', {
                detail: { path: '/' + rel, url: liveUrlFor(rel), data: data }
            }));
        }).catch(function () {
            done();                                // silent by design
        });
    }

    function refreshAllKnown() {
        for (var rel in known) if (Object.prototype.hasOwnProperty.call(known, rel)) refresh(rel);
    }

    /* ── Connectivity ───────────────────────────────────────────────────── */
    function syncOnlineState() {
        if (isOffline()) showOffline();
        else hideNotice();
    }
    window.addEventListener('offline', function () { showOffline(); });
    window.addEventListener('online',  function () { hideNotice(); refreshAllKnown(); });

    /* ── Public API ─────────────────────────────────────────────────────── */

    // Drop-in replacement for the old helper, same signature and same
    // Promise<Response> contract, so every existing call site keeps working:
    //     const res = await fetchLiveFirst(url, opts);
    //     if (!res.ok) throw …;  const data = await res.json();
    // The difference: it resolves from the BUNDLE, instantly.
    window.fetchLiveFirst = function (localUrl, fetchOpts) {
        var rel = relOf(localUrl);
        refresh(rel);                              // fire-and-forget, never awaited
        return fetch(localUrl, fetchOpts);         // bundled copy → immediate
    };

    // For files that are deliberately NOT bundled (whats-new.json): always the
    // live website, no local fallback. Callers handle their own offline case.
    window.fetchLiveOnly = function (urlOrRel, fetchOpts) {
        var rel = relOf(urlOrRel);
        var opts = {};
        if (fetchOpts) for (var k in fetchOpts) if (Object.prototype.hasOwnProperty.call(fetchOpts, k)) opts[k] = fetchOpts[k];
        if (!('cache' in opts)) opts.cache = 'no-store';
        delete opts.signal;                        // caller timeouts must not kill a live-only read
        return fetch(liveUrlFor(rel) + '?mmh_live=' + Date.now(), opts);
    };

    // One-line subscription for an engine:
    //     mmhOnLiveJson(HOME_CONFIG_URL, function (data) { …re-render… });
    window.mmhOnLiveJson = function (path, handler) {
        if (typeof handler !== 'function') return;
        var want = relOf(path);
        window.addEventListener('mmh-live-json-updated', function (ev) {
            var d = (ev && ev.detail) || {};
            if (!d.data || relOf(d.path) !== want) return;
            try { handler(d.data); }
            catch (e) { console.warn('[mmh-live] re-render failed for /' + want + ':', e); }
        });
    };

    window.mmhLiveRefresh   = refresh;
    window.mmhLiveRefreshAll = refreshAllKnown;
    window.mmhNetNotice     = { show: showNotice, hide: hideNotice, offline: showOffline, slow: showSlow };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', syncOnlineState);
    else syncOnlineState();
})();

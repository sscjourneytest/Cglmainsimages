// ════════════════════════════════════════════════════════════════════════
// MMH NOTIFY WORKER — thin push helper + broadcast history (Cloudflare Worker)
//
// Logic:
//   · user taps Allow in app → token POSTed here → we call Firebase IID to
//     subscribe it to topic "mmh_all". Firebase owns the subscription list —
//     NOTHING about devices/topics is stored in D1.
//   · admin sends → we verify Admin Password / Secret (via X-Admin-Secret
//     header or body.password / body.secret) → call FCM v1 (topic message to
//     every subscribed device) → insert the broadcast into D1 so the
//     notifications page can list it (including for users with push OFF).
//
// Routes
//   POST /api/subscribe-topic         { token }             → Firebase IID subscribe
//   POST /api/notify/send             { title, body, url, password? } → FCM → D1
//                                     header X-Admin-Secret === ADMIN_NOTIFY_SECRET
//   POST /api/notify/verify-password  { password? }         → verifies secret without sending
//   POST /api/notify/delete           { id, password? }     → deletes broadcast from D1
//   GET  /api/notify/list?limit=&before_id=                 → {notifications,hasMore}
//
// Bindings / secrets (Worker → Settings → Variables):
//   D1 binding name : DB      (database mmh-notify-db)
//   Secret          : ADMIN_NOTIFY_SECRET or ADMIN_PASSWORD
//   Secret          : FIREBASE_SERVICE_ACCOUNT (full service-account JSON)
//
// D1 schema — ONE table (run once in D1 console):
//   CREATE TABLE IF NOT EXISTS notifications (
//     id INTEGER PRIMARY KEY AUTOINCREMENT,
//     title TEXT NOT NULL,
//     body TEXT NOT NULL,
//     url TEXT DEFAULT '/',
//     created_at TEXT NOT NULL,
//     fcm_ok INTEGER DEFAULT 0
//   );
// ════════════════════════════════════════════════════════════════════════

const TOPIC = 'mmh_all';
const ALLOWED_ORIGINS = [
  'https://mockmatrixhub.in',
  'https://www.mockmatrixhub.in',
  'https://mockmatrixhub.pages.dev',
  'https://localhost',          // Android app (Capacitor default scheme)
  'http://localhost',
  'capacitor://localhost',
];

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const origin = req.headers.get('Origin') || '';
    const corsHeaders = {
      'Access-Control-Allow-Origin': ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0],
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Secret, X-Admin-Password',
      'Vary': 'Origin',
    };
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders });

    let out;
    let extraHeaders = {};

    try {
      if (req.method === 'POST' && url.pathname === '/api/subscribe-topic') {
        out = await handleSubscribe(req, env);
      } else if (req.method === 'POST' && url.pathname === '/api/notify/send') {
        out = await handleSend(req, env);
      } else if (req.method === 'POST' && (url.pathname === '/api/notify/verify-password' || url.pathname === '/api/notify/verify-secret')) {
        out = await handleVerifyPassword(req, env);
      } else if (req.method === 'POST' && url.pathname === '/api/notify/delete') {
        out = await handleDelete(req, env);
      } else if (req.method === 'GET' && url.pathname === '/api/notify/list') {
        out = await handleList(url, env);
        // Cache notification list for 60 seconds at edge to avoid hammering D1
        extraHeaders['Cache-Control'] = 'public, max-age=60, s-maxage=120';
      } else {
        out = { status: 404, body: { error: 'Not found' } };
      }
    } catch (e) {
      out = { status: 500, body: { error: 'Worker error: ' + e.message } };
    }

    return new Response(JSON.stringify(out.body), {
      status: out.status,
      headers: { 'Content-Type': 'application/json', ...corsHeaders, ...extraHeaders },
    });
  },
};

/* ── Helper: verify admin password/secret ── */
function verifySecret(req, body, env) {
  const configuredSecret = (env.ADMIN_NOTIFY_SECRET || env.ADMIN_PASSWORD || '').trim();
  // If no secret configured in worker env variables, allow (or enforce if set)
  if (!configuredSecret) return true;

  const headerSecret = (req.headers.get('X-Admin-Secret') || req.headers.get('X-Admin-Password') || '').trim();
  const bodySecret = (body && (body.password || body.secret || body.adminSecret) || '').trim();
  const given = headerSecret || bodySecret;

  return given === configuredSecret;
}

/* ── POST /api/subscribe-topic — Firebase owns the subscription, we just ask ── */
async function handleSubscribe(req, env) {
  let body;
  try { body = await req.json(); } catch (e) { return { status: 400, body: { error: 'Invalid JSON body' } }; }
  const token = body && body.token;
  if (!token) return { status: 400, body: { error: 'token is required' } };

  let serviceAccount;
  try { serviceAccount = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT); } catch (e) { return { status: 500, body: { error: 'Server misconfigured: FIREBASE_SERVICE_ACCOUNT invalid' } }; }
  let accessToken;
  try { accessToken = await getGoogleAccessToken(serviceAccount); } catch (e) { return { status: 500, body: { error: 'Firebase auth failed: ' + e.message } }; }

  const res = await fetch(`https://iid.googleapis.com/iid/v1/${token}/rel/topics/${TOPIC}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', access_token_auth: 'true' },
  });
  const result = await res.json().catch(() => ({}));
  if (!res.ok) return { status: 502, body: { error: 'Topic subscribe failed', details: result } };
  return { status: 200, body: { success: true } };
}

/* ── POST /api/notify/verify-password — verify secret without sending ── */
async function handleVerifyPassword(req, env) {
  let body = {};
  try { body = await req.json(); } catch (e) {}
  if (!verifySecret(req, body, env)) {
    return { status: 401, body: { error: 'Unauthorized: Invalid Admin Password' } };
  }
  return { status: 200, body: { success: true, message: 'Password verified' } };
}

/* ── POST /api/notify/send — verify secret → FCM topic → D1 history row ── */
async function handleSend(req, env) {
  let body;
  try { body = await req.json(); } catch (e) { return { status: 400, body: { error: 'Invalid JSON body' } }; }

  if (!verifySecret(req, body, env)) {
    return { status: 401, body: { error: 'Unauthorized: Invalid Admin Password' } };
  }

  const title = (body.title || '').trim();
  const message = (body.body || body.message || '').trim();
  const path = body.url || body.path || '/';
  if (!title || !message) return { status: 400, body: { error: 'title and message are required' } };

  /* 1) trigger FCM topic send (all subscribed devices) */
  let fcmOk = false;
  let fcmDetail = null;
  try {
    const sa = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT);
    const accessToken = await getGoogleAccessToken(sa);
    const fcmRes = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: {
          topic: TOPIC,
          notification: { title, body: message },
          data: { title, body: message, path, sentAt: new Date().toISOString() },
        },
      }),
    });
    fcmDetail = await fcmRes.json().catch(() => null);
    fcmOk = fcmRes.ok;
  } catch (e) { fcmDetail = { error: e.message }; }

  /* 2) always store the broadcast so the notifications page can list it */
  const now = new Date().toISOString();
  const ins = await env.DB.prepare(
    'INSERT INTO notifications (title, body, url, created_at, fcm_ok) VALUES (?1, ?2, ?3, ?4, ?5)'
  ).bind(title, message, path, now, fcmOk ? 1 : 0).run();

  return { status: 200, body: { notificationId: ins.meta.last_row_id, fcmOk, fcmDetail } };
}

/* ── POST /api/notify/delete — delete a broadcast from D1 history ── */
async function handleDelete(req, env) {
  let body;
  try { body = await req.json(); } catch (e) { return { status: 400, body: { error: 'Invalid JSON body' } }; }

  if (!verifySecret(req, body, env)) {
    return { status: 401, body: { error: 'Unauthorized: Invalid Admin Password' } };
  }

  const id = parseInt(body.id, 10);
  if (!id) return { status: 400, body: { error: 'id is required' } };

  await env.DB.prepare('DELETE FROM notifications WHERE id = ?1').bind(id).run();
  return { status: 200, body: { success: true, deletedId: id } };
}

/* ── GET /api/notify/list — history for the notifications page ── */
async function handleList(url, env) {
  const limit = Math.min(50, parseInt(url.searchParams.get('limit') || '20', 10) || 20);
  const before = parseInt(url.searchParams.get('before_id') || '0', 10) || null;
  const rows = await env.DB.prepare(
    'SELECT id, title, body, url, created_at, fcm_ok FROM notifications WHERE (?1 IS NULL OR id < ?1) ORDER BY id DESC LIMIT ?2'
  ).bind(before, limit + 1).all();
  const all = rows.results || [];
  return { status: 200, body: { notifications: all.slice(0, limit), hasMore: all.length > limit } };
}

/* ── Google OAuth2 service-account JWT flow (Web Crypto only) ── */
async function getGoogleAccessToken(serviceAccount) {
  const nowSec = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claimSet = {
    iss: serviceAccount.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: nowSec, exp: nowSec + 3600,
  };
  const unsignedJwt = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claimSet))}`;
  const key = await importPrivateKey(serviceAccount.private_key);
  const signature = await crypto.subtle.sign({ name: 'RSASSA-PKCS1-v1_5' }, key, new TextEncoder().encode(unsignedJwt));
  const signedJwt = `${unsignedJwt}.${base64urlFromArrayBuffer(signature)}`;
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: signedJwt }),
  });
  const tokenJson = await tokenRes.json();
  if (!tokenRes.ok) throw new Error(tokenJson.error_description || 'token exchange failed');
  return tokenJson.access_token;
}
function base64url(str) { return base64urlFromArrayBuffer(new TextEncoder().encode(str)); }
function base64urlFromArrayBuffer(buffer) {
  const bytes = new Uint8Array(buffer); let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
async function importPrivateKey(pem) {
  const pemContents = pem.replace('-----BEGIN PRIVATE KEY-----', '').replace('-----END PRIVATE KEY-----', '').replace(/\s/g, '');
  const binaryDer = Uint8Array.from(atob(pemContents), (c) => c.charCodeAt(0));
  return crypto.subtle.importKey('pkcs8', binaryDer.buffer, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
}

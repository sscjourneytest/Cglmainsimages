Mock Matrix Hub - v60 Update Details
====================================
Date: 2026-09-22

Files in this update package:
1. test.html (Root level & exams/test.html - Mobile Palette Width 315px & Welcome Page 1 Bottom Scroll Fix)
2. saved/test.html (Saved Questions Practice Test Engine - Mobile Palette Width 315px & Welcome Page 1 Bottom Scroll Fix)
3. data/home-config.json (Updated Paid Users / Premium Users count to 3000)
4. index.html (Root home page with instant boot and non-blocking auth)
4. js/home-engine.js (Instant un-gated homeReady reveal from cache)
5. auth.js (Stale-While-Revalidate background session & profile verification)
6. worker.js (Cloudflare Worker for Notifications & Admin Authentication)
7. admin-notify.html (Admin Broadcast Center with Password Authentication)
8. js/app-core.js (Notify Worker background scanning stopped on Home Page)
9. saved/index.html (Saved Questions Hub with Question Range Selector for 25+ questions)
10. js/saved-attempt.js (Test Generation Logic with Range Selection)
11. css/saved.css & css/q-render.css (MathJax small-screen equation breaking & Range UI)

Key Changes & Fixes:
--------------------
1. Welcome Screen Page 1 Mobile & Desktop Bottom Scroll Clearance:
   - Added `padding-bottom: calc(90px + env(safe-area-inset-bottom, 0px));` to `.ws-scroll-col` in `test.html`, `exams/test.html`, and `saved/test.html`.
   - On mobile devices, the fixed footer (.ws-action-footer) was directly overlapping the bottom 60px–80px of the instructions container (.ws-scroll-col), which caused the last instruction ("Single Tab Policy" / "एकल टैब परीक्षा नियम" / "Good Luck") to be trapped underneath the footer.
   - On screens where content height was close to viewport height, the container became unscrollable while the last item was clipped.
   - With this bottom clearance, the page scrolls smoothly and the last instruction row stops comfortably 55px–70px above the fixed footer with zero clipping.

2. Updated Paid Users Count in `data/home-config.json`:
   - Updated "premium-users" ("Premium Users" / Paid Users) value from 2400 to 3000.

3. Mobile Question Palette Width Increased (test.html, exams/test.html, saved/test.html):
   - Under @media (max-width: 991px), increased #palette width from 280px to 315px.
   - All 5 question buttons (44px each + 10px column gaps = 260px) now fit comfortably in each row with zero horizontal scrolling.
   - Desktop view (>=992px, 360px width) remains completely unchanged.

2. Instant Home Page Loading (Fix for Slow Internet / Offline):
   - Removed blocking MMH_AUTH_GATE_PENDING lock from home page boot path.
   - Stale-While-Revalidate: Cached user session (u_vault) loads and paints the home screen in < 100ms.
   - homeReady() in js/home-engine.js removes body.home-booting immediately upon painting from cache without waiting for slow server round-trips.
   - Reduced safety fallback timer from 10s to 1.5s with all gating blockers removed.
   - Background Verification: Supabase session checks and profile refreshes happen silently in the background; UI is never held hostage by slow 2G/3G connections.

3. Cloudflare Notify Worker (worker.js):
   - Secure Admin Verification:
     * verifySecret() helper supporting "X-Admin-Secret" / "X-Admin-Password" headers and JSON body parameters ("password", "secret", "adminSecret").
     * Supports either env.ADMIN_NOTIFY_SECRET or env.ADMIN_PASSWORD in Cloudflare Worker environment variables.
   - Dedicated Endpoints:
     * Added "POST /api/notify/verify-password" route to verify admin credentials without sending a broadcast.
     * Added "POST /api/notify/delete" route to allow authorized admins to remove test/obsolete broadcasts from D1 history.
   - Edge Caching:
     * "Cache-Control: public, max-age=60, s-maxage=120" added to "GET /api/notify/list" to prevent hammering D1 database.

4. Admin Broadcast Center Password Protection (admin-notify.html):
   - Added Admin Password / Secret input field (#adminSecret) with visibility eye icon.
   - Sends "X-Admin-Secret" header to worker.js.
   - Remembers secret in localStorage (mmh_admin_notify_secret) on successful send.

5. Home Page Worker Call Disabled (js/app-core.js):
   - refreshNotificationBadge() no longer calls https://mmh-notify-worker.mockmatrixsupport.workers.dev/api/notify/list on the home page.
   - The worker is now ONLY called when users explicitly visit notifications.html.

6. Saved Questions Practice Test Generator — Dynamic Scope Hierarchy & Advanced Custom Range:
   - Screen-Aware Scope Initialization:
     * When opened from Library Root (All Subjects view): Default is "Whole Library". Below it, option "Select Specific Subject(s)" allows selecting one or more subjects. Inside subjects, option "Select Specific Topics" allows picking specific topics.
     * When opened from Subject View (e.g. inside Mathematics): "Whole Library" is NOT shown. By default, that subject is selected, with option below to select specific topic(s) from that subject.
     * When opened from Topic View (inside a single topic): That topic is selected by default with no deeper sub-tree.
   - Collapsible Progress Bar / Breadcrumb (Keeps Modal Height Compact on Mobile):
     * When user drills down into topics, the preceding subject selection automatically collapses into a sleek 38px breadcrumb bar with an "Edit ✏️" button.
     * Clicking "Edit" re-expands the subjects selector so users can modify their subjects at any time, keeping modal height neat and thumb-friendly.
   - Smart Range System (Common Range + Three-Dot / Settings Icon for Itemized Ranges):
     * Default is "All Questions" across chosen scope.
     * When "Custom Range" is chosen, a "Common Range" row allows entering a range (e.g. From Q 1 to Q 20) applied across all selected topics/subjects.
     * Graceful fallback with NO errors: If any topic has fewer questions than the requested range (e.g. topic has only 7 questions when 1–20 is requested), it takes all available questions up to that limit without error!
     * Settings / Three-Dots Button (`#atRangeAdvBtn` with slider icon): When multiple topics or subjects are selected, clicking the settings icon expands an itemized breakdown (`#atItemizedBox`) where each topic or subject has its own individual From and To inputs.
   - Zero changes to test runner: Generated test hands off to saved/test.html through local sessionStorage exactly as before.

7. Saved Questions MathJax Overflow & Equation Line-Breaking:
   - Added MathJax wrapping and overflow safeguard CSS from test.html into css/q-render.css and css/saved.css.
   - Long equations wrap naturally on small screens without breaking card containers.

8. Welcome Screen Page 2 (Mobile & Desktop Enhancements):
   - Hidden ".ws-intro-blue" text above symbols image on mobile only (<992px); kept on desktop.
   - Language selector dropdown set to 50% width on mobile; optional subject picker takes the remaining 50% side-by-side.
   - Instruction confirmation checkbox line on mobile shortened to single concise line.

Upload Instructions:
--------------------
- Upload test.html to root / and exams/test.html.
- Upload saved/test.html to saved/test.html.
- Upload data/home-config.json to data/home-config.json.
- Upload index.html to root /index.html.
- Upload auth.js to root /auth.js.
- Upload js/home-engine.js to js/home-engine.js.
- Deploy worker.js in Cloudflare Workers (Worker Name: mmh-notify-worker). Set ADMIN_NOTIFY_SECRET in Worker Settings -> Variables.
- Upload admin-notify.html to root /admin-notify.html.
- Upload js/app-core.js to js/app-core.js.
- Upload saved/index.html to saved/index.html.
- Upload js/saved-attempt.js to js/saved-attempt.js.
- Upload css/saved.css to css/saved.css.
- Upload css/q-render.css to css/q-render.css.

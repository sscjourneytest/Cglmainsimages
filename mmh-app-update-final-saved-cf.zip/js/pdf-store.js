/* ═══════════════════════════════════════════════════════════════════════
   MMH PDFs — MY DOWNLOADS VAULT (app only; on the website `supported()`
   is false and nothing here runs).          window.MMHPdfStore
   ───────────────────────────────────────────────────────────────────────
   Storage (no base64 anywhere — files move natively):
     • files   → app-private internal storage  (Directory.DATA)
                 mmh-pdfs/free/<id>-v<v>.pdf    real PDF
                 mmh-pdfs/paid/<id>-v<v>.mmh    encrypted (AES-256-GCM, 1 MB chunks)
     • keys    → Android Keystore-backed secure storage (key + licence expiry)
     • index   → localStorage (titles / sizes / dates only — nothing secret)
   Premium:
     • OPEN (not downloaded) → this app session only: 1 Worker call + 1 file into
       the CACHE dir, key in sessionStorage. App closed → file + key wiped.
       "Save" from the viewer copies that same file into My Downloads (0 extra requests).
     • DOWNLOAD → My Downloads: stays until the user deletes it / clears app data /
       licence end = min(now + EXPIRY_DAYS (90, Worker var), premium end date).
       Re-open = 0 requests (offline OK). Days are NOT shown in the UI.
     • After licence end: tiny renew call (POST /v1/open want=key) — no re-download.
     • Logout / other account → all premium files + keys wiped.
     • Clock moved back → locked until the next online renew.
   Plugins: Filesystem (+ FileTransfer), SecureStoragePlugin, PlayIntegrity,
            PrivacyScreen (viewer), Share (export fallback).
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.MMHPdfStore) return;
    var M = window.MMHPdf;

    var IDX_KEY = 'mmh_pdf_dl_v1';
    var DIR = 'DATA';
    var ROOT = 'mmh-pdfs';
    var SEC = 'mmhpdf_';
    var CLOCK_SLACK = 10 * 60 * 1000;
    var HDR = 32;
    var CACHE = 'CACHE', SESS_DIR = 'mmh-pdfs-session', SESS_KEY = 'mmh_pdf_sess', SESS_ON = 'mmh_pdf_sess_on';

    function P(n) { try { return (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins[n]) || null; } catch (e) { return null; } }
    function err(code, msg, extra) { var e = new Error(msg || code); e.code = code; if (extra) for (var k in extra) e[k] = extra[k]; return e; }
    function supported() { return M.isApp() && !!P('Filesystem') && !!(P('FileTransfer') || (P('Filesystem') && P('Filesystem').downloadFile)); }
    function secPlugin() { return P('SecureStoragePlugin') || P('SecureStorage'); }
    function supportedPaid() { return supported() && !!secPlugin(); }
    function safe(s) { return String(s).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 100); }

    /* ── index (localStorage) ─────────────────────────────────────────── */
    function readIdx() {
        try { var j = JSON.parse(localStorage.getItem(IDX_KEY) || 'null'); if (j && j.items) return j; } catch (e) {}
        return { owner: '', items: {}, lastSeen: 0 };
    }
    function writeIdx(x) { try { localStorage.setItem(IDX_KEY, JSON.stringify(x)); } catch (e) {} }
    function touch(serverNowMs) {
        var x = readIdx(), now = Date.now();
        if (serverNowMs) x.lastSeen = Math.max(serverNowMs, now - 1);
        else if (now >= (x.lastSeen || 0) - CLOCK_SLACK) x.lastSeen = Math.max(x.lastSeen || 0, now);
        writeIdx(x);
    }
    function clockBack() { var x = readIdx(); return !!x.lastSeen && Date.now() < x.lastSeen - CLOCK_SLACK; }
    function list(kind) {
        var it = readIdx().items, out = [];
        for (var k in it) if (!kind || it[k].kind === kind) out.push(it[k]);
        return out.sort(function (a, b) { return (b.at || 0) - (a.at || 0); });
    }
    function get(id) { return readIdx().items[id] || null; }
    function put(e) { var x = readIdx(); x.items[e.id] = e; writeIdx(x); }
    function drop(id) { var x = readIdx(); delete x.items[id]; writeIdx(x); }
    function noteLive(id, v) {
        var x = readIdx(), e = x.items[id];
        if (e && v && e.lv !== v) { e.lv = v; writeIdx(x); }
    }
    function usage() {
        var u = { count: 0, bytes: 0, free: 0, paid: 0, nFree: 0, nPaid: 0 };
        list().forEach(function (e) {
            u.count++; u.bytes += e.size || 0;
            if (e.kind === 'paid') { u.paid += e.size || 0; u.nPaid++; } else { u.free += e.size || 0; u.nFree++; }
        });
        return u;
    }
    /* state for the UI: ready | update | expired | clock */
    function status(e, liveV) {
        if (!e) return { state: 'none' };
        var lv = liveV || e.lv || e.v, now = Date.now();
        if (e.kind === 'paid') {
            if (clockBack()) return { state: 'clock' };
            if (!e.exp || now > e.exp * 1000) return { state: 'expired' };
            return { state: lv > e.v ? 'update' : 'ready' };
        }
        return { state: lv > e.v ? 'update' : 'ready' };
    }

    /* ── secure storage (Keystore) ────────────────────────────────────── */
    var secure = {
        get: async function (k) {
            var p = secPlugin(); if (!p) return null;
            try { var r = await p.get({ key: SEC + k }); return r && r.value != null ? r.value : null; } catch (e) { return null; }
        },
        set: async function (k, v) { var p = secPlugin(); if (!p) throw err('update_app'); await p.set({ key: SEC + k, value: String(v) }); },
        remove: async function (k) { var p = secPlugin(); if (!p) return; try { await p.remove({ key: SEC + k }); } catch (e) {} }
    };
    async function installId() {
        var v = await secure.get('install');
        if (v) return v;
        v = (crypto.randomUUID ? crypto.randomUUID() : (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2)));
        await secure.set('install', v);
        return v;
    }

    /* ── native file ops ──────────────────────────────────────────────── */
    async function nativeDownload(url, rel, onProgress, DIR) {
        DIR = DIR || 'DATA';
        var FS = P('Filesystem'), FT = P('FileTransfer'), h = null;
        var dir = rel.split('/').slice(0, -1).join('/'), part = rel + '.part';
        try { await FS.mkdir({ path: dir, directory: DIR, recursive: true }); } catch (e) {}
        try { await FS.deleteFile({ path: part, directory: DIR }); } catch (e) {}
        var onP = function (e) { if (!e || (e.url && e.url !== url)) return; if (onProgress) onProgress(Number(e.bytes) || 0, Number(e.contentLength) || 0); };
        try {
            if (FT) {
                var uri = (await FS.getUri({ path: part, directory: DIR })).uri;
                if (onProgress && FT.addListener) h = await FT.addListener('progress', onP);
                await FT.downloadFile({ url: url, path: uri, progress: !!onProgress });
            } else {
                if (onProgress && FS.addListener) h = await FS.addListener('progress', onP);
                await FS.downloadFile({ url: url, path: part, directory: DIR, progress: !!onProgress, recursive: true });
            }
        } catch (e) {
            try { await FS.deleteFile({ path: part, directory: DIR }); } catch (e2) {}
            throw err(navigator.onLine === false ? 'offline' : 'download', 'Download failed');
        } finally { if (h && h.remove) try { h.remove(); } catch (e) {} }
        try { await FS.deleteFile({ path: rel, directory: DIR }); } catch (e) {}
        await FS.rename({ from: part, to: rel, directory: DIR, toDirectory: DIR });
        var st = await FS.stat({ path: rel, directory: DIR });
        return { size: Number(st.size) || 0 };
    }
    async function readBytes(rel, DIR) {
        DIR = DIR || 'DATA';
        var FS = P('Filesystem');
        var uri = (await FS.getUri({ path: rel, directory: DIR })).uri;
        var r = await fetch(Capacitor.convertFileSrc(uri));      // native file → ArrayBuffer (no base64)
        if (!r.ok) throw err('missing_file', 'File not found');
        return new Uint8Array(await r.arrayBuffer());
    }
    /* native file → same-origin URL (https://localhost/_capacitor_file_/…) — PDF.js / fetch read it, no bridge, no base64 */
    async function fileUrl(rel, D) {
        var uri = (await P('Filesystem').getUri({ path: rel, directory: D || DIR })).uri;
        return Capacitor.convertFileSrc(uri);
    }
    async function delFile(rel, D) { try { await P('Filesystem').deleteFile({ path: rel, directory: D || DIR }); } catch (e) {} }

    /* ── session cache (premium "Open" without download) ─────────────── */
    function sessRead() { try { return JSON.parse(sessionStorage.getItem(SESS_KEY) || '{}') || {}; } catch (e) { return {}; } }
    function sessWrite(x) { try { sessionStorage.setItem(SESS_KEY, JSON.stringify(x)); } catch (e) {} }
    async function sessWipe() {
        try { sessionStorage.removeItem(SESS_KEY); } catch (e) {}
        try { await P('Filesystem').rmdir({ path: SESS_DIR, directory: CACHE, recursive: true }); } catch (e) {}
    }
    /* new app session (sessionStorage empty) → remove files left by the last session */
    function sessInit() {
        if (!supported()) return;
        var on = null; try { on = sessionStorage.getItem(SESS_ON); } catch (e) {}
        if (on) return;
        try { sessionStorage.setItem(SESS_ON, '1'); } catch (e) {}
        sessWipe();
    }
    function sessGet(id, v) {
        var s = sessRead()[id];
        if (!s || s.v !== v || s.u !== M.uid() || !s.k || Date.now() > (s.exp || 0) * 1000) return null;
        return s;
    }
    function inSession(id, v) { return !!sessGet(id, v); }

    /* ── crypto ───────────────────────────────────────────────────────── */
    var enc = new TextEncoder();
    function b64ToBytes(b64) {
        var s = atob(String(b64).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(b64).length + 3) % 4));
        var a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a;
    }
    function bytesToB64u(a) {
        var s = ''; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
        return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    async function sha256b64u(str) { return bytesToB64u(new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(str)))); }
    /* .mmh v1 → header 32 B: "MMH1" | ver | 3×0 | chunk u32 | plainLen u64 | nonce 12
       chunk i: AES-256-GCM(iv = nonce with last 4 bytes XOR i, aad = "id|v|i|last") */
    async function decrypt(buf, keyB64, id, v) {
        if (buf.length < HDR || buf[0] !== 77 || buf[1] !== 77 || buf[2] !== 72 || buf[3] !== 49 || buf[4] !== 1) throw err('corrupt', 'Bad file');
        var dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
        var chunk = dv.getUint32(8), plainLen = dv.getUint32(12) * 4294967296 + dv.getUint32(16);
        var nonce = buf.slice(20, 32);
        var key = await crypto.subtle.importKey('raw', b64ToBytes(keyB64), { name: 'AES-GCM' }, false, ['decrypt']);
        var out = new Uint8Array(plainLen), n = Math.max(1, Math.ceil(plainLen / chunk)), off = HDR, pos = 0;
        for (var i = 0; i < n; i++) {
            var len = Math.min(chunk, plainLen - pos), iv = nonce.slice();
            iv[8] ^= (i >>> 24) & 255; iv[9] ^= (i >>> 16) & 255; iv[10] ^= (i >>> 8) & 255; iv[11] ^= i & 255;
            var pt;
            try {
                pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv, additionalData: enc.encode(id + '|' + v + '|' + i + '|' + (i === n - 1 ? 1 : 0)), tagLength: 128 },
                    key, buf.subarray(off, off + len + 16));
            } catch (e) { throw err('corrupt', 'Decrypt failed'); }
            out.set(new Uint8Array(pt), pos); pos += len; off += len + 16;
        }
        return out;
    }

    /* streaming version for big files: reads the .mmh in pieces and decrypts every
       1 MB chunk as soon as it has arrived → peak RAM ≈ PDF size + 2 MB (not 2×). */
    async function decryptUrl(url, keyB64, id, v, onProgress) {
        var r = await fetch(url, { cache: 'no-store' });
        if (!r.ok) throw err('missing_file', 'File not found');
        var reader = r.body && r.body.getReader ? r.body.getReader() : null;
        if (!reader) return decrypt(new Uint8Array(await r.arrayBuffer()), keyB64, id, v);
        var total = Number(r.headers.get('Content-Length')) || 0;
        var buf = new Uint8Array(2 * 1048576 + 64), len = 0, got = 0;
        var key = await crypto.subtle.importKey('raw', b64ToBytes(keyB64), { name: 'AES-GCM' }, false, ['decrypt']);
        var hdr = null, out = null, n = 0, chunk = 0, plainLen = 0, nonce = null, i = 0, pos = 0;
        function push(a) {
            if (len + a.length > buf.length) { var nb = new Uint8Array(Math.max(buf.length * 2, len + a.length)); nb.set(buf.subarray(0, len)); buf = nb; }
            buf.set(a, len); len += a.length;
        }
        function eat(k) { buf.copyWithin(0, k, len); len -= k; }
        for (;;) {
            var x = await reader.read();
            if (x.value) { push(x.value); got += x.value.length; if (onProgress) onProgress(got, total); }
            if (!hdr && len >= HDR) {
                if (buf[0] !== 77 || buf[1] !== 77 || buf[2] !== 72 || buf[3] !== 49 || buf[4] !== 1) { try { reader.cancel(); } catch (e) {} throw err('corrupt', 'Bad file'); }
                var dv = new DataView(buf.buffer, 0, HDR);
                chunk = dv.getUint32(8); plainLen = dv.getUint32(12) * 4294967296 + dv.getUint32(16);
                nonce = buf.slice(20, 32); hdr = true; eat(HDR);
                out = new Uint8Array(plainLen); n = Math.max(1, Math.ceil(plainLen / chunk));
            }
            while (hdr && i < n) {
                var plen = Math.min(chunk, plainLen - pos), need = plen + 16;
                if (len < need) break;
                var iv = nonce.slice();
                iv[8] ^= (i >>> 24) & 255; iv[9] ^= (i >>> 16) & 255; iv[10] ^= (i >>> 8) & 255; iv[11] ^= i & 255;
                var pt;
                try {
                    pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv, additionalData: enc.encode(id + '|' + v + '|' + i + '|' + (i === n - 1 ? 1 : 0)), tagLength: 128 },
                        key, buf.slice(0, need));
                } catch (e) { try { reader.cancel(); } catch (e2) {} throw err('corrupt', 'Decrypt failed'); }
                out.set(new Uint8Array(pt), pos); pos += plen; eat(need); i++;
            }
            if (x.done) break;
        }
        if (!hdr || i < n) throw err('corrupt', 'File incomplete');
        return out;
    }

    /* ── owner (logout / other account) ───────────────────────────────── */
    async function checkOwner() {
        if (!supported()) return;
        var u = M.uid(); if (!u) return;
        var x = readIdx();
        if (x.owner && x.owner !== u) {
            var paid = list('paid');
            for (var i = 0; i < paid.length; i++) await remove(paid[i].id);
            await sessWipe();
            x = readIdx();
        }
        if (x.owner !== u) { x.owner = u; writeIdx(x); }
    }

    /* ── premium ended → downloaded premium PDFs removed automatically ─
       (files + keys + My Downloads entries). Triggers:
         • the logged-in profile says the plan is not active any more, or
         • the Worker says 402 (no plan) on a renew. */
    function changed(n) { try { window.dispatchEvent(new CustomEvent('mmhpdf:changed', { detail: { removed: n || 0 } })); } catch (e) {} }
    async function premiumEnded(plan) {
        var l = list('paid').filter(function (e) { return !plan || (e.plan || 'premium') === plan; });
        for (var i = 0; i < l.length; i++) await remove(l[i].id);
        await sessWipe();
        if (l.length) changed(l.length);
        return l.length;
    }
    async function checkPlan() {
        if (!supported()) return 0;
        var p = null; try { p = (typeof getLocalProfile === 'function') ? getLocalProfile() : null; } catch (e) {}
        if (!p || !(p.id || p.uid) || !('is_paid' in p)) return 0;          // profile unknown → do nothing
        var hasList = Array.isArray(p.plans || p.pdf_plans);
        var gone = list('paid').filter(function (e) {
            var pl = e.plan || 'premium';
            if (pl !== 'premium' && !hasList) return false;                  // other plans: only when the profile lists plans
            return !M.hasPlan(pl);
        });
        for (var i = 0; i < gone.length; i++) await remove(gone[i].id);
        if (gone.length) { await sessWipe(); changed(gone.length); }
        return gone.length;
    }

    /* ── FREE: save inside the app ────────────────────────────────────── */
    async function downloadFree(node, ctx, onProgress) {
        if (!supported()) throw err('unsupported');
        var v = Number(node.v) || 1, rel = ROOT + '/free/' + safe(node.id) + '-v' + v + '.pdf';
        var old = get(node.id);
        var res = await nativeDownload(M.freeUrl(ctx.cfg, node), rel, onProgress);
        if (old && old.path !== rel) await delFile(old.path);
        var e = entry(node, ctx, 'free', rel, v, res.size);
        put(e); touch();
        return e;
    }
    function entry(node, ctx, kind, rel, v, size) {
        return { id: node.id, kind: kind, title: node.title || node.id, sub: node.sub || '', f: ctx.f, crumb: ctx.crumb || '',
            path: rel, v: v, lv: v, size: size || 0, pages: node.pages || 0, at: Date.now(), plan: kind === 'paid' ? (ctx.plan || 'premium') : '' };
    }

    /* ── PREMIUM: one Worker call + one encrypted file ───────────────── */
    async function integrityToken(nonce, c) {
        var PI = P('CapacitorPlayIntegrity') || P('PlayIntegrity'); if (!PI) return '';   // native name of @capacitor-community/play-integrity
        try {
            var r = await PI.requestIntegrityToken({ nonce: nonce, googleCloudProjectNumber: Number(c && c.cloudProjectNumber) || 0 });
            return (r && r.token) || '';
        } catch (e) { return ''; }
    }
    async function openCall(node, ctx, want) {
        if (navigator.onLine === false) throw err('offline');
        var token = await M.jwt(), u = M.uid(), install = await installId();
        var v = Number(node.v) || 1, ts = Math.floor(Date.now() / 1000);
        var nonce = await sha256b64u(u + '|' + node.id + '|' + v + '|' + install + '|' + ts);
        var body = { id: node.id, v: v, plan: ctx.plan || 'premium', install: install, ts: ts, nonce: nonce,
            integrity: await integrityToken(nonce, ctx.cfg), want: want };
        var r;
        try {
            r = await fetch(String(ctx.cfg.api).replace(/\/+$/, '/') + 'v1/open', {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(body)
            });
        } catch (e) { throw err(navigator.onLine === false ? 'offline' : 'network'); }
        var j = null; try { j = await r.json(); } catch (e) {}
        if (r.status === 401) throw err('login');
        if (r.status === 402) throw err('buy');
        if (r.status === 403) throw err('integrity', (j && j.error) || 'Not allowed');
        if (r.status === 404 || r.status === 409) throw err('version');
        if (r.status === 429) throw err('limit');
        if (!r.ok || !j || !j.ok) throw err('server');
        return j;
    }
    async function downloadPaid(node, ctx, onProgress) {
        if (!supportedPaid()) throw err('update_app');
        var v = Number(node.v) || 1, rel = ROOT + '/paid/' + safe(node.id) + '-v' + v + '.mmh';
        var old = get(node.id), s = sessGet(node.id, v), j = null, res = null;
        if (s) {                       // already opened this session → copy that file, 0 requests
            try {
                var FS = P('Filesystem');
                try { await FS.mkdir({ path: ROOT + '/paid', directory: DIR, recursive: true }); } catch (x) {}
                await FS.copy({ from: s.path, directory: CACHE, to: rel, toDirectory: DIR });
                res = { size: Number((await FS.stat({ path: rel, directory: DIR })).size) || 0 };
                j = { key: s.k, exp: s.exp, now: 0 };
                if (onProgress) onProgress(1, 1);
            } catch (x) { j = null; res = null; }
        }
        if (!j) {
            j = await openCall(node, ctx, 'file');
            res = await nativeDownload(j.dl, rel, onProgress);
        }
        await secure.set('k_' + node.id, JSON.stringify({ k: j.key, v: v, exp: j.exp, u: M.uid() }));
        if (old && old.path !== rel) await delFile(old.path);
        var e = entry(node, ctx, 'paid', rel, v, res.size);
        e.exp = j.exp;
        put(e); touch(j.now ? j.now * 1000 : 0);
        return e;
    }
    async function renew(id, node, ctx) {
        var e = get(id); if (!e) throw err('missing');
        var j;
        try { j = await openCall({ id: id, v: e.v }, ctx, 'key'); }
        catch (x) { if (x && x.code === 'buy') await premiumEnded(e.plan || 'premium'); throw x; }
        var sec = { k: j.key, v: e.v, exp: j.exp, u: M.uid() };
        await secure.set('k_' + id, JSON.stringify(sec));
        e.exp = j.exp; put(e); touch(j.now ? j.now * 1000 : 0);
        return e;
    }

    /* ── open (bytes for PDF.js) ──────────────────────────────────────── */
    async function openBytes(id, onProgress) {
        var e = get(id); if (!e) throw err('missing');
        if (e.kind !== 'paid') { touch(); return readBytes(e.path); }
        if (clockBack()) throw err('clock');
        var raw = await secure.get('k_' + id), sec = null;
        try { sec = JSON.parse(raw); } catch (x) {}
        if (!sec || !sec.k || sec.u !== M.uid() || sec.v !== e.v) throw err('license');
        if (Date.now() > sec.exp * 1000) throw err('expired');
        touch();
        e.lastOpen = Date.now(); put(e);
        return decryptUrl(await fileUrl(e.path), sec.k, e.id, e.v, onProgress);
    }
    /* free, saved → URL of the real file for PDF.js (it streams + parses progressively) */
    async function freeFileUrl(id) {
        var e = get(id); if (!e || e.kind !== 'free') throw err('missing');
        touch();
        return fileUrl(e.path);
    }

    /* premium "Open" without download → bytes for this session only */
    async function openPaidSession(node, ctx, onProgress) {
        if (!supportedPaid()) throw err('update_app');
        var v = Number(node.v) || 1, s = sessGet(node.id, v);
        if (s) { try { return await decryptUrl(await fileUrl(s.path, CACHE), s.k, node.id, v); } catch (e) { s = null; } }
        var j = await openCall(node, ctx, 'file');
        var rel = SESS_DIR + '/' + safe(node.id) + '-v' + v + '.mmh';
        await nativeDownload(j.dl, rel, onProgress, CACHE);
        var x = sessRead(); x[node.id] = { v: v, k: j.key, exp: j.exp, path: rel, u: M.uid() }; sessWrite(x);
        touch(j.now ? j.now * 1000 : 0);
        return decryptUrl(await fileUrl(rel, CACHE), j.key, node.id, v);
    }

    /* ── delete / export ──────────────────────────────────────────────── */
    async function remove(id) {
        var e = get(id); if (!e) return;
        await delFile(e.path);
        if (e.kind === 'paid') await secure.remove('k_' + id);
        drop(id);
    }
    async function removeAll(kind) {
        var l = list(kind);
        for (var i = 0; i < l.length; i++) await remove(l[i].id);
    }
    /* free only — copies the real PDF to the phone (Documents/MockMatrixHub/<title>.pdf),
       falls back to the share sheet (Save to Files / Drive / WhatsApp …).
       Saved in My Downloads → copied from there. NOT saved → downloaded to a temp file in the
       session cache dir (wiped on next app start) — it is NOT added to My Downloads. */
    async function exportFree(idOrNode, ctx) {
        var node = typeof idOrNode === 'string' ? null : idOrNode, id = node ? node.id : idOrNode;
        var e = get(id), FS = P('Filesystem'), Share = P('Share');
        if (e && e.kind !== 'free') throw err('not_free');
        var v = node ? (Number(node.v) || 1) : (e ? e.v : 1), src = null;
        if (e && !(node && v > e.v)) src = { path: e.path, dir: DIR, title: e.title };
        else {
            if (!node || !ctx) throw err('missing');
            var tmp = SESS_DIR + '/export/' + safe(id) + '-v' + v + '.pdf';
            try { await FS.stat({ path: tmp, directory: CACHE }); }
            catch (x) { await nativeDownload(M.freeUrl(ctx.cfg, node), tmp, null, CACHE); }
            src = { path: tmp, dir: CACHE, title: node.title };
        }
        var base = String(src.title || id).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'document';
        try { await FS.requestPermissions(); } catch (x) {}          // Android 9/10 only — 11+ needs nothing
        try { await FS.mkdir({ path: 'MockMatrixHub', directory: 'DOCUMENTS', recursive: true }); } catch (x) {}
        for (var k = 1; k <= 4; k++) {                                  // same name already there → "Title (2).pdf"
            var name = 'MockMatrixHub/' + base + (k > 1 ? ' (' + k + ')' : '') + '.pdf';
            var exists = false;
            try { await FS.stat({ path: name, directory: 'DOCUMENTS' }); exists = true; } catch (x) {}
            if (exists) continue;
            try { await FS.copy({ from: src.path, directory: src.dir, to: name, toDirectory: 'DOCUMENTS' }); return { where: 'Documents/MockMatrixHub' }; }
            catch (x) { /* try the next name, then the share sheet */ }
        }
        if (!Share) throw err('export');
        var uri = (await FS.getUri({ path: src.path, directory: src.dir })).uri;
        await Share.share({ title: src.title || base, files: [uri], dialogTitle: 'Save or share PDF' });
        return { where: 'share' };
    }
    /* screenshot block while a premium PDF is on screen */
    function protect(on) {
        var PS = P('PrivacyScreen'); if (!PS) return;
        try { (on ? PS.enable({ android: { dimBackground: true } }) : PS.disable()).catch(function () {}); } catch (e) {}
    }

    window.MMHPdfStore = {
        supported: supported, supportedPaid: supportedPaid, list: list, get: get, status: status, usage: usage, noteLive: noteLive,
        downloadFree: downloadFree, downloadPaid: downloadPaid, renew: renew, openBytes: openBytes, freeFileUrl: freeFileUrl,
        openPaidSession: openPaidSession, inSession: inSession, premiumEnded: premiumEnded, checkPlan: checkPlan, ready: null,
        remove: remove, removeAll: removeAll, exportFree: exportFree, protect: protect, checkOwner: checkOwner,
        _decrypt: decrypt, _decryptUrl: decryptUrl, _sha: sha256b64u
    };
    try { sessInit(); } catch (e) {}
    window.MMHPdfStore.ready = (async function () {
        try { await checkOwner(); } catch (e) {}
        try { await checkPlan(); } catch (e) {}
    })();
})();

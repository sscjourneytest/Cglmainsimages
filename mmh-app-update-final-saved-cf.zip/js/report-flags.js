// ═══════════════════════════════════════════════════════════════════════════
//  report-flags.js — "your report got an update" badge + banner
//
//  Why: the home page must NOT ask the report Worker on every visit. It only
//  asks when this device has reported something (or chatted) recently.
//
//  localStorage
//    mmh_rq_flags   { quid: { t: lastActivityMs, k: "r" | "c" } }
//                   set on report submit (test.html) and on a chat reply
//                   (reported page). A flag is dropped as soon as the user
//                   has SEEN the admin update / reply for that question
//                   (reported page → /seen → clear()), otherwise 5 days after t.
//    mmh_rq_status  { at: lastCheckMs, u: { quid: { e, a, m, d } } }
//                   unseen admin updates found by the last check
//                   (e = corrected, a = admin replied, m = short text, d = found at)
//  sessionStorage
//    mmh_rq_banner  the update set the banner was already shown for
//
//  Home (index.html) calls MMHReportFlags.check():
//    no flags                → nothing, 0 calls
//    checked < 30 min ago    → paint from mmh_rq_status, 0 calls
//    otherwise               → POST reports…/status { quids } (≤ 20) with the
//                              saved ticket (one saved /session first if the tab
//                              has no ticket yet). D1 reads = number of quids.
//  Every page that loads this file paints the sidebar badge from the cached
//  status — no call. The reported page calls clear(quids, since) after /seen:
//  the update leaves the badge AND the quid's flag is deleted (the home stops
//  asking about it). A chat message the user sends later adds the flag again.
//  `since` = when /seen started: a flag set after that (the user wrote in the
//  chat meanwhile) is kept, so the admin's answer to it is still noticed.
//
//  5-day rule: every page that loads this file first deletes flags older than
//  5 days (and status entries found more than 5 days ago). When nothing is
//  left the localStorage keys are removed completely — nothing stays behind.
//
//  Race conditions handled
//    • boot splash / login screen / app-update, Telegram, expiry, sale or any
//      other modal on screen → the banner waits (and hides again if a modal
//      opens on top of it), then shows once the screen is clear
//    • profile not ready yet → no call; re-tried on the 'profileUpdated' event
//    • check() called twice → both get the same request (one call)
//    • two tabs opened together → a 20 s lock, the other tab just repaints
//      from the 'storage' event
//    • report page marks seen while a check is still in the air → the late
//      answer can't bring the seen quids back
//    • back from the report page (bfcache) → badge/banner repainted
//    • another account logs in on the same device → the old account's badge
//      is not shown (status remembers its uid)
// ═══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const FLAGS_KEY   = "mmh_rq_flags";
const STATUS_KEY  = "mmh_rq_status";
const BANNER_KEY  = "mmh_rq_banner";
const LOCK_KEY    = "mmh_rq_lock";
const TICKET_KEY  = "mmh_saved_ticket_v1";
const REPORT_URL  = "https://reports.mockmatrixhub.in/";
const SAVED_URL   = "https://saved.mockmatrixhub.in/";
const PAGE_URL    = "/reported/index.html";
const FLAG_TTL    = 5 * 24 * 60 * 60 * 1000;
const CHECK_EVERY = 30 * 60 * 1000;
const MAX_FLAGS   = 20;
const LOCK_MS     = 20 * 1000;

function readLS(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } }
function writeLS(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

// ── flags ────────────────────────────────────────────────────────────────────
function flags() {
  const f = readLS(FLAGS_KEY) || {};
  const now = Date.now();
  let changed = false;
  Object.keys(f).forEach(q => { if (!f[q] || !(now - f[q].t < FLAG_TTL)) { delete f[q]; changed = true; } });
  if (changed) saveOrDrop(FLAGS_KEY, f, Object.keys(f).length);
  return f;
}
function saveOrDrop(k, v, keep) {
  if (keep) writeLS(k, v);
  else try { localStorage.removeItem(k); } catch (e) {}
}
function myUid() {
  try {
    const p = typeof getLocalProfile === "function" ? getLocalProfile() : null;
    return p && p.id ? String(p.id).toLowerCase() : "";
  } catch (e) { return ""; }
}
function add(quid, kind) {
  quid = String(quid || "").trim();
  if (!/^Q\d{10}$/.test(quid)) return;
  const f = flags();
  f[quid] = { t: Date.now(), k: kind === "c" ? "c" : "r" };
  const keys = Object.keys(f).sort((a, b) => f[b].t - f[a].t);
  keys.slice(MAX_FLAGS).forEach(k => delete f[k]);     // newest 20 only
  writeLS(FLAGS_KEY, f);
}

// ── status ───────────────────────────────────────────────────────────────────
function status() {
  const raw = readLS(STATUS_KEY);
  const s = raw && typeof raw === "object" ? raw : { at: 0, u: {} };
  if (!s.u || typeof s.u !== "object") s.u = {};
  if (!s.cl || typeof s.cl !== "object") s.cl = {};
  const now = Date.now();
  let changed = false;
  // an update nobody opened for 5 days stops nagging (and is deleted)
  Object.keys(s.u).forEach(q => { if (!(now - (s.u[q].d || 0) < FLAG_TTL)) { delete s.u[q]; changed = true; } });
  Object.keys(s.cl).forEach(q => { if (!(now - s.cl[q] < CHECK_EVERY)) { delete s.cl[q]; changed = true; } });
  if (changed) saveStatus(s);
  return s;
}
function saveStatus(s) {
  // nothing left to remember → remove the key (the 5-day rule: no leftovers)
  const keep = Object.keys(s.u).length || Object.keys(s.cl || {}).length || Object.keys(flags()).length;
  saveOrDrop(STATUS_KEY, s, keep);
}
// updates for the account that is logged in now (another account → none)
function mine(s) {
  const uid = myUid();
  return uid && (!s.uid || s.uid === uid) ? s.u : {};
}
function unread() { return Object.keys(mine(status())); }
function clear(quids, since) {
  const s = status();
  const f = flags();
  const now = Date.now();
  let gone = false;
  (quids || []).forEach(q => {
    delete s.u[q]; s.cl[q] = now;                      // cl: a late /status answer can't bring them back
    if (f[q] && !(since && f[q].t > since)) { delete f[q]; gone = true; }   // seen → flag not needed any more
  });
  if (gone) saveOrDrop(FLAGS_KEY, f, Object.keys(f).length);
  saveStatus(s);
  paint();
}

// ── ticket (same as the saved page) ──────────────────────────────────────────
function ticketOk(t, uid) {
  try {
    const p = t.split(".")[0].replace(/-/g, "+").replace(/_/g, "/");
    const x = JSON.parse(atob(p + "===".slice((p.length + 3) % 4)));
    return x && x.e - 60 > Date.now() / 1000 && (!uid || String(x.u).toLowerCase() === uid);
  } catch (e) { return false; }
}
async function ticket() {
  const prof = typeof getLocalProfile === "function" ? getLocalProfile() : null;
  if (!prof || !prof.id) return "";
  const uid = String(prof.id).toLowerCase();
  let t = "";
  try { t = sessionStorage.getItem(TICKET_KEY) || ""; } catch (e) {}
  if (t && ticketOk(t, uid)) return t;
  if (typeof getClient !== "function") return "";
  const client = await getClient();
  const res = typeof getSessionOnce === "function" ? await getSessionOnce(client) : await client.auth.getSession();
  const jwt = res && res.data && res.data.session ? res.data.session.access_token : "";
  if (!jwt) return "";
  const r = await fetch(SAVED_URL + "session", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + jwt }, body: "{}" });
  t = r.headers.get("X-MMH-Ticket") || "";
  if (t) try { sessionStorage.setItem(TICKET_KEY, t); } catch (e) {}
  return t;
}
const REAL = {
  async status(quids) {
    const t = await ticket();
    if (!t) return null;
    const r = await fetch(REPORT_URL + "status", {
      method: "POST", headers: { "Content-Type": "application/json", "X-MMH-Ticket": t },
      body: JSON.stringify({ quids: quids })
    });
    if (!r.ok) return { ok: false };
    return r.json().catch(() => ({ ok: false }));
  }
};

// ── home: the check ──────────────────────────────────────────────────────────
let inFlight = null;
let waitingProfile = false;
let homeMode = false;                                  // only the page that calls check() shows the banner
function check(opts) {
  homeMode = true;
  if (inFlight) return inFlight;                       // called twice → one request
  inFlight = run(opts || {}).catch(() => {}).then(() => { inFlight = null; paint(); banner(); });
  return inFlight;
}
async function run(opts) {
  paint();
  const quids = Object.keys(flags());
  if (!quids.length) return;                           // nothing reported in 5 days → 0 calls
  const uid = myUid();
  if (!uid) {                                          // profile not ready / logged out
    if (!waitingProfile) {
      waitingProfile = true;
      window.addEventListener("profileUpdated", function once() {
        window.removeEventListener("profileUpdated", once);
        waitingProfile = false;
        setTimeout(() => check(opts), 300);
      });
    }
    return;
  }
  let s = status();
  if (s.uid && s.uid !== uid) { s = { at: 0, u: {}, cl: {} }; }   // another account → start fresh
  if (!opts.force && Date.now() - (s.at || 0) < CHECK_EVERY) return;
  // two tabs opened at the same moment → only one asks
  const lock = Number(localStorage.getItem(LOCK_KEY) || 0);
  if (Date.now() - lock < LOCK_MS) return;
  try { localStorage.setItem(LOCK_KEY, String(Date.now())); } catch (e) {}
  const started = Date.now();
  try {
    const api = window.MMH_RQ_FLAGS_API || REAL;
    const d = await api.status(quids.slice(0, MAX_FLAGS));
    if (!d) return;                                    // no ticket / offline → try next visit
    const now = Date.now();
    const cur = status();                              // re-read: the page may have changed it meanwhile
    const prev = cur.uid === uid ? cur.u : {};
    const u = {};
    if (d.ok !== false) {
      (d.updates || []).forEach(x => {
        if (!x || !/^Q\d{10}$/.test(String(x.quid || ""))) return;
        if (cur.cl[x.quid] && cur.cl[x.quid] >= started) return;   // seen while we were asking
        u[x.quid] = { e: x.e ? 1 : 0, a: x.a ? 1 : 0, m: String(x.m || "").slice(0, 90), d: (prev[x.quid] && prev[x.quid].d) || now };
      });
    }
    // any answer (even an error) counts as "checked" → max 1 call per 30 min
    saveStatus({ at: now, uid: uid, u: d.ok === false ? prev : u, cl: cur.cl });
  } finally {
    try { localStorage.removeItem(LOCK_KEY); } catch (e) {}
  }
}

// ── paint: sidebar badge + hamburger dot (any page, no call) ─────────────────
function css() {
  if (document.getElementById("rqFlagsCss")) return;
  const st = document.createElement("style");
  st.id = "rqFlagsCss";
  st.textContent =
    ".rq-menu-badge{margin-left:auto;min-width:20px;height:20px;padding:0 6px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;background:var(--red,#e11d48);color:#fff;font-size:11px;font-weight:800;line-height:1;box-shadow:0 2px 6px rgba(225,29,72,.35)}" +
    ".rq-menu-badge[hidden]{display:none}" +
    ".rq-has-dot{position:relative}" +
    ".rq-menu-dot{position:absolute;top:6px;right:6px;width:9px;height:9px;border-radius:50%;background:var(--red,#e11d48);box-shadow:0 0 0 2px var(--surface,#fff);pointer-events:none}" +
    ".rq-menu-dot[hidden]{display:none}" +
    ".rq-hb{position:fixed;left:50%;z-index:1300;width:min(calc(100vw - 24px),520px);transform:translate(-50%,-14px);opacity:0;transition:transform .28s cubic-bezier(.2,.8,.2,1),opacity .22s;" +
      "display:flex;align-items:flex-start;gap:12px;padding:13px 12px 13px 14px;border-radius:18px;background:var(--surface,#fff);border:1px solid var(--border,#e5e9f2);box-shadow:0 18px 44px rgba(15,23,42,.18);color:var(--text,#0e1428);font-family:inherit}" +
    ".rq-hb.show{transform:translate(-50%,0);opacity:1}" +
    "body.dark-mode .rq-hb{box-shadow:0 18px 44px rgba(0,0,0,.55)}" +
    ".rq-hb-ico{flex:0 0 auto;width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:var(--grad-primary,linear-gradient(135deg,#4d6bff,#3050e8));color:#fff;position:relative}" +
    ".rq-hb-ico svg{width:20px;height:20px}" +
    ".rq-hb-ico i{position:absolute;top:-5px;right:-6px;min-width:18px;height:18px;padding:0 4px;border-radius:999px;background:var(--red,#e11d48);color:#fff;font:800 10.5px/18px inherit;font-style:normal;text-align:center;box-shadow:0 0 0 2px var(--surface,#fff)}" +
    ".rq-hb-txt{flex:1 1 auto;min-width:0}" +
    ".rq-hb-t{font-size:14px;font-weight:800;margin:1px 0 2px}" +
    ".rq-hb-s{font-size:12.5px;line-height:1.45;color:var(--text-2,#5c6580);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}" +
    ".rq-hb-acts{display:flex;gap:8px;margin-top:10px}" +
    ".rq-hb-go{display:inline-flex;align-items:center;gap:6px;height:34px;padding:0 16px;border-radius:10px;border:0;background:var(--grad-primary,linear-gradient(135deg,#4d6bff,#3050e8));color:#fff;font:700 12.5px/1 inherit;font-family:inherit;cursor:pointer;text-decoration:none;box-shadow:0 6px 16px rgba(61,90,254,.28)}" +
    ".rq-hb-later{height:34px;padding:0 14px;border-radius:10px;border:1px solid var(--border-strong,#d3d9e8);background:transparent;color:var(--text-2,#5c6580);font:700 12.5px/1 inherit;font-family:inherit;cursor:pointer}" +
    ".rq-hb-x{flex:0 0 auto;width:30px;height:30px;margin:-4px -2px 0 0;border:0;background:transparent;color:var(--text-3,#8a93ab);border-radius:9px;cursor:pointer;display:flex;align-items:center;justify-content:center}" +
    ".rq-hb-x svg{width:16px;height:16px}";
  document.head.appendChild(st);
}
function paint() {
  css();
  flags();                                             // 5-day cleanup on every page load
  const n = unread().length;
  document.querySelectorAll("[data-rq-badge]").forEach(b => {
    b.classList.add("rq-menu-badge");
    b.hidden = !n;
    b.textContent = n > 9 ? "9+" : String(n);
  });
  // the hamburger (home #menuBtn, test page menu buttons marked data-rq-dot)
  document.querySelectorAll("#menuBtn, [data-rq-dot]").forEach(btn => {
    let dot = btn.querySelector(".rq-menu-dot");
    if (!dot) {
      if (!n) return;
      btn.classList.add("rq-has-dot");
      dot = document.createElement("span");
      dot.className = "rq-menu-dot";
      btn.appendChild(dot);
    }
    dot.hidden = !n;
  });
}

// ── banner: once per tab session for a given set of updates ──────────────────
// It never sits on top of another popup: boot splash, login screen, the
// app-update / Telegram / expiry / sale popups, the install modal or any
// .modal-overlay all go first. While one of those is open the banner waits
// (or tucks itself away if one opens later) and comes back when it closes.
function visible(el) {
  if (!el) return false;
  const d = el.style ? el.style.display : "";
  if (d === "none") return false;
  if (d) return true;
  return el.offsetHeight > 0 || (el.getClientRects && el.getClientRects().length > 0);
}
function blocked() {
  const b = document.body, h = document.documentElement;
  if (!b || b.classList.contains("home-booting") || h.classList.contains("mmh-auth-active")) return true;
  if (document.visibilityState === "hidden") return true;
  const ids = ["mmhAppUpdateOverlay", "tgPopupOverlay", "expiryExpiredOverlay", "mmhSaleOverlay", "pwaInstallModal"];
  for (let i = 0; i < ids.length; i++) if (visible(document.getElementById(ids[i]))) return true;
  const others = document.querySelectorAll(".modal-overlay, .sync-modal-overlay");
  for (let j = 0; j < others.length; j++) if (visible(others[j])) return true;
  return false;
}
let waitTimer = null, waitTries = 0, watchTimer = null;
function banner() {
  const u = mine(status());
  const quids = Object.keys(u).sort();
  const old = document.querySelector(".rq-hb");
  if (!quids.length) { if (old) old.remove(); return; }   // seen elsewhere → take it away
  if (old || !homeMode) return;
  const sig = quids.join(",");
  try { if (sessionStorage.getItem(BANNER_KEY) === sig) return; } catch (e) {}
  if (blocked()) {                                     // wait for a clear screen (max ~60 s)
    if (!waitTimer && waitTries++ < 40) waitTimer = setTimeout(() => { waitTimer = null; banner(); }, 1500);
    return;
  }
  waitTries = 0;
  css();
  let title, sub;
  if (quids.length === 1) {
    const x = u[quids[0]];
    title = x.e ? "Your reported question was corrected" : "Admin replied to your report";
    sub = x.m ? "“" + x.m + (x.m.length >= 90 ? "…" : "") + "”" : (x.e ? "Tap View to see the corrected question." : "Tap View to read the reply.");
  } else {
    title = quids.length + " reported questions have updates";
    const fixed = quids.filter(q => u[q].e).length;
    sub = (fixed ? fixed + " corrected" : "") + (fixed && quids.length - fixed ? " · " : "") +
          (quids.length - fixed ? (quids.length - fixed) + " with an admin reply" : "");
  }
  const el = document.createElement("div");
  el.className = "rq-hb";
  el.setAttribute("role", "status");
  el.innerHTML =
    '<div class="rq-hb-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 9.2a6 6 0 1 0-12 0c0 5-2 6.3-2 6.3h16s-2-1.3-2-6.3"/><path d="M10.3 19.5a2 2 0 0 0 3.4 0"/></svg><i>' + (quids.length > 9 ? "9+" : quids.length) + '</i></div>' +
    '<div class="rq-hb-txt"><div class="rq-hb-t">' + esc(title) + '</div><div class="rq-hb-s">' + esc(sub) + '</div>' +
    '<div class="rq-hb-acts"><a class="rq-hb-go" href="' + PAGE_URL + '?tab=updated&fresh=1">View</a><button type="button" class="rq-hb-later">Later</button></div></div>' +
    '<button type="button" class="rq-hb-x" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
  const place = () => {
    const hdr = document.querySelector(".screen-header");
    const top = hdr ? Math.max(0, hdr.getBoundingClientRect().bottom) : 0;
    el.style.top = (top + 10) + "px";
  };
  place();
  document.body.appendChild(el);
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("show")));
  try { sessionStorage.setItem(BANNER_KEY, sig); } catch (e) {}
  // a popup opening later (sale / update …) → tuck the banner away until it closes
  watchTimer = setInterval(() => {
    if (!el.isConnected) { clearInterval(watchTimer); return; }
    const hide = blocked();
    el.classList.toggle("show", !hide);
    el.style.pointerEvents = hide ? "none" : "";
    if (!hide) place();
  }, 800);
  const close = () => { clearInterval(watchTimer); el.classList.remove("show"); setTimeout(() => el.remove(), 300); };
  el.querySelector(".rq-hb-x").onclick = close;
  el.querySelector(".rq-hb-later").onclick = close;
  el.querySelector(".rq-hb-go").addEventListener("click", () => clearInterval(watchTimer));
}

// other tab changed the status (checked / marked seen) → repaint here too
window.addEventListener("storage", e => {
  if (e.key === STATUS_KEY || e.key === FLAGS_KEY || e.key === null) { paint(); banner(); }
});
// back from the reported page via bfcache → page JS did not re-run
window.addEventListener("pageshow", e => { if (e.persisted) { paint(); banner(); } });

window.MMHReportFlags = { add: add, clear: clear, check: check, paint: paint, unread: unread, flags: flags };

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", paint);
else paint();
})();

/* ══════════════════════════════════════════════════════════════════════════
   admin-render.js — "Render Questions" (Upload Test admin page)
   Shows the questions of one or more tests exactly like the saved page list
   view (q-render.js mmhRenderCard, solution mode).

   Two kinds of source:
     "ID" / {kind:"live", id}            → what is LIVE now: /tests/export (R2 structure + D1 bodies)
     {kind:"file", key, id, name, data}  → a JSON file in Bulk upload (before / after upload):
                                           full question objects  → rendered from the FILE
                                           [localId, quid] items  → text loaded from D1 (only these quids)

   Two places:
     full-screen layer  → phone, Tests tab, History (palette: ≥992px column · small = green toggle)
     inline (side pane) → big screen Bulk tab: renders INSIDE the right pane, palette = green
                          toggle + sheet inside the pane (same as phone), "←" = back to details

   Open:  <button data-render="ID1,ID2">            → layer (live)
          MMHRender.open(["ID"], startId)           → layer (live)
          MMHRender.show(sources, { host, start })  → host pane on a big screen, else the layer
          MMHRender.closeIn(host)                   → close the inline view of that pane
   Needs: q-render.js, mmh-upload-core.js (assemble), admin-upload.js (MMHUpAdmin).
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
"use strict";
if (typeof document === "undefined") return;
var WIDE = "(min-width:992px)";
var LANG_KEY = "mmh_up_render_lang";
var BODY_BATCH = 1000;                 // quids per POST /tests/bodies (Worker v7 max)
var LANG = "en";
try { LANG = localStorage.getItem(LANG_KEY) || "en"; } catch (e) {}
var CACHE = {};                        // "live:ID" / "file:KEY" → loaded test
var LAYER = null;                      // the one full-screen view
var INLINE = [];                       // inline views (one per pane)
var SVG = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.5" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.5" cy="18" r="1.3" fill="currentColor" stroke="none"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/></svg>',
  retry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>'
};
function A() { return window.MMHUpAdmin; }
function U() { return window.MMHUpload; }
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
function plural(n, a, b) { return n + " " + (n === 1 ? a : (b || a + "s")); }
function mq(q) { return !!(window.matchMedia && window.matchMedia(q).matches); }
function paneScreen() { var a = A(); return a && a.wide ? !!a.wide() : mq(WIDE); }   // the side pane exists
function toast(m, ms) { if (A()) A().toast(m, ms); }
function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }
function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }

function normSrc(s) {
  if (typeof s === "string") { var id = s.trim(); return id ? { kind: "live", id: id, ck: "live:" + id } : null; }
  if (!s || !s.id) return null;
  var o = {}; Object.keys(s).forEach(function (k) { o[k] = s[k]; });
  if (o.kind !== "file") o.kind = "live";
  o.ck = o.kind === "file" ? "file:" + (o.key || o.id) : "live:" + o.id;
  return o;
}

/* ───────────────────────────── data ───────────────────────────── */
function load(src) {
  var c = CACHE[src.ck];
  if (c && !c.err) return Promise.resolve(c);
  var p = src.kind === "file" ? loadFile(src) : loadLive(src.id);
  return p.then(function (res) { CACHE[src.ck] = res; return res; });
}
function authFail(e) { if (e && e.auth) { closeAll(); A().authLost(); throw e; } }
function loadLive(id) {
  return A().API.exportTest(id).then(function (d) {
    var r2 = d.r2 || {}, names = (r2.names || []).filter(function (n) { return r2.sections && r2.sections[n] != null; });
    var qj = { meta: r2.meta || {}, sections: {} };
    names.forEach(function (n) { qj.sections[n] = r2.sections[n]; });
    var a = U().assemble(qj, d.bodies || {});
    var secs = names.map(function (n) {
      var sv = a.test.sections[n], qs = Array.isArray(sv) ? sv : (sv && sv.questions) || [];
      return { name: n, items: qs.map(function (q) { return { q: q, from: "live" }; }) };
    });
    return { id: id, kind: "live", row: d.row || null, meta: qj.meta, secs: secs, missing: a.missing || [] };
  }, function (e) {
    authFail(e);
    return { id: id, err: e && e.status === 404 ? "This test is not on R2." : A().failText(e) };
  });
}
/** D1 text of the [localId, quid] items only — 1000 quids per call */
function fetchBodies(quids) {
  var parts = [], out = {};
  for (var i = 0; i < quids.length; i += BODY_BATCH) parts.push(quids.slice(i, i + BODY_BATCH));
  return parts.reduce(function (p, part) {
    return p.then(function () {
      return A().API.testBodies(part).then(function (d) {
        part.forEach(function (q) { if (d && d.questions && d.questions[q]) out[q] = d.questions[q]; });
      });
    });
  }, Promise.resolve()).then(function () { return out; });
}
function loadFile(src) {
  var d = src.data, u = U();
  var err = d ? u.validateTest(d) : "Not valid JSON";
  if (err) return Promise.resolve({ id: src.id, err: err, perm: true });
  var meta = d.meta || {}, names = Object.keys(d.sections), need = [];
  names.forEach(function (n) {
    (u.sectionList(d.sections[n]) || []).forEach(function (it) {
      if (Array.isArray(it) && u.QUID_RE.test(String(it[1])) && need.indexOf(String(it[1])) === -1) need.push(String(it[1]));
    });
  });
  return (need.length ? fetchBodies(need) : Promise.resolve({})).then(function (bodies) {
    var missing = [], nFile = 0, nD1 = 0;
    var secs = names.map(function (n) {
      var items = (u.sectionList(d.sections[n]) || []).map(function (it) {
        if (Array.isArray(it)) {
          var quid = String(it[1]), b = bodies[quid];
          if (!b) { missing.push(quid); return { q: null, from: "d1", quid: quid, lid: it[0] }; }
          var one = {}; one[quid] = b;
          var a = u.assemble({ meta: meta, sections: { s: [it] } }, one);
          nD1++;
          return { q: a.test.sections.s[0], from: "d1" };
        }
        nFile++;
        return { q: clone(it), from: it.quid !== undefined && it.quid !== null && it.quid !== "" ? "file-quid" : "file" };
      });
      return { name: n, items: items };
    });
    return { id: src.id, kind: "file", name: src.name || "", meta: meta, secs: secs, missing: missing, nFile: nFile, nD1: nD1, need: need.length };
  }, function (e) {
    authFail(e);
    return { id: src.id, err: "Could not load the quid questions from D1: " + A().failText(e) };
  });
}
function mark(v) {
  if (typeof v !== "string") return v;
  var m = U() && U().toMark ? U().toMark(v) : null;
  return m && m.ok ? m.v : v;
}
function fullQ(q, meta, id) {
  var o = clone(q);
  o.quiz_id = id;
  if (o.correct_score === undefined && meta.correct_score !== undefined) o.correct_score = meta.correct_score;
  if (o.negative_score === undefined && meta.negative_score !== undefined) o.negative_score = meta.negative_score;
  o.correct_score = mark(o.correct_score); o.negative_score = mark(o.negative_score);
  ["option_1", "option_2", "option_3", "option_4", "question", "solution_text"].forEach(function (k) {
    if (o[k] === undefined || o[k] === null) o[k] = { en: "", hi: "" };
    else if (typeof o[k] === "string") o[k] = { en: o[k], hi: "" };
  });
  return o;
}

/* ───────────────────────────── one view ───────────────────────────── */
function View(inline, host) {
  this.inline = !!inline; this.host = host || null;
  this.srcs = []; this.cur = 0; this.btns = []; this.cells = []; this.seen = {}; this.curIdx = -1;
  this.raf = 0; this.isOpen = false; this.pushed = false; this.token = 0; this.onClose = null;
  this.build();
}
View.prototype.q = function (sel) { return this.root.querySelector(sel); };
View.prototype.build = function () {
  var self = this, el = document.createElement("div");
  el.className = this.inline ? "rd-inline" : "rd-layer";
  if (!this.inline) { el.id = "rdLayer"; el.setAttribute("aria-modal", "true"); }
  el.hidden = true;
  el.setAttribute("role", this.inline ? "region" : "dialog");
  el.setAttribute("aria-label", "Rendered questions");
  el.innerHTML =
    '<header class="rd-head">' +
      '<button type="button" class="icon-btn rd-close" aria-label="' + (this.inline ? "Back to details" : "Close") + '" title="' + (this.inline ? "Back to details (Esc)" : "Close (Esc)") + '">' + SVG.back + "</button>" +
      '<div class="rd-head-txt"><div class="rd-title">Render Questions</div><div class="rd-sub"></div></div>' +
      '<div class="rd-head-tools">' +
        '<select class="rd-select rd-test" aria-label="Test"></select>' +
        '<select class="rd-select rd-lang" aria-label="Language"><option value="en">English</option><option value="hi">Hindi</option><option value="bilingual">Bilingual</option></select>' +
      "</div>" +
    "</header>" +
    '<div class="rd-body">' +
      '<div class="rd-scroll"><div class="rd-inner"></div></div>' +
      '<div class="rd-backdrop"></div>' +
      '<aside class="rd-pal" aria-label="Question palette">' +
        '<div class="rd-pal-head"><span class="rd-pal-title">Questions</span><span class="rd-pal-count"></span>' +
          '<button type="button" class="icon-btn rd-pal-close" aria-label="Close palette">' + SVG.x + "</button></div>" +
        '<div class="rd-pal-grid"></div>' +
        '<div class="rd-pal-legend"><span><i class="rd-dot seen"></i>Viewed</span><span><i class="rd-dot now"></i>Current</span></div>' +
      "</aside>" +
      '<button type="button" class="rd-fab" aria-label="Question palette" title="Question palette">' + SVG.list + "</button>" +
    "</div>";
  (this.inline ? this.host : document.body).appendChild(el);
  this.root = el;
  this.$list = this.q(".rd-inner"); this.$scroll = this.q(".rd-scroll"); this.$grid = this.q(".rd-pal-grid");
  this.$count = this.q(".rd-pal-count"); this.$sub = this.q(".rd-sub"); this.$test = this.q(".rd-test"); this.$lang = this.q(".rd-lang");
  if (!this.inline) {                                   // old ids (screenshots / tests use them)
    this.$list.id = "rdList"; this.$scroll.id = "rdScroll"; this.$grid.id = "rdPalGrid"; this.$test.id = "rdTest"; this.$lang.id = "rdLang";
    this.q(".rd-close").id = "rdClose"; this.q(".rd-fab").id = "rdFab"; this.q(".rd-pal").id = "rdPal";
  }
  this.$lang.value = LANG;
  this.q(".rd-close").addEventListener("click", function () { self.close(); });
  this.q(".rd-fab").addEventListener("click", function () { self.pal(); });
  this.q(".rd-pal-close").addEventListener("click", function () { self.pal(false); });
  this.q(".rd-backdrop").addEventListener("click", function () { self.pal(false); });
  this.$lang.addEventListener("change", function () {
    LANG = this.value;
    try { localStorage.setItem(LANG_KEY, LANG); } catch (e) {}
    allViews().forEach(function (v) { if (v !== self) v.$lang.value = LANG; });
    self.paint(true);
  });
  this.$test.addEventListener("change", function () { self.cur = +this.value || 0; self.paint(false); });
  this.$grid.addEventListener("click", function (ev) {
    var b = ev.target.closest("[data-rd-i]"); if (!b) return;
    self.jump(+b.getAttribute("data-rd-i"));
  });
  this.$list.addEventListener("click", function (ev) {
    var c = ev.target.closest("[data-rd-copy]");
    if (c) { ev.stopPropagation(); copy(c.getAttribute("data-rd-copy")); return; }
    if (ev.target.closest("[data-rd-retry]")) { delete CACHE[self.srcs[self.cur].ck]; self.paint(false); }
  });
  this.$scroll.addEventListener("scroll", function () { self.onScroll(); }, { passive: true });
};
/** palette as an always-on column? only the full-screen layer on a big screen */
View.prototype.column = function () { return !this.inline && mq(WIDE); };
View.prototype.open = function (srcs, start) {
  var list = [], seen = {};
  (srcs || []).map(normSrc).forEach(function (s) { if (s && !seen[s.ck]) { seen[s.ck] = 1; list.push(s); } });
  if (!list.length) return false;
  this.srcs = list;
  var si = 0;
  if (start !== undefined && start !== null && start !== "") list.forEach(function (s, i) { if (s.id === start || s.ck === start || s.key === start) si = i; });
  this.cur = typeof start === "number" && list[start] ? start : si;
  this.$test.innerHTML = list.map(function (s, i) { return '<option value="' + i + '">' + esc(s.id) + (s.kind === "file" ? " · file" : "") + "</option>"; }).join("");
  this.$test.value = String(this.cur);
  this.$test.hidden = list.length < 2;
  this.$lang.value = LANG;
  this.root.hidden = false;
  this.isOpen = true;
  if (this.inline) {
    this.host.classList.add("rd-in-on");
    this.host.scrollTop = 0;
  } else {
    document.body.classList.add("rd-open");
    if (!this.pushed) { try { history.pushState({ mmhRender: 1 }, ""); this.pushed = true; } catch (e) {} }
  }
  this.paint(false);
  return true;
};
View.prototype.close = function (fromPop) {
  if (!this.isOpen) return;
  this.isOpen = false;
  this.token++;
  this.pal(false);
  this.root.hidden = true;
  this.$list.innerHTML = ""; this.$grid.innerHTML = ""; this.cells = []; this.btns = [];
  if (this.inline) this.host.classList.remove("rd-in-on");
  else {
    document.body.classList.remove("rd-open");
    if (this.pushed) { this.pushed = false; if (!fromPop) { try { history.back(); } catch (e) {} } }
  }
  if (typeof this.onClose === "function") { var f = this.onClose; this.onClose = null; f(); }
};
View.prototype.pal = function (on) {
  if (on === undefined) on = !this.root.classList.contains("rd-pal-open");
  if (on && this.column()) on = false;                 // big-screen layer: always a column
  this.root.classList.toggle("rd-pal-open", !!on);
};
View.prototype.paint = function (keepScroll) {
  var self = this, src = this.srcs[this.cur], sc = this.$scroll, list = this.$list;
  if (!src) return;
  var top = keepScroll ? sc.scrollTop : 0, tok = ++this.token;
  this.btns = []; this.cells = []; this.seen = {}; this.curIdx = -1;
  this.$grid.innerHTML = ""; this.$count.textContent = "";
  this.$sub.textContent = src.id;
  var c = CACHE[src.ck];
  if (!c || c.err) {
    list.innerHTML = '<div class="rd-state"><span class="up-spin"></span><p>' +
      (src.kind === "file" ? "Reading " + esc(src.id) + " (file + quid questions from D1)…" : "Loading " + esc(src.id) + " from R2 + D1…") + "</p></div>";
  }
  load(src).then(function (t) {
    if (tok !== self.token || !self.isOpen) return;
    if (t.err) {
      list.innerHTML = '<div class="rd-state bad"><p><b>' + esc(src.id) + "</b></p><p>" + esc(t.err) + "</p>" +
        (t.perm ? "" : '<button type="button" class="rq-btn" data-rd-retry="1">' + SVG.retry + "<span>Try again</span></button>") + "</div>";
      return;
    }
    self.cards(t, src);
    sc.scrollTop = top;
    self.onScroll();
  }).catch(function () {});
};
function srcTag(from) {
  if (from === "d1") return '<span class="rd-src d1" title="Text loaded from D1 (quid item in the file)">D1</span>';
  if (from === "file-quid") return '<span class="rd-src file" title="Full question in the file (has a quid)">File</span>';
  if (from === "file") return '<span class="rd-src new" title="New question — full text in the file">New</span>';
  return "";
}
View.prototype.cards = function (t, src) {
  var list = this.$list, grid = this.$grid, lang = this.$lang.value || LANG;
  var total = t.secs.reduce(function (s, x) { return s + x.items.length; }, 0);
  var meta = t.meta || {}, title = meta.title || meta.name, isFile = t.kind === "file";
  this.$sub.textContent = t.id + " · " + plural(total, "question") + (isFile ? " · file" : "");
  this.$count.textContent = String(total);
  var chips = "";
  if (isFile) {
    chips += '<span class="up-chip rd-chip-file">From file</span>' + (src.badge || "");
    if (t.nFile) chips += '<span class="up-chip">' + t.nFile + " from file</span>";
    if (t.nD1 || t.need) chips += '<span class="up-chip">' + t.nD1 + " from D1</span>";
  } else {
    chips += t.row ? '<span class="up-chip live">Live</span><span class="up-chip ' + (Number(t.row.is_free) === 1 ? "free" : "paid") + '">' + (Number(t.row.is_free) === 1 ? "Free" : "Paid") + '</span><span class="up-chip">' + esc(A().verTxt(t.row.ver)) + "</span>" : '<span class="up-chip is-hidden">Hidden</span>';
  }
  chips += '<span class="up-chip">' + plural(t.secs.length, "section") + "</span>";
  var frag = document.createDocumentFragment();
  var head = document.createElement("div");
  head.className = "rd-intro";
  head.innerHTML = '<div class="rd-intro-id">' + esc(t.id) + "</div>" + (title ? '<div class="rd-intro-title">' + esc(title) + "</div>" : "") +
    (isFile && t.name ? '<div class="rd-intro-file">' + esc(t.name) + "</div>" : "") +
    '<div class="rd-intro-chips">' + chips + "</div>" +
    (isFile ? '<div class="rd-intro-note">Full questions = text from the file · <b>[id, quid]</b> items = text from D1' + (t.nD1 || t.need ? "" : " (none in this file)") + "</div>" : "") +
    (t.missing.length ? '<div class="up-box warn" style="margin-top:10px"><p>' + plural(t.missing.length, "quid") + " not found in D1" + (isFile ? "" : " — not shown") + ": " + esc(t.missing.slice(0, 6).join(", ")) + (t.missing.length > 6 ? " …" : "") + "</p></div>" : "");
  frag.appendChild(head);
  var palHtml = "", gi = 0, self = this;
  t.secs.forEach(function (s) {
    var h = document.createElement("div");
    h.className = "rd-sec";
    h.innerHTML = "<b>" + esc(s.name) + "</b><span>" + plural(s.items.length, "question") + "</span>";
    frag.appendChild(h);
    var ql = document.createElement("div");
    ql.className = "q-list rd-qlist";
    palHtml += '<div class="rd-pal-sec"><div class="rd-pal-name" title="' + esc(s.name) + '">' + esc(s.name) + '</div><div class="rd-pal-btns">';
    s.items.forEach(function (it, qi) {
      var cell = document.createElement("div");
      cell.className = "q-cell rd-cell";
      cell.setAttribute("data-rd-cell", gi);
      var q = it.q, quid = q ? q.quid : it.quid, lid = q ? q.id : it.lid;
      var extra = (isFile ? srcTag(it.from) : "") +
        (quid ? '<button type="button" class="ar-quid" data-rd-copy="' + esc(quid) + '" title="Copy quid">' + esc(quid) + SVG.copy + "</button>" : "") +
        '<span class="rd-lid">id ' + esc(lid) + "</span>";
      var card;
      if (!q) {
        card = document.createElement("div");
        card.className = "quiz-card mmh-card rd-miss";
        card.innerHTML = '<div class="mmh-card-head"><div class="mmh-card-num">' + (qi + 1) + '</div><div class="mmh-card-head-extra">' + extra + '</div></div><div class="up-err">quid ' + esc(quid) + " is not in D1 — nothing to show.</div>";
      } else {
        try {
          card = window.mmhRenderCard(fullQ(q, meta, t.id), {
            lang: lang, quizId: t.id, index: qi + 1, total: 0,
            mode: "solution", allowSolution: false, solutionOpen: true, showPercent: false, onPick: null, headExtra: extra
          });
        } catch (e) {
          card = document.createElement("div");
          card.className = "quiz-card mmh-card";
          card.innerHTML = '<div class="mmh-card-head"><div class="mmh-card-num">' + (qi + 1) + '</div><div class="mmh-card-head-extra">' + extra + '</div></div><div class="up-err">Render failed: ' + esc(e.message) + "</div>";
        }
      }
      cell.appendChild(card);
      ql.appendChild(cell);
      palHtml += '<button type="button" class="qbtn' + (!q ? " rd-q-miss" : "") + '" data-rd-i="' + gi + '">' + (qi + 1) + "</button>";
      gi++;
    });
    palHtml += "</div></div>";
    frag.appendChild(ql);
  });
  if (!gi) { var em = document.createElement("div"); em.className = "rd-state"; em.innerHTML = "<p>No questions.</p>"; frag.appendChild(em); }
  list.innerHTML = "";
  list.appendChild(frag);
  grid.innerHTML = palHtml;
  this.cells = Array.prototype.slice.call(list.querySelectorAll(".rd-cell"));
  this.btns = Array.prototype.slice.call(grid.querySelectorAll(".qbtn"));
  typeset(list);
};
View.prototype.jump = function (i) {
  var c = this.cells[i], sc = this.$scroll; if (!c) return;
  sc.scrollTop += c.getBoundingClientRect().top - sc.getBoundingClientRect().top - 46;
  c.classList.remove("q-cell-flash"); void c.offsetWidth; c.classList.add("q-cell-flash");
  setTimeout(function () { c.classList.remove("q-cell-flash"); }, 1200);
  if (!this.column()) this.pal(false);
};
View.prototype.onScroll = function () {
  var self = this;
  if (this.raf) return;
  this.raf = requestAnimationFrame(function () {
    self.raf = 0;
    if (!self.cells.length) return;
    var sc = self.$scroll, r = sc.getBoundingClientRect(), mid = r.top + r.height * 0.55, line = r.top + 70, cur = -1;
    for (var i = 0; i < self.cells.length; i++) {
      var b = self.cells[i].getBoundingClientRect();
      if (b.top < mid) self.seen[i] = true;
      if (cur === -1 && b.bottom > line) cur = i;
      if (b.top > r.bottom) break;
    }
    if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4) { for (var k = 0; k < self.cells.length; k++) self.seen[k] = true; }
    self.curIdx = cur;
    self.btns.forEach(function (b, j) { b.classList.toggle("seen", !!self.seen[j] && j !== cur); b.classList.toggle("current", j === cur); });
    var cb = self.btns[cur];
    if (cb && (self.column() || self.root.classList.contains("rd-pal-open"))) {
      var g = self.$grid, gr = g.getBoundingClientRect(), br = cb.getBoundingClientRect();
      if (br.top < gr.top || br.bottom > gr.bottom) g.scrollTop += br.top - gr.top - gr.height / 2;
    }
  });
};

/* ───────────────────────────── helpers ───────────────────────────── */
function typeset(el) {
  if (window.MathJax && MathJax.typesetPromise) { MathJax.typesetPromise([el]).catch(function () { if (typeof window.renderMath === "function") window.renderMath(); }); }
  else if (typeof window.renderMath === "function") window.renderMath();
}
function copy(t) {
  var done = function () { toast("Copied " + t); };
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, function () { fallbackCopy(t); done(); }); return; }
  } catch (e) {}
  fallbackCopy(t); done();
}
function fallbackCopy(t) {
  var ta = document.createElement("textarea"); ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0";
  document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (e) {} ta.remove();
}
function ready() {
  if (typeof window.mmhRenderCard !== "function" || !U() || !A()) { toast("Render files missing"); return false; }
  return true;
}
function allViews() { return (LAYER ? [LAYER] : []).concat(INLINE); }
function layer() { if (!LAYER) LAYER = new View(false); return LAYER; }
function inlineFor(host) {
  for (var i = 0; i < INLINE.length; i++) if (INLINE[i].host === host) return INLINE[i];
  var v = new View(true, host); INLINE.push(v); return v;
}
function closeAll() { allViews().forEach(function (v) { v.close(); }); }

/* ───────────────────────────── public ───────────────────────────── */
/** open(["ID", …], startId?) — full-screen layer, live tests */
function open(ids, start) {
  if (!ready()) return;
  layer().open((ids || []).map(function (s) { return String(s).trim(); }), start);
}
/** show(sources, { host, start, onClose }) — inline in host (big screen) or the layer */
function show(srcs, o) {
  o = o || {};
  if (!ready()) return;
  var v = o.host && paneScreen() ? inlineFor(o.host) : layer();
  if (v.open(srcs, o.start)) v.onClose = o.onClose || null;
}
function closeIn(host) { INLINE.forEach(function (v) { if (!host || v.host === host) v.close(); }); }
function isOpenIn(host) { return INLINE.some(function (v) { return v.host === host && v.isOpen; }); }
/** forget a cached file render (file replaced / list cleared) */
function forget(key) { delete CACHE["file:" + key]; }

document.addEventListener("click", function (ev) {
  var b = ev.target.closest && ev.target.closest("[data-render]");
  if (!b || b.disabled) return;
  ev.preventDefault();
  open(b.getAttribute("data-render").split(","), b.getAttribute("data-render-start") || "");
});
document.addEventListener("keydown", function (ev) {
  if (ev.key !== "Escape") return;
  var v = LAYER && LAYER.isOpen ? LAYER : INLINE.filter(function (x) { return x.isOpen && x.host.offsetParent !== null; })[0];
  if (!v) return;
  if (document.getElementById("upSheet") && !document.getElementById("upSheet").hidden) return;
  if (v.root.classList.contains("rd-pal-open")) v.pal(false); else v.close();
});
window.addEventListener("popstate", function () { if (LAYER && LAYER.isOpen) LAYER.close(true); });
if (window.matchMedia) {
  var wq = window.matchMedia(WIDE);
  var onWide = function () {
    if (LAYER && LAYER.column()) LAYER.pal(false);
    if (!paneScreen()) closeIn();                      // the side pane is gone → inline views close
  };
  if (wq.addEventListener) wq.addEventListener("change", onWide); else if (wq.addListener) wq.addListener(onWide);
}
window.MMHRender = { open: open, show: show, close: function () { if (LAYER) LAYER.close(); }, closeIn: closeIn, isOpenIn: isOpenIn, forget: forget,
  _views: allViews, _cache: CACHE };
})();

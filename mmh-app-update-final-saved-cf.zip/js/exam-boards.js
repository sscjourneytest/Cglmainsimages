/* ══ MMH exam routing helper — IDENTICAL copy in js/exam-engine.js, js/ssc-sub-engine.js
   and js/exam-boards.js (first one loaded wins). Source: dev/turn172/mmh-exam-helper.js
   Query pages (no exam folders needed — a new exam = only website JSON):
     /exams/mocks.html?cgl&b=ssc                  full mocks      (exam-engine.js)
     /exams/chapters-wise.html?ssc-sub&b=ssc      chapter wise    (ssc-sub-engine.js)
     /exams/chapter-wise-exam.html?exam-ssc-sub&b=ssc  exam wise  (+ exam-sub-addon.js)
   · exam name = first query key that is not filter / b / a tracking param
                 (fbclid, gclid, utm_*…); old folder pages → the folder name
   · b         = board id → /data/exams/<b>.json; the item's "data" file wins,
                 else <exam>-data.json
   · worker    = cloudflare-config key with EXACTLY the exam name
                 (else paths[<exam>].worker)
   · data      = https://data.mockmatrixhub.in/data/… only (board dataBase / full URL in "data" can override)
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
    if (window.MMHExam) return;
    var TRACK = /^(fbclid|gclid|gbraid|wbraid|dclid|msclkid|yclid|twclid|ttclid|igshid|igsh|li_fat_id|mc_cid|mc_eid|_ga|_gl|ref|si|utm_[a-z0-9_]*)$/i;
    var DATA_BASE = 'https://data.mockmatrixhub.in/data/';
    var BOARD_DIR = '/data/exams/';
    var SITE = 'https://mockmatrixhub.in';

    function parts() { var s = String(location.search || '').replace(/^\?/, ''); return s ? s.split('&').filter(Boolean) : []; }
    function keyOf(p) { var k = String(p).split('=')[0]; try { k = decodeURIComponent(k.replace(/\+/g, ' ')); } catch (e) {} return k; }
    function isTrack(k) { return TRACK.test(k); }
    function copy(o) { var r = {}; for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }

    /* exam token + b (+ any other real param) — never filter / tracking params */
    function query() {
        return parts().filter(function (p) { var k = keyOf(p); return k && k !== 'filter' && !isTrack(k); }).join('&');
    }
    function name() {
        if (window.__EXAM_NAME__) return window.__EXAM_NAME__;
        var ks = parts().map(keyOf).filter(function (k) { return k && k !== 'filter' && k !== 'b' && !isTrack(k); });
        if (ks.length) return ks[0];
        var seg = location.pathname.split('/'), f = seg[seg.length - 2] || '';
        return (f === 'exams' || f === 'series') ? '' : f;
    }
    function board() {
        var v = '';
        try { v = new URLSearchParams(location.search).get('b') || ''; } catch (e) {}
        v = String(v).toLowerCase();
        return /^[a-z0-9_-]{1,40}$/.test(v) ? v : '';
    }
    function isQueryPage() { return /^\/exams\/[^\/]+\.html$/i.test(location.pathname) && !/\/(index|test)\.html$/i.test(location.pathname); }
    function home() { var b = board(); return '/exams/index.html' + (b ? '?b=' + encodeURIComponent(b) : ''); }
    /* does this quiz id belong to this exam? (CGL-2025-… → cgl) — prefix, never "contains" */
    function owns(id, exam) {
        var l = String(id || '').toLowerCase(), e = String(exam || '').toLowerCase();
        return !!e && (l === e || l.indexOf(e + '-') === 0);
    }
    /* attempts worker — EXACT exam-name key only */
    function workerUrl(cfg, exam) {
        if (!cfg || !exam) return null;
        var k = String(exam).toLowerCase();
        if (typeof cfg[k] === 'string' && cfg[k]) return cfg[k];
        var p = cfg.paths && cfg.paths[k];
        if (p && typeof p === 'object' && p.worker) {
            var w = String(p.worker);
            return /^https?:\/\//i.test(w) ? w : (typeof cfg[w] === 'string' ? cfg[w] : null);
        }
        return null;
    }

    /* ── data files: data.mockmatrixhub.in (or the board's own dataBase) ── */
    function absUrl(file, base) { return /^https?:\/\//i.test(file) ? String(file) : String(base || DATA_BASE) + String(file).replace(/^\/+/, ''); }
    function bust(u) { return u + (u.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now(); }
    function dataUrls(file, base) {
        if (/^https?:\/\//i.test(file)) return [String(file)];
        var out = [];
        [base, DATA_BASE].forEach(function (b) { if (!b) return; var u = absUrl(file, b); if (out.indexOf(u) < 0) out.push(u); });
        return out;
    }
    async function fetchData(file, base) {
        var list = dataUrls(file, base), err = null;
        for (var i = 0; i < list.length; i++) {
            try {
                var r = await fetch(bust(list[i]));
                if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + list[i]);
                return { json: await r.json(), url: list[i] };
            } catch (e) { err = e; }
        }
        throw err || new Error('Could not load ' + file);
    }
    function dataFileFor(item, exam) {
        var d = item && typeof item.data === 'string' ? item.data.trim() : '';
        return d || (exam + '-data.json');
    }

    /* ── board files: /data/exams/boards.json + /data/exams/<board>.json ── */
    var memo = {};
    function getJSON(url) {
        if (memo[url]) return memo[url];
        var f = (typeof window.fetchLiveFirst === 'function') ? window.fetchLiveFirst(url) : fetch(url, { cache: 'no-store' });
        memo[url] = Promise.resolve(f).then(function (r) {
            if (!r || !r.ok) throw new Error('HTTP ' + (r ? r.status : 0) + ' ' + url);
            return r.json();
        }).catch(function (e) { delete memo[url]; throw e; });
        return memo[url];
    }
    function boards() { return getJSON(BOARD_DIR + 'boards.json'); }
    function boardFile(b) { return b ? getJSON(BOARD_DIR + b + '.json') : Promise.resolve(null); }
    /* every board merged into the old exam-categories shape: { categories:[{…board, items:[…]}] } */
    function all() {
        return boards().then(function (bj) {
            var list = (bj && bj.boards) || [];
            return Promise.all(list.map(function (b) {
                if (!b || !b.id || b.comingSoon) return null;
                return boardFile(b.id).catch(function () { return null; });
            })).then(function (files) {
                return { categories: list.map(function (b, i) {
                    var f = files[i] || {}, c = copy(b);
                    c.items = ((f && f.items) || []).map(function (it) {
                        var o = copy(it); o._board = b.id; o._dataBase = (f && f.dataBase) || ''; return o;
                    });
                    return c;
                }) };
            });
        });
    }
    function examOfUrl(url) {
        var u = String(url || ''), q = u.indexOf('?'), h = u.indexOf('#');
        var end = q >= 0 ? q : (h >= 0 ? h : u.length);
        if (q >= 0) {
            var qs = u.slice(q + 1, h > q ? h : u.length).split('&');
            for (var i = 0; i < qs.length; i++) {
                var k = keyOf(qs[i]);
                if (k && k !== 'filter' && k !== 'b' && !isTrack(k)) return k.toLowerCase();
            }
        }
        var m = /\/exams\/([^\/?#]+)\/(index\.html)?$/i.exec(u.slice(0, end));
        return m ? m[1].toLowerCase() : '';
    }
    function item(exam, b) {
        var e = String(exam || '').toLowerCase();
        if (!e || !b) return Promise.resolve(null);
        return boardFile(b).then(function (f) {
            var list = (f && f.items) || [], it = null;
            for (var i = 0; i < list.length && !it; i++) if (list[i] && examOfUrl(list[i].url) === e) it = list[i];
            for (var j = 0; j < list.length && !it; j++) if (list[j] && String(list[j].id || '').toLowerCase() === e) it = list[j];
            if (!it) return null;
            var o = copy(it); o._board = b; o._dataBase = (f && f.dataBase) || ''; return o;
        }).catch(function () { return null; });
    }

    /* ── website SEO for query pages: title · description · canonical · og:* ── */
    function seo(o) {
        try {
            o = o || {};
            if (o.title) document.title = o.title;
            var meta = function (attr, key, val) {
                if (!val) return;
                var m = document.head.querySelector('meta[' + attr + '="' + key + '"]');
                if (!m) { m = document.createElement('meta'); m.setAttribute(attr, key); document.head.appendChild(m); }
                m.setAttribute('content', val);
            };
            meta('name', 'description', o.description);
            meta('property', 'og:type', 'website');
            meta('property', 'og:site_name', 'Mock Matrix Hub');
            meta('property', 'og:title', o.title);
            meta('property', 'og:description', o.description);
            var c = o.canonical;
            if (!c && isQueryPage()) { var n = name(), b = board(); c = location.pathname + '?' + n + (b ? '&b=' + b : ''); }
            if (c) {
                c = /^https?:\/\//i.test(c) ? c : SITE + (c.charAt(0) === '/' ? c : '/' + c);
                var l = document.head.querySelector('link[rel="canonical"]');
                if (!l) { l = document.createElement('link'); l.rel = 'canonical'; document.head.appendChild(l); }
                l.href = c;
                meta('property', 'og:url', c);
            }
        } catch (e) { /* cosmetic */ }
    }
    var ACRO = { SSC:1, CGL:1, CHSL:1, MTS:1, CPO:1, GD:1, PYQ:1, PYQS:1, RRB:1, NTPC:1, ALP:1, UG:1, JE:1, CBT:1, RPF:1, SI:1, IB:1, ACIO:1, DSSSB:1, ASO:1, JJA:1, TGT:1, PGT:1, PRT:1, II:1, III:1 };
    function pretty(t) {
        return String(t || '').replace(/\s+/g, ' ').trim().replace(/[A-Za-z]+/g, function (w) {
            var u = w.toUpperCase();
            if (ACRO[u]) return u;
            return (w === u || w === w.toLowerCase()) ? u.charAt(0) + u.slice(1).toLowerCase() : w;
        });
    }

    /* live copy of a board file landed (app live-json layer) → refresh the memo */
    window.addEventListener('mmh-live-json-updated', function (ev) {
        var d = (ev && ev.detail) || {}, p = String(d.path || '');
        if (!d.data || p.indexOf(BOARD_DIR) !== 0) return;
        memo[p] = Promise.resolve(d.data);
        try { window.dispatchEvent(new CustomEvent('mmh-exams-updated', { detail: { path: p } })); } catch (e) {}
    });

    window.MMHExam = {
        query: query, name: name, board: board, home: home, isQueryPage: isQueryPage, owns: owns, workerUrl: workerUrl,
        fetchData: fetchData, dataUrls: dataUrls, dataFileFor: dataFileFor,
        boards: boards, boardFile: boardFile, all: all, item: item, examOfUrl: examOfUrl,
        seo: seo, pretty: pretty, DATA_BASE: DATA_BASE
    };
})();

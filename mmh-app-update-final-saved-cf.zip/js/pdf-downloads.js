/* ═══════════════════════════════════════════════════════════════════════
   MMH — MY DOWNLOADS  (/pdfs/downloads.html)   app only
   Works fully OFFLINE (reads the local index; live JSON only to spot new
   versions when online).  All | Free | Premium tabs, storage used,
   Open · Export (free → phone) · Update · Renew · Delete · Delete all.
   Website: shows "My Downloads is in the app" + Google Play.
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    var M = window.MMHPdf, ST = window.MMHPdfStore, I = M.I, esc = M.esc;
    var app = M.isApp() && ST && ST.supported();
    var tab = M.qs('t') || 'all', root = null, live = {};
    var $ = function (x) { return document.getElementById(x); };

    function boot() {
        M.wireTheme();
        $('pdfBack').addEventListener('click', function () { location.href = M.qs('from') === 'home' ? '/index.html' : '/pdfs/index.html?f=free'; });
        M.dock('downloads', app ? ST.list().length : 0);
        if (!app) return website();
        render();
        $('pdfMain').addEventListener('click', onClick);
        $('pdfTabs').addEventListener('click', function (e) {
            var t = e.target.closest('[data-t]'); if (!t) return;
            tab = t.getAttribute('data-t');
            try { history.replaceState(null, '', '/pdfs/downloads.html' + (tab !== 'all' ? '?t=' + tab : '')); } catch (x) {}
            render();
        });
        if (navigator.onLine !== false) checkVersions();
        window.addEventListener('mmhpdf:changed', function (e) {
            render(); M.dock('downloads', ST.list().length);
            if (e.detail && e.detail.removed) M.toast('Premium ended — premium PDFs removed');
        });
    }
    function website() {
        $('pdfTabs').hidden = true;
        $('pdfMain').innerHTML = '<div class="pdf-empty"><div class="e-ico c-green">' + I.phone + '</div><h3>My Downloads is in the app</h3>' +
            '<p>Save PDFs inside the official Mock Matrix Hub app and read them offline — free PDFs anytime, premium PDFs securely inside the app.</p>' +
            '<div style="max-width:300px;margin:20px auto 0"><a class="play-btn" href="' + M.PLAY_URL + '" target="_blank" rel="noopener">' + I.play + '<span><small>GET IT ON</small><b>Google Play</b></span></a></div></div>';
    }

    /* live JSON (online only) → new versions + config for renew */
    function checkVersions() {
        var groups = {};
        ST.list().forEach(function (e) { if (e.f) groups[e.f] = 1; });
        Object.keys(groups).forEach(function (f) {
            M.resolve(f).then(function (res) {
                root = res;
                M.visible(res.node.items).forEach(function (n) { if (!M.isFolder(n)) { live[n.id] = n; ST.noteLive(n.id, Number(n.v) || 1); } });
                render();
            }).catch(function () {});
        });
    }

    function render() {
        var all = ST.list(), u = ST.usage();
        var counts = { all: all.length, free: u.nFree, paid: u.nPaid };
        $('pdfTabs').innerHTML = [['all', 'All'], ['free', 'Free'], ['paid', 'Premium']].map(function (t) {
            return '<button type="button" class="live-tab' + (tab === t[0] ? ' active' : '') + '" data-t="' + t[0] + '"' + (t[0] === 'paid' && tab === 'paid' ? ' data-tab="paid"' : '') + '>' +
                '<span>' + t[1] + '</span><span class="tab-count">' + counts[t[0]] + '</span></button>';
        }).join('');
        $('pdfSub').textContent = u.count ? u.count + ' file' + (u.count === 1 ? '' : 's') + ' · ' + M.fmtBytes(u.bytes) : 'Saved inside the app';
        M.dock('downloads', u.count);
        if (!all.length) {
            $('pdfMain').innerHTML = '<div class="pdf-empty"><div class="e-ico">' + I.dlbox + '</div><h3>No downloads yet</h3>' +
                '<p>Tap <b>Download</b> on any PDF — it is saved inside the app and opens without internet.</p>' +
                '<a class="pc-btn dl" href="/pdfs/index.html?f=free">' + I.search + '<span>Browse PDFs</span></a></div>';
            return;
        }
        var list = tab === 'all' ? all : ST.list(tab);
        var pf = u.bytes ? Math.round(u.free * 100 / u.bytes) : 0;
        var h = '<div class="dl-usage"><div class="u-ico c-blue">' + I.storage + '</div><div class="u-main">' +
            '<div class="u-title">' + M.fmtBytes(u.bytes) + ' used</div><div class="u-sub">' + u.nFree + ' free · ' + u.nPaid + ' premium</div>' +
            '<div class="u-bar"><i style="width:' + pf + '%;background:#10b981"></i><i style="width:' + (100 - pf) + '%;background:#f59e0b"></i></div>' +
            '<div class="dl-legend"><span><i style="background:#10b981"></i>Free ' + M.fmtBytes(u.free) + '</span><span><i style="background:#f59e0b"></i>Premium ' + M.fmtBytes(u.paid) + '</span></div></div>' +
            '<button type="button" class="u-del" data-act="delall">Delete all</button></div>';
        if (!list.length) h += '<div class="pdf-empty" style="padding-top:24px"><h3>Nothing here</h3><p>No ' + (tab === 'paid' ? 'premium' : 'free') + ' PDFs saved yet.</p></div>';
        else h += '<div class="pdf-cards">' + list.map(card).join('') + '</div>';
        h += '<div class="dl-note">' + I.shield + '<span>Files stay in the app’s private storage (not in Gallery / Files). Premium PDFs are encrypted and open only in this app, for this account. Export copies a <b>free</b> PDF to your phone.</span></div>';
        $('pdfMain').innerHTML = h;
    }
    function card(e) {
        var n = live[e.id], st = ST.status(e, n ? Number(n.v) || 1 : 0), paid = e.kind === 'paid';
        var meta = [e.pages ? '<span>' + I.pages + e.pages + ' pages</span>' : '', '<span>' + I.size + M.fmtBytes(e.size) + '</span>',
            '<span>' + I.calendar + 'Saved ' + M.fmtDate(e.at) + '</span>'].join('');
        var second;
        if (st.state === 'update') second = '<button type="button" class="pc-btn upd" data-act="update">' + I.refresh + '<span>Update</span></button>';
        else if (st.state === 'expired' || st.state === 'clock') second = '<button type="button" class="pc-btn upd" data-act="renew">' + I.refresh + '<span>Renew</span></button>';
        else if (!paid) second = '<button type="button" class="pc-btn dl" data-act="export">' + I.export + '<span>Export</span></button>';
        else second = '<button type="button" class="pc-btn danger" data-act="del">' + I.trash + '<span>Delete</span></button>';
        var stTxt = st.state === 'update' ? '<span class="pc-state warn">' + I.refresh + 'New version available</span>'
            : st.state === 'expired' ? '<span class="pc-state bad">' + I.lock + 'Locked — renew online</span>'
            : st.state === 'clock' ? '<span class="pc-state bad">' + I.clock + 'Phone time changed — renew online</span>'
            : paid ? '<span class="pc-state ok">' + I.lock + 'Saved securely</span>'
            : '<span class="pc-state ok">' + I.check + 'Saved</span>';
        return '<div class="pc-card' + (paid ? ' is-paid' : '') + '" data-id="' + esc(e.id) + '">' +
            '<div class="pc-top' + (!e.sub && !e.crumb ? ' solo' : '') + '"><div class="pc-thumb">' + I.file + '<b>PDF</b></div><div class="pc-info">' +
            (e.crumb ? '<div class="pc-path">' + esc(e.crumb) + '</div>' : '') + '<div class="pc-title">' + esc(e.title) + '</div>' +
            (e.sub ? '<div class="pc-sub">' + esc(e.sub) + '</div>' : '') + '</div>' +
            '<div class="pc-badges"><span class="badge-type ' + (paid ? 'paid-badge">PREMIUM' : 'free-badge">FREE') + '</span></div></div>' +
            '<div class="lv-meta">' + meta + '</div>' +
            '<div class="pc-actions"><button type="button" class="pc-btn open" data-act="open">' + I.open + '<span>Open</span></button>' + second + '</div>' +
            '<div class="lv-foot">' + stTxt + '<span class="pc-foot-btns">' +
            (paid && second.indexOf('data-act="del"') >= 0 ? '' : '<button type="button" class="pc-icon-btn del" data-act="del" aria-label="Delete" title="Delete">' + I.trash + '</button>') +
            '<button type="button" class="lv-share" data-act="share" aria-label="Share" title="Share link">' + I.share + '</button></span></div></div>';
    }

    function ctxFor(e) { return { cfg: root ? root.cfg : M.cfg(null), f: e.f, crumb: e.crumb, plan: e.plan || 'premium' }; }
    function onClick(ev) {
        var b = ev.target.closest('[data-act]'); if (!b) return;
        var act = b.getAttribute('data-act');
        if (act === 'delall') return confirmDel(null);
        var c = b.closest('.pc-card'), id = c && c.getAttribute('data-id'), e = id && ST.get(id);
        if (!e) return;
        if (act === 'open') {
            var st = ST.status(e, live[id] ? Number(live[id].v) || 1 : 0);
            if (st.state === 'expired' || st.state === 'clock') return renew(b, e);
            location.href = '/pdfs/view.html?f=' + (e.f || '') + '&id=' + encodeURIComponent(id) + '&from=dl'; return;
        }
        if (act === 'del') return confirmDel(e);
        if (act === 'share') return M.share(e.title, M.shareUrl(root ? root.cfg : null, e.f || 'free', id));
        if (act === 'export') {
            ST.exportFree(id).then(function (r) { if (r && r.where !== 'share') M.toast('Saved to ' + r.where); })
                .catch(function () { M.toast('Could not export — try again', 'error'); });
            return;
        }
        if (act === 'renew') return renew(b, e);
        if (act === 'update') {
            var n = live[id]; if (!n) return M.toast('Connect to the internet to update', 'error');
            spin(b, 'Updating…');
            (e.kind === 'paid' ? ST.downloadPaid : ST.downloadFree)(n, ctxFor(e), function (g, t) { if (t) spin(b, 'Updating ' + Math.min(99, Math.round(g * 100 / t)) + '%'); })
                .then(function () { M.toast('Updated to the latest version'); render(); })
                .catch(function (er) { M.toast(er && er.code === 'offline' ? "You're offline" : 'Update failed — try again', 'error'); render(); });
        }
    }
    function spin(b, t) { b.classList.add('busy'); b.innerHTML = I.refresh + '<span>' + t + '</span>'; }
    function renew(b, e) {
        if (navigator.onLine === false) return M.toast('Connect to the internet to renew', 'error');
        spin(b, 'Renewing…');
        ST.renew(e.id, live[e.id], ctxFor(e)).then(function () { M.toast('Renewed — opens offline again'); render(); })
            .catch(function (er) { M.toast(er && er.code === 'buy' ? 'Premium ended — premium PDFs removed' : 'Could not renew — try again', 'error'); render(); });
    }
    function confirmDel(e) {
        var u = ST.usage();
        M.sheet({
            icon: 'trash', iconCls: 'c-rose',
            title: e ? 'Delete this PDF?' : 'Delete all downloads?',
            text: e ? (e.kind === 'paid' ? 'It will be removed from this phone. You can download it again anytime while your premium is active.' : 'It will be removed from this phone. You can download it again anytime.')
                : 'All ' + u.count + ' PDFs (' + M.fmtBytes(u.bytes) + ') will be removed from this phone.',
            body: e ? M.fileBox({ title: e.title, pages: e.pages, size: M.fmtBytes(e.size) }, e.kind === 'paid') : '',
            actions: [
                { label: e ? 'Delete' : 'Delete all', cls: 'danger', icon: 'trash', onClick: function () {
                    (e ? ST.remove(e.id) : ST.removeAll()).then(function () { M.toast(e ? 'Deleted' : 'All downloads deleted'); render(); });
                } },
                { label: 'Cancel', cls: 'ghost' }
            ]
        });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* ═══════════════════════════════════════════════════════════════════════
   MMH PDF VIEWER  (/pdfs/view.html?f=<folder path>&id=<pdf id>)
   Official PDF.js viewer component (pdfjs-dist 6.4.299 legacy, /pdfjs/web/)
   The PDF is shown EXACTLY as uploaded — nothing is drawn on the pages
   (no header, no page number, no watermark).

   • Free, not saved   → streamed with HTTP Range (first page shows fast)
   • Free, saved       → from app storage, 0 network
   • Premium, saved    → decrypted in memory from My Downloads, 0 network
   • Premium, not saved→ "Open" = this app session only (1 Worker call + 1 file
                         into the cache dir; wiped when the app is closed)
   • Premium (website) → "open in the app" panel
   Features: search inside the PDF (highlight all + next / previous + count),
   go to page, working PDF links (table of contents / internal + web links),
   Drive-style side scroller with page bubble, pinch zoom (phones),
   Ctrl + wheel / Ctrl +/- zoom (desktop), resume last page.
   Header: search icon → search bar under the header.
   Blue ☰ button: Download · Export (free, app) · Share · Go to page.
   Screenshot block (PrivacyScreen) for premium only.
   Big PDFs: only the pages on screen are drawn (PDF.js keeps ~10 pages),
   canvas size capped on phones, free files streamed with Range (only the
   needed parts), premium decrypted chunk-by-chunk (~1× RAM).
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    var M = window.MMHPdf, ST = window.MMHPdfStore, I = M.I, esc = M.esc;
    var app = M.isApp() && ST && ST.supported();
    var f = (M.qs('f') || '').replace(/^\/+|\/+$/g, ''), id = M.qs('id') || '', fromDl = M.qs('from') === 'dl';
    var V = { node: null, paid: false, plan: 'premium', cfg: null, entry: null, session: false, crumb: '',
        pdf: null, viewer: null, bus: null, n: 0, cur: 1, fit: 'auto' };
    var $ = function (x) { return document.getElementById(x); };
    var POS = 'mmh_pdf_pos_';
    var fine = !!(window.matchMedia && matchMedia('(hover:hover) and (pointer:fine)').matches);
    var lib = null, VW = null;

    function head(title, sub) {
        $('pvTitle').textContent = title;
        document.title = title + ' — Mock Matrix Hub';
        if (sub != null) $('pvSub').innerHTML = sub;
    }
    function center(html) {
        $('pvPages').innerHTML = '<div class="pv-center">' + html + '</div>';
        $('pvFab').hidden = true; $('pvPage').hidden = true; $('pvSearchBtn').hidden = true;
    }
    function panel(ico, cls, title, text, actions) {
        center('<div class="pc-card"><div class="pdf-empty" style="padding:22px 6px 6px"><div class="e-ico ' + cls + '">' + M.icon(ico) + '</div><h3>' + esc(title) + '</h3><p>' + text + '</p></div>' +
            (V.node ? M.fileBox(V.node, V.paid) : '') + '<div class="pc-actions" style="flex-direction:column">' + actions + '</div></div>');
    }
    function opening(text) {
        center('<div class="pc-card pv-opening"><div class="pdf-empty" style="padding:22px 6px 4px"><div class="e-ico c-blue">' + I.lock + '</div><h3>' + esc(text) + '</h3>' +
            '<p>Premium PDF · opens inside the app only</p></div>' + (V.node ? M.fileBox(V.node, true) : '') +
            '<div class="pv-obar"><i id="pvOpenBar"></i></div><div class="pv-otxt" id="pvOpenTxt">Connecting…</div></div>');
    }
    function backUrl() { return fromDl ? '/pdfs/downloads.html' : (f ? '/pdfs/index.html?f=' + f : '/pdfs/index.html'); }
    function ctx() { return { cfg: V.cfg, f: f, crumb: V.crumb, plan: V.plan }; }
    var SUB = {
        saved: function () { return '<span class="pv-lock">' + I.check + 'Saved in My Downloads</span>'; },
        paidSaved: function () { return '<span class="pv-lock">' + I.lock + 'Saved securely</span>'; },
        session: function () { return '<span class="pv-sess">' + I.clock + 'Opened for this session only</span>'; }
    };

    async function boot() {
        M.wireTheme();
        $('pvBack').addEventListener('click', function () { if (window.MMHNav) MMHNav.up(backUrl()); else location.href = backUrl(); });
        if (app && ST.ready) { try { await ST.ready; } catch (e) {} }     // premium-ended cleanup finishes first
        V.entry = app ? ST.get(id) : null;
        var res = null;
        try { res = await M.resolve(f); } catch (e) { if (!V.entry) return fail(e); }
        V.cfg = res ? res.cfg : M.cfg(null);
        var node = res ? M.child(res.node, id) : null;
        if (res && !node && !V.entry) return notFound();
        V.node = node || { id: id, title: V.entry.title, v: V.entry.v, pages: V.entry.pages, size: V.entry.size };
        V.paid = node ? M.sectionPaid(res.section) : V.entry.kind === 'paid';
        V.plan = node ? M.planOf(node, res.section) : (V.entry.plan || 'premium');
        V.crumb = res ? res.chain.map(function (n) { return n.short || n.title; }).join(' › ') : (V.entry && V.entry.crumb) || '';
        if (V.entry && node) ST.noteLive(id, Number(node.v) || 1);
        document.body.classList.toggle('pv-premium', V.paid);
        head(V.node.title, '');
        wireUi();
        if (V.paid) return openPaid();
        return openFree();
    }

    /* ── sources ──────────────────────────────────────────────────────── */
    async function openFree() {
        if (V.entry) {
            // saved: PDF.js reads the real file from app storage (0 network, parsed while it streams in)
            try { var u = await ST.freeFileUrl(id); $('pvSub').innerHTML = SUB.saved(); if (await openDoc({ url: u, disableRange: true }, true, true)) return; } catch (e) { /* file gone → stream */ }
            $('pvSub').innerHTML = '';
        }
        // not saved: memory only (this session) — HTTP Range, only the parts of the pages you look at
        openDoc({ url: M.freeUrl(V.cfg, V.node), rangeChunkSize: 262144, disableAutoFetch: true, disableStream: true }, false);
    }
    async function openPaid() {
        if (!app) {
            return panel('phone', 'c-amber', 'Open this PDF in the app', 'Premium PDFs can be accessed from the <b>official Mock Matrix Hub app</b> only.',
                '<a class="play-btn" href="' + M.PLAY_URL + '" target="_blank" rel="noopener">' + I.play + '<span><small>GET IT ON</small><b>Google Play</b></span></a>');
        }
        var v = Number(V.node.v) || 1;
        if (V.entry) {
            var st = ST.status(V.entry, v);
            if (st.state === 'expired' || st.state === 'clock') {
                if (navigator.onLine === false) return lockedPanel(st.state);
                opening('Unlocking…');
                try { await ST.renew(id, V.node, ctx()); V.entry = ST.get(id); }
                catch (e) { if (e && e.code === 'buy') { await ST.premiumEnded(); return buyPanel(true); } return lockedPanel(st.state); }
            }
            try {
                var bytes = await ST.openBytes(id, progTop);
                protectOn(); $('pvSub').innerHTML = SUB.paidSaved();
                if (st.state === 'update') setTimeout(function () { M.toast('A new version of this PDF is available — tap Update on its card'); }, 900);
                return openDoc({ data: bytes }, true);
            } catch (e) {
                return panel('info', 'c-rose', "Couldn't open this PDF", 'Delete it from My Downloads and download it again.', '<a class="pc-btn dl" href="/pdfs/downloads.html">Open My Downloads</a>');
            }
        }
        if (!M.hasPlan(V.plan)) return buyPanel(false);
        // not downloaded → open for this app session only
        var quick = ST.inSession(id, v);
        if (!quick) opening('Opening securely…');
        try {
            var b = await ST.openPaidSession(V.node, ctx(), function (got, tot) {
                var bar = $('pvOpenBar'), t = $('pvOpenTxt'); if (!bar) return;
                var pc = tot ? Math.min(99, Math.round(got * 100 / tot)) : 0;
                bar.style.width = pc + '%'; t.textContent = tot ? 'Loading ' + pc + '%' : 'Loading…';
            });
            V.session = true; protectOn(); $('pvSub').innerHTML = SUB.session();
            V.entry = null;
            openDoc({ data: b }, true);
        } catch (e) { paidError(e); }
    }
    function protectOn() {
        ST.protect(true);
        window.addEventListener('pagehide', function () { ST.protect(false); });
    }
    function buyPanel(ended) {
        panel('crown', 'c-amber', ended ? 'Premium plan ended' : 'Premium PDF', ended ? 'Renew Premium to open this PDF again.' : 'Buy Premium to open and download this PDF.',
            '<a class="pc-btn buy" href="/buy-premium.html">' + I.crown + '<span>' + (ended ? 'Renew Premium' : 'Buy Premium') + '</span></a>');
    }
    function lockedPanel(state) {
        panel('lock', 'c-amber', state === 'clock' ? 'Phone time changed' : 'Connect to unlock',
            'Connect to the internet once to unlock this PDF again — the file stays on your phone, nothing downloads again.',
            '<button type="button" class="pc-btn upd" id="pvRenew">' + I.refresh + '<span>Unlock again</span></button>');
    }
    function paidError(e) {
        var c = e && e.code;
        if (c === 'buy') return buyPanel(false);
        if (c === 'login') { location.href = '/?login&redirect=' + encodeURIComponent(location.pathname + location.search); return; }
        if (c === 'offline' || c === 'network') return panel('wifi', 'c-blue', "You're offline", 'Connect to the internet to open this PDF — or download it once to read it offline.', '<button type="button" class="pc-btn dl" onclick="location.reload()">' + I.refresh + '<span>Try again</span></button>');
        if (c === 'integrity') return panel('shield', 'c-rose', 'Use the official app', 'Premium PDFs open only in the official Mock Matrix Hub app installed from Google Play.', '<a class="play-btn" href="' + M.PLAY_URL + '" target="_blank" rel="noopener">' + I.play + '<span><small>GET IT ON</small><b>Google Play</b></span></a>');
        if (c === 'update_app') return panel('refresh', 'c-blue', 'Update the app', 'Update Mock Matrix Hub from Google Play to open Premium PDFs.', '<a class="play-btn" href="' + M.PLAY_URL + '" target="_blank" rel="noopener">' + I.play + '<span><small>GET IT ON</small><b>Google Play</b></span></a>');
        if (c === 'limit') return panel('clock', 'c-amber', 'Daily limit reached', 'You have opened many premium PDFs today. Please try again tomorrow.', '<a class="pc-btn ghost" href="' + backUrl() + '">Go back</a>');
        if (c === 'version') return panel('refresh', 'c-blue', 'PDF updated', 'This PDF was just updated. Go back and open it again.', '<a class="pc-btn dl" href="' + backUrl() + '">Go back</a>');
        panel('info', 'c-rose', "Couldn't open this PDF", 'Please try again in a moment.', '<button type="button" class="pc-btn dl" onclick="location.reload()">' + I.refresh + '<span>Try again</span></button>');
    }

    /* ── PDF.js viewer ────────────────────────────────────────────────── */
    function progTop(got, tot) { if (tot) { var p = $('pvProg'); p.style.opacity = '1'; p.style.width = Math.min(100, got * 100 / tot) + '%'; } }
    async function openDoc(src, local, quiet) {
        $('pvPages').innerHTML = '<div class="pv-skel"></div>';
        try {
            lib = lib || await import('/pdfjs/pdf.min.mjs');
            globalThis.pdfjsLib = lib;
            lib.GlobalWorkerOptions.workerSrc = '/pdfjs/pdf.worker.min.mjs';
            VW = VW || await import('/pdfjs/web/pdf_viewer.mjs');
            var task = lib.getDocument(Object.assign(docBase(), src));
            V.src = local || src.data ? null : src;                      // streamed from the internet → can be re-opened
            task.onProgress = function (p) { if (p && p.total) $('pvProg').style.width = Math.min(100, p.loaded * 100 / p.total) + '%'; };
            V.pdf = await task.promise;
        } catch (e) {
            $('pvProg').style.width = '0';
            if (quiet) return false;
            if (!local && navigator.onLine === false) return panel('wifi', 'c-blue', "You're offline", 'Connect to the internet to read this PDF, or download it to read offline.', '<a class="pc-btn dl" href="/pdfs/downloads.html">Open My Downloads</a>');
            if (!local && window.mmhPageFail) return mmhPageFail.show({ retry: function () { openDoc(src, local); } });
            return panel('info', 'c-rose', "Couldn't open this PDF", 'The file could not be read. Please try again later.', '<a class="pc-btn ghost" href="' + backUrl() + '">Go back</a>');
        }
        $('pvProg').style.width = '100%'; setTimeout(function () { $('pvProg').style.opacity = '0'; }, 500);
        setupViewer();
        return true;
    }
    function docBase() {
        return { cMapUrl: '/pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl: '/pdfjs/standard_fonts/', wasmUrl: '/pdfjs/wasm/',
            isEvalSupported: false, enableXfa: false };
    }
    function setupViewer() {
        var bus = new VW.EventBus();
        var link = new VW.PDFLinkService({ eventBus: bus, externalLinkTarget: VW.LinkTarget.BLANK, externalLinkRel: 'noopener noreferrer nofollow' });
        var find = new VW.PDFFindController({ eventBus: bus, linkService: link });
        var viewer = new VW.PDFViewer({
            container: $('pvScroll'), viewer: $('pvViewer'), eventBus: bus, linkService: link, findController: find,
            removePageBorders: true, textLayerMode: 1, annotationMode: lib.AnnotationMode.ENABLE,
            maxCanvasPixels: fine ? 16777216 : 8388608, enableAutoLinking: true
        });
        link.setViewer(viewer);
        V.bus = bus; V.viewer = viewer; V.link = link; V.n = V.pdf.numPages;
        bus.on('pagesinit', function () {
            if (V.keep) {                                                   // re-opened after a network drop → same page + zoom
                var k = V.keep; V.keep = null;
                viewer.currentScaleValue = k.scale; viewer.currentPageNumber = k.page;
                V.cur = k.page; updChip(); scrubSync(); return;
            }
            viewer.currentScaleValue = V.fit;
            var saved = 0; try { saved = parseInt(localStorage.getItem(POS + id) || '0', 10); } catch (e) {}
            if (saved > 1 && saved <= V.n) { viewer.currentPageNumber = saved; M.toast('Resumed from page ' + saved); }
            V.cur = viewer.currentPageNumber; updChip(); scrubSync();
        });
        bus.on('pagechanging', function (e) {
            V.cur = e.pageNumber; updChip();
            $('pvBubble').textContent = V.cur + ' / ' + V.n;
            clearTimeout(posT); posT = setTimeout(function () { try { localStorage.setItem(POS + id, String(V.cur)); } catch (x) {} }, 400);
        });
        // a page could not be drawn (slow / no internet while streaming) → keep showing
        // "Loading page N…" and try again (when back online / every 3 s) — never an error
        bus.on('pagerendered', function (e) {
            var pv = viewer.getPageView(e.pageNumber - 1); if (!pv || !pv.div) return;
            if (!e.error) { pv.div.classList.remove('pv-wait'); return; }
            pv.div.classList.add('pv-wait');
            retryLater(pv);
        });
        bus.on('updatefindmatchescount', function (e) { findCount(e.matchesCount); });
        bus.on('updatefindcontrolstate', function (e) { findCount(e.matchesCount, e.state); });
        viewer.setDocument(V.pdf);
        link.setDocument(V.pdf, null);
        $('pvPages').innerHTML = '';
        $('pvFab').hidden = false; $('pvSearchBtn').hidden = false;
        renderFab();
    }
    var posT = null, retryT = null, retryList = [];
    function retryLater(pv) {
        if (retryList.indexOf(pv) < 0) retryList.push(pv);
        clearTimeout(retryT); retryT = setTimeout(recover, 3000);
    }
    async function recover() {
        clearTimeout(retryT);
        if (!retryList.length || V.reopening) return;
        if (navigator.onLine === false) { retryT = setTimeout(recover, 3000); return; }   // wait for internet (also 'online' event)
        var l = retryList; retryList = [];
        if (!V.src) {                                                       // local file / decrypted bytes → just draw again
            l.forEach(function (p) { try { p.reset(); } catch (x) {} });
            if (V.viewer) V.viewer.update();
            return;
        }
        // streamed PDF: a failed internet request stays broken inside PDF.js → open the same
        // file again quietly and continue on the same page + zoom (no error, no reload)
        V.reopening = true;
        try {
            var pdf = await lib.getDocument(Object.assign(docBase(), V.src)).promise, old = V.pdf;
            V.keep = { page: V.cur, scale: V.fit || V.viewer.currentScale };
            V.pdf = pdf; V.viewer.setDocument(pdf); V.link.setDocument(pdf, null);
            try { old.destroy(); } catch (x) {}
        } catch (e) {
            retryList = l.concat(retryList); retryT = setTimeout(recover, 3000);
        }
        V.reopening = false;
    }
    window.addEventListener('online', function () {
        if (!retryList.length && V.src && document.querySelector('.pdfViewer .page.loading, .pdfViewer .page.pv-wait')) retryList.push('stuck');
        if (retryList.length) { clearTimeout(retryT); retryT = setTimeout(recover, 400); }
    });
    function updChip() { var c = $('pvPage'); c.textContent = V.cur + ' / ' + (V.n || '–'); c.hidden = !V.n; }
    function jump(p) { if (V.viewer && p >= 1 && p <= V.n) { V.viewer.currentPageNumber = p; V.cur = p; updChip(); } }
    function zoomBy(steps, origin) { if (!V.viewer) return; V.fit = null; V.viewer.updateScale({ steps: steps, origin: origin, drawingDelay: 250 }); }
    function fitWidth() { if (!V.viewer) return; V.fit = 'page-width'; V.viewer.currentScaleValue = 'page-width'; }

    /* ── search inside the PDF ────────────────────────────────────────── */
    function openFind() {
        if (!V.viewer) return;
        $('pvFind').hidden = false; document.body.classList.add('pv-finding'); $('pvSearchBtn').classList.add('on');
        setTimeout(function () { $('pvFindInput').focus(); $('pvFindInput').select(); }, 60);
    }
    function closeFind() {
        $('pvFind').hidden = true; document.body.classList.remove('pv-finding'); $('pvSearchBtn').classList.remove('on');
        $('pvFindInput').value = ''; $('pvFindCount').textContent = ''; $('pvFindCount').className = 'pv-find-count';
        if (V.bus) V.bus.dispatch('findbarclose', { source: window });
    }
    function doFind(type, prev) {
        var q = $('pvFindInput').value.trim();
        if (!V.bus) return;
        if (!q) { V.bus.dispatch('findbarclose', { source: window }); $('pvFindCount').textContent = ''; return; }
        V.bus.dispatch('find', { source: window, type: type, query: q, caseSensitive: false, entireWord: false, highlightAll: true, findPrevious: !!prev, matchDiacritics: false });
    }
    function findCount(mc, state) {
        var el = $('pvFindCount');
        if (!$('pvFindInput').value.trim()) { el.textContent = ''; return; }
        if (state === 1) { el.textContent = 'No match'; el.className = 'pv-find-count none'; return; }   // FindState.NOT_FOUND
        if (mc && mc.total) { el.textContent = mc.current + ' / ' + mc.total; el.className = 'pv-find-count'; }
        else if (state === 3) { el.textContent = '…'; el.className = 'pv-find-count'; }                    // PENDING
    }

    /* ── Drive-style side scroller ────────────────────────────────────
       Shown ONLY while the user scrolls by hand (finger / wheel / keys / dragging
       the tab). Jumps (Go to page, links, search) never show it. Finger lifted →
       hidden 2 s after the page stops moving. */
    var drag = null, hideT = null, hand = false, fingers = 0;
    function scrubSync() {
        var sc = $('pvScroll'), max = sc.scrollHeight - sc.clientHeight, s = $('pvScrub'), t = $('pvThumb');
        if (max <= 4 || !V.n) { s.classList.remove('show'); return false; }
        var tr = s.clientHeight - t.offsetHeight;
        if (!drag) t.style.transform = 'translateY(' + Math.round(tr * Math.min(1, sc.scrollTop / max)) + 'px)';
        return true;
    }
    function scrubHideLater() {
        clearTimeout(hideT);
        if (drag || fingers) return;                     // finger still on the screen → stay
        hideT = setTimeout(function () { $('pvScrub').classList.remove('show'); hand = false; }, 2000);
    }
    function scrubShow() {
        if (!hand || !scrubSync()) return;
        $('pvBubble').textContent = V.cur + ' / ' + V.n;
        $('pvScrub').classList.add('show');
        scrubHideLater();
    }
    function wireScrub() {
        var sc = $('pvScroll'), s = $('pvScrub'), t = $('pvThumb');
        sc.addEventListener('scroll', function () { if (hand) scrubShow(); else scrubSync(); }, { passive: true });
        sc.addEventListener('touchstart', function (e) { fingers = e.touches.length; if (fingers === 1) { hand = true; clearTimeout(hideT); } }, { passive: true });
        var lift = function (e) { fingers = e.touches ? e.touches.length : 0; if (!fingers && hand && s.classList.contains('show')) scrubHideLater(); };
        sc.addEventListener('touchend', lift, { passive: true });
        sc.addEventListener('touchcancel', lift, { passive: true });
        sc.addEventListener('wheel', function (e) { if (!(e.ctrlKey || e.metaKey)) hand = true; }, { passive: true });
        document.addEventListener('keydown', function (e) { if (/^(ArrowUp|ArrowDown|PageUp|PageDown|Home|End| )$/.test(e.key) && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) hand = true; });
        t.addEventListener('pointerdown', function (e) {
            var m = /translateY\(([-\d.]+)px\)/.exec(t.style.transform || '');
            drag = { y0: e.clientY, t0: m ? parseFloat(m[1]) : 0 }; hand = true;
            try { t.setPointerCapture(e.pointerId); } catch (x) {}
            s.classList.add('show', 'drag'); clearTimeout(hideT);
            $('pvBubble').textContent = V.cur + ' / ' + V.n;
            e.preventDefault();
        });
        t.addEventListener('pointermove', function (e) {
            if (!drag) return;
            var tr = s.clientHeight - t.offsetHeight, max = sc.scrollHeight - sc.clientHeight;
            var y = Math.max(0, Math.min(tr, drag.t0 + e.clientY - drag.y0));
            t.style.transform = 'translateY(' + Math.round(y) + 'px)';
            sc.scrollTop = tr > 0 ? y / tr * max : 0;
        });
        var end = function () { if (!drag) return; drag = null; fingers = 0; s.classList.remove('drag'); scrubHideLater(); };
        t.addEventListener('pointerup', end); t.addEventListener('pointercancel', end);
        window.addEventListener('resize', function () {
            if (V.viewer && V.fit) V.viewer.currentScaleValue = V.fit;
            scrubSync();
        });
    }

    /* ── pinch zoom (phones) + Ctrl/⌘ + wheel (desktop) ───────────────── */
    function wireZoom() {
        var sc = $('pvScroll'), vw = $('pvViewer'), pinch = null;
        function dist(t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
        function mid(t) { return [(t[0].clientX + t[1].clientX) / 2, (t[0].clientY + t[1].clientY) / 2]; }
        sc.addEventListener('touchstart', function (e) {
            if (e.touches.length !== 2 || !V.viewer) return;
            var r = sc.getBoundingClientRect(), m = mid(e.touches);
            pinch = { d0: dist(e.touches), k: 1, m: m, ox: sc.scrollLeft + m[0] - r.left, oy: sc.scrollTop + m[1] - r.top };
            vw.style.transformOrigin = pinch.ox + 'px ' + pinch.oy + 'px'; vw.style.willChange = 'transform';
        }, { passive: true });
        sc.addEventListener('touchmove', function (e) {
            if (!pinch || e.touches.length !== 2) return;
            e.preventDefault();
            var cur = V.viewer.currentScale, k = dist(e.touches) / pinch.d0;
            k = Math.max(0.4 / cur, Math.min(5 / cur, k));               // keep the final zoom in 40%–500%
            pinch.k = k; pinch.m = mid(e.touches);
            vw.style.transform = 'scale(' + k + ')';                      // GPU only — no re-draw while pinching
        }, { passive: false });
        function endPinch() {
            if (!pinch) return;
            var p = pinch; pinch = null;
            vw.style.transform = ''; vw.style.transformOrigin = ''; vw.style.willChange = '';
            if (Math.abs(p.k - 1) < 0.02) return;
            V.fit = null;
            V.viewer.updateScale({ scaleFactor: p.k, origin: p.m, drawingDelay: 120 });   // one re-draw, same spot stays under the fingers
        }
        sc.addEventListener('touchend', function (e) { if (e.touches.length < 2) endPinch(); }, { passive: true });
        sc.addEventListener('touchcancel', endPinch, { passive: true });
        sc.addEventListener('wheel', function (e) {
            if (!(e.ctrlKey || e.metaKey) || !V.viewer) return;
            e.preventDefault();
            zoomBy(e.deltaY < 0 ? 1 : -1, [e.clientX, e.clientY]);
        }, { passive: false });
        document.addEventListener('keydown', function (e) {
            if (!(e.ctrlKey || e.metaKey) || !V.viewer) return;
            if (e.key === '+' || e.key === '=') { e.preventDefault(); zoomBy(1); }
            else if (e.key === '-') { e.preventDefault(); zoomBy(-1); }
            else if (e.key === '0') { e.preventDefault(); fitWidth(); }
        });
    }

    /* ── blue ☰ options button ────────────────────────────────────────── */
    function fabList() {
        var e = app ? ST.get(id) : null, v = Number(V.node && V.node.v) || 1;
        var stt = e ? ST.status(e, v).state : 'none', L = [];
        if (!app) { if (!V.paid) L.push(['download', 'Download', I.download]); }
        else if (stt === 'update') L.push(['save', 'Update to new version', I.refresh]);
        else if (e) L.push(['saved', 'Downloaded', I.check]);
        else L.push(['save', 'Download', I.download]);
        if (app && !V.paid) L.push(['export', 'Export to phone', I.export]);
        L.push(['share', 'Share', I.share]);
        L.push(['goto', 'Go to page', I.goto]);
        return L;
    }
    function renderFab() {
        $('pvFabItems').innerHTML = fabList().map(function (x, i) {
            return '<button type="button" class="pv-fab-item" data-k="' + x[0] + '" style="--i:' + i + '"><span class="lbl">' + esc(x[1]) + '</span><span class="dot">' + x[2] + '</span></button>';
        }).join('');
    }
    function fab(open) {
        var w = $('pvFab'), on = open == null ? !w.classList.contains('open') : open;
        w.classList.toggle('open', on); $('pvScrim').classList.toggle('on', on);
        $('pvFabBtn').setAttribute('aria-expanded', on ? 'true' : 'false');
    }
    async function act(k, btn) {
        fab(false);
        if (k === 'goto') return gotoSheet();
        if (k === 'share') return M.share(V.node.title, M.shareUrl(V.cfg, f, id));
        if (k === 'download') return webDownload();
        if (k === 'save') return save();
        if (k === 'saved') return M.toast(V.paid ? 'Saved securely in My Downloads' : 'Already in My Downloads');
        if (k === 'export') return exportPdf();
    }
    function gotoSheet() {
        if (!V.n) return;
        M.sheet({ icon: 'pages', title: 'Go to page', text: '1 – ' + V.n,
            body: '<input class="s-input" id="pvJump" type="number" inputmode="numeric" min="1" max="' + V.n + '" value="' + V.cur + '">',
            actions: [{ label: 'Go', cls: 'dl', onClick: function () { jump(parseInt($('pvJump').value, 10)); } }, { label: 'Cancel', cls: 'ghost' }] });
        setTimeout(function () { var x = $('pvJump'); if (x) { x.focus(); x.select(); } }, 60);
    }
    async function save() {
        var v = Number(V.node.v) || 1, e = ST.get(id), wasUpd = !!(e && ST.status(e, v).state === 'update');
        if (e && ST.status(e, v).state === 'ready') return M.toast('Already in My Downloads');
        M.toast('Downloading…');
        try {
            if (V.paid) { await ST.downloadPaid(V.node, ctx()); V.session = false; $('pvSub').innerHTML = SUB.paidSaved(); M.toast('Saved securely in My Downloads'); }
            else { await ST.downloadFree(V.node, ctx()); $('pvSub').innerHTML = SUB.saved(); M.toast('Saved in My Downloads'); }
            V.entry = ST.get(id); renderFab();
            if (wasUpd) setTimeout(function () { location.reload(); }, 700);      // show the new version
        } catch (er) { M.toast(er && er.code === 'offline' ? "You're offline" : 'Could not save — try again', 'error'); }
    }
    /* free only: copy the real PDF to the phone. NOT saved → temp copy only (not added to My Downloads) */
    async function exportPdf() {
        try {
            M.toast('Preparing…');
            var r = await ST.exportFree(V.node, ctx());
            M.toast(r.where === 'share' ? 'Choose where to save the PDF' : 'Exported to Documents/MockMatrixHub');
        } catch (er) { M.toast(er && er.code === 'offline' ? "You're offline" : 'Export failed — try again', 'error'); }
    }
    function webDownload() {
        M.toast('Downloading…');
        var url = M.freeUrl(V.cfg, V.node);
        fetch(url).then(function (r) { if (!r.ok) throw 0; return r.blob(); }).then(function (bl) {
            var a = document.createElement('a'); a.href = URL.createObjectURL(bl);
            a.download = String(V.node.title || 'document').replace(/[\\/:*?"<>|]+/g, ' ').trim() + '.pdf';
            document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
        }).catch(function () { window.open(url, '_blank', 'noopener'); });
    }

    function wireUi() {
        $('pvFabBtn').innerHTML = I.menu;
        $('pvFabBtn').addEventListener('click', function () { fab(); });
        $('pvScrim').addEventListener('click', function () { fab(false); });
        $('pvFabItems').addEventListener('click', function (e) { var b = e.target.closest('.pv-fab-item'); if (b) act(b.getAttribute('data-k'), b); });
        $('pvPage').addEventListener('click', gotoSheet);
        $('pvSearchBtn').addEventListener('click', function () { if ($('pvFind').hidden) openFind(); else closeFind(); });
        $('pvFindPrev').innerHTML = I.up; $('pvFindNext').innerHTML = I.down; $('pvFindClose').innerHTML = I.x;
        var t = null;
        $('pvFindInput').addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { doFind('', false); }, 280); });
        $('pvFindInput').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); doFind('again', e.shiftKey); }
            if (e.key === 'Escape') closeFind();
        });
        $('pvFindNext').addEventListener('click', function () { doFind('again', false); });
        $('pvFindPrev').addEventListener('click', function () { doFind('again', true); });
        $('pvFindClose').addEventListener('click', closeFind);
        document.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F') && V.viewer) { e.preventDefault(); openFind(); }
            if (e.key === 'Escape' && $('pvFab').classList.contains('open')) fab(false);
        });
        document.addEventListener('click', function (e) {
            var g = e.target.closest('#pvRenew'); if (!g) return;
            g.classList.add('busy'); g.innerHTML = '<span class="prog" style="width:100%"></span>' + I.refresh + '<span>Unlocking…</span>';
            ST.renew(id, V.node, ctx()).then(function () { location.reload(); }).catch(function (er) {
                var c = er && er.code;
                if (c === 'buy') return buyPanel(true);
                M.toast(c === 'offline' || c === 'network' ? "You're offline" : c === 'integrity' ? 'Use the official app from Google Play' : 'Could not unlock — try again', 'error');
                setTimeout(function () { location.reload(); }, 1600);
            });
        });
        wireScrub(); wireZoom();
    }
    function notFound() {
        head('PDF not found', '');
        panel('file', 'c-slate', 'PDF not found', 'This PDF may have been moved or replaced with a new version.', '<a class="pc-btn dl" href="/pdfs/index.html?f=' + esc(f || 'free') + '">Open folder</a>');
    }
    function fail(e) {
        head('PDF', '');
        if (e && (e.notFound || e.missing)) return notFound();
        if (window.mmhPageFail) mmhPageFail.show({ retry: function () { location.reload(); } });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

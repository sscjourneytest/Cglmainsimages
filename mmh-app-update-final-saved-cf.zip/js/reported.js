// ═══════════════════════════════════════════════════════════════════════════
//  Reported Questions page  —  /reported/index.html
//
//  Data:  report Worker (reports.mockmatrixhub.in), ticket auth (X-MMH-Ticket).
//         The ticket is the SAME one the saved page uses (sessionStorage
//         mmh_saved_ticket_v1, issued by the saved Worker /session).
//
//    GET  /my-reports?tab=updated|review&offset=N
//         → { ok, reports:[…≤10], questions:{quid:body}, next_offset, counts? }
//           counts = { updated, review, unread } (only on offset 0)
//    POST /seen   { quids:[≤10] }         → admin updates marked as seen
//    POST /reply  { quid, text, r? }      → { ok, at, thread }   (NOT sent to Telegram)
//         r = index of the message this one replies to (Telegram-style quote).
//         thread = the whole chat after the append → exact indexes for the next reply.
//
//  Chat = reported_questions.chat (ONE column: report + user + admin), append-only array (index never changes):
//    [0] the report {from:"user",reason,details,at,n}   [i] {from:"user"|"admin",text,at,r?}
//    "r": k → quote of message k (only the index is stored, the page shows thread[k]).
//
//  Cache: sessionStorage only (mmh_rq_cache_v2) — back / reload in the same
//  tab repaints without a call; ?fresh=1 or the refresh button reloads.
//
//  The preview build sets window.MMH_RQ_API (mock) before this file loads;
//  the live page uses the real API below.
// ═══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const REPORT_URL    = "https://reports.mockmatrixhub.in/";
const SAVED_URL     = "https://saved.mockmatrixhub.in/";
const TICKET_SS_KEY = "mmh_saved_ticket_v1";
const CACHE_KEY     = "mmh_rq_cache_v2";
const CACHE_TTL     = 10 * 60 * 1000;
const MAX_ITEMS     = 50;
const MSG_MAX       = 1000;

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// ── icons ────────────────────────────────────────────────────────────────────
const IC = {
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  reply: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-12.3 7.5L3 21l2-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  flag:  '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 2.8a1 1 0 0 1 1 1V4h11.6a.8.8 0 0 1 .65 1.27L15.9 8.6l2.35 3.33a.8.8 0 0 1-.65 1.27H6V21a1 1 0 1 1-2 0V3.8a1 1 0 0 1 1-1z"/></svg>',
  info:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.6v.1"/></svg>',
  edit:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>',
  inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l2.6-7.2A2 2 0 0 1 7.5 4.5h9a2 2 0 0 1 1.9 1.3L21 13v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5z"/><path d="M3 13h5l1.5 2.5h5L16 13h5"/></svg>',
  tick:  '<svg viewBox="0 0 16 11" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 6l3.4 3.4L12 2"/></svg>',
  wait:  '<svg viewBox="0 0 16 11" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="8" cy="5.5" r="4.2"/><path d="M8 3.3v2.4l1.6 1"/></svg>',
  fail:  '<svg viewBox="0 0 16 11" fill="currentColor"><circle cx="8" cy="5.5" r="5"/><path d="M8 2.8v3.3M8 7.6v.4" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>',
  back:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>'
};

// ══════════════════════════════════════════════════════════════════════════
//  REAL API (ticket → report Worker)
// ══════════════════════════════════════════════════════════════════════════
const REAL_API = (function () {
  let USER_UUID = "";
  let TICKET = "";
  try { TICKET = sessionStorage.getItem(TICKET_SS_KEY) || ""; } catch (e) {}

  function keepTicket(res) {
    try {
      const t = res && res.headers ? res.headers.get("X-MMH-Ticket") : null;
      if (!t) return;
      TICKET = t;
      try { sessionStorage.setItem(TICKET_SS_KEY, t); } catch (e) {}
    } catch (e) {}
  }
  function ticketUsable() {
    try {
      const p = TICKET.split(".")[0].replace(/-/g, "+").replace(/_/g, "/");
      const t = JSON.parse(atob(p + "===".slice((p.length + 3) % 4)));
      if (!t || !(t.e - 60 > Date.now() / 1000)) return false;
      return !USER_UUID || String(t.u).toLowerCase() === USER_UUID;
    } catch (e) { return false; }
  }
  function dropTicket() { TICKET = ""; try { sessionStorage.removeItem(TICKET_SS_KEY); } catch (e) {} }
  async function userJwt() {
    let client = null;
    try { client = (typeof getClient === "function") ? await getClient() : null; } catch (e) {}
    if (!client) throw loginErr();
    const res = (typeof getSessionOnce === "function") ? await getSessionOnce(client) : await client.auth.getSession();
    const s = res && res.data ? res.data.session : null;
    if (!s || !s.access_token) throw loginErr();
    return s.access_token;
  }
  function loginErr() { const e = new Error("login"); e.login = true; return e; }
  async function newSession() {
    const r = await fetch(SAVED_URL + "session", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + await userJwt() },
      body: "{}"
    });
    keepTicket(r);
    if (r.status === 401) throw loginErr();
    if (!r.ok || !TICKET) throw new Error("session " + r.status);
  }
  async function call(path, method, body) {
    if (!ticketUsable()) { dropTicket(); await newSession(); }
    const go = () => fetch(REPORT_URL + path, {
      method: method,
      headers: Object.assign({ "X-MMH-Ticket": TICKET }, body !== undefined ? { "Content-Type": "application/json" } : {}),
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    let r = await go();
    if (r.status === 401) { dropTicket(); await newSession(); r = await go(); }
    let data = null;
    try { data = await r.json(); } catch (e) {}
    if (!r.ok || !data || data.ok === false) {
      const e = new Error((data && data.error) || ("HTTP " + r.status));
      e.status = r.status;
      throw e;
    }
    return data;
  }
  return {
    async profile() {
      for (let i = 0; i < 60 && typeof getLocalProfile !== "function"; i++) await new Promise(r => setTimeout(r, 100));
      const p = typeof getLocalProfile === "function" ? getLocalProfile() : null;
      if (!p || (p.username === "User" && !p.id)) throw loginErr();
      USER_UUID = String(p.id || "").toLowerCase();
      return { uid: USER_UUID };
    },
    list(tab, offset) { return call("my-reports?tab=" + encodeURIComponent(tab) + "&offset=" + (offset | 0), "GET"); },
    seen(quids)       { return call("seen", "POST", { quids: quids }); },
    reply(quid, text, r) { return call("reply", "POST", r == null ? { quid: quid, text: text } : { quid: quid, text: text, r: r }); }
  };
})();
const API = window.MMH_RQ_API || REAL_API;

// ══════════════════════════════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════════════════════════════
const S = {
  uid: "",
  tab: "updated",
  tabs: { updated: null, review: null },   // { items:[], next:null|number }
  questions: {},                            // quid -> body (object)
  counts: { updated: 0, review: 0, unread: 0 },
  fresh: new Set(),                         // quids shown as NEW during this visit
  chatOpened: new Set(),                    // chats opened during this visit
  wide: false,                              // ≥992px: Telegram-style pane on the right
  sideQuid: "",                             // card shown in the right pane
  lang: "en",
  chatQuid: "",
  replyTo: null,                            // index of the message being replied to (or null)
  sheetQuid: "",
  loading: false
};
try { S.lang = localStorage.getItem("quiz_lang") || "en"; } catch (e) {}
if (["en", "hi", "bilingual"].indexOf(S.lang) < 0) S.lang = "en";

function saveCache() {
  try {
    sessionStorage.setItem(CACHE_KEY, JSON.stringify({
      uid: S.uid, at: Date.now(), tabs: S.tabs, questions: S.questions, counts: S.counts
    }));
  } catch (e) {}
}
function loadCache() {
  try {
    const c = JSON.parse(sessionStorage.getItem(CACHE_KEY) || "null");
    if (!c || c.uid !== S.uid || !(Date.now() - c.at < CACHE_TTL)) return false;
    S.tabs = c.tabs || S.tabs; S.questions = c.questions || {}; S.counts = c.counts || S.counts;
    return true;
  } catch (e) { return false; }
}

// ══════════════════════════════════════════════════════════════════════════
//  DATA HELPERS
// ══════════════════════════════════════════════════════════════════════════
function toMs(at) {
  if (at == null || at === "") return 0;
  const n = Number(at);
  if (!isNaN(n)) return n < 1e12 ? n * 1000 : n;
  const d = Date.parse(at);
  return isNaN(d) ? 0 : d;
}
// One normalised view of a report row.
function view(r) {
  const raw = Array.isArray(r.chat) ? r.chat : [];
  // _i = the message's index in the stored chat (what "r" points at)
  const thread = raw.map((m, i) => Object.assign({}, m, { _i: i }));
  const first = thread.find(m => m.from !== "admin" && (m.reason || m.details)) || null;
  const adminMsgs = thread.filter(m => m.from === "admin");
  const lastAdmin = adminMsgs.length ? adminMsgs[adminMsgs.length - 1] : null;
  const status = r.edited ? "fixed" : (lastAdmin ? "replied" : "review");
  const last = thread.length ? thread[thread.length - 1] : null;
  return {
    r: r, thread: thread, first: first,
    reason: (first && first.reason) || "Reported",
    details: (first && first.details) || "",
    status: status,
    lastAdmin: lastAdmin,
    unread: !r.seen && status !== "review",
    chatUnread: !r.seen && !!(last && last.from === "admin")
  };
}
function questionObj(quid) {
  let b = S.questions[quid];
  if (!b) return null;
  if (typeof b === "string") { try { b = JSON.parse(b); } catch (e) { return null; } S.questions[quid] = b; }
  const q = Object.assign({}, b);
  q.quid = quid;
  if (!q.id) q.id = quid;
  return q;
}
function plainText(html) {
  const d = document.createElement("div");
  d.innerHTML = String(html || "");
  return (d.textContent || "").replace(/\s+/g, " ").trim();
}
// One-line preview of LaTeX for the pinned bar: \(\cosec\theta = \frac{5}{3}\) → cosec θ = 5/3
const TEX_SYM = { theta:"θ", alpha:"α", beta:"β", gamma:"γ", delta:"δ", pi:"π", phi:"φ", lambda:"λ", mu:"μ", sigma:"σ", omega:"ω",
  angle:"∠", circ:"°", degree:"°", times:"×", div:"÷", cdot:"·", pm:"±", le:"≤", leq:"≤", ge:"≥", geq:"≥", ne:"≠", neq:"≠",
  infty:"∞", Rightarrow:"⇒", rightarrow:"→", therefore:"∴", because:"∵", triangle:"△", sqrt:"√", left:"", right:"", quad:" ", qquad:" " };
const SUP = { "0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹","n":"ⁿ" };
function texToText(t) {
  let s = String(t || "");
  s = s.replace(/\\\(|\\\)|\\\[|\\\]|\$\$/g, " ");
  s = s.replace(/\\sqrt\s*\{([^{}]*)\}/g, "√($1)").replace(/√\(([A-Za-z0-9.]+)\)/g, "√$1");
  const part = x => /^[A-Za-z0-9.√\\]+$/.test(x.trim()) ? x.trim() : "(" + x.trim() + ")";
  for (let i = 0; i < 3; i++) s = s.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, (m, a, b) => part(a) + "/" + part(b));
  s = s.replace(/\^\s*\{?\s*\\circ\s*\}?/g, "°");
  s = s.replace(/\\(?:operatorname|text|mathrm|mathbf|textbf)\s*\{([^{}]*)\}/g, "$1");
  s = s.replace(/\^\{?([0-9n])\}?/g, (m, d) => SUP[d] || m);
  s = s.replace(/\\([A-Za-z]+)/g, (m, w) => (w in TEX_SYM ? TEX_SYM[w] : w) + " ");
  s = s.replace(/[{}]/g, "").replace(/\\[,;! ]/g, " ");
  return s.replace(/\s+([,.?)])/g, "$1").replace(/\s+/g, " ").trim();
}
function questionPreview(quid) {
  const q = questionObj(quid);
  if (!q) return "Question";
  const t = typeof mmhQuestionDisplay === "function" ? mmhQuestionDisplay(q.question, S.lang === "bilingual" ? "en" : S.lang, "").text : "";
  return texToText(plainText(t)).slice(0, 140) || "Question";
}

// ── dates ────────────────────────────────────────────────────────────────────
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
function dayKey(ms) { const d = new Date(ms); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); }
function dayLabel(ms) {
  const d = new Date(ms), now = new Date();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ms) === dayKey(now.getTime())) return "Today";
  if (dayKey(ms) === dayKey(y.getTime())) return "Yesterday";
  return d.getDate() + " " + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? " " + d.getFullYear() : "");
}
function timeLabel(ms) {
  const d = new Date(ms);
  let h = d.getHours(); const m = d.getMinutes();
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return h + ":" + String(m).padStart(2, "0") + " " + ap;
}
function shortDate(ms) {
  if (!ms) return "";
  const d = new Date(ms), now = new Date();
  const lbl = dayLabel(ms);
  if (lbl === "Today" || lbl === "Yesterday") return lbl;
  return d.getDate() + " " + MONTHS[d.getMonth()].slice(0, 3) + (d.getFullYear() !== now.getFullYear() ? " " + d.getFullYear() : "");
}
function fullDate(ms) {
  if (!ms) return "—";
  const d = new Date(ms);
  return d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear() + ", " + timeLabel(ms);
}

// ══════════════════════════════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════════════════════════════
let toastT = 0;
function toast(msg) {
  const t = $("rqToast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove("show"), 2400);
}
const STATUS_TXT = {
  fixed:   { chip: "Corrected",    hero: "Question corrected",  sub: "Admin has corrected this question. Thanks for reporting!" },
  replied: { chip: "Replied",      hero: "Admin replied",       sub: "Admin has replied to your report. Open chat to see or reply." },
  review:  { chip: "Under review", hero: "Under review",        sub: "Your report has reached the admin and will be checked soon." }
};
function statusIcon(st) { return st === "fixed" ? IC.check : st === "replied" ? IC.reply : IC.clock; }
function statusChip(st) {
  return '<span class="rq-status is-' + st + '">' + statusIcon(st) + '<span>' + STATUS_TXT[st].chip + '</span></span>';
}
function langSelect() {
  const o = (v, t) => '<option value="' + v + '"' + (S.lang === v ? " selected" : "") + '>' + t + '</option>';
  return '<div class="lang-container"><span class="lang-label">Select Language:</span>' +
         '<select class="card-lang-dropdown" aria-label="Language">' +
         o("en", "English") + o("hi", "Hindi") + o("bilingual", "Bilingual") + '</select></div>';
}
function cardFor(quid, index, headExtra) {
  const q = questionObj(quid);
  if (!q || typeof mmhRenderCard !== "function") {
    const c = document.createElement("div");
    c.className = "quiz-card mmh-card";
    c.innerHTML = '<div class="mmh-card-head"><div class="mmh-card-num">' + index + '</div>' +
      '<div class="mmh-card-head-extra">' + headExtra + '</div></div>' +
      '<div class="rq-missing">This question is no longer available in the question bank.</div>';
    return c;
  }
  return mmhRenderCard(q, {
    lang: S.lang, quizId: "", index: index, total: 0,
    mode: "solution", allowSolution: false, solutionOpen: true, showPercent: false,
    onPick: null, headExtra: headExtra
  });
}

// ══════════════════════════════════════════════════════════════════════════
//  LIST
// ══════════════════════════════════════════════════════════════════════════
function skeleton() {
  const one = '<div class="rq-skel"><div class="rq-skel-head"></div><div class="rq-skel-body">' +
    '<div class="rq-skel-line" style="width:92%"></div><div class="rq-skel-line" style="width:70%"></div>' +
    '<div class="rq-skel-line" style="width:84%"></div><div class="rq-skel-line" style="width:55%;margin:0"></div></div></div>';
  $("rqList").innerHTML = one + one;
  $("rqMore").hidden = true; $("rqEnd").hidden = true;
}
function paintIntro() {
  const t = S.tabs[S.tab];
  const n = S.tab === "updated" ? S.counts.updated : S.counts.review;
  $("rqTitle").textContent = S.tab === "updated" ? "Updated" : "Under review";
  if (!t) { $("rqSub").textContent = "Loading your reports…"; return; }
  const total = Math.max(n || 0, t.items.length);
  $("rqSub").textContent = S.tab === "updated"
    ? (total ? total + (total === 1 ? " report" : " reports") + " checked by the admin" : "No updates yet")
    : (total ? total + (total === 1 ? " report" : " reports") + " waiting for the admin" : "Nothing pending");
}
function paintBadges() {
  const b = $("rqBadgeUpdated");
  const n = S.counts.unread | 0;
  b.hidden = !n;
  b.textContent = n > 9 ? "9+" : String(n);
}
function paintDock() {
  document.querySelectorAll("#rqDock .ex-dock-item").forEach(btn => {
    const on = btn.getAttribute("data-tab") === S.tab;
    btn.classList.toggle("active", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  });
}
function emptyState() {
  const upd = S.tab === "updated";
  return '<div class="rq-empty"><div class="rq-empty-ico">' + (upd ? IC.inbox : IC.clock) + '</div>' +
    '<h3>' + (upd ? "No updates yet" : "Nothing under review") + '</h3>' +
    '<p>' + (upd
      ? "When the admin corrects a question you reported or replies to you, it will show up here."
      : "Report a wrong question from any test using the Report button. It will wait here until the admin checks it.") + '</p>' +
    (upd && S.counts.review ? '<button type="button" class="rq-btn rq-btn-soft" data-go-tab="review">See ' + S.counts.review + ' under review</button>' : '') +
    '</div>';
}
function barFor(v, isNew) {
  const ms = toMs(v.r.reported_at) || toMs(v.first && v.first.at);
  const reply = v.lastAdmin && S.tab === "updated"
    ? '<div class="rq-bar-reply"><b>Admin:</b> ' + esc(plainText(v.lastAdmin.text || "").slice(0, 160)) + '</div>' : "";
  const fixedLine = !reply && v.status === "fixed"
    ? '<div class="rq-bar-reply"><b>Admin:</b> Question has been corrected.</div>' : "";
  // an admin message the user has not read in the chat yet (stays during this
  // visit even after /seen, until the chat is opened)
  const last = v.thread[v.thread.length - 1];
  const chatNew = !S.chatOpened.has(v.r.quid) && !!last && last.from === "admin" && (v.chatUnread || isNew);
  const chatCount = chatNew ? '<span class="rq-count">1</span>' : "";
  // tex2jax_ignore: user / admin text is never typeset by MathJax
  return '<div class="rq-bar tex2jax_ignore">' +
    '<div class="rq-bar-main">' +
      '<div class="rq-bar-line">' +
        '<span class="rq-bar-ico">' + IC.flag + '</span>' +
        '<span class="rq-bar-reason">' + esc(v.reason) + '</span>' +
        (ms ? '<span class="rq-bar-sep"></span><span class="rq-bar-time">' + esc(shortDate(ms)) + '</span>' : "") +
        (isNew ? '<span class="rq-new">NEW</span>' : "") +
      '</div>' + reply + fixedLine +
    '</div>' +
    '<div class="rq-bar-actions">' +
      '<button type="button" class="rq-btn" data-act="details">' + IC.info + '<span>Details</span></button>' +
      '<button type="button" class="rq-btn ' + (chatNew ? "rq-btn-primary" : "rq-btn-soft") + '" data-act="chat">' + IC.reply + '<span>Chat</span>' + chatCount + '</button>' +
    '</div></div>';
}
function paintList(keepScroll) {
  const box = $("rqList");
  const sc = $("rqScroll");
  const y = keepScroll ? sc.scrollTop : 0;
  const t = S.tabs[S.tab];
  paintIntro(); paintBadges(); paintDock();
  if (!t) { skeleton(); return; }
  box.innerHTML = "";
  if (!t.items.length) {
    box.innerHTML = emptyState();
  } else {
    const frag = document.createDocumentFragment();
    t.items.forEach((r, i) => {
      const v = view(r);
      const isNew = S.fresh.has(r.quid);
      const cell = document.createElement("div");
      cell.className = "q-cell rq-cell" + (isNew ? " is-new" : "");
      cell.setAttribute("data-quid", r.quid);
      const card = cardFor(r.quid, i + 1, statusChip(v.status) + langSelect());
      card.insertAdjacentHTML("beforeend", barFor(v, isNew));
      cell.appendChild(card);
      frag.appendChild(cell);
    });
    box.appendChild(frag);
  }
  const canMore = t.next != null && t.items.length < MAX_ITEMS;
  $("rqMore").hidden = !canMore;
  $("rqEnd").hidden = canMore || !t.items.length;
  $("rqEnd").textContent = t.items.length >= MAX_ITEMS ? "Showing your latest " + MAX_ITEMS + " reports." : "That's all.";
  if (typeof renderMath === "function") renderMath();
  sc.scrollTop = y;
  markActive();
}

async function loadTab(tab, opts) {
  opts = opts || {};
  const append = !!opts.append;
  const cur = S.tabs[tab];
  if (S.loading) return;
  S.loading = true;
  if (!append && tab === S.tab && !cur) skeleton();
  const btn = $("rqMoreBtn");
  if (append) { btn.disabled = true; btn.textContent = "Loading…"; }
  try {
    const offset = append && cur ? cur.items.length : 0;
    const d = await API.list(tab, offset);
    Object.assign(S.questions, d.questions || {});
    if (d.counts) S.counts = Object.assign({ updated: 0, review: 0, unread: 0 }, d.counts);
    const items = (d.reports || []);
    const base = append && cur ? cur.items : [];
    const seenQ = new Set(base.map(x => x.quid));
    S.tabs[tab] = { items: base.concat(items.filter(x => !seenQ.has(x.quid))).slice(0, MAX_ITEMS), next: d.next_offset != null ? d.next_offset : null };
    saveCache();
    if (tab === S.tab) paintList(append);
    if (tab === "updated") markSeen(items);
  } catch (e) {
    if (e && e.login) { location.replace("/?login&redirect=" + encodeURIComponent(location.pathname + location.search)); return; }
    if (!append && !S.tabs[tab]) {
      $("rqList").innerHTML = '<div class="rq-empty"><div class="rq-empty-ico">' + IC.info + '</div><h3>Could not load</h3>' +
        '<p>Check your internet connection and try again.</p><button type="button" class="rq-btn rq-btn-primary" data-retry>Try again</button></div>';
    } else toast("Could not load. Try again.");
  } finally {
    S.loading = false;
    btn.disabled = false; btn.textContent = "Load more";
  }
}

// Admin updates on the page that was just shown → ONE /seen call (≤10 quids).
// They keep the NEW look for this visit; the home badge clears right away.
async function markSeen(items) {
  const quids = items.filter(r => !r.seen && view(r).status !== "review").map(r => r.quid).slice(0, 10);
  if (!quids.length) return;
  quids.forEach(q => S.fresh.add(q));
  if (S.tab === "updated") paintList(true);
  const since = Date.now();                            // a chat flag set after this (user wrote meanwhile) stays
  try {
    await API.seen(quids);
    Object.keys(S.tabs).forEach(k => (S.tabs[k] ? S.tabs[k].items : []).forEach(r => { if (quids.indexOf(r.quid) >= 0) r.seen = true; }));
    S.counts.unread = Math.max(0, (S.counts.unread | 0) - quids.length);
    saveCache();
    paintBadges();
    if (window.MMHReportFlags) MMHReportFlags.clear(quids, since);   // badge gone + flag deleted (seen)
  } catch (e) { /* stays unseen; next visit tries again */ }
}

function switchTab(tab) {
  if (tab !== "updated" && tab !== "review") return;
  if (tab === S.tab && S.tabs[tab]) { $("rqScroll").scrollTo({ top: 0, behavior: "smooth" }); return; }
  S.tab = tab;
  try { const u = new URL(location.href); u.searchParams.set("tab", tab); u.searchParams.delete("fresh"); history.replaceState(history.state, "", u.pathname + u.search + u.hash); } catch (e) {}
  $("rqScroll").scrollTop = 0;
  paintList(false);
  if (!S.tabs[tab]) loadTab(tab);
  else if (tab === "updated") markSeen(S.tabs[tab].items);
}

function findItem(quid) {
  for (const k of ["updated", "review"]) {
    const t = S.tabs[k];
    const r = t && t.items.find(x => x.quid === quid);
    if (r) return r;
  }
  return null;
}
function indexOfQuid(quid) {
  const t = S.tabs[S.tab];
  const i = t ? t.items.findIndex(x => x.quid === quid) : -1;
  return i >= 0 ? i + 1 : 1;
}

// ══════════════════════════════════════════════════════════════════════════
//  DETAILS SHEET
// ══════════════════════════════════════════════════════════════════════════
function detailsHtml(r) {
  const v = view(r);
  const st = v.status;
  const repMs = toMs(r.reported_at) || toMs(v.first && v.first.at);
  const userReplies = v.thread.filter(m => m.from !== "admin" && !(m.reason || m.details)).length;
  const lastAdmin = v.lastAdmin;
  let html =
    '<div class="rq-hero is-' + st + '"><div class="rq-hero-ico">' + statusIcon(st) + '</div><div>' +
      '<div class="rq-hero-title">' + STATUS_TXT[st].hero + '</div>' +
      '<div class="rq-hero-sub">' + STATUS_TXT[st].sub + '</div></div></div>' +
    '<div class="rq-sec-label">Your report</div>' +
    '<div class="rq-kv">' +
      '<div class="rq-kv-row"><div class="rq-kv-k">Reason</div><div class="rq-kv-v">' + esc(v.reason) + '</div></div>' +
      '<div class="rq-kv-row"><div class="rq-kv-k">Details</div><div class="rq-kv-v' + (v.details ? " plain" : " muted") + '">' + (v.details ? esc(v.details) : "No details written") + '</div></div>' +
      '<div class="rq-kv-row"><div class="rq-kv-k">Reported</div><div class="rq-kv-v">' + esc(fullDate(repMs)) + '</div></div>' +
      (userReplies ? '<div class="rq-kv-row"><div class="rq-kv-k">Your replies</div><div class="rq-kv-v">' + userReplies + ' in chat</div></div>' : '') +
    '</div>';
  if (lastAdmin) {
    html += '<div class="rq-sec-label">Latest from admin</div><div class="rq-admin-box">' + esc(lastAdmin.text || "") +
      (toMs(lastAdmin.at) ? '<small>' + esc(fullDate(toMs(lastAdmin.at))) + '</small>' : '') + '</div>';
  }
  const step = (cls, t, s) => '<div class="rq-step ' + cls + '"><div class="rq-step-dot">' + (cls === "done" ? IC.check : "") + '</div><div><div class="rq-step-t">' + t + '</div>' + (s ? '<div class="rq-step-s">' + s + '</div>' : '') + '</div></div>';
  html += '<div class="rq-sec-label">Progress</div><div class="rq-steps">' +
    step("done", "Reported", esc(fullDate(repMs))) +
    (st === "review"
      ? step("now", "Under review", "Admin will check it soon")
      : step("done", "Checked by admin", "") +
        (st === "fixed" ? step("done", "Question corrected", "The corrected version is shown above")
                        : step("done", "Admin replied", lastAdmin && toMs(lastAdmin.at) ? esc(fullDate(toMs(lastAdmin.at))) : ""))) +
    '</div>';
  return html;
}
function openSheet(quid, push) {
  const r = findItem(quid);
  if (!r) return;
  if (S.wide) { openSide(quid); return; }
  S.sheetQuid = quid;
  $("rqSheetBody").innerHTML = detailsHtml(r);
  $("rqSheetBody").scrollTop = 0;
  $("rqSheet").hidden = false;
  if (push !== false) history.pushState({ rq: "sheet", quid: quid }, "", location.pathname + location.search + location.hash);
}
function closeSheetUI() { $("rqSheet").hidden = true; S.sheetQuid = ""; }
function closeSheet() {
  if ($("rqSheet").hidden) return;
  if (history.state && history.state.rq === "sheet") history.back();
  else closeSheetUI();
}

// ══════════════════════════════════════════════════════════════════════════
//  RIGHT PANE (big screens, Telegram Desktop style) — empty · details · chat
// ══════════════════════════════════════════════════════════════════════════
function markActive() {
  document.querySelectorAll("#rqList .rq-cell").forEach(c =>
    c.classList.toggle("is-active", S.wide && !!S.sideQuid && c.getAttribute("data-quid") === S.sideQuid));
}
function openSide(quid) {
  const r = findItem(quid);
  if (!r) return;
  if (!$("rqChat").hidden) closeChatUI(true);
  S.sideQuid = quid;
  $("rqPaneSub").textContent = "Question " + indexOfQuid(quid) + " · " + view(r).reason;
  $("rqPaneBody").innerHTML = detailsHtml(r);
  $("rqPaneBody").scrollTop = 0;
  $("rqPaneEmpty").hidden = true;
  $("rqPaneDetails").hidden = false;
  markActive();
}
function closeSide() {
  if (!$("rqChat").hidden) closeChatUI(true);
  S.sideQuid = "";
  $("rqPaneDetails").hidden = true;
  $("rqPaneEmpty").hidden = false;
  markActive();
}
// Switch between the right pane and the phone layout (sheet + full screen chat).
function placeLayout() {
  S.wide = window.matchMedia("(min-width:992px) and (hover:hover) and (pointer:fine)").matches;
  document.body.classList.toggle("rq-wide", S.wide);
  const hdr = document.querySelector(".exam-page-container > .screen-header");
  if (hdr) document.documentElement.style.setProperty("--rq-hdr", hdr.offsetHeight + "px");
  const chat = $("rqChat");
  const home = S.wide ? $("rqPaneScreen") : document.body;
  if (chat.parentNode !== home) {
    // leaving one layout: close whatever was open in it
    if (!chat.hidden) closeChatUI(true);
    if (!$("rqSheet").hidden) closeSheetUI();
    closeSide();
    if (history.state && history.state.rq) history.replaceState(null, "", location.pathname + location.search);
    home.appendChild(chat);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  CHAT
// ══════════════════════════════════════════════════════════════════════════
// a message can be replied to once it is saved (not while sending / failed)
const canReply = m => m && m._i != null && (!m._st || m._st === "sent");
function whoName(m) { return m.from === "admin" ? "Admin" : "You"; }
function msgPreview(m) {
  if (!m) return "Message";
  if (m.from !== "admin" && (m.reason || m.details)) return "Report · " + (m.reason || "Reported");
  return String(m.text || "").replace(/\s+/g, " ").trim() || "Message";
}
function quoteHtml(thread, k) {
  const q = thread.find(x => x._i === k);
  if (!q) return "";
  return '<span class="rq-quote" data-jump="' + k + '"><b>' + esc(whoName(q)) + '</b><span>' + esc(msgPreview(q).slice(0, 160)) + '</span></span>';
}
function bubble(m, cls, inner) {
  const out = m.from !== "admin";
  const ms = toMs(m.at);
  let tick = "";
  if (out) tick = m._st === "sending" ? IC.wait : m._st === "fail" ? IC.fail : IC.tick;
  const rep = canReply(m);
  return '<div class="rq-msg ' + (out ? "out" : "in") + " " + cls + (m._st === "fail" ? " fail" : "") + '"' +
    (m._id ? ' data-mid="' + m._id + '"' : "") + (m._i != null ? ' data-i="' + m._i + '"' : "") + '>' +
    (rep ? '<button type="button" class="rq-reply-btn" data-reply="' + m._i + '" aria-label="Reply" title="Reply">' + IC.back + '</button>' +
           '<span class="rq-swipe-ico" aria-hidden="true">' + IC.back + '</span>' : "") +
    '<div class="rq-bubble">' + inner +
    // a message without a time → no empty meta line
    (ms || tick ? '<span class="rq-spacer"></span><span class="rq-meta">' + (ms ? esc(timeLabel(ms)) : "") + tick + '</span>' : "") +
    '</div></div>' +
    (m._st === "fail" ? '<button type="button" class="rq-retry" data-retry-mid="' + m._id + '">Not sent · Tap to retry</button>' : "");
}
function paintChat(scrollBottom) {
  const r = findItem(S.chatQuid);
  if (!r) return;
  const v = view(r);
  const list = $("rqChatList");
  // the stored order IS the time order (append-only) — never re-sorted, so indexes match
  const msgs = v.thread.slice();
  let html = "";
  let lastDay = "";
  msgs.forEach((m, i) => {
    const ms = toMs(m.at);
    if (ms && dayKey(ms) !== lastDay) {
      lastDay = dayKey(ms);
      html += '<div class="rq-day"><span>' + esc(dayLabel(ms)) + '</span></div>';
    }
    const prev = msgs[i - 1], next = msgs[i + 1];
    const side = x => x ? (x.from === "admin" ? "in" : "out") : "";
    const nextDay = next && toMs(next.at) && ms && dayKey(toMs(next.at)) !== dayKey(ms);
    const firstInGroup = !prev || side(prev) !== side(m) || (ms && prev && toMs(prev.at) && dayKey(toMs(prev.at)) !== dayKey(ms));
    const tail = !next || side(next) !== side(m) || nextDay;
    const cls = (firstInGroup ? "first " : "") + (tail ? "tail" : "");
    let inner;
    const quote = m.r != null ? quoteHtml(v.thread, Number(m.r)) : "";
    if (m.from !== "admin" && (m.reason || m.details)) {
      inner = '<span class="rq-report-head">' + IC.flag + 'Report</span>' +
              '<span class="rq-report-reason">' + esc(m.reason || "Reported") + '</span>' +
              (m.details ? '<span class="rq-report-details">' + esc(m.details) + '</span>' : "");
    } else {
      inner = (m.from === "admin" && firstInGroup ? '<span class="rq-name">Admin</span>' : "") + quote + esc(m.text || "");
    }
    html += bubble(m, cls, inner);
    // right after the report: a hint while it waits
    if (i === 0 && v.status === "review" && msgs.length === 1) {
      html += '<div class="rq-thread-hint"><span><b>Under review</b>Admin will check this question soon. You can add more details or a source here.</span></div>';
    }
  });
  if (v.status === "fixed") html += '<div class="rq-sys"><span>' + IC.check + 'Admin corrected this question</span></div>';
  list.innerHTML = html;
  paintReplyBar();
  const sc = $("rqChatScroll");
  if (scrollBottom) requestAnimationFrame(() => { sc.scrollTop = sc.scrollHeight; });
}
function paintQPanel() {
  const panel = $("rqQPanel");
  panel.innerHTML = "";
  const r = findItem(S.chatQuid);
  if (!r) return;
  const card = cardFor(S.chatQuid, indexOfQuid(S.chatQuid), langSelect());
  panel.appendChild(card);
  if (typeof renderMath === "function") renderMath();
}
function setQPanel(open) {
  $("rqQLayer").hidden = !open;
  $("rqPin").setAttribute("aria-expanded", open ? "true" : "false");
  if (open) paintQPanel();
}
function openChat(quid, push) {
  const r = findItem(quid);
  if (!r) return;
  const v = view(r);
  if (S.chatQuid !== quid) S.replyTo = null;
  S.chatQuid = quid;
  S.chatOpened.add(quid);
  if (S.wide) { S.sideQuid = quid; push = false; markActive(); }
  const cb = document.querySelector('#rqList .rq-cell[data-quid="' + quid + '"] [data-act="chat"]');
  if (cb) { cb.classList.remove("rq-btn-primary"); cb.classList.add("rq-btn-soft"); const c = cb.querySelector(".rq-count"); if (c) c.remove(); }
  $("rqChatSub").textContent = "Question " + indexOfQuid(quid) + " · " + v.reason;
  $("rqPinText").textContent = questionPreview(quid);
  setQPanel(false);
  $("rqChat").hidden = false;
  if (!S.wide) document.body.classList.add("rq-chat-open");
  paintChat(true);
  const inp = $("rqInput");
  inp.value = loadDraft(quid);
  autosize(); syncSend();
  if (push !== false) history.pushState({ rq: "chat", quid: quid }, "", location.pathname + location.search + "#chat=" + encodeURIComponent(quid));
  // an admin message waiting → mark seen (same /seen call)
  if (!r.seen && v.status !== "review") markSeen([r]);
}
function closeChatUI(quiet) {
  saveDraft();
  S.replyTo = null;
  $("rqChat").hidden = true;
  document.body.classList.remove("rq-chat-open");
  setQPanel(false);
  S.chatQuid = "";
  if (!quiet) paintList(true);
}
function closeChat() {
  if ($("rqChat").hidden) return;
  // right pane: Back = the same report's details
  if (S.wide) { const q = S.chatQuid; closeChatUI(true); paintList(true); openSide(q); return; }
  if (history.state && history.state.rq === "chat") history.back();
  else { closeChatUI(); history.replaceState(null, "", location.pathname + location.search); }
}

// ── reply-to (Telegram) ─────────────────────────────────────────────────────
function threadOf(quid) { const r = findItem(quid); return r ? view(r).thread : []; }
function setReply(i) {
  const m = threadOf(S.chatQuid).find(x => x._i === i);
  if (!canReply(m)) return;
  S.replyTo = i;
  paintReplyBar();
  const inp = $("rqInput");
  // phones: focus opens the keyboard like Telegram; keep the caret at the end
  try { inp.focus({ preventScroll: true }); inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) {}
}
function clearReply() { if (S.replyTo === null) return; S.replyTo = null; paintReplyBar(); }
function paintReplyBar() {
  const bar = $("rqReplyBar"), sc = $("rqChatScroll");
  const m = S.replyTo === null ? null : threadOf(S.chatQuid).find(x => x._i === S.replyTo);
  // the bar makes the chat shorter → stay pinned to the bottom if we were there (Telegram)
  const atBottom = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 48;
  if (!m) { S.replyTo = null; bar.hidden = true; }
  else {
    $("rqReplyName").textContent = "Reply to " + (m.from === "admin" ? "Admin" : "yourself");
    $("rqReplyText").textContent = msgPreview(m).slice(0, 160);
    bar.hidden = false;
  }
  if (atBottom) sc.scrollTop = sc.scrollHeight;
}
function jumpTo(i) {
  const el = $("rqChatList").querySelector('.rq-msg[data-i="' + i + '"]');
  if (!el) return;
  el.scrollIntoView({ block: "center", behavior: "smooth" });
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  setTimeout(() => el.classList.remove("flash"), 1200);
}
// swipe a message to the LEFT (touch) → reply, like Telegram
function bindSwipe(list) {
  const MAX = 84, GO = 56;
  let st = null;
  list.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) { st = null; return; }
    const row = e.target.closest(".rq-msg[data-i]");
    if (!row || !row.querySelector(".rq-swipe-ico")) { st = null; return; }
    const t = e.touches[0];
    st = { row: row, x: t.clientX, y: t.clientY, dx: 0, on: false, dead: false, ready: false,
           bub: row.querySelector(".rq-bubble"), ico: row.querySelector(".rq-swipe-ico") };
  }, { passive: true });
  list.addEventListener("touchmove", e => {
    if (!st || st.dead) return;
    const t = e.touches[0];
    const dx = t.clientX - st.x, dy = t.clientY - st.y;
    if (!st.on) {
      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) { st.dead = true; return; }   // vertical → scroll
      if (dx < -10 && Math.abs(dx) > Math.abs(dy) * 1.2) { st.on = true; st.row.classList.add("swiping"); }
      else return;
    }
    if (e.cancelable) e.preventDefault();
    const pull = Math.max(-MAX, Math.min(0, dx));
    const eased = pull > -GO ? pull : -GO - (-pull - GO) * 0.35;           // resistance after the threshold
    st.dx = pull;
    st.bub.style.transform = "translateX(" + eased + "px)";
    const p = Math.min(1, -pull / GO);
    st.ico.style.opacity = String(p);
    st.ico.style.transform = "scale(" + (0.4 + 0.6 * p) + ")";
    const ready = -pull >= GO;
    if (ready !== st.ready) {
      st.ready = ready;
      st.row.classList.toggle("ready", ready);
      if (ready && navigator.vibrate) try { navigator.vibrate(8); } catch (e2) {}
    }
  }, { passive: false });
  const end = () => {
    if (!st) return;
    const s0 = st; st = null;
    if (!s0.on) return;
    s0.row.classList.remove("swiping", "ready");
    s0.bub.style.transform = "";
    s0.ico.style.opacity = ""; s0.ico.style.transform = "";
    if (s0.ready) setReply(Number(s0.row.getAttribute("data-i")));
  };
  list.addEventListener("touchend", end);
  list.addEventListener("touchcancel", end);
}

// two-finger swipe left on a laptop trackpad → reply (Telegram Desktop does the same)
function bindTrackpadSwipe(list) {
  const GO = 56, MAX = 84;
  let st = null, timer = 0;
  const finish = () => {
    if (!st) return;
    const s0 = st; st = null;
    s0.row.classList.remove("swiping", "ready");
    s0.bub.style.transform = ""; s0.ico.style.opacity = ""; s0.ico.style.transform = "";
    if (s0.ready) setReply(Number(s0.row.getAttribute("data-i")));
  };
  list.addEventListener("wheel", e => {
    if (!st) {
      if (Math.abs(e.deltaX) <= Math.abs(e.deltaY) || e.deltaX <= 0) return;   // only a sideways swipe to the left
      const row = e.target.closest(".rq-msg[data-i]");
      if (!row || !row.querySelector(".rq-swipe-ico")) return;
      st = { row: row, pull: 0, ready: false, bub: row.querySelector(".rq-bubble"), ico: row.querySelector(".rq-swipe-ico") };
      row.classList.add("swiping");
    }
    e.preventDefault();
    st.pull = Math.max(0, Math.min(MAX, st.pull + e.deltaX * (e.deltaMode === 1 ? 16 : 1)));
    const eased = st.pull < GO ? st.pull : GO + (st.pull - GO) * 0.35;
    st.bub.style.transform = "translateX(" + (-eased) + "px)";
    const p = Math.min(1, st.pull / GO);
    st.ico.style.opacity = String(p); st.ico.style.transform = "scale(" + (0.4 + 0.6 * p) + ")";
    st.ready = st.pull >= GO; st.row.classList.toggle("ready", st.ready);
    clearTimeout(timer); timer = setTimeout(finish, 140);   // fingers lifted → wheel events stop
  }, { passive: false });
}

// drafts (sessionStorage, per quid)
function loadDraft(q) { try { return sessionStorage.getItem("mmh_rq_draft_" + q) || ""; } catch (e) { return ""; } }
function saveDraft() {
  if (!S.chatQuid) return;
  try {
    const v = $("rqInput").value;
    if (v.trim()) sessionStorage.setItem("mmh_rq_draft_" + S.chatQuid, v);
    else sessionStorage.removeItem("mmh_rq_draft_" + S.chatQuid);
  } catch (e) {}
}
function autosize() {
  const t = $("rqInput");
  t.style.height = "auto";
  t.style.height = Math.min(t.scrollHeight, 132) + "px";
}
function syncSend() { $("rqSend").disabled = !$("rqInput").value.trim(); }

let midSeq = 0;
async function sendMessage(text, existing) {
  const quid = S.chatQuid;
  const r = findItem(quid);
  if (!r) return;
  if (!Array.isArray(r.chat)) r.chat = [];
  let m = existing;
  if (!m) {
    m = { from: "user", text: text, at: Math.floor(Date.now() / 1000), _st: "sending", _id: "m" + (++midSeq) };
    if (S.replyTo !== null) m.r = S.replyTo;
    r.chat.push(m);
    clearReply();
  } else { m._st = "sending"; }
  paintChat(true);
  try {
    const d = await API.reply(quid, m.text, m.r);
    m._st = "sent";
    if (d && d.at) m.at = d.at;
    delete m._id;
    // the Worker's chat is the truth (exact indexes + any admin message that came meanwhile);
    // messages still sending / failed stay at the end
    if (d && Array.isArray(d.thread)) {
      const pending = r.chat.filter(x => x._st && x !== m && x._st !== "sent");
      r.chat = d.thread.concat(pending);
    }
    if (window.MMHReportFlags) MMHReportFlags.add(quid, "c");
    saveCache();
  } catch (e) {
    if (e && e.login) { location.replace("/?login&redirect=" + encodeURIComponent(location.pathname + location.search)); return; }
    m._st = "fail";
  }
  if (S.chatQuid === quid) paintChat(true);
}

// ══════════════════════════════════════════════════════════════════════════
//  EVENTS
// ══════════════════════════════════════════════════════════════════════════
function setLang(l) {
  if (["en", "hi", "bilingual"].indexOf(l) < 0 || l === S.lang) return;
  S.lang = l;
  try { localStorage.setItem("quiz_lang", l); } catch (e) {}
  paintList(true);
  if (!$("rqQLayer").hidden) paintQPanel();
  if (S.chatQuid) $("rqPinText").textContent = questionPreview(S.chatQuid);
}

function bind() {
  $("rqBack").addEventListener("click", () => {
    if (window.MMHNav) { MMHNav.back("/index.html"); return; } /* t255 */
    const ref = document.referrer;
    if (history.length > 1 && ref && ref.indexOf(location.origin) === 0) history.back();
    else location.href = "/";
  });
  $("rqRefresh").addEventListener("click", async () => {
    const b = $("rqRefresh");
    if (b.classList.contains("spin")) return;
    b.classList.add("spin");
    const other = S.tab === "updated" ? "review" : "updated";
    S.tabs[other] = null;          // re-fetched when opened
    await loadTab(S.tab);
    b.classList.remove("spin");
  });
  $("rqDock").addEventListener("click", e => {
    const b = e.target.closest(".ex-dock-item");
    if (b) switchTab(b.getAttribute("data-tab"));
  });
  $("rqMoreBtn").addEventListener("click", () => loadTab(S.tab, { append: true }));
  $("rqList").addEventListener("click", e => {
    const go = e.target.closest("[data-go-tab]");
    if (go) { switchTab(go.getAttribute("data-go-tab")); return; }
    if (e.target.closest("[data-retry]")) { S.tabs[S.tab] = null; loadTab(S.tab); return; }
    const a = e.target.closest("[data-act]");
    if (!a) return;
    const cell = a.closest(".rq-cell");
    const quid = cell && cell.getAttribute("data-quid");
    if (!quid) return;
    if (a.getAttribute("data-act") === "details") openSheet(quid);
    else openChat(quid);
  });
  document.addEventListener("change", e => {
    if (e.target && e.target.classList && e.target.classList.contains("card-lang-dropdown")) setLang(e.target.value);
  });

  // sheet
  $("rqSheet").addEventListener("click", e => { if (e.target.closest("[data-close]")) closeSheet(); });
  $("rqSheetChat").addEventListener("click", () => {
    const q = S.sheetQuid;
    // replace the sheet's history entry with the chat's
    closeSheetUI();
    if (history.state && history.state.rq === "sheet") {
      history.replaceState({ rq: "chat", quid: q }, "", location.pathname + location.search + "#chat=" + encodeURIComponent(q));
      openChat(q, false);
    } else openChat(q);
  });

  // right pane
  $("rqPaneClose").addEventListener("click", closeSide);
  $("rqPaneChat").addEventListener("click", () => { if (S.sideQuid) openChat(S.sideQuid); });
  const mq = window.matchMedia("(min-width:992px) and (hover:hover) and (pointer:fine)");
  if (mq.addEventListener) mq.addEventListener("change", placeLayout); else if (mq.addListener) mq.addListener(placeLayout);

  // chat
  $("rqChatBack").addEventListener("click", closeChat);
  $("rqPin").addEventListener("click", () => setQPanel($("rqQLayer").hidden));
  $("rqQLayer").addEventListener("click", e => { if (e.target.closest("[data-qclose]")) setQPanel(false); });
  const inp = $("rqInput");
  inp.addEventListener("input", () => { autosize(); syncSend(); });
  inp.addEventListener("keydown", e => {
    // desktop: Enter sends, Shift+Enter = new line. Phones keep Enter = new line.
    if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(hover:hover) and (pointer:fine)").matches) {
      e.preventDefault();
      $("rqComposer").requestSubmit ? $("rqComposer").requestSubmit() : $("rqSend").click();
    }
  });
  $("rqComposer").addEventListener("submit", e => {
    e.preventDefault();
    const text = inp.value.replace(/\s+$/, "").replace(/^\s+/, "").slice(0, MSG_MAX);
    if (!text) return;
    inp.value = ""; autosize(); syncSend();
    try { sessionStorage.removeItem("mmh_rq_draft_" + S.chatQuid); } catch (e2) {}
    sendMessage(text);
    inp.focus();
  });
  // reply (Telegram): swipe left on touch / trackpad; mouse resting on a message → reply arrow
  $("rqChatList").addEventListener("click", e => {
    const rb = e.target.closest("[data-reply]");
    if (rb) { setReply(Number(rb.getAttribute("data-reply"))); return; }
    const jq = e.target.closest("[data-jump]");
    if (jq) { jumpTo(Number(jq.getAttribute("data-jump"))); return; }
  });
  bindSwipe($("rqChatList"));
  bindTrackpadSwipe($("rqChatList"));
  $("rqReplyCancel").addEventListener("click", () => { clearReply(); $("rqInput").focus(); });
  $("rqReplyJump").addEventListener("click", () => { if (S.replyTo !== null) jumpTo(S.replyTo); });
  $("rqChatList").addEventListener("click", e => {
    const b = e.target.closest("[data-retry-mid]");
    if (!b) return;
    const r = findItem(S.chatQuid);
    const m = r && (r.chat || []).find(x => x._id === b.getAttribute("data-retry-mid"));
    if (m) sendMessage(m.text, m);
  });

  // hardware / browser back
  window.addEventListener("popstate", () => {
    const st = history.state;
    if (!$("rqSheet").hidden && !(st && st.rq === "sheet")) closeSheetUI();
    if (!$("rqChat").hidden && !(st && st.rq === "chat")) closeChatUI();
    if (st && st.rq === "chat" && $("rqChat").hidden && findItem(st.quid)) openChat(st.quid, false);
  });
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    if (!$("rqChat").hidden && S.replyTo !== null) { clearReply(); return; }   // Telegram: Esc cancels the reply first
    if (!$("rqQLayer").hidden) setQPanel(false);
    else if (!$("rqSheet").hidden) closeSheet();
    else if (!$("rqChat").hidden) closeChat();
    else if (S.wide && S.sideQuid) closeSide();
  });
  window.addEventListener("pagehide", saveDraft);
}

// ══════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════
async function boot() {
  bind();
  placeLayout();
  const qs = new URLSearchParams(location.search);
  if (qs.get("tab") === "review") S.tab = "review";
  paintDock();
  skeleton();
  try {
    const p = await API.profile();
    S.uid = p.uid;
  } catch (e) {
    if (e && e.login) { location.replace("/?login&redirect=" + encodeURIComponent(location.pathname + location.search)); return; }
  }
  const cached = qs.get("fresh") !== "1" && loadCache();
  if (qs.get("fresh") === "1") {
    try { const u = new URL(location.href); u.searchParams.delete("fresh"); history.replaceState(null, "", u.pathname + u.search + u.hash); } catch (e) {}
  }
  if (cached && S.tabs[S.tab]) {
    paintList(false);
    if (S.tab === "updated") markSeen(S.tabs.updated.items);
  } else {
    await loadTab(S.tab);
  }
  // reload with #chat=<quid> → reopen that chat
  const m = location.hash.match(/^#chat=([A-Za-z0-9_-]+)/);
  if (m && findItem(m[1])) {
    // list entry underneath, chat on top → Back closes the chat, not the page
    history.replaceState(null, "", location.pathname + location.search);
    openChat(m[1]);
  } else if (m) {
    history.replaceState(null, "", location.pathname + location.search);
  }
}

// ── phones + keyboard: the chat header must never scroll away ───────────────
// The chat is a fixed full-screen layer (header · messages · composer).
// Chrome / Android: <meta viewport … interactive-widget=resizes-content> makes the page
// itself shrink above the keyboard, so the layer simply gets shorter (nothing to do here).
// iOS Safari & browsers without it: only the VISIBLE area (visualViewport) shrinks and the
// page is panned up → pin the layer to the visible area. The newest message stays in view.
function keyboardFit() {
  const vv = window.visualViewport, el = document.getElementById("rqChat"), sc = document.getElementById("rqChatScroll");
  if (!el || !sc) return;
  let stick = true;
  sc.addEventListener("scroll", () => { stick = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 48; }, { passive: true });
  function fit() {
    const full = document.documentElement.clientHeight;
    const on = vv && !el.hidden && !document.body.classList.contains("rq-wide") && vv.scale < 1.01 && vv.height < full - 1;
    if (on) { el.style.top = vv.offsetTop + "px"; el.style.height = vv.height + "px"; el.style.bottom = "auto"; }
    else if (el.style.height) { el.style.top = ""; el.style.height = ""; el.style.bottom = ""; }
    if (stick && !el.hidden) sc.scrollTop = sc.scrollHeight;
  }
  if (vv) { vv.addEventListener("resize", fit); vv.addEventListener("scroll", fit); }
  window.addEventListener("resize", fit);
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { boot(); keyboardFit(); });
else { boot(); keyboardFit(); }
})();

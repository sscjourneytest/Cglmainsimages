/* ═══════════════════════════════════════════════════════════════════════════
   mmh-nav.js — t255  (one small helper for every header back arrow)

   The rule:
     the header back arrow does EXACTLY what the phone back button would do,
     whenever that is the right parent — and never anything else.

   · Each page remembers WHERE IT CAME FROM, stored on its own history entry
     (history.state.mmhFrom). sessionStorage only carries it across one page
     load (no localStorage, no cache).
   · MMHNav.up(parent)  — hierarchical pages (exam / pdf folders):
         came from that parent  → history.back()   (same as phone back)
         anything else          → location.replace(parent)  (no new entry)
   · MMHNav.back(fallback) — utility pages (premium, profile, saved …):
         came from any app page → history.back()
         direct link            → location.replace(fallback)
     So the header arrow can never close the app and never adds an entry,
     which keeps the phone back (MainActivity → webView.goBack) clean.
   · MMHNav.show(ids, id) — in-page screens: the slide direction comes from
     the screen depth (deeper = from right, shallower = from left, same =
     none). No slide at all on a page load / restore.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.MMHNav) return;

    var H = window.history, D = document, R = D.documentElement;
    var K_LAST = 'mmhNav.last', K_REP = 'mmhNav.rep';
    var DROP = /^(q|utm_.*|fbclid|gclid|ref)$/i;

    function ss(k, v) {
        try {
            if (v === undefined) { var s = sessionStorage.getItem(k); return s ? JSON.parse(s) : null; }
            if (v === null) sessionStorage.removeItem(k); else sessionStorage.setItem(k, JSON.stringify(v));
        } catch (e) { return null; }
    }

    /* "/" ≡ "/index.html", hash + tracking params ignored, params sorted */
    function norm(u) {
        try {
            var a = new URL(u, location.href);
            if (a.origin !== location.origin) return '';
            var p = a.pathname.replace(/\/{2,}/g, '/');
            if (p.charAt(p.length - 1) === '/') p += 'index.html';
            if (p === '/index.html') return p;              /* Home is Home (?login, ?redirect … are only modals) */
            var q = [];
            a.searchParams.forEach(function (v, k) { if (!DROP.test(k)) q.push(k + '=' + v); });
            q.sort();
            return p + (q.length ? '?' + q.join('&') : '');
        } catch (e) { return ''; }
    }

    function st() { var s = H.state; return (s && typeof s === 'object') ? s : null; }
    function from() { var s = st(); return (s && s.mmhFrom) || ''; }
    function first() { var s = st(); return !!(s && s.mmhFirst); }
    function idx() { var s = st(); return (s && typeof s.mmhIdx === 'number') ? s.mmhIdx : -1; }
    function saveLast() { ss(K_LAST, { url: norm(location.href), idx: idx() }); }

    /* ── history wrappers: every in-page entry keeps the page's "from" ── */
    var _push = H.pushState, _rep = H.replaceState;
    function carry(s, keepFirst) {
        var cur = st();
        if (!cur || !('mmhFrom' in cur)) return s;
        if (s !== null && s !== undefined && typeof s !== 'object') return s;
        var o = {}, k;
        if (s) for (k in s) if (Object.prototype.hasOwnProperty.call(s, k)) o[k] = s[k];
        if (!('mmhFrom' in o)) o.mmhFrom = cur.mmhFrom;
        if (keepFirst && cur.mmhFirst && !('mmhFirst' in o)) o.mmhFirst = 1;
        if (typeof cur.mmhIdx === 'number') o.mmhIdx = cur.mmhIdx + (keepFirst ? 0 : 1);
        return o;
    }
    H.pushState = function (s, t, u) { var r = _push.call(H, carry(s, false), t, u); saveLast(); return r; };
    H.replaceState = function (s, t, u) { var r = _rep.call(H, carry(s, true), t, u); saveLast(); return r; };

    /* ── on load: find where this page came from ── */
    (function init() {
        var type = '';
        try { type = performance.getEntriesByType('navigation')[0].type; } catch (e) {}
        var here = norm(location.href), last = ss(K_LAST), rep = ss(K_REP), cur = st();
        ss(K_REP, null);
        if (cur && ('mmhFrom' in cur) && type !== 'navigate') { saveLast(); return; } /* reload / back-forward: entry already knows */
        /* a new page is always the LAST entry; it came from `last` only if that
           page sat right before it (works after back + new link too) */
        var f = '', i = H.length - 1;
        if (rep && rep.to === here && Date.now() - rep.t < 20000) { f = rep.from || ''; if (rep.idx >= 0) i = rep.idx; }
        else if (type === 'navigate' && last && last.url && last.url !== here && last.idx === H.length - 2) f = last.url;
        var o = {}, k;
        if (cur) for (k in cur) if (Object.prototype.hasOwnProperty.call(cur, k)) o[k] = cur[k];
        o.mmhFrom = f; o.mmhFirst = 1; o.mmhIdx = i;
        try { _rep.call(H, o, '', location.href); } catch (e) {}
        saveLast();
    })();

    var leaving = false, tapAt = Date.now();   /* no back in the first 450 ms of a page (a double tap's 2nd tap) */
    addEventListener('popstate', function () { saveLast(); });
    addEventListener('pagehide', function () { saveLast(); });
    addEventListener('pageshow', function (e) { leaving = false; if (e.persisted) { tapAt = Date.now(); saveLast(); } });

    /* one back per tap: blocks double / triple taps */
    function tap() {
        var n = Date.now();
        if (leaving || n - tapAt < 450) return false;
        tapAt = n; return true;
    }
    function replaceTo(url, f) {
        leaving = true;
        ss(K_REP, { to: norm(url), from: f || '', idx: idx(), t: Date.now() });
        location.replace(url);
    }
    function backTo(url) {
        leaving = true;
        var here = location.href, t = setTimeout(function () {
            if (location.href === here && D.visibilityState !== 'hidden') replaceTo(url, '');
        }, 1500);
        var stop = function () { clearTimeout(t); };
        addEventListener('pagehide', stop, { once: true });
        addEventListener('popstate', stop, { once: true });
        H.back();
    }

    var MMHNav = {
        norm: norm,
        from: from,
        tap: tap,
        /* hierarchical parent */
        up: function (parent) {
            if (!tap()) return;
            var f = from();
            if (f && first() && f === norm(parent)) backTo(parent);
            else replaceTo(parent, (f && first() && f !== norm(parent)) ? f : '');
        },
        /* utility page: back to wherever the user came from */
        back: function (fallback) {
            if (!tap()) return;
            var f = from();
            if (f && first()) backTo(fallback || '/index.html');
            else replaceTo(fallback || '/index.html', '');
        },
        /* in-page header back on a screen WE pushed → pop it (= phone back) */
        pop: function () {
            if (!tap()) return true;
            var s = st();
            if (s && s.mmhNav) { H.back(); return true; }
            return false;
        },
        /* in-page screens, direction by depth */
        show: function (ids, id) {
            var cur = -1, to = ids.indexOf(id), i, e;
            for (i = 0; i < ids.length; i++) { e = D.getElementById(ids[i]); if (e && e.classList.contains('active')) cur = i; }
            for (i = 0; i < ids.length; i++) { e = D.getElementById(ids[i]); if (e) e.classList.remove('active', 'from-left', 'mmh-still'); }
            var el = D.getElementById(id);
            if (!el) return null;
            if (cur < 0 || to === cur) el.classList.add('mmh-still');
            else if (to < cur) el.classList.add('from-left');
            el.classList.add('active');
            reveal();
            return el;
        }
    };
    window.MMHNav = MMHNav;

    /* ── deep link / reload inside a drill (?filter=…): keep the screens hidden
          until the engine has picked the right one → no first-screen flash ── */
    var deepT = 0;
    function reveal() { if (deepT) { clearTimeout(deepT); deepT = 0; } R.classList.remove('mmh-deep'); }
    if (/[?&]filter=/.test(location.search)) { R.classList.add('mmh-deep'); deepT = setTimeout(reveal, 6000); }

    /* ── no slide on page load / restore ── */
    R.classList.add('mmh-boot');
    var css = D.createElement('style');
    css.textContent = 'html.mmh-boot .screen.active,.screen.active.mmh-still{animation:none!important}html.mmh-deep .screen{visibility:hidden!important}';
    (D.head || R).appendChild(css);
    function endBoot() {
        if (!R.classList.contains('mmh-boot')) return;
        Array.prototype.forEach.call(D.querySelectorAll('.screen.active'), function (s) {
            s.classList.add('mmh-still');          /* already on screen: must not slide now … */
            if (!window.MutationObserver) return;  /* … but slides again normally once it is left */
            var mo = new MutationObserver(function () {
                if (!s.classList.contains('active')) { s.classList.remove('mmh-still'); mo.disconnect(); }
            });
            mo.observe(s, { attributes: true, attributeFilter: ['class'] });
        });
        R.classList.remove('mmh-boot');
        ['pointerdown', 'touchstart', 'keydown', 'popstate'].forEach(function (n) { removeEventListener(n, endBoot, true); });
    }
    ['pointerdown', 'touchstart', 'keydown', 'popstate'].forEach(function (n) { addEventListener(n, endBoot, true); });
    addEventListener('pageshow', function (e) { if (e.persisted) { R.classList.add('mmh-boot'); ['pointerdown', 'touchstart', 'keydown', 'popstate'].forEach(function (n) { addEventListener(n, endBoot, true); }); } });

    /* ── plain <a class="nav-back" href="…"> arrows (premium, profile, policies …) ── */
    D.addEventListener('click', function (e) {
        if (e.defaultPrevented || e.button) return;
        var a = e.target && e.target.closest && e.target.closest('a.nav-back[href]');
        if (!a || a.target === '_blank') return;
        e.preventDefault();
        MMHNav.back(a.getAttribute('href'));
    });
})();

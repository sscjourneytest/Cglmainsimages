/* ═══════════════════════════════════════════════════════════════════════
   MMH PDFs & Study Materials — LIBRARY PAGE  (/pdfs/index.html?f=<path>)
   One page for every level:  ?f=free  ·  ?f=free/ssc  ·  ?f=free/ssc/cgl/2025
   Section level  → Free | Premium tabs + board tiles
   Board & deeper → breadcrumbs + search (searches the whole board, any depth)
   Cards: Open + Download (premium & not bought, in the app → Buy Premium),
          Share (website link) on every card.
   Website: premium Open/Download → "app only" sheet; no My Downloads.
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    var M = window.MMHPdf, ST = window.MMHPdfStore, I = M.I, esc = M.esc;
    var app = M.isApp() && ST && ST.supported();
    var S = { res: null, f: '', q: '' };
    var $ = function (id) { return document.getElementById(id); };

    /* ── boot ─────────────────────────────────────────────────────────── */
    function boot() {
        M.wireTheme();
        S.f = (M.qs('f') || 'free').replace(/^\/+|\/+$/g, '');
        S.q = M.qs('q') || '';
        skeleton();
        load(false);
        $('pdfBack').addEventListener('click', goBack);
        $('pdfMain').addEventListener('click', onClick);
        var inp = $('pdfSearchInput'), t = null;
        inp.addEventListener('input', function () {
            clearTimeout(t);
            t = setTimeout(function () { S.q = inp.value; $('pdfSearch').classList.toggle('has', !!S.q); syncUrl(); renderBody(); }, 140);
        });
        $('pdfSearchClear').addEventListener('click', function () { inp.value = ''; S.q = ''; $('pdfSearch').classList.remove('has'); syncUrl(); renderBody(); inp.focus(); });
        window.addEventListener('pageshow', function (e) { if (e.persisted && S.res) renderBody(); });
        window.addEventListener('mmhpdf:changed', function (e) {
            if (S.res) render();
            if (e.detail && e.detail.removed) M.toast('Premium ended — premium PDFs removed from My Downloads');
        });
    }
    function syncUrl() {
        try {
            var u = '/pdfs/index.html?f=' + S.f + (S.q ? '&q=' + encodeURIComponent(S.q) : '');
            history.replaceState(null, '', u);
        } catch (e) {}
    }
    function skeleton() {
        $('pdfMain').innerHTML = '<div class="pdf-cards">' + '<div class="pdf-skel skeleton-card"></div>'.repeat(5) + '</div>';
    }
    function load(fresh) {
        if (fresh) try { Object.keys(sessionStorage).forEach(function (k) { if (k.indexOf('mmh_pdfjson_v1:') === 0) sessionStorage.removeItem(k); }); } catch (e) {}
        M.resolve(S.f).then(function (res) {
            S.res = res;
            if (!res.chain.length) { S.f = 'free'; return load(false); }
            render();
        }).catch(fail);
    }
    function fail(e) {
        dockFor('free');
        if (e && e.notFound) {
            head('PDFs & Study Materials', 'Not found');
            return state('folder', 'This folder is not available', 'It may have been moved or renamed. Open the PDF library to find it again.', 'Open PDF library', '/pdfs/index.html?f=free');
        }
        if (e && e.missing) {
            head('PDFs & Study Materials', 'Coming soon');
            if (window.mmhPageFail) mmhPageFail.noData();
            return state('notes', 'PDFs are coming soon', 'Free PDFs & study materials will appear here very soon.');
        }
        head('PDFs & Study Materials', '');
        if (app && navigator.onLine === false && ST.list().length) {
            return state('wifi', "You're offline", 'Your saved PDFs still open without internet.', 'Open My Downloads', '/pdfs/downloads.html');
        }
        if (window.mmhPageFail) mmhPageFail.show({ retry: function () { skeleton(); load(false); } });
        else state('wifi', "Couldn't load PDFs", 'Check your internet and try again.', 'Reload', location.href);
    }
    function state(ico, title, text, btn, href) {
        $('pdfMain').innerHTML = '<div class="pdf-empty"><div class="e-ico">' + M.icon(ico) + '</div><h3>' + esc(title) + '</h3><p>' + esc(text) + '</p>' +
            (btn ? '<a class="pc-btn dl" href="' + esc(href) + '">' + esc(btn) + '</a>' : '') + '</div>';
    }
    function head(title, sub) {
        $('pdfTitle').textContent = title;
        $('pdfSub').textContent = sub || '';
        $('pdfSub').hidden = !sub;
        document.title = title + ' — Mock Matrix Hub';
    }
    function dockFor(active) { M.dock(active, app ? ST.list().length : 0); }
    function goBack() {
        var segs = S.f.split('/');
        var to = segs.length > 1 ? '/pdfs/index.html?f=' + segs.slice(0, -1).join('/') : '/index.html';
        if (window.MMHNav) MMHNav.up(to); else location.href = to;   /* t255 */
    }

    /* ── render ───────────────────────────────────────────────────────── */
    function render() {
        var r = S.res, depth = r.chain.length, sec = r.section;
        dockFor(sec.id === 'paid' || M.sectionPaid(sec) ? 'paid' : 'free');
        if (depth <= 1) head(r.root.title || 'PDFs & Study Materials', sec.title);
        else head(r.node.title, sec.title);   // full path now shows below the header (progress line)

        // tabs (section level)
        var tabs = $('pdfTabs');
        if (depth <= 1) {
            tabs.hidden = false;
            tabs.innerHTML = M.visible(r.root.items).map(function (s) {
                var c = M.countPdfs(s);
                return '<a class="live-tab' + (s.id === sec.id ? ' active' : '') + '" href="/pdfs/index.html?f=' + esc(s.id) + '" style="text-decoration:none"' +
                    (M.sectionPaid(s) && s.id === sec.id ? ' data-tab="paid"' : '') + '>' +
                    (M.sectionPaid(s) ? I.crown.replace('<svg', '<svg width="15" height="15"') : I.free.replace('<svg', '<svg width="15" height="15"')) +
                    '<span>' + esc(s.short || s.title) + '</span>' + (c ? '<span class="tab-count">' + c + '</span>' : '') + '</a>';
            }).join('');
        } else tabs.hidden = true;

        // crumbs + search (board level and deeper)
        var cr = $('pdfCrumbs'), sb = $('pdfSearch');
        if (depth >= 2) {
            var acc = [];
            cr.hidden = false;
            cr.innerHTML = r.chain.map(function (n, i) {
                acc.push(n.id);
                var cur = i === r.chain.length - 1, t = esc(n.short || n.title);
                return (i ? '<span class="pc-sep" aria-hidden="true">›</span>' : '') +
                    (cur ? '<span class="pdf-crumb cur" aria-current="page">' + t + '</span>'
                         : '<a class="pdf-crumb" href="/pdfs/index.html?f=' + esc(acc.join('/')) + '">' + t + '</a>');
            }).join('');
            sb.hidden = false;
            var board = r.chain[1];
            $('pdfSearchInput').placeholder = 'Search in ' + (board.short || board.title) + ' — PDFs, topics, years…';
            if (S.q && !$('pdfSearchInput').value) { $('pdfSearchInput').value = S.q; sb.classList.add('has'); }
        } else { cr.hidden = true; sb.hidden = true; S.q = ''; }
        renderBody();
    }

    function renderBody() {
        var r = S.res; if (!r) return;
        var depth = r.chain.length, node = r.node, sec = r.section, html = '';
        if (S.q && depth >= 2) { $('pdfMain').innerHTML = searchHtml(S.q); return; }

        if (depth <= 1 && r.root.notice && r.root.notice.text) {
            html += '<div class="pdf-notice">' + (r.root.notice.badge ? '<b>' + esc(r.root.notice.badge) + '</b>' : '') + '<span>' + esc(r.root.notice.text) + '</span></div>';
        }
        if (M.sectionPaid(sec) && r.root.premiumEnabled === false) {
            $('pdfMain').innerHTML = html + emptyHtml('crown', 'Premium PDFs are coming soon', 'Complete notes, all-shift keys and topic-wise premium PDFs will appear here.');
            return;
        }
        var items = M.visible(node.items);
        var folders = items.filter(M.isFolder), pdfs = items.filter(function (n) { return !M.isFolder(n); });
        if (!items.length || node.comingSoon) {
            $('pdfMain').innerHTML = html + emptyHtml('notes', 'Coming soon', 'PDFs for ' + (node.title || 'this folder') + ' will be added here soon.');
            return;
        }
        if (folders.length) {
            var layout = node.layout || (depth <= 1 ? 'grid' : 'list');
            html += '<div class="pdf-sec"><h2>' + (depth <= 1 ? 'Choose board' : 'Folders') + '</h2><span class="cnt">' + folders.length + '</span></div>';
            html += folderHtml(folders, layout, S.f);
        }
        if (pdfs.length) {
            html += '<div class="pdf-sec"><h2>PDFs</h2><span class="cnt">' + pdfs.length + '</span></div><div class="pdf-cards">' +
                pdfs.map(function (n) { return cardHtml(n, { f: S.f, sec: sec }); }).join('') + '</div>';
        }
        $('pdfMain').innerHTML = html;
    }
    function emptyHtml(ico, t, s) { return '<div class="pdf-empty"><div class="e-ico">' + M.icon(ico) + '</div><h3>' + esc(t) + '</h3><p>' + esc(s) + '</p></div>'; }

    function icoHtml(n, cls) {
        var c = 'c-' + (n.color || (M.isFolder(n) ? 'blue' : 'rose'));
        return '<div class="' + cls + ' ' + (n.image ? '' : c) + '">' + (n.image ? '<img src="' + esc(n.image) + '" alt="" loading="lazy">' : M.icon(n.icon || 'folder')) + '</div>';
    }
    function folderHtml(list, layout, base) {
        if (layout === 'pills') {
            return '<div class="pdf-pills">' + list.map(function (n) {
                var c = M.countPdfs(n), soon = n.comingSoon || (!c && n._loaded);
                return '<a class="pdf-pill' + (soon ? ' soon' : '') + '" ' + (soon ? 'data-act="soon"' : 'href="/pdfs/index.html?f=' + esc(base + '/' + n.id) + '"') + '>' +
                    esc(n.title) + (c ? '<small>' + c + '</small>' : '') + '</a>';
            }).join('') + '</div>';
        }
        if (layout === 'grid') {
            return '<div class="pdf-tiles">' + list.map(function (n) {
                var c = M.countPdfs(n), soon = !!n.comingSoon;
                // t227: ONE markup, two looks — 2-4 column tiles (≥600 px) · one row card per line like the exams page (<600 px, CSS)
                var bt = soon ? 'SOON' : n.badge ? String(n.badge) : '';
                return '<a class="pdf-tile' + (soon ? ' soon' : '') + '" ' + (soon ? 'data-act="soon"' : 'href="/pdfs/index.html?f=' + esc(base + '/' + n.id) + '"') + '>' +
                    (bt ? '<span class="t-badge">' + esc(bt) + '</span>' : '') +
                    icoHtml(n, 't-ico') + '<div class="t-main"><div class="t-title">' + esc(n.title) +
                    (bt ? '<span class="t-nb' + (soon ? ' soon' : '') + '">' + esc(bt) + '</span>' : '') + '</div>' +
                    (n.sub ? '<div class="t-sub">' + esc(n.sub) + '</div>' : '') + '</div>' +
                    '<div class="t-foot"><span class="t-txt">' + (soon ? 'Coming soon' : c ? c + ' PDF' + (c === 1 ? '' : 's') : 'Open') + '</span>' +
                    (!soon && c ? '<span class="t-cnt">' + c + '</span>' : '') + I.chev + '</div></a>';
            }).join('') + '</div>';
        }
        return '<div class="pdf-rows">' + list.map(function (n) { return rowHtml(n, base, ''); }).join('') + '</div>';
    }
    function rowHtml(n, base, path) {
        var c = M.countPdfs(n), soon = !!n.comingSoon;
        var sub = n.sub || (soon ? 'Coming soon' : c ? c + ' PDF' + (c === 1 ? '' : 's') : 'Open folder');
        return '<a class="pdf-row' + (soon ? ' soon' : '') + '" ' + (soon ? 'data-act="soon"' : 'href="/pdfs/index.html?f=' + esc(base + '/' + n.id) + '"') + '>' +
            icoHtml(n, 'r-ico') + '<div class="r-main">' + (path ? '<div class="r-path">' + esc(path) + '</div>' : '') +
            '<div class="r-title">' + esc(n.title) + '</div><div class="r-sub">' + esc(sub) + '</div></div>' +
            '<div class="r-end">' + (soon ? '<span class="r-badge">SOON</span>' : n.badge ? '<span class="r-badge">' + esc(n.badge) + '</span>' : '') + I.chev + '</div></a>';
    }

    /* ── PDF card ─────────────────────────────────────────────────────── */
    function langLabel(l) { return { hi: 'Hindi', en: 'English', bi: 'Hindi + English' }[String(l || '').toLowerCase()] || ''; }
    function cardHtml(n, ctx) {
        var paid = M.sectionPaid(ctx.sec), plan = M.planOf(n, ctx.sec);
        var e = app ? ST.get(n.id) : null;
        if (e) ST.noteLive(n.id, Number(n.v) || 1);
        var st = e ? ST.status(e, Number(n.v) || 1) : null;
        var locked = paid && app && !M.hasPlan(plan);
        var meta = [
            n.pages ? '<span>' + I.pages + n.pages + ' pages</span>' : '',
            M.fmtSize(n) ? '<span>' + I.size + esc(M.fmtSize(n)) + '</span>' : '',
            langLabel(n.lang) ? '<span>' + I.language + esc(langLabel(n.lang)) + '</span>' : ''
        ].join('');
        var acts;
        if (locked) {
            acts = '<a class="pc-btn buy" href="/buy-premium.html">' + I.crown + '<span>Buy Premium</span></a>';
        } else {
            var dl;
            if (!e) dl = '<button type="button" class="pc-btn dl" data-act="dl">' + I.download + '<span>Download</span></button>';
            else if (st.state === 'update') dl = '<button type="button" class="pc-btn upd" data-act="dl">' + I.refresh + '<span>Update</span></button>';
            else if (st.state === 'expired' || st.state === 'clock') dl = '<button type="button" class="pc-btn upd" data-act="renew">' + I.refresh + '<span>Renew</span></button>';
            else dl = '<a class="pc-btn saved" href="/pdfs/downloads.html">' + I.tick + '<span>Saved</span></a>';
            acts = '<button type="button" class="pc-btn open" data-act="open">' + I.open + '<span>Open</span></button>' + dl;
        }
        var foot;
        if (e && st) {
            foot = st.state === 'update' ? '<span class="pc-state warn">' + I.refresh + 'New version available</span>'
                : st.state === 'expired' ? '<span class="pc-state bad">' + I.clock + 'Offline access expired — Renew</span>'
                : st.state === 'clock' ? '<span class="pc-state bad">' + I.clock + 'Phone time changed — Renew online</span>'
                : e.kind === 'paid' ? '<span class="pc-state ok">' + I.lock + 'Saved securely · In My Downloads</span>'
                : '<span class="pc-state ok">' + I.check + 'In My Downloads</span>';
        } else {
            foot = '<span class="pc-state">' + I.calendar + (n.updated ? 'Updated ' + esc(M.fmtDate(n.updated)) : (paid ? 'Premium PDF' : 'Free PDF')) + '</span>';
        }
        var badge = n.badge || (M.isNew(n) ? 'NEW' : '');
        return '<div class="pc-card' + (paid ? ' is-paid' : '') + '" data-id="' + esc(n.id) + '" data-f="' + esc(ctx.f) + '">' +
            '<div class="pc-top' + (!n.sub && !ctx.path ? ' solo' : '') + '"><div class="pc-thumb">' + (n.image ? '<img src="' + esc(n.image) + '" alt="" loading="lazy">' : I.file + '<b>PDF</b>') + '</div>' +
            '<div class="pc-info">' + (ctx.path ? '<div class="pc-path">' + esc(ctx.path) + '</div>' : '') +
            '<div class="pc-title">' + esc(n.title) + '</div>' + (n.sub ? '<div class="pc-sub">' + esc(n.sub) + '</div>' : '') + '</div>' +
            '<div class="pc-badges"><span class="badge-type ' + (paid ? 'paid-badge">PREMIUM' : 'free-badge">FREE') + '</span>' + (badge ? '<span class="pc-new">' + esc(badge) + '</span>' : '') + '</div></div>' +
            (meta ? '<div class="lv-meta">' + meta + '</div>' : '') +
            '<div class="pc-actions">' + acts + '</div>' +
            '<div class="lv-foot">' + foot + '<button type="button" class="lv-share" data-act="share" aria-label="Share" title="Share link">' + I.share + '</button></div></div>';
    }

    /* ── search (whole board, any depth) ──────────────────────────────── */
    function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, ' ').trim(); }
    function searchHtml(q) {
        var r = S.res, board = r.chain[1], toks = norm(q).split(' ').filter(Boolean);
        var basePath = r.chain.slice(0, 2).map(function (n) { return n.id; }).join('/');
        var folders = [], pdfs = [];
        M.walk(board, function (n, trail) {
            var hay = norm([n.title, n.sub, n.id, (n.tags || []).join(' '), trail.map(function (t) { return t.title; }).join(' ')].join(' '));
            if (!toks.every(function (t) { return hay.indexOf(t) >= 0; })) return;
            var parent = basePath + (trail.length ? '/' + trail.map(function (t) { return t.id; }).join('/') : '');
            var label = [board.short || board.title].concat(trail.map(function (t) { return t.short || t.title; })).join(' › ');
            (M.isFolder(n) ? folders : pdfs).push({ n: n, f: parent, label: label });
        });
        var total = folders.length + pdfs.length;
        if (!total) return emptyHtml('search', 'No results for "' + q + '"', 'Try a shorter word — e.g. a topic, exam or year.');
        var h = '<div class="pdf-sec"><h2>Results</h2><span class="cnt">' + total + ' found</span></div>';
        if (folders.length) h += '<div class="pdf-rows" style="margin-bottom:12px">' + folders.slice(0, 30).map(function (x) { return rowHtml(x.n, x.f, x.label); }).join('') + '</div>';
        if (pdfs.length) h += '<div class="pdf-cards">' + pdfs.slice(0, 60).map(function (x) { return cardHtml(x.n, { f: x.f, sec: r.section, path: x.label }); }).join('') + '</div>';
        return h;
    }

    /* ── actions ──────────────────────────────────────────────────────── */
    function findNode(f, id) {
        var segs = f.split('/'), node = S.res.root;
        for (var i = 0; i < segs.length; i++) { node = M.child(node, segs[i]); if (!node) return null; }
        return M.child(node, id);
    }
    function crumbOf(f) {
        var segs = f.split('/'), node = S.res.root, out = [];
        for (var i = 0; i < segs.length; i++) { node = M.child(node, segs[i]); if (!node) break; out.push(node.short || node.title); }
        return out.join(' › ');
    }
    function viewUrl(f, id) { return '/pdfs/view.html?f=' + f + '&id=' + encodeURIComponent(id); }
    function onClick(ev) {
        var b = ev.target.closest('[data-act]');
        if (!b) return;
        var act = b.getAttribute('data-act');
        if (act === 'soon') { ev.preventDefault(); M.toast('Coming soon'); return; }
        var card = b.closest('.pc-card'); if (!card) return;
        ev.preventDefault();
        var f = card.getAttribute('data-f'), id = card.getAttribute('data-id'), n = findNode(f, id);
        if (!n) return;
        var sec = S.res.section, paid = M.sectionPaid(sec), c = S.res.cfg;
        var ctx = { cfg: c, f: f, crumb: crumbOf(f), plan: M.planOf(n, sec) };
        if (act === 'share') return M.share(n.title, M.shareUrl(c, f, id));
        if (paid && !app) return M.appOnlySheet(n);              // website: browse yes, open/download → app only
        if (act === 'open') {
            // free → stream · premium → viewer (saved = offline, else opened for this app session only)
            location.href = viewUrl(f, id); return;
        }
        if (act === 'renew') return doRenew(b, n, ctx, false);
        if (act === 'dl') {
            if (!app) return webDownload(M.freeUrl(c, n), n.title);
            return doDownload(b, n, ctx, false);
        }
    }
    function busy(b, pct, label) {
        if (!b._orig) b._orig = b.innerHTML;
        b.classList.add('busy');
        b.innerHTML = '<span class="prog" style="width:' + (pct || 0) + '%"></span>' + I.download + '<span>' + label + '</span>';
    }
    function unbusy(b) { if (b._orig) { b.innerHTML = b._orig; b._orig = null; } b.classList.remove('busy'); }
    function doDownload(b, n, ctx, thenOpen) {
        var paid = M.sectionPaid(S.res.section);
        busy(b, 0, paid ? 'Unlocking…' : 'Starting…');
        var fn = paid ? ST.downloadPaid : ST.downloadFree;
        fn(n, ctx, function (got, total) {
            var p = total ? Math.min(99, Math.round(got * 100 / total)) : 0;
            busy(b, p, total ? 'Downloading ' + p + '%' : 'Downloading…');
        }).then(function () {
            unbusy(b);
            if (thenOpen) { location.href = viewUrl(ctx.f, n.id); return; }
            M.toast(paid ? 'Saved securely in My Downloads' : 'Saved in My Downloads');
            renderBody(); dockFor(paid ? 'paid' : 'free');
        }).catch(function (e) { unbusy(b); storeError(e, n); });
    }
    function doRenew(b, n, ctx, thenOpen) {
        busy(b, 100, 'Renewing…');
        ST.renew(n.id, n, ctx).then(function () {
            unbusy(b);
            if (thenOpen) { location.href = viewUrl(ctx.f, n.id); return; }
            M.toast('Renewed — opens offline again'); renderBody();
        }).catch(function (e) { unbusy(b); storeError(e, n); });
    }
    function storeError(e, n) {
        var c = e && e.code;
        if (c === 'offline' || c === 'network') return M.toast("You're offline — connect to the internet to download", 'error');
        if (c === 'login') { location.href = '/?login&redirect=' + encodeURIComponent(location.pathname + location.search); return; }
        if (c === 'buy') return M.buySheet(n);
        if (c === 'limit') return M.toast('Daily download limit reached. Try again tomorrow.', 'error');
        if (c === 'version') { M.toast('This PDF was just updated — refreshing…'); return setTimeout(function () { load(true); }, 700); }
        if (c === 'integrity') return M.sheet({ icon: 'shield', iconCls: 'c-rose', title: 'Use the official app',
            text: 'Premium PDFs download only in the official Mock Matrix Hub app installed from Google Play, on a phone that passes Google’s security check.',
            actions: [{ label: '', cls: 'play', href: M.PLAY_URL, blank: true }, { label: 'Close', cls: 'ghost' }] });
        if (c === 'update_app') return M.sheet({ icon: 'refresh', iconCls: 'c-blue', title: 'Update the app',
            text: 'Update Mock Matrix Hub from Google Play to download Premium PDFs.', actions: [{ label: '', cls: 'play', href: M.PLAY_URL, blank: true }, { label: 'Later', cls: 'ghost' }] });
        M.toast('Download failed — please try again', 'error');
    }
    /* website: real file download (CORS-enabled bucket), fallback = open in a new tab */
    function webDownload(url, title) {
        M.toast('Downloading…');
        fetch(url).then(function (r) { if (!r.ok) throw 0; return r.blob(); }).then(function (blob) {
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = String(title || 'document').replace(/[\\/:*?"<>|]+/g, ' ').trim() + '.pdf';
            document.body.appendChild(a); a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
        }).catch(function () { window.open(url, '_blank', 'noopener'); });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

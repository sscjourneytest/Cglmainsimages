/* ═══════════════════════════════════════════════════════════════════════════
   MY ATTEMPTS — /attempted/index.html
   ───────────────────────────────────────────────────────────────────────────
   One page for EVERY attempted test of the logged-in user (all exams + live).
   No new worker, no worker change, no per-card call:

   • Attempts  = the SAME per-exam cache the exam pages use
                 (CLOUD_SYNC_<user>_<exam> {workerSynced, local, worker}),
                 + this device's qsum_/result_ keys, absorbed with the SAME
                 rule as exam-engine.js (newest submit wins, qsum_ deleted).
                 Worker /attempted-status only for an exam never synced on
                 this device (same as the exam page) or on "Refetch Attempts".
   • Titles    = exam data JSONs (data.mockmatrixhub.in/data/…),
                 loaded in the BACKGROUND on every page load (no own cache —
                 same as the engines). Until a title arrives the card shows
                 the quiz id. Exam-wise filter = the exam whose data JSON
                 contains that id (workers are common, so never by worker).
   • Done      = MMH_ATT_<user> {v, done:{id:{at,c,s}}, hide:{id:1}} — only the
                 user's Mark Done / Hide choices (not a cache).
   ═══════════════════════════════════════════════════════════════════════════ */
(function(){
'use strict';

var DATA_BASE = 'https://data.mockmatrixhub.in/data/';
var CFG_URL   = '/cloudflare-config.json';
var CATS_URL  = '/data/exams/boards.json';   // board-wise exam files (js/exam-boards.js)
var REV_DAYS  = 14;                 // Revision: below cutoff + analysis done + ≥14 days old
var DAY       = 86400000;
var FALLBACK_EXAMS = [
    ['ssc-sub','SSC Subject Wise PYQ'],['ssc-sub-top','SSC Top Questions'],['cgl','SSC CGL'],['chsl','SSC CHSL'],
    ['mts','SSC MTS'],['cpo','SSC CPO'],['steno','SSC Steno'],['selection-post','SSC Phase'],['gd','SSC GD'],
    ['ntpcg','RRB NTPC Graduate'],['ntpc-ug','RRB NTPC UG'],['group-d','RRB Group D'],['alp','RRB ALP'],
    ['exam-ssc-sub','Chapter Wise PYQs Exam Wise']
];
// exams/exam-ssc-sub (Chapter Wise PYQs Exam Wise): ids SSC-SUB-<YY>-<EXAM>-…, attempts on the ssc-sub worker.
// Its page syncs with the ssc-sub cache (js/exam-sub-addon.js) → same cache here.
var EXW = 'exam-ssc-sub';
var SYNC_AS = { 'exam-ssc-sub': 'ssc-sub' };
var LIVE_EXAM = ['live-test','Live Mocks'];
var KIND_LABEL = { full:'Full Mock', sec:'Sectional', sub:'Subject Wise', live:'Live Mock' };

/* ── live-first fetch (same helper the engines define) ─────────────────── */
window.MMH_LIVE_BASE = window.MMH_LIVE_BASE || 'https://mockmatrixhub.in';
if (typeof window.fetchLiveFirst !== 'function') {
    window.fetchLiveFirst = async function (localUrl, fetchOpts) {
        var rel = String(localUrl); while (rel.charAt(0) === '/') rel = rel.slice(1);
        try { var res = await fetch(window.MMH_LIVE_BASE + '/' + rel, fetchOpts); if (res && res.ok) return res; } catch (e) {}
        var r2 = await fetch(localUrl, fetchOpts);
        if (!r2.ok) throw new Error('Failed to load ' + localUrl);
        return r2;
    };
}

var S = {
    user: null, exams: [], examName: {}, cfg: null,
    dataFile: {}, dataBase: {},   // exam → board item "data" file / board dataBase
    att: {},            // id → {score, createdAt, ms}
    idx: null, store: null,
    tab: 'pending',
    f: { q: '', ex: 'all', ty: 'all', sort: 'new' },
    trendEx: null
};

/* ── tiny utils ─────────────────────────────────────────────────────────── */
function $(id){ return document.getElementById(id); }
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function lsGet(k){ try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v){ try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
function lsDel(k){ try { localStorage.removeItem(k); } catch (e) {} }
function lsKeys(){ try { return Object.keys(localStorage); } catch (e) { return []; } }
function num(n){ return Number.isInteger(n) ? String(n) : String(parseFloat(Number(n).toFixed(2))); }
function toMs(createdAt){
    if (!createdAt) return 0;
    var d = new Date(String(createdAt).replace(' ', 'T'));   // D1 gives "YYYY-MM-DD HH:MM" (same parse as the engines)
    var t = d.getTime(); return isNaN(t) ? 0 : t;
}
function dayStart(ms){ var d = new Date(ms); d.setHours(0,0,0,0); return d.getTime(); }
var MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var MONTH = ['January','February','March','April','May','June','July','August','September','October','November','December'];
function fmtDate(ms){
    if (!ms) return '—';
    var d = new Date(ms), now = new Date();
    var s = d.getDate() + ' ' + MON[d.getMonth()];
    if (d.getFullYear() !== now.getFullYear()) s += ' ' + d.getFullYear();
    return s;
}
function fmtTime(ms){
    var d = new Date(ms), h = d.getHours(), m = d.getMinutes();
    return ((h % 12) || 12) + ':' + (m < 10 ? '0' : '') + m + ' ' + (h < 12 ? 'AM' : 'PM');
}
function daysAgo(ms){ return Math.floor((dayStart(Date.now()) - dayStart(ms)) / DAY); }
function agoText(ms){
    var d = daysAgo(ms);
    if (d <= 0) {
        var mins = Math.max(1, Math.round((Date.now() - ms) / 60000));
        return mins < 60 ? mins + ' min ago' : Math.round(mins / 60) + 'h ago';
    }
    return d === 1 ? 'yesterday' : d + ' days ago';
}

/* ── exams + worker config ──────────────────────────────────────────────── */
async function loadExams(){
    var list = [];
    try {
        // boards.json + every /data/exams/<board>.json (js/exam-boards.js), Coming Soon exams skipped
        var j = window.MMHExam ? await MMHExam.all() : { categories: [] };
        (j.categories || []).forEach(function(c){
            (c.items || []).forEach(function(i){
                if (!i || i.comingSoon) return;
                var ex = window.MMHExam ? MMHExam.examOfUrl(i.url) : '';   // ?cgl&b=ssc → cgl (engine's exam name)
                if (!ex || list.some(function(x){ return x[0] === ex; })) return;
                list.push([ex, i.title || i.id || ex]);
                if (typeof i.data === 'string' && i.data.trim()) S.dataFile[ex] = i.data.trim();
                if (i._dataBase) S.dataBase[ex] = i._dataBase;
            });
        });
    } catch (e) {}
    if (!list.length) list = FALLBACK_EXAMS.slice();
    if (!list.some(function(x){ return x[0] === LIVE_EXAM[0]; })) list.push(LIVE_EXAM);
    S.exams = list.map(function(x){ return x[0]; });
    list.forEach(function(x){ S.examName[x[0]] = prettyExam(x[1]); });
}
var ACRO = { SSC:1, CGL:1, CHSL:1, MTS:1, CPO:1, GD:1, PYQ:1, RRB:1, NTPC:1, ALP:1, UG:1, JE:1, CBT:1, DP:1, HC:1 };
function prettyExam(t){
    return String(t).replace(/\s+/g, ' ').trim().replace(/[A-Za-z]+/g, function(w){
        var u = w.toUpperCase();
        if (ACRO[u]) return u;
        return w === u || w === w.toLowerCase() ? u.charAt(0) + u.slice(1).toLowerCase() : w;
    });
}

// Engines claim a qsum_/result_ id for their exam cache when the id CONTAINS a token:
// exam-engine / ssc-sub-engine → the exam name; live-mock-engine → name minus "-test" ("live").
function tokenOf(ex){ return ex.slice(-5) === '-test' ? ex.slice(0, -5) : ex; }
function claimers(id){ var l = String(id).toLowerCase(); return S.exams.filter(function(ex){ return l.indexOf(tokenOf(ex)) >= 0; }); }

async function loadCfg(){
    if (S.cfg) return S.cfg;
    var r = await fetchLiveFirst(CFG_URL);
    S.cfg = await r.json();
    return S.cfg;
}
// SAME rule as exam-engine.js getAttemptsWorkerURL()
function workerFor(cfg, exam){
    // EXACT exam-name key only (cloudflare-config "<exam>" or paths["<exam>"].worker)
    if (window.MMHExam) return MMHExam.workerUrl(cfg, exam);
    var k = String(exam).toLowerCase();
    return typeof cfg[k] === 'string' ? cfg[k] : null;
}
// quiz id belongs to this exam? prefix rule (CGL-… → cgl) like the engines; live mocks keep "contains"
function ownsId(id, exam){
    if (exam === LIVE_EXAM[0] || !window.MMHExam) return String(id).toLowerCase().includes(exam);
    return MMHExam.owns(id, exam);
}
/* exam data file (board item "data" wins) on data.mockmatrixhub.in */
function dataFile(ex){ return S.dataFile[ex] || (ex + '-data.json'); }
function dataJson(ex, file){
    if (window.MMHExam) return MMHExam.fetchData(file, S.dataBase[ex] || '').then(function(r){ return r.json; });
    var url = /^https?:\/\//.test(file) ? file : DATA_BASE + file;
    return fetch(url).then(function(r){ if (!r.ok) throw new Error('data ' + r.status); return r.json(); });
}

/* ── CLOUD_SYNC cache — identical shape/rules to exam-engine.js ─────────── */
function ck(exam){ return 'CLOUD_SYNC_' + S.user + '_' + (SYNC_AS[exam] || exam); }
function loadCache(key){
    var raw = lsGet(key);
    if (!raw) return { workerSynced: false, local: {}, worker: {} };
    try {
        var p = JSON.parse(raw);
        return { workerSynced: !!p.workerSynced, local: p.local || {}, worker: p.worker || {} };
    } catch (e) { lsDel(key); return { workerSynced: false, local: {}, worker: {} }; }
}
function saveCache(key, c){ lsSet(key, JSON.stringify(c)); }
function attemptTimeMs(e){ if (!e || !e.createdAt) return 0; var t = new Date(e.createdAt).getTime(); return isNaN(t) ? 0 : t; }
function shouldAbsorb(incoming, cache, id){
    var kl = cache.local ? cache.local[id] : null, kw = cache.worker ? cache.worker[id] : null;
    if (!kl && !kw) return true;
    var mine = attemptTimeMs(incoming), newest = Math.max(attemptTimeMs(kl), attemptTimeMs(kw));
    if (!mine) return false;
    if (!newest) return true;
    return mine > newest;
}
// qsum_ (preferred, deleted after) + result_ (legacy, kept) → the SAME exam caches the
// exam pages would put them in (every exam whose token the id contains), with the
// engines' own rules: newest submit wins (live engine: first attempt only). So it never
// matters which page absorbs first — the attempt lands where every engine expects it.
function absorbLocal(){
    var caches = {}, changed = {}, handled = {};
    function get(ex){ return caches[ex] || (caches[ex] = loadCache(ck(ex))); }
    function put(ex, id, inc){
        var c = get(ex);
        var ok = ex === LIVE_EXAM[0] ? (!c.worker[id] && !c.local[id]) : shouldAbsorb(inc, c, id);
        if (ok) { c.local[id] = inc; changed[ex] = 1; }
    }
    var pq = 'qsum_' + S.user + '_', pr = 'result_' + S.user + '_';
    lsKeys().forEach(function(key){
        if (key.indexOf(pq) !== 0) return;
        var id = key.slice(pq.length), exs = claimers(id);
        if (!exs.length) return;                            // no exam page would claim it — leave it alone
        try {
            var s = JSON.parse(lsGet(key));
            var inc = { score: typeof s.score === 'number' ? s.score : null,
                        createdAt: s.submittedAt ? new Date(s.submittedAt).toISOString() : new Date().toISOString() };
            handled[id] = 1;
            exs.forEach(function(ex){ put(ex, id, inc); });
        } catch (e) {}
        lsDel(key);                                         // same as the engines: absorbed → small key done
    });
    lsKeys().forEach(function(key){
        if (key.indexOf(pr) !== 0) return;
        var id = key.slice(pr.length), exs = claimers(id);
        if (!exs.length || handled[id]) return;
        try {
            var fp = (JSON.parse(lsGet(key)) || {}).firebasePayload || {};
            var inc = { score: typeof fp.score === 'number' ? fp.score : null,
                        createdAt: fp.submittedAt ? new Date(fp.submittedAt).toISOString() : new Date().toISOString() };
            exs.forEach(function(ex){ put(ex, id, inc); });
        } catch (e) {}
    });
    Object.keys(changed).forEach(function(ex){ saveCache(ck(ex), caches[ex]); });
}
// SAME as exam-engine.js _overwriteWithWorkerData (minus the re-render)
function overwriteWithWorker(exam, fresh){
    var pr = 'result_' + S.user + '_';
    lsKeys().forEach(function(key){
        if (key.indexOf(pr) !== 0) return;
        var id = key.slice(pr.length);
        if (ownsId(id, exam) && !fresh[id]) { lsDel(pr + id); lsDel('state_' + S.user + '_' + id); }
    });
    saveCache(ck(exam), { workerSynced: true, worker: fresh, local: {} });
}
async function fetchStatus(url){
    var res = await fetch(url + '/attempted-status', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailKey: S.user })
    });
    if (!res.ok) throw new Error('Worker ' + res.status);
    var data = await res.json();
    return data.results || {};
}
// Groups exams by worker URL → one call per unique worker.
function groupByWorker(cfg, exams){
    var g = {};
    exams.forEach(function(ex){
        var u = workerFor(cfg, ex);
        if (!u) return;
        (g[u] = g[u] || []).push(ex);
    });
    return g;
}
async function syncExams(exams, onEach){
    var cfg = await loadCfg();
    var groups = groupByWorker(cfg, exams);
    var missing = exams.filter(function(ex){ return !workerFor(cfg, ex); });
    var jobs = Object.keys(groups).map(function(url){
        return fetchStatus(url).then(function(fresh){
            groups[url].forEach(function(ex){ overwriteWithWorker(ex, fresh); });
            if (onEach) onEach(groups[url], true);
        }, function(){ if (onEach) onEach(groups[url], false); });
    });
    await Promise.all(jobs);
    return { groups: groups, missing: missing };
}

/* ── merge everything into S.att ────────────────────────────────────────── */
function collectAttempts(){
    var out = {};
    function take(id, e){
        if (!e) return;
        var ms = toMs(e.createdAt);
        var cur = out[id];
        if (!cur || ms > cur.ms) out[id] = { score: typeof e.score === 'number' ? e.score : null, createdAt: e.createdAt, ms: ms };
    }
    S.exams.forEach(function(ex){
        var c = loadCache(ck(ex)), m = Object.assign({}, c.worker, c.local);
        Object.keys(m).forEach(function(id){ take(id, m[id]); });
    });
    S.att = out;
}

/* ── titles + exam membership from the exam data JSONs (memory only) ─────
   Every page load: cards render at once (quiz id as title), the needed data
   JSONs load in the background, titles/marks/exam chips fill in as each one
   arrives. No localStorage cache — like the engines. Plain URL (no ?t=) so
   the browser revalidates with ETag: always fresh, usually a tiny 304.     */

/* ── ssc-sub engine data formats (copied VERBATIM from js/ssc-sub-engine.js) ──
   classic arrays, compact topics (parts auto-generated) and split-by-year files. */
function isSubEngine(ex){ return ex.indexOf('ssc-sub') === 0 || ex === EXW; }   // exams/ssc-sub, ssc-sub-top, exam-ssc-sub load ssc-sub-engine.js
function _isLeafMockTopic(val) {
    if (!val || typeof val !== 'object') return false;
    if (Array.isArray(val)) {
        return val.length === 0 || (val[0] && (val[0].id != null || val[0].title != null || val[0].qs != null));
    }
    return !!(
        val.id != null ||
        val.commonId != null ||
        val.baseId != null ||
        val.totalQs != null ||
        val.total_qs != null ||
        val.parts != null
    );
}
function _expandCompactTopic(compact, defaultCfg) {
    if (Array.isArray(compact)) return compact; // Already classic format
    if (!compact || typeof compact !== 'object') return [];

    const cfg = defaultCfg || {};

    const baseId = compact.id || compact.commonId || compact.baseId || '';
    const baseLink = compact.linkStr || compact.commonLinkStr || compact.baseLinkStr || baseId;
    const baseTitle = compact.title || compact.commonTitle || compact.baseTitle || baseId;

    const marksPerQ = Number(compact.marksPerQ != null ? compact.marksPerQ : (compact.mpq != null ? compact.mpq : (cfg.marksPerQ != null ? cfg.marksPerQ : 2))) || 2;
    const partQs = Number(compact.partQs != null ? compact.partQs : (compact.qsPerPart != null ? compact.qsPerPart : (cfg.partQs != null ? cfg.partQs : 25))) || 25;
    const totalQs = Number(compact.totalQs != null ? compact.totalQs : (compact.total_qs != null ? compact.total_qs : (compact.qs != null ? compact.qs : 0))) || 0;

    const mergeLast = compact.mergeLast != null ? !!compact.mergeLast : (compact.merge_last != null ? !!compact.merge_last : (compact.mergeLast15 != null ? !!compact.mergeLast15 : !!cfg.mergeLast));
    const mergeThreshold = Number(compact.mergeThreshold != null ? compact.mergeThreshold : (cfg.mergeThreshold != null ? cfg.mergeThreshold : 15)) || 15;

    const suffixId = compact.partSuffixId != null ? compact.partSuffixId : (compact.part_suffix_id != null ? compact.part_suffix_id : '-part-');
    const suffixLink = compact.partSuffixLink != null ? compact.partSuffixLink : (compact.part_suffix_link != null ? compact.part_suffix_link : '&section=PART-');
    const suffixTitle = compact.partSuffixTitle != null ? compact.partSuffixTitle : (compact.part_suffix_title != null ? compact.part_suffix_title : ' PART-');

    const defaultType = compact.type || 'free';
    const defaultRd = compact.releaseDate != null ? compact.releaseDate : '';

    // Resolve question count breakdown per part
    let partCounts = [];
    if (Array.isArray(compact.parts) && compact.parts.length > 0) {
        partCounts = compact.parts;
    } else {
        if (totalQs <= partQs) {
            partCounts = [totalQs];
        } else {
            const count = Math.floor(totalQs / partQs);
            const rem = totalQs % partQs;
            if (rem === 0) {
                partCounts = Array(count).fill(partQs);
            } else if (mergeLast && rem < mergeThreshold && count >= 1) {
                partCounts = Array(count - 1).fill(partQs);
                partCounts.push(partQs + rem);
            } else {
                partCounts = Array(count).fill(partQs);
                partCounts.push(rem);
            }
        }
    }

    const typesList = Array.isArray(compact.types) ? compact.types : null;
    const expanded = [];

    for (let idx = 0; idx < partCounts.length; idx++) {
        const itemSpec = partCounts[idx];
        const pQs = typeof itemSpec === 'object' && itemSpec !== null ? Number(itemSpec.qs || partQs) : Number(itemSpec || 0);
        const pNum = idx + 1;

        let pTime = '';
        if (typeof itemSpec === 'object' && itemSpec !== null && itemSpec.time) {
            pTime = itemSpec.time;
        } else if (compact.time) {
            pTime = compact.time;
        } else if (compact.timePerPart && pQs === partQs) {
            pTime = compact.timePerPart;
        } else {
            pTime = Math.max(1, Math.round(pQs * 0.6)) + ' Min';
        }

        let pType = defaultType;
        if (typesList && idx < typesList.length) {
            pType = typesList[idx];
        } else if (typeof itemSpec === 'object' && itemSpec !== null && itemSpec.type) {
            pType = itemSpec.type;
        } else if (compact.freeParts != null && pNum > Number(compact.freeParts)) {
            pType = 'paid';
        }

        const pMarks = (typeof itemSpec === 'object' && itemSpec !== null && itemSpec.marks != null)
            ? Number(itemSpec.marks)
            : pQs * marksPerQ;

        const pReleaseDate = (typeof itemSpec === 'object' && itemSpec !== null && itemSpec.releaseDate != null)
            ? itemSpec.releaseDate
            : defaultRd;

        expanded.push({
            id: `${baseId}${suffixId}${pNum}`,
            linkStr: `${baseLink}${suffixLink}${pNum}`,
            title: `${baseTitle}${suffixTitle}${pNum}`,
            type: pType,
            releaseDate: pReleaseDate,
            qs: pQs,
            time: pTime,
            marks: pMarks
        });
    }

    return expanded;
}
function _isSplitStructure(json) {
    if (!json || typeof json !== 'object') return false;
    if (json.splitByYear === true || json.splitYears === true || json.isSplit === true) return true;
    if (json.yearFiles && typeof json.yearFiles === 'object') return true;
    if (Array.isArray(json.years) && (!json.data || Object.keys(json.data).length === 0)) return true;
    if (json.data && typeof json.data === 'object') {
        const vals = Object.values(json.data);
        if (vals.some(v => typeof v === 'string' || v === null || (v && typeof v === 'object' && Object.keys(v).length === 0))) {
            return true;
        }
    }
    return false;
}
function _extractYearPayload(yearJson, year) {
    if (!yearJson || typeof yearJson !== 'object') return {};
    if (yearJson[year] && typeof yearJson[year] === 'object') return yearJson[year];
    if (yearJson.data) {
        if (yearJson.data[year] && typeof yearJson.data[year] === 'object') return yearJson.data[year];
        if (typeof yearJson.data === 'object' && !Array.isArray(yearJson.data)) return yearJson.data;
    }
    const out = {};
    for (const [k, v] of Object.entries(yearJson)) {
        if (k !== 'config' && k !== 'examCode' && k !== 'examName' && k !== 'year' && k !== 'splitByYear') {
            out[k] = v;
        }
    }
    return Object.keys(out).length > 0 ? out : yearJson;
}
function _normalizeYearBranch(yearBranch, defaultCfg) {
    if (!yearBranch || typeof yearBranch !== 'object') return {};

    function walk(node) {
        if (!node || typeof node !== 'object') return node;
        if (_isLeafMockTopic(node)) {
            return _expandCompactTopic(node, defaultCfg);
        }
        const out = {};
        for (const [k, v] of Object.entries(node)) {
            if (_isLeafMockTopic(v)) {
                out[k] = _expandCompactTopic(v, defaultCfg);
            } else if (typeof v === 'object' && v !== null && !Array.isArray(v)) {
                out[k] = walk(v);
            } else {
                out[k] = v;
            }
        }
        return out;
    }

    return walk(yearBranch);
}
function normalizeSscSubData(json) {
    if (!json || typeof json !== 'object') return json;
    const defaultCfg = (json.config && json.config.default) ? json.config.default : {};

    if (!json.data || typeof json.data !== 'object' || Array.isArray(json.data)) {
        json.data = {};
    }

    // Extract years list & sort descending (newest first)
    let years = [];
    if (Array.isArray(json.years)) {
        years = json.years.slice();
    } else if (json.years && typeof json.years === 'object') {
        years = Object.keys(json.years);
    } else if (json.data && typeof json.data === 'object') {
        years = Object.keys(json.data);
    }
    years.sort((a, b) => String(b).localeCompare(String(a), undefined, { numeric: true }));
    json.years = years;

    // Normalize any already-present year branches (classic single-file or pre-loaded)
    for (const yr of Object.keys(json.data)) {
        const val = json.data[yr];
        if (val && typeof val === 'object' && !Array.isArray(val) && Object.keys(val).length > 0) {
            json.data[yr] = _normalizeYearBranch(val, defaultCfg);
        }
    }

    return json;
}
// Split structure: load every year file the same way ensureYearDataLoaded() does (yearFiles / data[year] string / <exam>-<year>.json).
function loadSubYears(ex, j){
    var years = (j.years || []).filter(function(y){ var v = j.data[y]; return !(v && typeof v === 'object' && Object.keys(v).length); });
    return Promise.all(years.map(function(y){
        var yf = (j.yearFiles && j.yearFiles[y]) || (typeof j.data[y] === 'string' ? j.data[y] : ex + '-' + y + '.json');
        return dataJson(ex, yf)
            .then(function(yj){
                var cfg = (yj.config && yj.config.default) ? yj.config.default : ((j.config && j.config.default) ? j.config.default : {});
                j.data[y] = _normalizeYearBranch(_extractYearPayload(yj, y), cfg);
            })
            .catch(function(){ j.data[y] = {}; });
    })).then(function(){ return j; });
}
function prepJson(ex, j){
    if (ex === EXW || !isSubEngine(ex) || !j || typeof j !== 'object') return Promise.resolve(j);
    j = normalizeSscSubData(j);
    return _isSplitStructure(j) ? loadSubYears(ex, j) : Promise.resolve(j);
}
var J = { done: {}, busy: {} };
function linkBase(ex, tc, kind){
    if (ex === LIVE_EXAM[0]) return null;                    // live: resolved from live JSON config
    var f = kind === 'sec' ? tc.sectional_link : (kind === 'sub' ? tc.subject_link : tc.full_link);
    return '/exams/' + (f || 'test.html');                   // engines use "../<link>" from /exams/<exam>/
}
function indexExamJson(ex, json){
    var cfg = (json && json.config) || {}, found = 0;
    var isLive = ex === LIVE_EXAM[0];
    function tierCfg(path){
        for (var i = 0; i < path.length; i++) if (cfg[path[i]] && typeof cfg[path[i]] === 'object') return cfg[path[i]];
        return cfg['default'] || {};
    }
    function put(id, o){
        if (!S.idx.it[id]) S.idx.it[id] = o;
        var m = S.idx.mem[id] || (S.idx.mem[id] = []);
        if (m.indexOf(ex) < 0) m.push(ex);
        found++;
    }
    function add(it, listKey, path){
        var tc = tierCfg(path);
        // SAME as the engines:
        //  exam-engine    → full_mocks: full_link ?id=<id> · any other list: subject_link ?id=<id> (linkStr NOT used)
        //  ssc-sub-engine → subject_link ?id=<linkStr || id>
        //  live engine    → <category link> ?id=<linkStr || id>
        var subEng = isSubEngine(ex);
        var kind = isLive ? 'live' : (subEng ? 'sub' : (listKey === 'full_mocks' ? 'full' : 'sub'));
        var useLs = (isLive || subEng) && it.linkStr && String(it.linkStr).trim();
        var idParam = useLs ? String(it.linkStr).trim() : it.id;
        var base = isLive ? (((cfg[path[0]] || {}).link) || ((cfg['default'] || {}).link) || '/test.html') : linkBase(ex, tc, kind);
        var marks = typeof it.marks === 'number' ? it.marks : Number(it.marks) || null;
        put(String(it.id), { t: it.title || it.id, m: marks, q: it.qs, tm: it.time, p: it.type === 'paid' ? 1 : 0,
                             k: kind, ex: ex, cut: typeof it.cutoff === 'number' ? it.cutoff : null, l: base + '?id=' + idParam,
                             lc: isLive ? String(path[0] || '') : undefined });
        // t262 — same as exam-engine: "no_sectional" mock → no sectionals; "sectional_from_full": false →
        // the separate <id><sectional_suffix || "-SEC"> file (its meta.id = that id → attempt id <that id>-<section>)
        var noSec = it.no_sectional === true || /^(yes|true|1|on)$/i.test(String(it.no_sectional == null ? '' : it.no_sectional).trim());
        var sff = tc.sectional_from_full;
        var fromFull = !(sff === false || /^(no|false|0|off)$/i.test(String(sff == null ? '' : sff).trim()));
        var secId = fromFull ? String(it.id) : String(it.id) + ((typeof tc.sectional_suffix === 'string' && tc.sectional_suffix.trim()) ? tc.sectional_suffix.trim() : '-SEC');
        if (kind === 'full' && Array.isArray(tc.sections) && !noSec) {
            tc.sections.forEach(function(sec){
                var clean = String(sec.backendName || '').replace(/\s+/g, '').toLowerCase();
                put(secId + '-' + clean, { t: (it.title || it.id) + ' - ' + sec.name, m: sec.marks, q: sec.qs, tm: sec.time,
                    p: it.type === 'paid' ? 1 : 0, k: 'sec', ex: ex, cut: typeof sec.cutoff === 'number' ? sec.cutoff : null,   // same as exam-engine
                    l: linkBase(ex, tc, 'sec') + '?id=' + secId + '&section=' + encodeURIComponent(sec.backendName) });
            });
        }
    }
    (function walk(node, path){
        if (Array.isArray(node)) {
            var lk = path[path.length - 1];
            node.forEach(function(it){ if (it && typeof it === 'object' && it.id != null) add(it, lk, path); });
        } else if (node && typeof node === 'object') {
            Object.keys(node).forEach(function(k){ walk(node[k], path.concat(k)); });
        }
    })((json && json.data) || {}, []);
    return found;
}
// Exams whose JSON may hold this id: the claiming exams + their sub-exams (ssc-sub → ssc-sub-top).
function candidates(id){
    var c = claimers(id), out = c.slice();
    c.forEach(function(k){ S.exams.forEach(function(x){ if (x.indexOf(k + '-') === 0 && out.indexOf(x) < 0) out.push(x); }); });
    if (/^ssc-sub-\d{2}-/i.test(String(id)) && S.exams.indexOf(EXW) >= 0 && out.indexOf(EXW) < 0) out.push(EXW);
    return out;
}
/* exam-ssc-sub: main JSON once, then only the (year, exam) files that hold an attempted id.
   SSC-SUB-26-CGL-MATH-…-part-1 → files["2026"]["cgl"] (longest exam key first: selection-post before …). */
var EXW_MAIN = null, EXW_F = { done: {}, busy: {} };
function exwFilesFor(ids){
    var files = (EXW_MAIN && EXW_MAIN.files) || {}, out = {};
    ids.forEach(function(id){
        var m = /^ssc-sub-(\d{2})-(.+)$/i.exec(String(id)); if (!m) return;
        var y = '20' + m[1], fy = files[y]; if (!fy || typeof fy !== 'object') return;
        var rest = m[2].toLowerCase();
        var k = Object.keys(fy).sort(function(a, b){ return b.length - a.length; })
            .find(function(x){ return rest.indexOf(String(x).toLowerCase() + '-') === 0; });
        if (k && typeof fy[k] === 'string' && fy[k].trim()) out[y + '|' + k.toLowerCase()] = { y: y, f: fy[k].trim() };
    });
    return out;
}
function loadExamWise(ids){
    if (J.busy[EXW]) return;
    J.busy[EXW] = 1;
    var main = EXW_MAIN ? Promise.resolve(EXW_MAIN)
        : dataJson(EXW, dataFile(EXW))
            .then(function(j){ EXW_MAIN = j || {}; return EXW_MAIN; });
    main.then(function(mj){
        var need = exwFilesFor(ids), mcfg = (mj.config && mj.config.default) ? mj.config.default : {};
        return Promise.all(Object.keys(need).map(function(key){
            if (EXW_F.done[key] || EXW_F.busy[key]) return null;
            EXW_F.busy[key] = 1;
            var y = need[key].y, f = need[key].f;
            return dataJson(EXW, f)
                .then(function(fj){
                    var cfg = (fj && fj.config && fj.config.default) ? fj.config.default : mcfg, data = {};
                    data[y] = _normalizeYearBranch(_extractYearPayload(fj, y), cfg);
                    indexExamJson(EXW, { config: { 'default': cfg }, data: data });
                    EXW_F.done[key] = 1;
                })
                .catch(function(){ /* not done → retried on the next refresh */ })
                .then(function(){ delete EXW_F.busy[key]; });
        }));
    }).catch(function(){}).then(function(){ delete J.busy[EXW]; quietRender(); });
}
function titlesBusy(){ return Object.keys(J.busy).length > 0; }
var rTick = 0;
function quietRender(){ if (rTick || !S.ready) return; rTick = requestAnimationFrame(function(){ rTick = 0; S.quiet = true; renderAll(); S.quiet = false; }); }
function loadTitles(){
    var need = {}, orphan = false, exwIds = [];
    Object.keys(S.att).forEach(function(id){
        if (S.idx.mem[id]) return;
        var c = candidates(id);
        if (!c.length) orphan = true;
        c.forEach(function(ex){ need[ex] = 1; });
        if (c.indexOf(EXW) >= 0) exwIds.push(id);
    });
    if (orphan) S.exams.forEach(function(ex){ need[ex] = 1; });   // unknown prefix → look in every exam
    Object.keys(need).forEach(function(ex){
        if (ex === EXW) { if (exwIds.length) loadExamWise(exwIds); return; }   // per-file loader (above)
        if (J.done[ex] || J.busy[ex]) return;
        J.busy[ex] = 1;
        dataJson(ex, dataFile(ex))
            .then(function(j){ return prepJson(ex, j); })
            .then(function(j){ indexExamJson(ex, j); J.done[ex] = 1; })
            .catch(function(){ /* not marked done → retried on the next refresh */ })
            .then(function(){ delete J.busy[ex]; quietRender(); });
    });
}
// Exam shown on the card: the exam whose JSON has the id (most specific name first).
function primaryEx(id){
    var m = S.idx.mem[id]; if (!m || !m.length) return null;
    if (m.length === 1) return m[0];
    var l = String(id).toLowerCase();
    var sc = function(x){ var t = tokenOf(x); return l.indexOf(t) >= 0 ? t.length : 0; };
    return m.slice().sort(function(a, b){ return sc(b) - sc(a); })[0];
}
// Card data for an id (JSON info → else the quiz id itself until the title arrives)
function info(id){
    var it = S.idx.it[id];
    if (it) { var o = Object.assign({}, it); o.ex = primaryEx(id) || it.ex; return o; }
    var live = claimers(id).indexOf(LIVE_EXAM[0]) >= 0;
    var sec = /-[a-z]+$/.test(id) && !/-part-\d+$/i.test(id);
    return { t: String(id), m: null, q: null, tm: null, p: 0, k: live ? 'live' : (sec ? 'sec' : 'full'), ex: null, cut: null,
             l: (live ? '/live-test/test.html' : '/exams/test.html') + '?id=' + encodeURIComponent(id), fb: 1 };
}

/* ── local "done" store ─────────────────────────────────────────────────── */
function sk(){ return 'MMH_ATT_' + S.user; }
function loadStore(){
    try { var o = JSON.parse(lsGet(sk()) || 'null'); if (o && o.v === 1) { o.done = o.done || {}; o.hide = o.hide || {}; return o; } } catch (e) {}
    return { v: 1, done: {}, hide: {} };
}
function saveStore(){ lsSet(sk(), JSON.stringify(S.store)); }
// Done only counts for the SAME attempt it was marked on; a newer attempt → back to pending.
function doneOf(id){ var d = S.store.done[id], a = S.att[id]; return (d && a && d.c === a.createdAt) ? d : null; }
function reattemptedFrom(id){ var d = S.store.done[id], a = S.att[id]; return (d && a && d.c !== a.createdAt) ? d : null; }

/* ── derived rows ───────────────────────────────────────────────────────── */
function rowOf(id){
    var a = S.att[id], inf = info(id), m = inf.m;
    var cut = typeof inf.cut === 'number' ? inf.cut : (m ? m * 0.7 : null);
    var pct = (typeof a.score === 'number' && m) ? Math.max(0, Math.min(100, a.score / m * 100)) : null;
    return { id: id, a: a, inf: inf, marks: m, cut: cut, pct: pct, done: doneOf(id), re: reattemptedFrom(id),
             below: (typeof a.score === 'number' && cut != null) ? a.score < cut : false };
}
function allRows(){ return Object.keys(S.att).map(rowOf); }
function inTab(r, tab){
    if (tab === 'pending') return !r.done;
    if (tab === 'done') return !!r.done;
    if (tab === 'revision') return !!r.done && r.below && r.inf.k !== 'live' && daysAgo(r.a.ms) >= REV_DAYS && !S.store.hide[r.id];
    return false;
}

/* ── render: chips ──────────────────────────────────────────────────────── */
function chip(label, count, on, attr){
    return '<button type="button" class="pill-filter' + (on ? ' active' : '') + '" ' + attr + '>' + esc(label) +
           (count != null ? ' <span class="pill-count">' + count + '</span>' : '') + '</button>';
}
function inExam(r, ex){
    if (ex === 'all') return true;
    var m = S.idx.mem[r.id];
    return ex === 'other' ? !(m && m.length) : !!(m && m.indexOf(ex) >= 0);
}
function renderChips(rows, exId, tyId){
    exId = exId || 'atExamChips'; tyId = tyId || 'atTypeChips';
    var exCount = {}, tyCount = {};
    var busy = titlesBusy();
    rows.forEach(function(r){
        var m = S.idx.mem[r.id];
        if (m && m.length) m.forEach(function(e){ exCount[e] = (exCount[e] || 0) + 1; });
        else if (!busy) exCount.other = (exCount.other || 0) + 1;      // in no exam JSON (after all loaded)
    });
    var exs = Object.keys(exCount).sort(function(a, b){ return exCount[b] - exCount[a]; });
    if (S.f.ex !== 'all' && !exCount[S.f.ex] && !busy) S.f.ex = 'all';
    var h = chip('All exams', rows.length, S.f.ex === 'all', 'data-ex="all"');
    exs.forEach(function(e){ h += chip(S.examName[e] || (e === 'other' ? 'Other' : e.toUpperCase()), exCount[e], S.f.ex === e, 'data-ex="' + esc(e) + '"'); });
    $(exId).innerHTML = h;
    if ($('atExamWrap')) $('atExamWrap').classList.remove('is-hidden');   // always shown (All exams + each exam)

    rows.filter(function(r){ return inExam(r, S.f.ex); })
        .forEach(function(r){ tyCount[r.inf.k] = (tyCount[r.inf.k] || 0) + 1; });
    var tys = ['full', 'sec', 'sub', 'live'].filter(function(k){ return tyCount[k]; });
    if (S.f.ty !== 'all' && !tyCount[S.f.ty]) S.f.ty = 'all';
    var t = chip('All types', null, S.f.ty === 'all', 'data-ty="all"');
    tys.forEach(function(k){ t += chip(KIND_LABEL[k], tyCount[k], S.f.ty === k, 'data-ty="' + k + '"'); });
    $(tyId).innerHTML = t;                            // always shown (All types + each type)
}

/* ── render: one card (same markup family as the exam page card) ────────── */
var IC = {
    list : '<svg class="cmi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 6H21M8.5 12H21M8.5 18H21M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></svg>',
    clock: '<svg class="cmi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>',
    tgt  : '<svg class="cmi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="0.5" fill="currentColor"/></svg>',
    cal  : '<svg class="aoc" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
    tick : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    undo : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>',
    eye  : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6 0 9.5 7 9.5 7a17 17 0 0 1-3.1 3.9M6.1 6.6C3.8 8.3 2.5 12 2.5 12s3.5 7 9.5 7a9.6 9.6 0 0 0 4.4-1.1"/></svg>',
    re   : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v4.5h-4.5"/></svg>'
};
function cardHtml(r, tab){
    var inf = r.inf, a = r.a;
    var paid = inf.p === 1;
    var isLive = inf.k === 'live';
    var btns = isLive
        ? '<a href="' + esc(inf.l) + '" class="action-btn analysis-btn" data-open="' + esc(r.id) + '">ANALYSIS</a>'
        : '<div class="btn-grid btn-dual">' +
              '<a href="' + esc(inf.l) + '" class="action-btn analysis-btn" data-open="' + esc(r.id) + '">ANALYSIS</a>' +
              '<button type="button" class="action-btn reattempt-btn" data-re="' + esc(r.id) + '">REATTEMPT</button>' +
          '</div>';
    var meta = (inf.q || inf.tm || r.marks)
        ? '<div class="card-meta">' +
              (inf.q  ? '<span class="cm">' + IC.list  + esc(inf.q) + ' Qs</span>' : '') +
              (inf.tm ? '<span class="cm">' + IC.clock + esc(inf.tm) + '</span>' : '') +
              (r.marks ? '<span class="cm">' + IC.tgt + num(r.marks) + ' Marks</span>' : '') +
          '</div>' : '';
    var score = '';
    if (r.pct != null) {
        var cutPct = Math.max(0, Math.min(100, r.cut / r.marks * 100));
        score = '<div class="score-row"><div class="score-bar-bg">' +
                    '<div class="score-bar-fill ' + (a.score >= r.cut ? 'fill-green' : 'fill-yellow') + '" style="width:' + r.pct + '%;"></div>' +
                    '<div class="cutoff-marker" style="left:' + cutPct + '%;"></div>' +
                '</div><div class="score-text">' + num(a.score) + ' / ' + num(r.marks) + '</div></div>';
    } else if (typeof a.score === 'number') {
        score = '<div class="score-row at-score-only"><div class="score-text">Score ' + num(a.score) + '</div></div>';
    }
    var reChip = r.re && tab === 'pending'
        ? '<div class="at-re">' + IC.re + 'Re-attempted' + (typeof r.re.s === 'number' ? ' · was ' + num(r.re.s) + (typeof a.score === 'number' ? (a.score > r.re.s ? ' <b class="up">▲ ' + num(a.score - r.re.s) + '</b>' : (a.score < r.re.s ? ' <b class="down">▼ ' + num(r.re.s - a.score) + '</b>' : '')) : '') : '') + '</div>'
        : '';
    var when = 'Attempted on ' + fmtDate(a.ms) + ', ' + fmtTime(a.ms);
    var foot;
    if (tab === 'done') {
        foot = '<span class="attempted-on">' + IC.cal + when + '</span>' +
               '<button type="button" class="at-foot-btn is-done" data-undo="' + esc(r.id) + '" title="Tap to move back to Attempted">' + IC.tick + 'Done</button>';
    } else if (tab === 'revision') {
        foot = '<span class="attempted-on at-rev-on">' + IC.cal + 'Below cutoff · ' + agoText(a.ms) + '</span>' +
               '<button type="button" class="at-foot-btn ghost" data-hide="' + esc(r.id) + '">' + IC.eye + 'Hide</button>';
    } else {
        foot = '<span class="attempted-on">' + IC.cal + when + '</span>' +
               '<button type="button" class="at-foot-btn" data-done="' + esc(r.id) + '">Mark Done</button>';
    }
    var tag = isLive
        ? '<div class="at-tag"><span>Live Mock</span>' + (inf.lc ? '<i></i>' + esc(inf.lc) : '') + '</div>'
        : (inf.fb ? '' : '<div class="at-tag"><span>' + esc(S.examName[inf.ex] || (inf.ex ? inf.ex.toUpperCase() : 'Test')) + '</span><i></i>' + KIND_LABEL[inf.k] + '</div>');
    return '<div class="mock-card at-card' + (paid ? ' is-paid' : '') + (isLive ? ' is-live' : '') + '" data-id="' + esc(r.id) + '">' +
             '<div class="card-clip">' +
               '<div class="card-row"><div class="card-top"><div class="card-info">' + tag +
                 '<div class="card-title">' + esc(inf.t) + ' <span class="badge-type ' + (paid ? 'paid-badge' : 'free-badge') + '">' + (paid ? 'PAID' : 'FREE') + '</span></div>' +
                 meta + '</div></div><div class="btn-grid">' + btns + '</div></div>' +
               reChip + score +
               '<div class="card-footer">' + foot + '</div>' +
             '</div></div>';
}

/* ── render: list tabs ──────────────────────────────────────────────────── */
function groupLabel(ms){
    var d = daysAgo(ms);
    if (d <= 0) return 'Today';
    if (d === 1) return 'Yesterday';
    if (d < 7) return 'This week';
    if (d < 14) return 'Last week';
    var x = new Date(ms); return MONTH[x.getMonth()] + ' ' + x.getFullYear();
}
function renderList(){
    var tab = S.tab, rows = allRows().filter(function(r){ return inTab(r, tab); });
    renderChips(rows);
    var q = S.f.q.trim().toLowerCase();
    var vis = rows.filter(function(r){
        if (!inExam(r, S.f.ex)) return false;
        if (S.f.ty !== 'all' && r.inf.k !== S.f.ty) return false;
        if (q && String(r.inf.t).toLowerCase().indexOf(q) < 0) return false;
        return true;
    });
    var keyMs = function(r){ return r.a.ms; };
    var sort = S.f.sort;
    vis.sort(function(x, y){
        if (sort === 'low' || sort === 'high') {
            var px = x.pct == null ? -1 : x.pct, py = y.pct == null ? -1 : y.pct;
            if (px !== py) return sort === 'low' ? (px < 0 ? 1 : py < 0 ? -1 : px - py) : py - px;
        }
        return sort === 'old' ? keyMs(x) - keyMs(y) : keyMs(y) - keyMs(x);
    });

    renderBanner(rows);
    $('atTools').classList.toggle('is-hidden', !Object.keys(S.att).length);   // brand-new user: no search/filters
    var grid = $('atGrid');
    grid.classList.toggle('at-quiet', !!S.quiet);
    $('atBanner').classList.toggle('at-quiet', !!S.quiet);
    if (!rows.length) { grid.innerHTML = emptyHtml(tab); return; }
    if (!vis.length) { grid.innerHTML = '<div class="empty-state"><div class="empty-title">No match</div><div class="empty-sub">Try another search or filter.</div></div>'; return; }

    var h = '', last = null, groups = sort === 'new' || sort === 'old';
    if (!groups) h += '<div class="at-group"><span>' + (sort === 'low' ? 'Lowest score first' : 'Highest score first') + '</span><em>' + vis.length + '</em></div>';
    vis.forEach(function(r, i){
        if (groups) {
            var g = groupLabel(keyMs(r));
            if (g !== last) {
                var inG = vis.filter(function(x){ return groupLabel(keyMs(x)) === g; });
                var pcts = inG.filter(function(x){ return x.pct != null; }).map(function(x){ return x.pct; });
                var avg = pcts.length ? Math.round(pcts.reduce(function(s, v){ return s + v; }, 0) / pcts.length) : null;
                h += '<div class="at-group"><span>' + g + '</span><em>' + inG.length + (inG.length === 1 ? ' test' : ' tests') + (avg != null ? ' · avg ' + avg + '%' : '') + '</em></div>';
                last = g;
            }
        }
        h += cardHtml(r, tab).replace('class="mock-card', 'style="animation-delay:' + Math.min(i * 35, 280) + 'ms" class="mock-card');
    });
    grid.innerHTML = h;
}
function renderBanner(rows){
    var b = $('atBanner');
    if (S.tab === 'pending' && rows.length) {
        var oldest = rows.reduce(function(m, r){ return Math.min(m, r.a.ms || Infinity); }, Infinity);
        var d = oldest === Infinity ? 0 : daysAgo(oldest);
        b.innerHTML = '<div class="at-banner"><div class="at-banner-ico">' + IC.clock + '</div><div class="at-banner-txt"><b>' + rows.length +
            (rows.length === 1 ? ' test is' : ' tests are') + ' waiting for analysis</b><span>' +
            (d > 0 ? 'Oldest one is from ' + (d === 1 ? 'yesterday' : d + ' days ago') : 'All from today') +
            ' · analyse, then tap <b>Mark Done</b></span></div>' +
            (rows.length > 1 && S.f.sort !== 'old' ? '<button type="button" class="at-banner-btn" data-sort="old">Oldest first</button>' : '') + '</div>';
    } else if (S.tab === 'done' && rows.length) {
        var tot = Object.keys(S.att).length, pctDone = tot ? Math.round(rows.length / tot * 100) : 0;
        b.innerHTML = '<div class="at-banner ok"><div class="at-banner-ico">' + IC.tick + '</div><div class="at-banner-txt"><b>' + rows.length + ' of ' + tot +
            ' attempts analysed</b><span>' + pctDone + '% analysis completion</span></div><div class="at-ring" style="--p:' + pctDone + '"><i>' + pctDone + '%</i></div></div>';
    } else if (S.tab === 'revision' && rows.length) {
        b.innerHTML = '<div class="at-banner warn"><div class="at-banner-ico">' + IC.re + '</div><div class="at-banner-txt"><b>' + rows.length +
            (rows.length === 1 ? ' mock is' : ' mocks are') + ' worth a reattempt</b><span>Below cutoff, analysis done, and ' + REV_DAYS + '+ days old</span></div></div>';
    } else b.innerHTML = '';
}
function emptyHtml(tab){
    var ico = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="4" width="14" height="17" rx="2.5"/><path d="M9 4.5V3h6v1.5M8.5 11h7M8.5 15h4.5"/></svg>';
    var t = { pending: ['No pending analysis', Object.keys(S.att).length ? 'Every attempt is analysed. Great work!' : 'Attempt a mock and it will show up here.'],
              done: ['Nothing marked done yet', 'After analysing a test, tap “Mark Done” on its card.'],
              revision: ['No reattempt suggestions', 'Mocks below cutoff show up here ' + REV_DAYS + ' days after you finish their analysis.'] }[tab];
    var btn = (!Object.keys(S.att).length && tab === 'pending') ? '<a class="at-empty-btn" href="/exams/index.html">Browse exams</a>' : '';
    return '<div class="empty-state"><div class="empty-ico">' + ico + '</div><div class="empty-title">' + t[0] + '</div><div class="empty-sub">' + t[1] + '</div>' + btn + '</div>';
}

/* ── render: Progress (score + date only — no extra calls) ─────────────── */
function renderProgress(){
    var el = $('atProgress'), all = allRows();
    if (!all.length) { el.innerHTML = emptyHtml('pending'); return; }
    // same Exam + Type chips as the list tabs (shared filter) → every number below uses only these tests
    var tools = '<div class="mocks-tools at-pg-tools">' +
                  '<div class="filter-block"><div class="filter-scroll-wrapper"><div class="chips" id="atPgExamChips"></div></div></div>' +
                  '<div class="filter-block"><div class="filter-scroll-wrapper"><div class="chips" id="atPgTypeChips"></div></div></div>' +
                '</div>';
    el.innerHTML = tools;
    renderChips(all, 'atPgExamChips', 'atPgTypeChips');
    var rows = all.filter(function(r){ return inExam(r, S.f.ex) && (S.f.ty === 'all' || r.inf.k === S.f.ty); });
    tools = el.innerHTML;
    if (!rows.length) { el.innerHTML = tools + '<div class="empty-state"><div class="empty-title">No match</div><div class="empty-sub">No attempts for this exam / type.</div></div>'; return; }
    var fl = (S.f.ex !== 'all' ? (S.examName[S.f.ex] || (S.f.ex === 'other' ? 'Other' : S.f.ex.toUpperCase())) : '') +
             (S.f.ty !== 'all' ? (S.f.ex !== 'all' ? ' · ' : '') + KIND_LABEL[S.f.ty] : '');
    var now = Date.now(), today = dayStart(now);
    var week = rows.filter(function(r){ return r.a.ms >= today - 6 * DAY; }).length;
    var month = rows.filter(function(r){ var d = new Date(r.a.ms), n = new Date(); return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear(); }).length;
    var done = rows.filter(function(r){ return r.done; }).length;
    var scored = rows.filter(function(r){ return r.pct != null; });
    var avg = scored.length ? Math.round(scored.reduce(function(s, r){ return s + r.pct; }, 0) / scored.length) : 0;
    var cleared = scored.filter(function(r){ return !r.below; }).length;
    var days = {}; rows.forEach(function(r){ if (r.a.ms) { var k = dayStart(r.a.ms); days[k] = (days[k] || 0) + 1; } });
    var streak = 0, d0 = days[today] ? today : today - DAY;
    while (days[d0]) { streak++; d0 -= DAY; }

    function tile(v, l, cls){ return '<div class="at-stat ' + (cls || '') + '"><b>' + v + '</b><span>' + l + '</span></div>'; }
    var h = tools + '<div class="at-pg-head">Your progress<span>' + (fl ? 'Showing ' + esc(fl) + ' · ' + rows.length + (rows.length === 1 ? ' test' : ' tests') : 'Based on score and attempt date of every test') + '</span></div>';
    h += '<div class="at-stats">' + tile(rows.length, 'Total attempts') + tile(week, 'Last 7 days') + tile(month, 'This month') +
         tile(avg + '%', 'Average score', 'blue') + tile(streak + (streak === 1 ? ' day' : ' days'), 'Current streak', 'amber') +
         tile(Math.round(done / rows.length * 100) + '%', 'Analysis done', 'green') + '</div>';

    // trend
    var byEx = {};
    var trendK = S.f.ty === 'all' ? null : S.f.ty;          // All types → full + live mocks; a type chip → that type
    scored.forEach(function(r){ if (trendK ? r.inf.k === trendK : (r.inf.k === 'full' || r.inf.k === 'live')) (byEx[r.inf.ex] = byEx[r.inf.ex] || []).push(r); });
    var trendExs = Object.keys(byEx).filter(function(e){ return byEx[e].length >= 2; }).sort(function(a, b){ return byEx[b].length - byEx[a].length; });
    h += '<div class="at-pg-grid">';
    var trendName = trendK ? KIND_LABEL[trendK].toLowerCase() + (trendK === 'sub' ? ' tests' : 's') : 'full mocks';
    h += '<section class="at-panel at-span2"><div class="at-panel-h">Score trend <small>' + trendName + ' · % of total marks</small></div>';
    if (trendExs.length) {
        if (!S.trendEx || trendExs.indexOf(S.trendEx) < 0) S.trendEx = trendExs[0];
        h += '<div class="filter-scroll-wrapper at-trend-chips"><div class="chips">' + trendExs.map(function(e){
            return chip(S.examName[e] || e, byEx[e].length, e === S.trendEx, 'data-trend="' + esc(e) + '"'); }).join('') + '</div></div>';
        h += trendSvg(byEx[S.trendEx].slice().sort(function(a, b){ return a.a.ms - b.a.ms; }).slice(-15));
    } else h += '<div class="at-panel-empty">Attempt 2 or more ' + trendName + ' of the same exam to see your trend.</div>';
    h += '</section>';

    // cutoff tracker
    var cp = scored.length ? Math.round(cleared / scored.length * 100) : 0;
    h += '<section class="at-panel"><div class="at-panel-h">Cutoff tracker</div><div class="at-cut"><div class="at-ring big" style="--p:' + cp + '"><i>' + cp + '%</i></div>' +
         '<div><b>' + cleared + ' / ' + scored.length + '</b><span>tests above cutoff</span><em>Cutoff = test cutoff, else 70% of marks</em></div></div>';
    var exList = Object.keys(scored.reduce(function(m, r){ m[r.inf.ex] = 1; return m; }, {}));
    h += '<div class="at-cut-rows">' + exList.map(function(e){
        var xs = scored.filter(function(r){ return r.inf.ex === e; }), c = xs.filter(function(r){ return !r.below; }).length, p = Math.round(c / xs.length * 100);
        return '<div class="at-cut-row"><span>' + esc(S.examName[e] || e) + '</span><div class="at-mini"><i style="width:' + p + '%"></i></div><b>' + c + '/' + xs.length + '</b></div>';
    }).join('') + '</div></section>';

    // heatmap — last 12 weeks
    var start = today - (12 * 7 - 1) * DAY; start -= ((new Date(start).getDay() + 6) % 7) * DAY;
    var cells = '', cnt = 0;
    for (var t = start; t <= today; t += DAY) {
        var n = days[t] || 0; if (n) cnt += n;
        cells += '<i class="h' + Math.min(n, 4) + '" title="' + fmtDate(t) + ': ' + n + ' test' + (n === 1 ? '' : 's') + '"></i>';
    }
    h += '<section class="at-panel"><div class="at-panel-h">Activity <small>last 12 weeks · ' + cnt + ' tests</small></div><div class="at-heat">' + cells + '</div>' +
         '<div class="at-heat-legend">Less <i class="h0"></i><i class="h1"></i><i class="h2"></i><i class="h3"></i><i class="h4"></i> More</div></section>';

    // best / weakest
    var sorted = scored.slice().sort(function(a, b){ return b.pct - a.pct; });
    function li(r){ return '<a class="at-li" href="' + esc(r.inf.l) + '"><div><b>' + esc(r.inf.t) + '</b><span>' + esc(S.examName[r.inf.ex] || '') + ' · ' + fmtDate(r.a.ms) + '</span></div><em class="' + (r.below ? 'lo' : 'hi') + '">' + Math.round(r.pct) + '%</em></a>'; }
    h += '<section class="at-panel"><div class="at-panel-h">Best scores</div>' + sorted.slice(0, 3).map(li).join('') + '</section>';
    h += '<section class="at-panel"><div class="at-panel-h">Needs work</div>' + sorted.slice(-3).reverse().map(li).join('') + '</section>';
    h += '</div>';
    el.innerHTML = h;
}
function trendSvg(rs){
    var host = $('atProgress');
    var W = Math.max(280, Math.round(((host && host.clientWidth) || 640) - 30)), H = 200, pl = 34, pr = 12, pt = 14, pb = 26, n = rs.length;
    var x = function(i){ return pl + (n === 1 ? 0 : i * (W - pl - pr) / (n - 1)); };
    var y = function(p){ return pt + (100 - p) * (H - pt - pb) / 100; };
    var cutP = rs.reduce(function(s, r){ return s + r.cut / r.marks * 100; }, 0) / n;
    var g = '';
    [0, 25, 50, 75, 100].forEach(function(p){ g += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(p) + '" y2="' + y(p) + '" class="gl"/><text x="' + (pl - 6) + '" y="' + (y(p) + 3.5) + '" class="ax" text-anchor="end">' + p + '</text>'; });
    var pts = rs.map(function(r, i){ return x(i).toFixed(1) + ',' + y(r.pct).toFixed(1); });
    var area = 'M' + pts[0] + ' L' + pts.join(' L') + ' L' + x(n - 1).toFixed(1) + ',' + y(0) + ' L' + x(0).toFixed(1) + ',' + y(0) + ' Z';
    var dots = rs.map(function(r, i){ return '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(r.pct).toFixed(1) + '" r="4" class="' + (r.below ? 'dl' : 'dh') + '"><title>' + esc(r.inf.t) + ': ' + Math.round(r.pct) + '%</title></circle>'; }).join('');
    var lbl = rs.map(function(r, i){ return (i === 0 || i === n - 1 || n <= 6 || (W >= 600 && n <= 10)) ? '<text x="' + x(i).toFixed(1) + '" y="' + (H - 8) + '" class="ax" text-anchor="middle">' + fmtDate(r.a.ms) + '</text>' : ''; }).join('');
    return '<svg class="at-trend" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '">' + g +
           '<path d="' + area + '" class="ar"/><polyline points="' + pts.join(' ') + '" class="ln"/>' +
           '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(cutP) + '" y2="' + y(cutP) + '" class="ct"/><text x="' + (pl + 6) + '" y="' + (y(cutP) - 6) + '" class="ctx" text-anchor="start">cutoff ' + Math.round(cutP) + '%</text>' +
           dots + lbl + '</svg>';
}

/* ── tabs / badges ──────────────────────────────────────────────────────── */
function renderAll(){
    var rows = allRows();
    ['pending', 'done', 'revision'].forEach(function(t){
        var n = rows.filter(function(r){ return inTab(r, t); }).length;
        var b = document.querySelector('[data-badge="' + t + '"]');
        if (b) { b.textContent = n > 99 ? '99+' : (n || ''); b.classList.toggle('is-on', n > 0); }
    });
    var tot = rows.length;
    $('atSub').textContent = tot ? tot + (tot === 1 ? ' attempted test' : ' attempted tests') : 'All your attempted tests';
    document.querySelectorAll('.at-tab').forEach(function(b){ b.classList.toggle('is-on', b.getAttribute('data-tab') === S.tab); });
    var prog = S.tab === 'progress';
    $('atListView').classList.toggle('is-hidden', prog);
    $('atProgress').classList.toggle('is-hidden', !prog);
    if (prog) renderProgress(); else renderList();
}
function setTab(t){
    if (S.tab === t) return;
    S.tab = t;
    try { sessionStorage.setItem('mmh_att_tab', t); } catch (e) {}
    renderAll();
    $('atScroll').scrollTop = 0;
}

/* ── actions ────────────────────────────────────────────────────────────── */
// Chip flips first (Mark Done → green ✓ Done), then the card slides to its new tab.
function flipThenMove(id, btn, html, on, done){
    var card = document.querySelector('.at-card[data-id="' + cssEsc(id) + '"]');
    if (btn) { btn.disabled = true; btn.classList.toggle('is-done', on); btn.innerHTML = html; btn.classList.add('pop'); }
    var finish = function(){ S.quiet = true; renderAll(); S.quiet = false; done(); };
    setTimeout(function(){
        if (card) { card.classList.add('at-leave'); setTimeout(finish, 260); } else finish();
    }, btn ? 520 : 0);
}
function markDone(id, btn){
    var a = S.att[id]; if (!a) return;
    S.store.done[id] = { at: Date.now(), c: a.createdAt, s: a.score };
    saveStore();
    flipThenMove(id, btn, IC.tick + 'Done', true, function(){
        undoToast('Moved to Analysis Done', function(){ delete S.store.done[id]; saveStore(); S.quiet = true; renderAll(); S.quiet = false; });
    });
}
function undoDone(id, btn){
    var prev = S.store.done[id]; if (!prev) return;
    delete S.store.done[id]; saveStore();
    flipThenMove(id, btn, 'Mark Done', false, function(){
        undoToast('Moved back to Attempted', function(){ S.store.done[id] = prev; saveStore(); S.quiet = true; renderAll(); S.quiet = false; });
    });
}
function hideRev(id){ S.store.hide[id] = 1; saveStore(); renderAll(); undoToast('Hidden from Revision', function(){ delete S.store.hide[id]; saveStore(); renderAll(); }); }
function cssEsc(s){ return String(s).replace(/["\\]/g, '\\$&'); }
function undoToast(msg, undo){
    var root = $('toastRoot'); if (!root) return;
    root.querySelectorAll('.at-undo').forEach(function(x){ x.remove(); });
    var t = document.createElement('div');
    t.className = 'toast at-undo';
    t.innerHTML = '<span>' + esc(msg) + '</span><button type="button">UNDO</button>';
    var gone = false, kill = function(){ if (gone) return; gone = true; t.classList.add('out'); setTimeout(function(){ t.remove(); }, 260); };
    t.querySelector('button').onclick = function(){ undo(); kill(); };
    root.appendChild(t);
    setTimeout(kill, 5000);
}
// SAME steps as exam-engine.js reattempt(); the id is dropped from every cache that holds it.
async function reattempt(id){
    var inf = info(id);
    var ok = window.showAppConfirm
        ? await window.showAppConfirm({ title: 'Reattempt this mock?', body: 'Your previous attempt for this mock will be cleared on this device.', confirmLabel: 'Yes, Reattempt' })
        : confirm('Confirm Reattempt? Are you sure to reattempt.');
    if (!ok) return;
    try {
        ['result_', 'state_', 'stream_'].forEach(function(p){ lsDel(p + S.user + '_' + id); });
        var pre = 'CLOUD_SYNC_' + S.user + '_';
        lsKeys().forEach(function(key){
            if (key.indexOf(pre) !== 0) return;
            var c = loadCache(key);
            if (c.local[id] || c.worker[id]) { delete c.local[id]; delete c.worker[id]; saveCache(key, c); }
        });
        var left = ['result_', 'state_', 'stream_'].every(function(p){ return lsGet(p + S.user + '_' + id) === null; });
        if (!left) throw new Error('Cache clear failed');
        window.location.href = inf.l + '&mode=reattempt';
    } catch (err) {
        alert('Something went wrong while clearing your previous attempt. Please try again.');
    }
}

/* ── Refetch Attempts popup (same look/text as the exam pages) ──────────── */
function injectSync(){
    var ov = document.createElement('div');
    ov.id = 'syncModalOverlay';
    ov.className = 'sync-modal-overlay hidden';
    ov.innerHTML =
        '<div class="sync-modal-box">' +
            '<div class="sync-modal-icon"><i class="fas fa-rotate"></i></div>' +
            '<h5>Attempted a test but don\'t see it here?</h5>' +
            '<p>This can happen if you attempted it on another device. Tap refresh to check all exams again.</p>' +
            '<div class="at-sync-list" id="atSyncList"></div>' +
            '<div class="sync-modal-actions">' +
                '<button class="sync-modal-btn cancel" type="button">Cancel</button>' +
                '<button class="sync-modal-btn confirm" type="button" id="syncModalConfirmBtn">Refresh Now</button>' +
            '</div>' +
            '<div id="syncModalStatus" class="sync-modal-status"></div>' +
        '</div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', function(e){ if (e.target === ov) closeSync(); });
    ov.querySelector('.cancel').onclick = closeSync;
    ov.querySelector('#syncModalConfirmBtn').onclick = confirmSync;
    $('cloudSyncBtn').onclick = openSync;
}
function openSync(){
    if (!S.user) { if (window.showToast) showToast('Sign in to refresh your attempts', 'error'); return; }
    var st = $('syncModalStatus'); st.textContent = ''; st.className = 'sync-modal-status';
    $('atSyncList').innerHTML = '';
    $('syncModalOverlay').classList.remove('hidden');
}
function closeSync(){ $('syncModalOverlay').classList.add('hidden'); }
async function confirmSync(){
    var btn = $('syncModalConfirmBtn'), st = $('syncModalStatus'), list = $('atSyncList');
    btn.disabled = true; st.textContent = 'Checking your attempts in all exams…'; st.className = 'sync-modal-status';
    var rowsHtml = {};
    try {
        var cfg = await loadCfg();
        var groups = groupByWorker(cfg, S.exams);
        Object.keys(groups).forEach(function(u, i){ rowsHtml[u] = i; });
        list.innerHTML = Object.keys(groups).map(function(u, i){
            return '<div class="at-sync-row" data-g="' + i + '"><span>' + groups[u].map(function(e){ return esc(S.examName[e] || e); }).join(', ') + '</span><em class="wait">…</em></div>';
        }).join('');
        var fails = 0;
        await syncExams(S.exams, function(exs, ok){
            var u = Object.keys(groups).find(function(k){ return groups[k].indexOf(exs[0]) >= 0; });
            var row = list.querySelector('[data-g="' + rowsHtml[u] + '"] em');
            if (row) { row.className = ok ? 'ok' : 'bad'; row.textContent = ok ? '✓' : '✗'; }
            if (!ok) fails++;
        });
        collectAttempts(); renderAll(); loadTitles();
        st.textContent = fails ? 'Updated — ' + fails + ' exam group(s) could not be checked. Try again later.' : 'Updated!';
        st.className = 'sync-modal-status ' + (fails ? 'error' : 'success');
        if (!fails) setTimeout(closeSync, 1100);
    } catch (e) {
        st.textContent = 'Could not refresh — please try again.'; st.className = 'sync-modal-status error';
    } finally { btn.disabled = false; }
}

/* ── wiring ─────────────────────────────────────────────────────────────── */
function bind(){
    document.addEventListener('click', function(e){
        var t = e.target.closest ? e.target : e.target.parentElement;
        var el;
        if ((el = t.closest('[data-tab]'))) return setTab(el.getAttribute('data-tab'));
        if ((el = t.closest('[data-done]'))) return markDone(el.getAttribute('data-done'), el);
        if ((el = t.closest('[data-undo]'))) return undoDone(el.getAttribute('data-undo'), el);
        // Title/link still loading → wait for it (ssc-sub / sectional links come from the exam JSON)
        if ((el = t.closest('[data-open],[data-re]')) && info(el.getAttribute('data-open') || el.getAttribute('data-re')).fb && titlesBusy()) {
            e.preventDefault(); if (window.showToast) showToast('Loading test details… try again in a moment'); return;
        }
        if ((el = t.closest('[data-hide]'))) return hideRev(el.getAttribute('data-hide'));
        if ((el = t.closest('[data-re]'))) return reattempt(el.getAttribute('data-re'));
        if ((el = t.closest('[data-ex]'))) { S.f.ex = el.getAttribute('data-ex'); S.f.ty = 'all'; saveF(); return S.tab === 'progress' ? renderProgress() : renderList(); }
        if ((el = t.closest('[data-ty]'))) { S.f.ty = el.getAttribute('data-ty'); saveF(); return S.tab === 'progress' ? renderProgress() : renderList(); }
        if ((el = t.closest('[data-sort]'))) { S.f.sort = el.getAttribute('data-sort'); $('atSort').value = S.f.sort; saveF(); return renderList(); }
        if ((el = t.closest('[data-trend]'))) { S.trendEx = el.getAttribute('data-trend'); return renderProgress(); }
    });
    $('atSort').addEventListener('change', function(){ S.f.sort = this.value; saveF(); renderList(); });
    $('mockSearch').addEventListener('input', function(){ S.f.q = this.value; renderList(); });
    $('themeToggle').onclick = function(){ window.toggleTheme && window.toggleTheme(); };
    $('atBack').onclick = function(){
        if (window.MMHNav) { MMHNav.back('/index.html'); return; } /* t255 */
        var ref = document.referrer || '';
        if (ref && ref.indexOf(location.origin) === 0 && history.length > 1) { try { history.back(); return; } catch (e) {} }
        location.href = '/';
    };
    // Back from test.html → absorb its fresh qsum_ (new attempt shows up at once).
    window.addEventListener('pageshow', function(ev){ if (ev.persisted && S.user) refreshLocal(); });
    var rzT = 0;
    window.addEventListener('resize', function(){ clearTimeout(rzT); rzT = setTimeout(function(){ if (S.user && S.tab === 'progress') renderProgress(); }, 180); });
    document.addEventListener('visibilitychange', function(){ if (!document.hidden && S.user) refreshLocal(); });
}
function saveF(){ try { sessionStorage.setItem('mmh_att_f', JSON.stringify({ ex: S.f.ex, ty: S.f.ty, sort: S.f.sort })); } catch (e) {} }
function loadF(){
    try { var o = JSON.parse(sessionStorage.getItem('mmh_att_f') || 'null'); if (o) { S.f.ex = o.ex || 'all'; S.f.ty = o.ty || 'all'; S.f.sort = o.sort || 'new'; } } catch (e) {}
    try { var t = sessionStorage.getItem('mmh_att_tab'); if (t) S.tab = t; } catch (e) {}
    $('atSort').value = S.f.sort;
}
function refreshLocal(){ if (!S.ready) return; absorbLocal(); collectAttempts(); S.quiet = true; renderAll(); S.quiet = false; loadTitles(); }


/* ── first-visit guide on the Refetch button ───────────────────────────── */
function syncTip(){
    var btn = $('cloudSyncBtn');
    if (!btn || S.store.tip || document.querySelector('.at-tip')) return;
    var el = document.createElement('div');
    el.className = 'at-tip'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'What Refetch Attempts does');
    el.innerHTML = '<span class="at-tip-arrow"></span>' +
        '<div class="at-tip-h"><span class="at-tip-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 0 0-14.6-4.5L4 8"/><path d="M4 3.5V8h4.5"/><path d="M4 13a8 8 0 0 0 14.6 4.5L20 16"/><path d="M20 20.5V16h-4.5"/></svg></span>Refetch Attempts</div>' +
        '<p>Brings <b>all your attempts</b> from the server again.</p>' +
        '<ul><li>Gave a test on <b>another phone / browser</b>?</li><li>A finished test is <b>missing</b> here or shows an old score?</li></ul>' +
        '<div class="at-tip-f"><span>Tap it then. Tests from this device show up on their own.</span><button type="button" class="at-tip-ok">Got it</button></div>';
    document.body.appendChild(el);
    btn.classList.add('at-tip-target');
    function place(){
        var r = btn.getBoundingClientRect(), w = el.offsetWidth, vw = document.documentElement.clientWidth;
        var left = Math.max(10, Math.min(r.right + 6 - w, vw - w - 10));
        el.style.top = Math.round(r.bottom + 12) + 'px';
        el.style.left = Math.round(left) + 'px';
        el.querySelector('.at-tip-arrow').style.left = Math.round(r.left + r.width / 2 - left - 7) + 'px';
    }
    function close(){
        if (!el.parentNode) return;
        S.store.tip = 1; saveStore();
        btn.classList.remove('at-tip-target');
        el.classList.add('out'); setTimeout(function(){ el.remove(); }, 180);
        window.removeEventListener('resize', place); document.removeEventListener('pointerdown', outside, true);
    }
    function outside(e){ if (!el.contains(e.target)) close(); }   // a tap on the button itself also runs the refetch
    place(); requestAnimationFrame(function(){ el.classList.add('in'); });
    el.querySelector('.at-tip-ok').addEventListener('click', close);
    window.addEventListener('resize', place);
    setTimeout(function(){ document.addEventListener('pointerdown', outside, true); }, 50);
}

function skeleton(){
    $('atGrid').innerHTML = Array(4).join('.').split('.').map(function(){
        return '<div class="skeleton-card"><div class="card-info"><div class="skeleton-line skeleton-title"></div><div class="skeleton-line skeleton-meta"></div></div><div class="skeleton-line skeleton-btn"></div></div>';
    }).join('');
}

async function init(){
    if (window.applyTheme && window.currentTheme) applyTheme(currentTheme());
    bind(); injectSync(); loadF();
    var p = typeof getLocalProfile === 'function' ? getLocalProfile() : null;
    if (!p || !p.username || p.username === 'Guest') {
        document.body.classList.add('at-guest');
        $('atTools').classList.add('is-hidden');
        $('atGrid').innerHTML = '<div class="empty-state"><div class="empty-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/></svg></div>' +
            '<div class="empty-title">Login to see your attempts</div><div class="empty-sub">All your attempted tests from every exam appear here.</div><a class="at-empty-btn" href="/">Go to Home</a></div>';
        return;
    }
    S.user = p.username;                     // original case — same key test.html / engines use
    S.store = loadStore(); S.idx = { it: {}, mem: {} };
    skeleton();
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
    await loadExams();

    absorbLocal(); collectAttempts();
    // First visit on this device: exams never synced here get ONE worker check (same rule as exam pages).
    var unsynced = S.exams.filter(function(ex){ return !loadCache(ck(ex)).workerSynced; });
    var hasLocal = Object.keys(S.att).length > 0;
    if (hasLocal || !unsynced.length) { S.ready = true; renderAll(); }   // cards at once (quiz id until its title arrives)
    // (else: keep the skeleton — no "No attempts" flash while the first sync runs)
    loadTitles();                                    // background — never blocks the cards
    if (unsynced.length) {
        // SAME rule as the exam pages: an exam whose cache was never worker-synced on this
        // device gets the worker call; one call per worker URL (common worker = one call).
        try { await syncExams(unsynced); collectAttempts(); } catch (e) { /* offline — local data only */ }
        S.ready = true; renderAll(); loadTitles();
    }
    setTimeout(syncTip, 700);                        // first visit only (S.store.tip)
}

window.MMHAttempts = { _state: S, claimers: claimers, info: info };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

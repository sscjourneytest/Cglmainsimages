/* ══════════════════════════════════════════════════════════════════════════
   admin-bulk.js — Upload Test › "Bulk" tab (many tests at once)
   Needs mmh-rules.js, mmh-upload-core.js, mmh-zip.js and admin-upload.js
   (window.MMHUpAdmin = its API + helpers) loaded first.

   DOWNLOAD  quiz ids / prefixes (one per line) → GET /tests/list → pick →
             GET /tests/export per test (structure + every bank body, 1 call)
             → ONE zip: {id}.full.json and/or {id}.quid.json
             + DELETE selected tests (admin Worker v6 /tests/delete, 3 at a time):
             R2 folder + tests row, D1 quids only when ticked · backup zip first.
   UPLOAD    (admin Worker v7) many JSON files or a zip →
             1. ONE call POST /tests/check {ids}: which quiz ids exist (tests row / R2)
             2. this computer: bank rules (prepare) + quid rule + Free/Paid
             3. D1 text of the quids used in the JSONs (POST /tests/bodies, 1000 per call)
                → OVERWRITE list = questions whose text differs from D1 (admin confirms)
             4. no dry run: the Worker checks everything ONCE, on the real upload
             → upload 3 tests at the same time (the Worker retries a quid clash itself).
   The pure part (MMHBulkCore) has no DOM → also used by the node tests.
   ══════════════════════════════════════════════════════════════════════════ */
(function (root) {
"use strict";

var R = root.MMHRules, U = root.MMHUpload;
var MAX_OVERWRITE = 500;                    // = admin Worker v5
var CMP_FIELDS = ["question", "option_1", "option_2", "option_3", "option_4", "option_5", "answer", "solution_text",
                  "question_image", "option_image_1", "option_image_2", "option_image_3", "option_image_4",
                  "option_image_5", "solution_image", "solution_video", "comprehension", "topic", "topic_tag", "topic_tag_id"];
function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }

/* ═════════════════════════════ PURE PART ═════════════════════════════ */
function baseName(n) { return String(n || "").split(/[\\/]/).pop(); }
function idFromName(n) { return baseName(n).replace(/\.json$/i, "").replace(/\.(quid|full)$/i, ""); }
/** quiz id of a file = meta.id (when valid) else the file name without .json / .full / .quid (same as single upload) */
function fileId(name, data) {
  var m = data && data.meta;
  if (m && typeof m.id === "string" && U.ID_RE.test(m.id)) return m.id;
  var f = idFromName(name);
  return U.ID_RE.test(f) ? f : "";
}
/** full test (question objects) or quid JSON ([localId, quid] items only)? */
function isFull(data) {
  var s = data && data.sections;
  if (!isObj(s)) return false;
  return Object.keys(s).some(function (n) { return (U.sectionList(s[n]) || []).some(function (q) { return isObj(q); }); });
}
/** files [{name, data|null, error}] → tests [{id, name, data, error, note}] — one per quiz id.
 *  Same id twice: a full JSON wins over a quid JSON; two of the same kind = error on the second. */
function groupFiles(files) {
  var byId = {}, out = [];
  files.forEach(function (f) {
    if (f.error) { out.push({ id: f.id || idFromName(f.name), name: f.name, data: null, error: f.error }); return; }
    var shape = U.validateTest(f.data);
    if (shape) { out.push({ id: idFromName(f.name), name: f.name, data: null, error: shape }); return; }
    var id = fileId(f.name, f.data);
    if (!id) { out.push({ id: idFromName(f.name), name: f.name, data: null, error: "No quiz id: meta.id is missing and the file name is not a valid id (A-Z a-z 0-9 _ -)" }); return; }
    var t = { id: id, name: f.name, data: f.data, error: null, full: isFull(f.data), note: "" };
    var o = byId[id];
    if (!o) { byId[id] = t; out.push(t); return; }
    if (t.full && !o.full) {                                       // full replaces the quid JSON already listed
      t.note = "quid JSON " + baseName(o.name) + " skipped (full JSON used)";
      out[out.indexOf(o)] = t; byId[id] = t; return;
    }
    if (!t.full && o.full) { o.note = (o.note ? o.note + " · " : "") + "quid JSON " + baseName(t.name) + " skipped (full JSON used)"; return; }
    out.push({ id: id, name: f.name, data: null, error: "Same quiz id as " + baseName(o.name) + " — only one file per test" });
  });
  return out;
}
function fieldsDiff(oldBody, newBody) {
  var oe = R.expand(oldBody), ne = R.expand(newBody);
  var f = CMP_FIELDS.filter(function (k) { return JSON.stringify(oe[k] === undefined ? "" : oe[k]) !== JSON.stringify(ne[k] === undefined ? "" : ne[k]); });
  return f.length ? f : ["other fields"];
}
/** quids whose bank body is needed: quid rows with a question object + live quids matched by local id */
function neededQuids(P, liveR2) {
  var out = {};
  P.rows.forEach(function (r) { if (r.quid && r.q && U.QUID_RE.test(r.quid)) out[r.quid] = 1; });
  if (liveR2 && liveR2.sections && P.counts.nw) {
    var lids = {};
    P.rows.forEach(function (r) { if (r.newIndex !== null) lids[String(r.lid)] = 1; });
    Object.keys(liveR2.sections).forEach(function (n) {
      (U.sectionList(liveR2.sections[n]) || []).forEach(function (it) { if (lids[String(it[0])] && U.QUID_RE.test(String(it[1]))) out[it[1]] = 1; });
    });
  }
  return Object.keys(out);
}
/**
 * P = U.prepare(), liveR2 = live structure or null, bank = {quid: {body (compact object), base}} (null = not in D1)
 * → { ow:[{quid, body, base, where, fields, kind:"quid"|"match"}], matches, keep:{newIndex: oldQuid}, same, missing[], errors[] }
 *   ow  : questions that would CHANGE in D1 (text differs) — sent only when the admin says Overwrite
 *   keep: new questions that point at the live quid (identical OR different text) → never a duplicate quid
 */
function planTest(P, liveR2, bank) {
  var out = { ow: [], matches: [], keep: {}, same: 0, missing: [], errors: [] }, seen = {};
  function addOw(o) {
    var s = seen[o.quid];
    if (s) { if (s.body !== o.body) out.errors.push(o.quid + " is in the JSON twice with different text (" + s.where + " / " + o.where + ")"); return; }
    seen[o.quid] = o; out.ow.push(o);
  }
  P.rows.forEach(function (r) {
    if (!(r.quid && r.q && U.QUID_RE.test(r.quid))) return;
    var where = r.sec + " Q" + (r.pos + 1);
    var b = bank[r.quid];
    if (!b) { out.missing.push(r.quid); return; }
    var res = R.check(r.q, b.body, { fields: P.fields || {} });   // no exam tag added: bank questions already · D1 body = original (fields it already has are allowed)
    if (!res.ok) { out.errors.push(where + " (" + r.quid + "): " + res.errors.join(" · ")); return; }
    if (U.bodyText(b.body) === res.text) { out.same++; if (seen[r.quid] && seen[r.quid].body !== res.text) out.errors.push(r.quid + " is in the JSON twice with different text"); return; }
    addOw({ quid: r.quid, body: res.text, base: b.base, where: where, lid: r.lid, fields: fieldsDiff(b.body, JSON.parse(res.text)), kind: "quid" });
  });
  if (liveR2 && liveR2.sections) {
    var bodies = {};
    Object.keys(bank).forEach(function (q) { if (bank[q]) bodies[q] = bank[q].body; });
    out.matches = U.matchExisting(P, liveR2, bodies);
    out.matches.forEach(function (m) {
      if (m.missing) return;                                       // live quid gone from D1 → stays a new question
      out.keep[m.row.newIndex] = m.oldQuid;
      if (m.same) { out.same++; return; }
      addOw({ quid: m.oldQuid, body: P.newBodies[m.row.newIndex], base: bank[m.oldQuid].base, where: m.row.sec + " Q" + (m.row.pos + 1),
              lid: m.row.lid, fields: m.fields, kind: "match" });
    });
  }
  if (out.missing.length) out.errors.push(out.missing.length + " quid(s) are not in D1: " + out.missing.slice(0, 6).join(", ") + (out.missing.length > 6 ? " …" : ""));
  if (out.ow.length > MAX_OVERWRITE) out.errors.push(out.ow.length + " questions differ from D1 — max " + MAX_OVERWRITE + " overwrites per test");
  return out;
}
/** NEW field names to ask Keep / Remove AFTER the D1 bodies are loaded:
 *  new questions → every unknown field · quid questions → only if their D1 body does not already have it */
function fieldsToAsk(P, bank) {
  var nf = {}, ch = P.fields || {};
  P.rows.forEach(function (r) {
    if (!isObj(r.q)) return;
    var isNew = !r.quid, b = !isNew && bank ? bank[r.quid] : null;
    Object.keys(r.q).forEach(function (k) {
      if (R.isKnownField(k) || k === "quid") return;
      if (!isNew && b && isObj(b.body) && Object.prototype.hasOwnProperty.call(b.body, k)) return;
      var e = nf[k] || (nf[k] = { name: k, nw: 0, old: 0, sample: "", choice: ch[k] || null });
      if (isNew) e.nw++; else e.old++;
      if (!e.sample) { var v = r.q[k]; e.sample = (typeof v === "string" ? v : JSON.stringify(v)).slice(0, 80); }
    });
  });
  return Object.keys(nf).map(function (k) { return nf[k]; });
}
/** upload payload. owOn = send the overwrite list. live = {row, r2} or null (new id) */
function payloadOf(t, owOn, dry) {
  var a = U.applyMatches(t.P, t.plan.keep);
  var p = { id: t.id, is_free: t.isFree, meta: t.P.meta, sections: a.sections, new: a.newBodies };
  if (owOn && t.plan.ow.length) p.overwrite = t.plan.ow.map(function (o) { return { quid: o.quid, body: o.body, base: o.base }; });
  if (t.live) { p.replace = true; p.expect_ver = t.live.row ? t.live.row.ver : 0; }
  if (dry) p.dry = true;
  return p;
}
function stamp(d) {
  d = d || new Date();
  var z = function (n) { return (n < 10 ? "0" : "") + n; };
  return String(d.getFullYear()).slice(2) + z(d.getMonth() + 1) + z(d.getDate()) + "-" + z(d.getHours()) + z(d.getMinutes());
}
/** export answer → files for the zip */
function exportFiles(d, fmt) {
  var qj = { meta: d.r2.meta, sections: {} };
  d.r2.names.forEach(function (n) { if (d.r2.sections[n] !== undefined && d.r2.sections[n] !== null) qj.sections[n] = d.r2.sections[n]; });
  var files = [], missing = [];
  if (fmt !== "quid") {
    var a = U.assemble(qj, d.bodies || {});
    missing = a.missing;
    files.push([d.id + ".full.json", JSON.stringify(a.test, null, 1)]);
  }
  if (fmt !== "full") files.push([d.id + ".quid.json", JSON.stringify(qj, null, 1)]);
  return { files: files, missing: missing };
}
root.MMHBulkCore = { fileId: fileId, isFull: isFull, groupFiles: groupFiles, neededQuids: neededQuids, planTest: planTest, fieldsToAsk: fieldsToAsk,
                     payloadOf: payloadOf, exportFiles: exportFiles, stamp: stamp, MAX_OVERWRITE: MAX_OVERWRITE };
if (typeof document === "undefined") return;

/* ═════════════════════════════ SCREEN ═════════════════════════════ */
var A = null;                       // MMHUpAdmin (set at boot)
var $ = function (id) { return document.getElementById(id); };
var B = {
  mode: "upload",
  // download
  groups: [], sel: {}, info: {}, fmt: "full", searching: false, dl: null,
  delR2: true, delD1: false, delBk: true, deleting: false, del: null,
  // upload
  defFree: 0, tests: [], loading: false, busy: false, ran: false, upFmt: "full", phase: "",
  tagOk: null,                       // bulk confirm: exam tag lagana hai? null = abhi chuna nahi
  fields: {},                        // NEW (non-standard) field → "keep" | "remove" — poore batch ke liye ek baar
  pane: null                         // big screen: key of the test shown in the side pane
};
function wide() { return !!(A && A.wide && A.wide()); }
function RD() { return root.MMHRender || null; }
/** file can be rendered: valid test JSON (sections with full questions / [localId, quid]) */
function canRender(t) { return !!(t && t.data && !U.validateTest(t.data)); }
var MAX_LIST_PAGES = 5;             // 5 × 1000 ids per line
var MAX_TESTS = 200;                // per bulk upload
var DL_PARALLEL = 3;
var CHECK_IDS = 200;                // quiz ids per POST /tests/check (Worker v7 max)
var BODY_BATCH = 1000;              // quids per POST /tests/bodies (Worker v7 max)
var BODY_PARALLEL = 3;
var UP_PARALLEL = 3;                // tests uploading at the same time
var DEL_PARALLEL = 3;               // tests deleting at the same time

function esc(s) { return A.esc(s); }
function chip(cls, txt) { return '<span class="up-chip ' + cls + '">' + esc(txt) + "</span>"; }
function liveChips(row, hiddenR2) {
  if (row) return chip("live", "Live") + chip(Number(row.is_free) === 1 ? "free" : "paid", A.freeTxt(row.is_free)) + chip("", A.verTxt(row.ver));
  return hiddenR2 ? chip("is-hidden", "Hidden") : chip("bk-new", "New");
}
function fail(e) {
  if (e && e.auth) { A.authLost(); return true; }
  return false;
}
async function pool(list, n, fn) {
  var i = 0;
  async function worker() { while (i < list.length) { var k = i++; await fn(list[k], k); } }
  var ws = [];
  for (var j = 0; j < Math.min(n, list.length); j++) ws.push(worker());
  await Promise.all(ws);
}

function show() { paintMode(); }
function setMode(m) { B.mode = m; paintMode(); }
function paintMode() {
  document.querySelectorAll("#bkMode [data-mode]").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-mode") === B.mode); });
  $("bkDown").hidden = B.mode !== "download";
  $("bkUp").hidden = B.mode !== "upload";
}

/* ───────────────────────────── DOWNLOAD ───────────────────────────── */
async function search() {
  if (B.searching) return;
  var lines = $("bkQuery").value.split(/[\n,]+/).map(function (s) { return s.trim(); }).filter(Boolean);
  var uniq = []; lines.forEach(function (l) { if (uniq.indexOf(l) === -1) uniq.push(l); });
  if (!uniq.length) { $("bkQuery").focus(); A.toast("Type a quiz id or prefix"); return; }
  var bad = uniq.filter(function (l) { return !U.ID_RE.test(l); });
  if (bad.length) { A.toast("Only A-Z a-z 0-9 _ - allowed: " + bad.slice(0, 3).join(", "), 4000); return; }
  if (uniq.length > 50) { A.toast("Max 50 lines at once", 3000); return; }
  B.searching = true; B.dl = null;
  var btn = $("bkSearch");
  A.busyBtn(btn, true, "Searching…");
  var groups = [];
  try {
    for (var i = 0; i < uniq.length; i++) {
      var q = uniq[i], items = [], cursor = null, pages = 0, more = false;
      btn.querySelector("span:last-child").textContent = "Searching " + (i + 1) + "/" + uniq.length + "…";
      do {
        var d = await A.API.list(q, cursor);
        items = items.concat(d.items || []); cursor = d.cursor; pages++;
      } while (cursor && pages < MAX_LIST_PAGES);
      more = !!cursor;
      groups.push({ q: q, items: items, more: more });
    }
  } catch (e) {
    if (fail(e)) return;
    A.toast(A.failText(e), 4200);
  } finally { B.searching = false; A.busyBtn(btn, false); }
  if (!groups.length) return;
  B.groups = groups; B.sel = {}; B.info = {};
  if (RD()) RD().closeIn($("bkDownSide"));
  groups.forEach(function (g) {
    g.items.forEach(function (it) {
      B.info[it.id] = it.row;
      if (it.id === g.q) B.sel[it.id] = true;            // the exact id typed = selected; a prefix → pick
    });
  });
  paintFound();
}
function allIds() {
  var ids = [];
  B.groups.forEach(function (g) { g.items.forEach(function (it) { if (ids.indexOf(it.id) === -1) ids.push(it.id); }); });
  return ids;
}
function selIds() { return allIds().filter(function (id) { return B.sel[id]; }); }
function paintFound() {
  var el = $("bkFound");
  paintZip();
  if (!B.groups.length) { el.hidden = true; return; }
  el.hidden = false;
  var ids = allIds(), n = selIds().length;
  var h = '<div class="bk-head"><div><div class="bk-title">' + A.plural(ids.length, "test") + " found</div>" +
    '<div class="bk-sub"><b id="bkSelN">' + n + "</b> selected</div></div>" +
    '<div class="bk-head-btns"><button type="button" class="rq-btn bk-mini" data-bk="all">Select all</button><button type="button" class="rq-btn bk-mini" data-bk="none">Clear</button></div></div>';
  B.groups.forEach(function (g, gi) {
    var gs = g.items.filter(function (it) { return B.sel[it.id]; }).length;
    h += '<div class="bk-group"><div class="bk-ghead"><code>' + esc(g.q) + "</code><span>" + (g.items.length ? A.plural(g.items.length, "match", "matches") + (g.more ? "+ (first " + g.items.length + ")" : "") : "no match") + "</span>" +
      (g.items.length > 1 ? '<button type="button" class="bk-link" data-bk-g="' + gi + '">' + (gs === g.items.length ? "Unselect" : "Select") + " these</button>" : "") + "</div>";
    if (g.items.length) {
      h += '<div class="bk-items">' + g.items.map(function (it) {
        return '<label class="bk-item"><input type="checkbox" data-bk-id="' + esc(it.id) + '"' + (B.sel[it.id] ? " checked" : "") + '><span class="bk-id">' + esc(it.id) + '</span><span class="bk-chips">' + liveChips(it.row, true) + "</span></label>";
      }).join("") + "</div>";
    }
    h += "</div>";
  });
  el.innerHTML = h;
}
/** zip options + Download (phone: under the list · big screen: side pane) */
function paintZip() {
  var z = $("bkZip"), has = B.groups.length > 0;
  $("bkDownEmpty").hidden = has;
  z.hidden = !has;
  if (!has) { z.innerHTML = ""; return; }
  var n = selIds().length, all = allIds().length;
  z.innerHTML = '<div class="bk-rdbox"><button type="button" class="rq-btn rq-btn-soft up-render-btn" id="bkRd"' + (n ? "" : " disabled") + ">" + A.IC.render + "<span>Render Questions (" + n + ")</span></button>" +
      '<span class="up-hint">' + (wide() ? "Selected tests open right here in this pane (switch test from the list on top)." : "Selected tests open on a full screen.") + "</span></div>" +
    '<div class="up-step"><span class="up-step-no up-step-ico">' + A.IC.down + '</span><span>Download zip</span></div>' +
    '<div class="bk-zipsum"><b id="bkZipN">' + n + "</b> of " + all + " selected</div>" +
    '<div class="bk-fmt"><span class="up-label">Zip contains</span>' + fmtSeg("bkFmt", B.fmt) +
    '<span class="up-hint">' + fmtHint(B.fmt) + "</span></div>" +
    '<div class="up-btns"><button type="button" class="rq-btn rq-btn-primary" id="bkDl"' + (n && !B.deleting ? "" : " disabled") + ">" + A.IC.down + "<span>Download zip (" + n + ")</span></button></div>" +
    '<div id="bkDlRes"></div>' +
    '<div class="bk-del"><div class="up-step"><span class="up-step-no up-step-ico bk-del-ico">' + A.IC.trash + "</span><span>Delete selected</span></div>" +
    '<span class="up-hint">R2 folder + tests row of every selected test (users get 404). D1 questions only if you tick it in the next step.</span>' +
    '<div class="up-btns"><button type="button" class="rq-btn up-del-btn" id="bkDel"' + (n && !B.deleting ? "" : " disabled") + ">" + A.IC.trash + "<span>Delete selected (" + n + ")</span></button></div>" +
    '<div id="bkDelRes"></div></div>';
  paintDlRes(); paintDelRes();
}
function fmtSeg(id, v) {
  return '<div class="up-seg bk-seg3" id="' + id + '"><button type="button" data-fmt="full" class="' + (v === "full" ? "on" : "") + '">Full JSON</button>' +
    '<button type="button" data-fmt="quid" class="' + (v === "quid" ? "on" : "") + '">Quid JSON</button>' +
    '<button type="button" data-fmt="both" class="' + (v === "both" ? "on" : "") + '">Both</button></div>';
}
function fmtHint(v) {
  return v === "full" ? "Questions with text + quid in every question (edit and upload again)." :
         v === "quid" ? "Only [localId, quid] — exactly what R2 keeps (small)." : "Both files for every test.";
}
function syncSel() {
  var n = selIds().length;
  if ($("bkSelN")) $("bkSelN").textContent = n;
  if ($("bkZipN")) $("bkZipN").textContent = n;
  var rb = $("bkRd");
  if (rb) { rb.disabled = !n; rb.querySelector("span:last-child").textContent = "Render Questions (" + n + ")"; }
  var d = $("bkDel");
  if (d && !d.querySelector(".up-spin")) { d.disabled = !n || B.deleting; d.querySelector("span:last-child").textContent = "Delete selected (" + n + ")"; }
  var b = $("bkDl");
  if (!b || b.querySelector(".up-spin")) return;          // busy downloading
  b.disabled = !n || B.deleting;
  b.querySelector("span:last-child").textContent = "Download zip (" + n + ")";
}
async function downloadZip(ids, fmt, btn, resKey, namePrefix) {
  if (!ids.length) return;
  var zip = MMHZip.writer(), done = 0, res = { ok: [], failed: [], missing: {}, fmt: fmt };
  A.busyBtn(btn, true, "0/" + ids.length);
  try {
    await pool(ids, DL_PARALLEL, async function (id) {
      try {
        var d = await A.API.exportTest(id);
        var f = exportFiles(d, fmt);
        for (var i = 0; i < f.files.length; i++) await zip.add(f.files[i][0], f.files[i][1]);
        var miss = (d.missing || []).concat(f.missing.filter(function (q) { return (d.missing || []).indexOf(q) === -1; }));
        if (miss.length) res.missing[id] = miss;
        res.ok.push(id);
      } catch (e) {
        if (e && e.auth) throw e;
        res.failed.push({ id: id, error: A.failText(e), status: e && e.status, notFound: !!(e && e.data && e.data.notFound) });
      }
      done++;
      var s = btn.querySelector("span:last-child"); if (s) s.textContent = done + "/" + ids.length;
    });
    if (res.ok.length) {
      var name = (namePrefix || "MMH-tests-") + res.ok.length + "-" + stamp() + ".zip";
      var blob = zip.blob();
      res.name = name; res.size = blob.size;
      A.saveBlob(name, blob, "application/zip");
    }
  } catch (e) {
    if (fail(e)) return null;
    A.toast(A.failText(e), 4200);
  } finally { A.busyBtn(btn, false); }
  if (resKey === "dl") { B.dl = res; paintDlRes(); }
  return res;
}
function dlResHtml(r) {
  if (!r) return "";
  var miss = Object.keys(r.missing);
  var h = '<div class="up-box ' + (r.failed.length || miss.length ? "warn" : "ok") + '" style="margin-top:12px"><h4>' +
    (r.ok.length ? "Zip saved · " + A.plural(r.ok.length, "test") + (r.size ? " · " + A.kb(r.size) : "") : "Nothing downloaded") + "</h4>";
  if (r.name) h += '<p><code class="up-mono">' + esc(r.name) + "</code></p>";
  if (miss.length) h += "<p>Some quids are missing in D1 (left out of the full JSON): " + miss.slice(0, 5).map(function (id) { return "<b>" + esc(id) + "</b> " + r.missing[id].length; }).join(" · ") + (miss.length > 5 ? " …" : "") + "</p>";
  if (r.failed.length) h += "<p>Failed: " + r.failed.slice(0, 6).map(function (f) { return "<b>" + esc(f.id) + "</b> (" + esc(f.error) + ")"; }).join(" · ") + (r.failed.length > 6 ? " …" : "") + "</p>";
  return h + "</div>";
}
function paintDlRes() { var el = $("bkDlRes"); if (el) el.innerHTML = dlResHtml(B.dl); }

/* ───────────────────────────── DOWNLOAD · bulk delete ───────────────────────────── */
function delCounts(ids) {
  var live = 0, hidden = 0;
  ids.forEach(function (id) { if (B.info[id]) live++; else hidden++; });
  return { live: live, hidden: hidden };
}
function delSheetHtml(ids) {
  var c = delCounts(ids);
  var h = '<div class="up-box info"><p><b>' + A.plural(ids.length, "test") + "</b> selected · " + c.live + " live · " + c.hidden + " hidden. " +
    (ids.length > 1 ? "They are deleted " + DEL_PARALLEL + " at a time." : "") + "</p></div>";
  h += '<div class="up-drows bk-conf">' + ids.slice(0, 60).map(function (id) {
    var row = B.info[id];
    return '<div class="up-drow"><span class="w"><b class="bk-id">' + esc(id) + '</b></span><span class="v">' +
      (row ? "Live · " + esc(A.freeTxt(row.is_free)) + " · " + esc(A.verTxt(row.ver)) : "Hidden (R2 only)") + "</span></div>";
  }).join("") + (ids.length > 60 ? '<div class="up-more-note">… ' + (ids.length - 60) + " more</div>" : "") + "</div>";
  h += '<label class="up-check up-del-opt"><input type="checkbox" id="bkDelBk"' + (B.delBk ? " checked" : "") + "><span>Download a backup zip first" +
    "<small>Full JSON of " + (ids.length > 1 ? "these " + A.plural(ids.length, "test") : "this test") + ". If the backup fails for a test, nothing is deleted.</small></span></label>";
  h += '<label class="up-check up-del-opt"><input type="checkbox" id="bkDelR2"' + (B.delR2 ? " checked" : "") + "><span>Delete the test folders from R2" +
    "<small>Every file in <code>{id}/</code> + the tests row. Users cannot open these tests any more.</small></span></label>";
  h += '<label class="up-check up-del-opt' + (B.delR2 ? "" : " is-off") + '"><input type="checkbox" id="bkDelD1"' + (B.delD1 ? " checked" : "") + (B.delR2 ? "" : " disabled") + "><span>Also delete their quids from D1" +
    "<small>The bank rows (<code>questions</code> table) of every quid these tests use.</small></span></label>";
  h += '<div class="up-box ' + (B.delD1 ? "bad" : "warn") + ' up-del-warn"><h4>' + A.IC.bad + "<span>D1: only if no other test uses these questions</span></h4>" +
    "<p>Questions are shared by quid. If any other test (full mock, sectional, PART…) loads even one of these quids, that test will show missing questions after this. " +
    "Saved lists and reports of these questions stop opening too. D1 rows cannot be brought back — keep the backup zip.</p></div>";
  h += '<label class="up-check"><input type="checkbox" id="bkDelAgree"> <span>Haan — ' + A.plural(ids.length, "test") + (B.delD1 ? " + their D1 questions" : "") + " delete karo. I checked the list.</span></label>";
  return h;
}
function delSheetOk() {
  var ok = $("upSheetOk"), ag = $("bkDelAgree"), n = selIds().length;
  if (!ok) return;
  ok.disabled = !B.delR2 || !(ag && ag.checked);
  ok.textContent = !B.delR2 ? "Tick option 2 to delete" : "Delete " + A.plural(n, "test") + (B.delD1 ? " + D1" : "");
}
function confirmDelete() {
  var ids = selIds();
  if (!ids.length || B.deleting) return;
  B.delR2 = true; B.delD1 = false; B.delBk = true;
  A.openSheet("Delete " + A.plural(ids.length, "test") + "?", delSheetHtml(ids), "Delete", runDelete, true);
  delSheetOk();
}
function repaintDelSheet() {
  var body = $("upSheetBody"), top = body.scrollTop, ag = $("bkDelAgree"), was = ag && ag.checked;
  body.innerHTML = delSheetHtml(selIds());
  body.scrollTop = top;
  if (was && $("bkDelAgree")) $("bkDelAgree").checked = true;
  delSheetOk();
}
async function runDelete() {
  var ids = selIds();
  if (!ids.length || B.deleting || !B.delR2) return;
  var d1 = B.delD1, backup = B.delBk;
  A.closeSheet();
  B.deleting = true; B.del = null;
  paintZip();
  var btn = $("bkDel"), res = { ok: [], gone: [], failed: [], d1: d1, r2n: 0, d1n: 0, purgeFail: 0, backup: null, stopped: "" };
  try {
    if (backup) {
      var bk = await downloadZip(ids, "full", btn, "bk", "MMH-backup-before-delete-");
      if (!bk) { res.stopped = "Backup stopped — nothing was deleted."; return; }
      var bad = bk.failed.filter(function (f) { return !(f.status === 404); });   // 404 = no R2 files → nothing to back up
      res.backup = bk;
      if (bad.length) { res.stopped = "Backup failed for " + A.plural(bad.length, "test") + " — nothing was deleted: " + bad.slice(0, 4).map(function (f) { return f.id + " (" + f.error + ")"; }).join(" · "); return; }
    }
    var done = 0, stop = false;
    A.busyBtn(btn, true, "Deleting 0/" + ids.length);
    await pool(ids, DEL_PARALLEL, async function (id) {
      if (stop) return;
      var row = B.info[id];
      try {
        var r = await A.API.delTest(id, { d1: d1, expect_ver: row ? row.ver : 0 });
        res.ok.push(id); res.r2n += r.r2_deleted || 0; res.d1n += r.d1_deleted || 0;
        if (r.d1 && r.purged === false) res.purgeFail++;
        A.histAdd({ act: "delete", id: id, ok: true, r2n: r.r2_deleted, row: !!r.row_deleted, d1: !!r.d1, d1n: r.d1_deleted || 0, quids: r.quids, purged: r.purged, bulk: 1 });
      } catch (e) {
        if (e && e.auth) { stop = true; throw e; }
        if (e && e.status === 404 && e.data && e.data.notFound) res.gone.push(id);           // already gone
        else {
          var msg = e && e.status === 404 ? "The admin Worker has no Delete route — deploy admin Worker v7" :
                    e && e.status === 409 ? "Changed meanwhile — search again" : A.failText(e);
          res.failed.push({ id: id, error: msg, half: !!(e && e.data && (e.data.row_deleted || e.data.stage === "d1" || e.data.stage === "r2")) });
          A.histAdd({ act: "delete", id: id, ok: false, stage: e && e.data && e.data.stage, error: msg.slice(0, 160), bulk: 1 });
        }
      }
      done++;
      var s = btn && btn.querySelector("span:last-child"); if (s) s.textContent = "Deleting " + done + "/" + ids.length;
    });
  } catch (e) {
    if (!fail(e)) A.toast(A.failText(e), 4200);
  } finally {
    B.deleting = false;
    var gone = res.ok.concat(res.gone);
    if (gone.length) {
      B.groups.forEach(function (g) { g.items = g.items.filter(function (it) { return gone.indexOf(it.id) === -1; }); });
      gone.forEach(function (id) { delete B.sel[id]; delete B.info[id]; });
    }
    B.del = res;
    paintFound();
    if (!res.stopped) A.toast(res.ok.length + " deleted" + (res.failed.length ? " · " + res.failed.length + " failed" : " ✓"), 3600);
  }
}
function delResHtml(r) {
  if (!r) return "";
  if (r.stopped) return '<div class="up-box bad" style="margin-top:12px"><h4>Nothing deleted</h4><p>' + esc(r.stopped) + "</p></div>";
  var h = '<div class="up-box ' + (r.failed.length ? "warn" : "ok") + '" style="margin-top:12px"><h4>Deleted · ' + A.plural(r.ok.length, "test") + "</h4><p>R2 " + A.plural(r.r2n, "file") +
    " · " + (r.d1 ? A.plural(r.d1n, "D1 row") + " deleted" + (r.purgeFail ? " (cache purge failed for " + r.purgeFail + ")" : "") : "D1 kept") + "</p>";
  if (r.gone.length) h += "<p>Already gone: " + r.gone.slice(0, 6).map(esc).join(", ") + (r.gone.length > 6 ? " …" : "") + "</p>";
  if (r.backup && r.backup.name) h += '<p>Backup: <code class="up-mono">' + esc(r.backup.name) + "</code></p>";
  if (r.failed.length) h += "<p>Failed (still selected — press Delete again): " + r.failed.slice(0, 6).map(function (f) { return "<b>" + esc(f.id) + "</b> (" + esc(f.error) + (f.half ? ", half done" : "") + ")"; }).join(" · ") + (r.failed.length > 6 ? " …" : "") + "</p>";
  return h + "</div>";
}
function paintDelRes() { var el = $("bkDelRes"); if (el) el.innerHTML = delResHtml(B.del); }

/* ───────────────────────────── UPLOAD · load ───────────────────────────── */
function readAsBytes(f) {
  return new Promise(function (res, rej) { var fr = new FileReader(); fr.onload = function () { res(new Uint8Array(fr.result)); }; fr.onerror = function () { rej(new Error("Could not read " + f.name)); }; fr.readAsArrayBuffer(f); });
}
var DEC = new TextDecoder("utf-8");
function parseJson(name, text) {
  try { return { name: name, data: JSON.parse(String(text).replace(/^\uFEFF/, "")) }; }
  catch (e) { return { name: name, data: null, error: "Not valid JSON: " + String(e && e.message || e).slice(0, 140) }; }
}
async function readFiles(list) {
  if (!list || !list.length || B.loading || B.busy) return;
  $("bkLoadErr").hidden = true;
  B.loading = true; paintUp();
  var files = [], errs = [];
  try {
    for (var i = 0; i < list.length; i++) {
      var f = list[i];
      if (f.size > 300 * 1048576) { errs.push(f.name + ": bigger than 300 MB"); continue; }
      var bytes = await readAsBytes(f);
      if (MMHZip.isZip(bytes)) {
        var ents;
        try { ents = MMHZip.read(bytes); } catch (e) { errs.push(f.name + ": " + e.message); continue; }
        var js = ents.filter(function (e) { return /\.json$/i.test(e.name) && !/(^|\/)__MACOSX\//.test(e.name) && !/(^|\/)\._/.test(e.name); });
        if (!js.length) { errs.push(f.name + ": no .json file inside"); continue; }
        for (var k = 0; k < js.length; k++) {
          if (js[k].size > 40 * 1048576) { files.push({ name: js[k].name, data: null, error: "bigger than 40 MB" }); continue; }
          try { files.push(parseJson(js[k].name, await js[k].text())); }
          catch (e) { errs.push(js[k].name + ": " + e.message); }
        }
      } else {
        if (bytes.length > 40 * 1048576) { files.push({ name: f.name, data: null, error: "bigger than 40 MB" }); continue; }
        files.push(parseJson(f.name, DEC.decode(bytes)));
      }
    }
  } catch (e) { errs.push(String(e && e.message || e)); }
  B.loading = false;
  if (errs.length) { $("bkLoadErr").textContent = errs.slice(0, 8).join("\n"); $("bkLoadErr").hidden = false; }
  if (!files.length) { paintUp(); return; }
  // new files are added to the list (same id again = replaces the old row if it was not uploaded yet)
  var keep = B.ran ? [] : B.tests.filter(function (t) { return t.status !== "done"; });
  var grouped = groupFiles(files);
  grouped.forEach(function (g) {
    var old = keep.findIndex(function (t) { return t.id === g.id; });
    if (old !== -1) keep.splice(old, 1);
  });
  B.ran = false;
  B.tests = keep.concat(grouped.map(newTest));
  if (B.tests.length > MAX_TESTS) {
    $("bkLoadErr").textContent = "Max " + MAX_TESTS + " tests in one bulk upload — only the first " + MAX_TESTS + " are kept."; $("bkLoadErr").hidden = false;
    B.tests = B.tests.slice(0, MAX_TESTS);
  }
  $("bkFile").value = "";
  paintUp();
  analyzeAll();
}
var keyN = 0;
function newTest(g) {
  return { key: "t" + (++keyN), id: g.id, name: baseName(g.name), data: g.data, note: g.note || "", status: g.error ? "error" : "wait",
           errors: g.error ? [g.error] : [], warns: 0, P: null, live: null, plan: null, dry: null, owOn: true,
           isFree: 0, freeSet: false, open: false, res: null, fail: null };
}

/* ───────────────────────────── UPLOAD · check ───────────────────────────── */
function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }
/** bank bodies of many quids: POST /tests/bodies, 1000 per call, 3 calls at the same time */
async function fetchBank(quids, onStep) {
  var out = {}, parts = [], done = 0;
  for (var i = 0; i < quids.length; i += BODY_BATCH) parts.push(quids.slice(i, i + BODY_BATCH));
  await pool(parts, BODY_PARALLEL, async function (part) {
    var d = await A.API.testBodies(part);
    part.forEach(function (q) { out[q] = d.questions && d.questions[q] ? { body: d.questions[q], base: d.base && d.base[q] } : null; });
    done++; if (onStep) onStep(done, parts.length);
  });
  return out;
}
function setErr(t, list) { t.errors = list; t.status = "error"; }
/** this computer only (no network): bank rules + quid rule + Free/Paid. live = /tests/check item or null */
function prepTest(t, live) {
  var org = U.guessOrg(t.id) || "SSC";
  var P = U.prepare(t.data, { quizId: t.id, tag: U.tagForQuiz(t.id, org).tag || "", fields: B.fields });
  t.P = P; t.Ptag = P; t.Pno = null;
  if (P.error) { setErr(t, [P.error]); return false; }
  t.newFields = (P.newFields || []).filter(function (f) { return f.nw > 0; });   // quid questions: asked after D1 is loaded (step 3)
  if (t.newFields.some(function (f) { return !f.choice; })) {      // ask once (box on top of the list), then check again
    setErr(t, ["Naya field: " + t.newFields.filter(function (f) { return !f.choice; }).map(function (f) { return f.name; }).join(", ") + " — upar Rakho / Hatao chuno"]);
    return false;
  }
  t.warns = P.counts.warn;
  if (!P.ok) { setErr(t, P.problems.errors.slice(0, 30)); return false; }
  t.live = live && live.exists && (live.row || live.r2) ? { row: live.row, r2: live.r2, hidden: live.hidden } : null;
  if (t.live) {                                                  // existing test → every question needs its quid
    var nq = U.noQuidError(P);
    if (nq) { setErr(t, nq); return false; }
  }
  if (!t.freeSet) {
    var mf = t.data.meta.is_free;
    t.isFree = t.live && t.live.row ? Number(t.live.row.is_free) : (mf === 1 || mf === true || mf === "1") ? 1 : (mf === 0 || mf === false || mf === "0") ? 0 : B.defFree;
  }
  return true;
}
function setPhase(txt) { B.phase = txt || ""; paintFoot(); }
/**
 * Check every waiting test:
 *   1. ONE call (≤200 ids): which quiz ids already exist — tests row (paid-users DB) / R2
 *   2. this computer: bank rules + quid rule (no network)
 *   3. D1 text of the quids used in the JSONs (only when a JSON has quids) → overwrite list
 *   No dry run — the Worker checks everything once, on the real upload.
 */
async function analyzeAll() {
  if (B.busy) return;
  var list = B.tests.filter(function (t) { return (t.status === "wait" || t.status === "recheck") && t.data; });
  if (!list.length) return;
  B.busy = true;
  list.forEach(function (t) { t.status = "checking"; t.errors = []; t.dry = null; t.plan = null; t.res = null; t.fail = null; t.P = null; t.live = null; });
  paintUp();
  var authLost = false;
  try {
    // 1. which quiz ids exist?
    var ids = [];
    list.forEach(function (t) { if (ids.indexOf(t.id) === -1) ids.push(t.id); });
    setPhase("1/3 · Checking " + A.plural(ids.length, "quiz id") + " on R2 + D1…");
    var found = {};
    for (var i = 0; i < ids.length; i += CHECK_IDS) {
      var d = await A.API.check(ids.slice(i, i + CHECK_IDS));
      Object.keys(d.items || {}).forEach(function (k) { found[k] = d.items[k]; });
    }
    // 2. bank rules on this computer
    var okList = [];
    for (var k = 0; k < list.length; k++) {
      var t = list[k];
      if (k % 2 === 0) { setPhase("2/3 · Bank rules on this computer · " + (k + 1) + "/" + list.length); await tick(); }
      try { if (prepTest(t, found[t.id] || null)) okList.push(t); }
      catch (e) { setErr(t, [String(e && e.message || e)]); }
      if (t.status === "error") paintRow(t);
    }
    // 3. D1 text of the quids in the JSONs (one list for all tests, no duplicates)
    var need = {};
    okList.forEach(function (t) { neededQuids(t.P, t.live && t.live.r2).forEach(function (q) { need[q] = 1; }); });
    var nq = Object.keys(need), bank = {};
    if (nq.length) {
      setPhase("3/3 · Loading " + A.plural(nq.length, "question") + " from D1…");
      bank = await fetchBank(nq, function (a, b) { setPhase("3/3 · Loading " + A.plural(nq.length, "question") + " from D1 · " + a + "/" + b); });
    }
    okList.forEach(function (t) {
      try {
        t.newFields = fieldsToAsk(t.P, bank);
        var openF = t.newFields.filter(function (f) { return !f.choice; });
        if (openF.length) { setErr(t, ["Naya field: " + openF.map(function (f) { return f.name; }).join(", ") + " — upar Rakho / Hatao chuno"]); return; }
        t.plan = planTest(t.P, t.live && t.live.r2, bank);
        if (t.plan.errors.length) setErr(t, t.plan.errors.slice()); else t.status = "ready";
      } catch (e) { setErr(t, [String(e && e.message || e)]); }
    });
  } catch (e) {
    var msg = e && e.status === 404 ? "The admin Worker has no /tests/check route yet — deploy admin Worker v7 first." : A.failText(e);
    authLost = !!(e && e.auth);
    list.forEach(function (t) { if (t.status === "checking") setErr(t, [authLost ? "Admin password needed — press Check again" : msg]); });
    if (!fail(e)) A.toast(msg, 4200);
  } finally {
    B.busy = false; B.phase = "";
    paintUp();
  }
  if (!authLost && B.tests.some(function (t) { return t.status === "wait" || t.status === "recheck"; })) analyzeAll();
}

/* ───────────────────────────── UPLOAD · paint ───────────────────────────── */
function counts(t) {
  var P = t.P, plan = t.plan, nNew = 0, reuse = 0;
  if (P && plan) {
    var a = U.applyMatches(P, plan.keep);
    nNew = a.newBodies.length; reuse = P.counts.total - nNew;
  }
  return { total: P && P.counts ? P.counts.total : 0, nw: nNew, reuse: reuse, ow: plan ? plan.ow.length : 0 };
}
function statusIco(t) {
  if (t.status === "checking" || t.status === "uploading") return '<span class="up-spin"></span>';
  if (t.status === "done") return A.IC.ok;
  if (t.status === "error" || t.status === "failed") return A.IC.bad;
  return A.IC.file;
}
function rowHtml(t) {
  var c = counts(t), st = t.status;
  var sub = esc(t.name) + (c.total ? " · " + A.plural(c.total, "question") + (t.P ? " · " + A.plural(t.P.names.length, "section") : "") : "");
  var chips = "";
  if (st === "wait") chips += chip("", "Waiting");
  else if (st === "checking") chips += chip("", "Checking…");
  else if (st === "uploading") chips += chip("", "Uploading…");
  else if (st === "done") chips += chip("live", "Uploaded · " + A.verTxt(t.res.ver));
  else if (st === "failed") chips += chip("is-hidden", "Failed" + (t.fail && t.fail.stage ? " at " + t.fail.stage : ""));
  if (t.P && t.plan) {
    chips += liveChips(t.live && t.live.row, !!(t.live && t.live.r2));
    chips += '<span class="up-b up-b-new">+' + c.nw + " new</span>";
    if (c.reuse) chips += '<span class="up-b up-b-old">' + c.reuse + " existing quid</span>";
    if (c.ow) chips += '<span class="up-b up-b-warn">' + c.ow + (t.owOn ? " overwrite" : " differ · keep D1") + "</span>";
  }
  if (t.errors.length) chips += '<span class="up-b up-b-bad">' + A.plural(t.errors.length, "error") + "</span>";
  var canEdit = st === "ready" && !B.busy;
  var free = t.P && t.plan && st !== "done" ? '<div class="up-seg bk-free" data-bk-free="' + t.key + '"><button type="button" data-v="0" class="' + (t.isFree ? "" : "on") + '"' + (canEdit ? "" : " disabled") + '>Paid</button><button type="button" data-v="1" class="' + (t.isFree ? "on" : "") + '"' + (canEdit ? "" : " disabled") + ">Free</button></div>" : "";
  var inline = t.open && !wide(), act = wide() && B.pane === t.key;
  return '<div class="bk-row ' + st + (inline ? " open" : "") + (act ? " is-active" : "") + '" data-key="' + t.key + '">' +
    '<div class="bk-row-head"><button type="button" class="bk-row-main" data-bk-open="' + t.key + '"><span class="bk-ico">' + statusIco(t) + '</span><span class="bk-row-txt"><span class="bk-id">' + esc(t.id) + '</span><span class="bk-row-sub">' + sub + "</span></span>" + A.IC.chev + "</button>" + free + "</div>" +
    '<div class="bk-chips bk-row-chips">' + chips + "</div>" +
    (inline ? '<div class="bk-row-body">' + rowBody(t) + "</div>" : "") + "</div>";
}
function rowBody(t) {
  var h = "";
  if (t.note) h += '<div class="up-hint">' + esc(t.note) + "</div>";
  if (t.errors.length) h += '<div class="up-problems"><h4>Fix these first</h4><ul>' + t.errors.slice(0, 20).map(function (e) { return "<li>" + esc(e) + "</li>"; }).join("") + "</ul></div>";
  if (t.status === "failed" && t.fail) h += failHtml(t);
  if (t.status === "done") h += doneHtml(t);
  if (!t.P || !t.plan) return h + rowBtns(t);
  var c = counts(t);
  h += '<dl class="up-sum">' +
    "<dt>Test</dt><dd>" + (t.live ? (t.live.row ? "Live " + esc(A.verTxt(t.live.row.ver)) + " → replaced (ver + 1)" : "Hidden files on R2 → replaced, live again") : "New test") + "</dd>" +
    "<dt>Access</dt><dd>" + A.freeTxt(t.isFree) + (t.live && t.live.row && Number(t.live.row.is_free) !== t.isFree ? ' <span class="up-b up-b-warn">was ' + A.freeTxt(t.live.row.is_free) + "</span>" : "") + "</dd>" +
    "<dt>D1 new</dt><dd>" + (c.nw ? A.plural(c.nw, "question") + " · quids given at upload" : "none") + "</dd>" +
    "<dt>Existing quids</dt><dd>" + c.reuse + (t.plan.same ? " · " + t.plan.same + " identical to D1" : "") + "</dd></dl>";
  if (t.plan.ow.length) {
    h += '<div class="up-h5">Different from D1 (' + t.plan.ow.length + ")</div>" +
      '<div class="bk-owsw"><div class="up-seg" data-bk-ow="' + t.key + '"><button type="button" data-v="1" class="' + (t.owOn ? "on" : "") + '"' + (t.status === "ready" && !B.busy ? "" : " disabled") + ">Overwrite " + t.plan.ow.length + '</button><button type="button" data-v="0" class="' + (t.owOn ? "" : "on") + '"' + (t.status === "ready" && !B.busy ? "" : " disabled") + ">Keep D1</button></div>" +
      '<span class="up-hint">' + (t.owOn ? "D1 text is replaced by the JSON text (cache purged). A quid used in other tests changes there too." : "D1 keeps its text; the test still points at the same quids (no duplicate).") + "</span></div>" +
      '<div class="up-drows">' + t.plan.ow.slice(0, 40).map(function (o) {
        return '<div class="up-drow"><span class="w">' + esc(o.where) + " · id " + esc(o.lid) + " · " + (o.kind === "quid" ? "quid in JSON" : "same local id as live") + '</span><span class="v"><b>' + esc(o.quid) + "</b> · " + esc(o.fields.join(", ")) + "</span></div>";
      }).join("") + (t.plan.ow.length > 40 ? '<div class="up-more-note">… ' + (t.plan.ow.length - 40) + " more</div>" : "") + "</div>";
  }
  if (t.live && t.live.r2) {
    var p = payloadOf(t, false, false), df = U.diff(t.live.r2, { meta: U.metaOut(t.P.meta, t.P.names, t.P.kind), sections: p.sections }), k = df.counts;
    h += '<div class="up-h5">Live test → this file</div>' + (df.same ? '<div class="up-box ok"><p>Same structure as live (R2 files stay the same).</p></div>' :
      '<div class="up-dcount"><div><b>' + k.same + '</b><span>Same</span></div><div class="ch"><b>' + k.changed + '</b><span>Changed</span></div><div class="ad"><b>' + k.added + '</b><span>Added</span></div><div class="rm"><b>' + k.removed + "</b><span>Removed</span></div></div>" +
      (df.secAdded.length || df.secRemoved.length || df.metaKeys.length ? '<div class="up-hint">' + (df.secAdded.length ? "+ sections: " + esc(df.secAdded.join(", ")) + " · " : "") + (df.secRemoved.length ? "− sections: " + esc(df.secRemoved.join(", ")) + " · " : "") + (df.metaKeys.length ? "meta: " + esc(df.metaKeys.join(", ")) : "") + "</div>" : ""));
  }
  if (t.warns) {
    var wl = [];
    t.P.rows.forEach(function (r) { r.warnings.forEach(function (w) { wl.push(r.sec + " Q" + (r.pos + 1) + ": " + w); }); });
    h += '<div class="up-problems warn" style="margin-top:12px"><h4>' + A.plural(t.warns, "question") + " with warnings</h4><ul>" + wl.slice(0, 20).map(function (w) { return "<li>" + esc(w) + "</li>"; }).join("") + "</ul>" +
      (wl.length > 20 ? '<div class="up-more-note">… ' + (wl.length - 20) + " more</div>" : "") + "</div>";
  }
  return h + rowBtns(t);
}
function rowBtns(t) {
  var b = [];
  if (canRender(t)) b.push('<button type="button" class="rq-btn rq-btn-soft up-render-btn" data-bk-render="' + t.key + '">' + A.IC.render + "<span>Render Questions</span></button>");
  if ((t.status === "error" && t.data) || t.status === "failed" && !(t.fail && t.fail.retry)) b.push('<button type="button" class="rq-btn" data-bk-recheck="' + t.key + '">' + A.IC.retry + "<span>Check again</span></button>");
  if (t.status === "failed" && t.fail && t.fail.retry) b.push('<button type="button" class="rq-btn rq-btn-primary" data-bk-retry="' + t.key + '">' + A.IC.retry + "<span>Retry (no new quids)</span></button>");
  if (t.status === "done") b.push('<button type="button" class="rq-btn" data-open-test="' + esc(t.id) + '">' + A.IC.stack + "<span>Open in Tests</span></button>");
  if (t.status !== "done" && t.status !== "uploading" && !B.busy) b.push('<button type="button" class="rq-btn" data-bk-remove="' + t.key + '">' + A.IC.x + "<span>Remove</span></button>");
  return b.length ? '<div class="up-btns">' + b.join("") + "</div>" : "";
}
function failHtml(t) {
  var f = t.fail;
  return '<div class="up-box bad"><h4>' + esc(f.head) + "</h4><p>" + esc(f.msg) + "</p>" +
    (f.ow ? "<p>" + A.plural(f.ow, "question") + " were already overwritten in D1" + (f.purged === false ? " (cache purge failed — use Purge in Check Reports or wait for the cache to expire)" : "") + ". Retry does NOT overwrite again.</p>" : "") + "</div>";
}
function doneHtml(t) {
  var r = t.res;
  return '<div class="up-box ok"><h4>' + (t.live ? "Replaced" : "Uploaded") + " · " + esc(A.verTxt(r.ver)) + "</h4><p>" +
    (r.new_count ? A.plural(r.new_count, "new quid") + " <code>" + esc(r.first) + "</code> → <code>" + esc(r.last) + "</code>" : "No new quid") +
    (r.overwritten ? " · " + A.plural(r.overwritten, "question") + " overwritten" + (r.purged === false ? " (cache purge failed)" : " (cache purged)") : "") +
    (r.overwrite_skipped && r.overwrite_skipped.length ? " · " + r.overwrite_skipped.length + " skipped (changed by someone meanwhile)" : "") + "</p></div>";
}
function paintRow(t) {
  var old = document.querySelector('.bk-row[data-key="' + t.key + '"]');
  if (!old) { paintUp(); return; }
  var tmp = document.createElement("div"); tmp.innerHTML = rowHtml(t);
  old.replaceWith(tmp.firstChild);
  paintFoot();
  if (B.pane === t.key) paintPane();
}
function paneChips(t) {
  var tmp = document.createElement("div"); tmp.innerHTML = rowHtml(t);
  var c = tmp.querySelector(".bk-row-chips"), f = tmp.querySelector("[data-bk-free]");
  return (c ? c.innerHTML : "") + (f ? f.outerHTML : "");
}
/** big screen: the selected test in the side pane (same body as the phone's expanded row) */
function paintPane() {
  var pane = $("bkPane"), em = $("bkUpEmpty");
  if (!pane) return;
  var t = wide() ? find(B.pane) : null;
  em.hidden = !!t;
  em.querySelector("span").textContent = B.tests.length ? "Select a test to see its details" : "Choose files — select a test to see its details";
  pane.hidden = !t;
  if (!t) { pane.innerHTML = ""; return; }
  var c = counts(t), st = $("bkUpSide").querySelector(".bk-side-main"), top = st.scrollTop;
  pane.innerHTML = '<div class="up-side-head"><span class="bk-ico">' + statusIco(t) + '</span><div style="min-width:0"><div class="up-side-title bk-id">' + esc(t.id) + "</div>" +
      '<div class="up-side-sub">' + esc(t.name) + (c.total ? " · " + A.plural(c.total, "question") : "") + "</div></div></div>" +
    '<div class="bk-pane-chips bk-chips">' + paneChips(t) + "</div>" +
    '<div class="bk-pane-body">' + rowBody(t) + "</div>";
  st.scrollTop = top;
}
function paintUp() {
  var el = $("bkList");
  $("bkDropTitle").textContent = B.loading ? "Reading files…" : B.tests.length ? "Add more files" : "Choose JSON files or a zip";
  if (B.pane && !find(B.pane)) B.pane = null;
  if (wide() && !B.pane && B.tests.length) B.pane = B.tests[0].key;
  paintPane();
  if (!B.tests.length) { el.hidden = true; el.innerHTML = ""; paintFoot(); return; }
  el.hidden = false;
  el.innerHTML = '<div class="bk-head"><div><div class="bk-title">' + A.plural(B.tests.length, "test") + '</div><div class="bk-sub" id="bkUpSub"></div></div>' +
    '<div class="bk-head-btns"><button type="button" class="rq-btn bk-mini" data-bk="clearup"' + (B.busy ? " disabled" : "") + ">Clear all</button></div></div>" +
    fieldsAskHtml() +
    '<div class="bk-rows">' + B.tests.map(rowHtml).join("") + "</div><div id=\"bkFoot\"></div>";
  paintFoot();
}
/* NEW fields of all tests in the list (not uploaded yet) → one Rakho / Hatao box for the whole batch */
function fieldsAskHtml() {
  var by = {};
  B.tests.forEach(function (t) {
    if (t.status === "done" || !t.newFields) return;
    t.newFields.forEach(function (f) {
      var e = by[f.name] || (by[f.name] = { name: f.name, nw: 0, old: 0, sample: f.sample, choice: B.fields[f.name] || null });
      e.nw += f.nw; e.old += f.old;
    });
  });
  var list = Object.keys(by).map(function (k) { return by[k]; });
  return list.length ? '<div class="bk-fields">' + A.fieldsBoxHtml(list, "data-bkfield", "Ek baar chuno — poore batch pe lagega, phir tests apne aap dobara check honge.") + "</div>" : "";
}
function paintFoot() {
  var side = $("bkSideFoot"), el = wide() ? side : $("bkFoot");
  if ($("bkFoot") && el !== $("bkFoot")) $("bkFoot").innerHTML = "";
  if (side && el !== side) { side.innerHTML = ""; side.hidden = true; }
  if (!el) return;
  var by = {};
  B.tests.forEach(function (t) { by[t.status] = (by[t.status] || 0) + 1; });
  var ready = B.tests.filter(function (t) { return t.status === "ready"; });
  var owN = ready.reduce(function (s, t) { return s + (t.owOn ? t.plan.ow.length : 0); }, 0);
  var sub = [];
  if (by.ready) sub.push(by.ready + " ready");
  if (by.wait || by.checking) sub.push(((by.wait || 0) + (by.checking || 0)) + " checking");
  if (by.error) sub.push('<span class="bad">' + by.error + " with errors</span>");
  if (by.done) sub.push(by.done + " uploaded");
  if (by.failed) sub.push('<span class="bad">' + by.failed + " failed</span>");
  if (B.phase) sub.unshift('<span class="bk-phase">' + esc(B.phase) + "</span>");
  if ($("bkUpSub")) $("bkUpSub").innerHTML = sub.join(" · ");
  var h = "";
  if (by.ready) {
    h += '<div class="bk-total">' + A.plural(ready.length, "test") + " · " + ready.reduce(function (s, t) { return s + counts(t).nw; }, 0) + " new questions" +
      (owN ? ' · <b class="bk-warn">' + owN + " overwrite</b>" : "") + "</div>" +
      '<div class="up-btns"><button type="button" class="rq-btn rq-btn-primary" id="bkGo"' + (B.busy ? " disabled" : "") + ">" + A.IC.up + "<span>" + (B.busy ? "Please wait…" : "Upload " + A.plural(ready.length, "test")) + "</span></button></div>";
  }
  var done = B.tests.filter(function (t) { return t.status === "done"; });
  if (done.length && !B.busy) {
    h += '<div class="bk-after"><div class="up-h5">Download what was uploaded (with quids)</div>' + fmtSeg("bkUpFmt", B.upFmt) +
      '<div class="up-btns"><button type="button" class="rq-btn" id="bkUpDl">' + A.IC.down + "<span>Download zip (" + done.length + ")</span></button>" +
      '<button type="button" class="rq-btn rq-btn-soft up-render-btn" id="bkRender">' + A.IC.render + "<span>Render Questions (" + done.length + ")</span></button></div><div id=\"bkUpDlRes\"></div></div>";
  }
  el.innerHTML = h;
  if (el === side) side.hidden = !h;
}

/* ───────────────────────────── UPLOAD · confirm + run ───────────────────────────── */
function tagN(t) { return t.Ptag && t.Ptag.counts ? t.Ptag.counts.tagAdded : 0; }
/** chosen variant: "Nahi" → same file prepared without the auto exam tag */
function useTag(t) {
  if (!t.Ptag) return;
  if (B.tagOk === false && tagN(t)) {
    if (!t.Pno) t.Pno = U.prepare(t.data, { quizId: t.id, tag: "", fields: B.fields });
    t.P = t.Pno.ok ? t.Pno : t.Ptag;
  } else t.P = t.Ptag;
}
function bkSync() {
  var a = $("bkAgree"), ok = $("upSheetOk");
  if (!ok) return;
  ok.disabled = (a ? !a.checked : false) || (!!$("bkTagAsk") && B.tagOk === null);
}
function tagAskHtml(ready) {
  var tt = ready.filter(function (t) { return tagN(t) > 0; });
  if (!tt.length) return "";
  var n = tt.reduce(function (s, t) { return s + tagN(t); }, 0);
  return '<div id="bkTagAsk"><div class="up-box ' + (B.tagOk === null ? "warn" : "info") + '"><h4>Exam tag generate karna hai?</h4><p>' + A.plural(tt.length, "test") + " me <b>" + n +
    "</b> naye questions me exam tag nahi hai. Haan → har question ko uski quiz id se bana tag milega (jaise <code>[" + esc(U.tagForQuiz(tt[0].id, U.guessOrg(tt[0].id) || "SSC").tag || "") +
    "]</code>). Jin questions me pehle se tag hai wo waise hi rahenge.</p></div>" +
    '<div class="up-seg up-tagok" data-bktag><button type="button" data-v="1" class="' + (B.tagOk === true ? "on" : "") + '">Haan, tag lagao</button>' +
    '<button type="button" data-v="0" class="' + (B.tagOk === false ? "on" : "") + '">Nahi, bina tag</button></div></div>';
}
function confirmUpload() {
  var ready = B.tests.filter(function (t) { return t.status === "ready"; });
  if (!ready.length || B.busy) return;
  B.tagOk = null;
  var rep = ready.filter(function (t) { return t.live; }), owT = ready.filter(function (t) { return t.owOn && t.plan.ow.length; });
  var owN = owT.reduce(function (s, t) { return s + t.plan.ow.length; }, 0);
  var skip = B.tests.filter(function (t) { return t.status === "error"; }).length;
  var h = tagAskHtml(ready) + '<div class="up-box info"><p>' + A.plural(ready.length, "test") + " will be uploaded, " + UP_PARALLEL + " at a time." + (skip ? " " + A.plural(skip, "test") + " with errors are skipped." : "") + "</p></div>";
  h += '<div class="up-drows bk-conf">' + ready.map(function (t) {
    var c = counts(t);
    return '<div class="up-drow"><span class="w"><b class="bk-id">' + esc(t.id) + "</b> · " + (t.live ? (t.live.row ? "replace live " + esc(A.verTxt(t.live.row.ver)) : "over hidden files") : "new") + " · " + A.freeTxt(t.isFree) + '</span><span class="v">+' + c.nw + " new · " + c.reuse + " existing" +
      (t.plan.ow.length ? (t.owOn ? ' · <b class="bk-warn">' + t.plan.ow.length + " overwrite</b>" : " · " + t.plan.ow.length + " differ (keep D1)") : "") + "</span></div>";
  }).join("") + "</div>";
  var need = rep.length || owN;
  if (owN) h += '<div class="up-box warn" style="margin-top:12px"><h4>' + A.plural(owN, "question") + " will be overwritten in D1</h4><p>In " + A.plural(owT.length, "test") + ". The D1 text is replaced by the JSON text and the cache of those quids is purged. A quid that is also used in other tests changes there too. Reports are not changed.</p></div>";
  if (rep.length) h += '<div class="up-box warn"><h4>' + A.plural(rep.length, "existing test") + " will be replaced</h4><p>Their R2 files are replaced; users get the new version.</p></div>";
  if (need) h += '<label class="up-check"><input type="checkbox" id="bkAgree"> <span>Haan — ' + [rep.length ? A.plural(rep.length, "test") + " replace" : "", owN ? A.plural(owN, "question") + " overwrite" : ""].filter(Boolean).join(" + ") + " karo. I checked the list.</span></label>";
  A.openSheet("Upload " + A.plural(ready.length, "test") + "?", h, "Upload " + ready.length, runUpload, false);
  bkSync();
}
async function runUpload() {
  var ready = B.tests.filter(function (t) { return t.status === "ready"; });
  A.closeSheet();
  B.busy = true; B.ran = true;
  paintUp();
  var okN = 0, badN = 0, stop = false;
  try {
    await pool(ready, UP_PARALLEL, async function (t) {
      if (stop) return;
      t.status = "uploading"; paintRow(t);
      useTag(t);
      var p = payloadOf(t, t.owOn, false);
      try {
        var res = await A.API.upload(p);
        t.res = res; t.status = "done"; okN++;
        A.histAdd({ act: t.live ? "replace" : "upload", id: t.id, ok: true, ver: res.ver, first: res.first || null, last: res.last || null,
                    nw: p.new.length, old: t.P.counts.total - p.new.length, free: p.is_free, kind: res.row && res.row.kind, ow: res.overwritten || 0, bulk: 1 });
      } catch (e) {
        if (e && e.auth) { stop = true; t.status = "ready"; paintRow(t); throw e; }
        badN++;
        var d = (e && e.data) || {}, st = d.stage || "";
        var retry = (st === "r2" || st === "tests") && d.structure ? { structure: d.structure, first: d.first, last: d.last } : null;
        var head = st === "d1" ? "Nothing was saved" : retry ? (st === "r2" ? "Saved in D1 — R2 upload failed" : "D1 + R2 done — tests row failed") :
                   e && e.status === 409 ? "Changed meanwhile — check again" : "Upload failed";
        t.fail = { stage: st, head: head, msg: A.failText(e), retry: retry, ow: d.overwritten || 0, purged: d.purged };
        t.status = "failed";
        A.histAdd({ act: "upload", id: t.id, ok: false, stage: st, error: A.failText(e).slice(0, 160) });
      }
      paintRow(t);
    });
  } catch (e) { if (!fail(e)) A.toast(A.failText(e), 4200); }
  finally {
    B.tests.forEach(function (t) { if (t.status === "uploading") t.status = "ready"; });
    B.busy = false; paintUp();
    A.toast(okN + " uploaded" + (badN ? " · " + badN + " failed" : " ✓"), 3600);
  }
}
async function retryTest(t, btn) {
  var f = t.fail;
  A.busyBtn(btn, true, "Retrying…");
  try {
    var p = { id: t.id, is_free: t.isFree, meta: t.P.meta, sections: f.retry.structure.sections, new: [] };
    var c = await A.API.check([t.id]), it = c.items && c.items[t.id];
    if (it && it.exists) { p.replace = true; p.expect_ver = it.row ? it.row.ver : 0; }
    var res = await A.API.upload(p);
    res.new_count = 0; res.overwritten = f.ow || 0; res.purged = f.purged;
    if (f.retry.first) { res.first = f.retry.first; res.last = f.retry.last; }
    t.res = res; t.status = "done"; t.fail = null;
    A.histAdd({ act: "retry", id: t.id, ok: true, ver: res.ver, first: f.retry.first || null, last: f.retry.last || null, nw: 0, old: 0, free: p.is_free, kind: res.row && res.row.kind });
    A.toast("Done ✓  " + A.verTxt(res.ver));
  } catch (e) {
    if (fail(e)) return;
    A.toast(A.failText(e), 4200);
  } finally { A.busyBtn(btn, false); paintRow(t); }
}

/** Render one test of the list: before upload = the FILE (full questions from the file, [localId, quid] from D1);
    uploaded = what is live now. Big screen → inside the side pane · phone → full screen. */
function renderTest(t) {
  if (!t || !RD()) return;
  if (t.status === "done") { RD().show([t.id], { host: $("bkUpSide") }); return; }
  if (!canRender(t)) { A.toast("This file cannot be rendered"); return; }
  var badge = t.live ? chip("", t.live.row ? "Re-upload · live test" : "Hidden test on R2") : t.plan ? chip("bk-new", "New test") : "";
  RD().forget(t.key);                                  // always the current file
  RD().show([{ kind: "file", key: t.key, id: t.id, name: t.name, data: t.data, badge: badge }], { host: $("bkUpSide") });
}

/* ───────────────────────────── EVENTS ───────────────────────────── */
function find(key) { return B.tests.find(function (t) { return t.key === key; }); }
function bind() {
  $("bkMode").addEventListener("click", function (ev) { var b = ev.target.closest("[data-mode]"); if (b) setMode(b.getAttribute("data-mode")); });
  $("bkSearch").addEventListener("click", search);
  $("bkQuery").addEventListener("keydown", function (ev) { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); search(); } });
  $("bkFound").addEventListener("change", function (ev) {
    var c = ev.target.closest("[data-bk-id]");
    if (c) { B.sel[c.getAttribute("data-bk-id")] = c.checked; syncSel(); var gi = c.closest(".bk-group"); if (gi) paintGroupBtn(gi); }
  });
  $("bkFound").addEventListener("click", function (ev) {
    var a = ev.target.closest("[data-bk]");
    if (a) {
      var v = a.getAttribute("data-bk");
      if (v === "all" || v === "none") { allIds().forEach(function (id) { B.sel[id] = v === "all"; }); paintFound(); }
      return;
    }
    var g = ev.target.closest("[data-bk-g]");
    if (g) {
      var grp = B.groups[+g.getAttribute("data-bk-g")], all = grp.items.every(function (it) { return B.sel[it.id]; });
      grp.items.forEach(function (it) { B.sel[it.id] = !all; });
      paintFound(); return;
    }
  });
  $("bkZip").addEventListener("click", function (ev) {
    var f = ev.target.closest("#bkFmt [data-fmt]");
    if (f) { B.fmt = f.getAttribute("data-fmt"); paintZip(); return; }
    if (ev.target.closest("#bkDl")) { if (!B.deleting) downloadZip(selIds(), B.fmt, $("bkDl"), "dl"); return; }
    if (ev.target.closest("#bkDel")) { confirmDelete(); return; }
    if (ev.target.closest("#bkRd")) { var ids = selIds(); if (ids.length && RD()) RD().show(ids, { host: $("bkDownSide") }); }
  });

  var inp = $("bkFile");
  var openAll = function () { if (A.isNative()) inp.removeAttribute("accept"); };
  openAll(); inp.addEventListener("click", openAll);
  inp.addEventListener("change", function (ev) { readFiles(Array.prototype.slice.call(ev.target.files || [])); });
  var drop = $("bkDrop");
  ["dragenter", "dragover"].forEach(function (k) { drop.addEventListener(k, function (ev) { ev.preventDefault(); drop.classList.add("over"); }); });
  ["dragleave", "drop"].forEach(function (k) { drop.addEventListener(k, function (ev) { ev.preventDefault(); drop.classList.remove("over"); }); });
  drop.addEventListener("drop", function (ev) { readFiles(Array.prototype.slice.call((ev.dataTransfer && ev.dataTransfer.files) || [])); });
  $("bkDefFree").addEventListener("click", function (ev) {
    var b = ev.target.closest("[data-v]"); if (!b) return;
    B.defFree = Number(b.getAttribute("data-v"));
    $("bkDefFree").querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    B.tests.forEach(function (t) { if (t.status === "ready" && !t.freeSet && !(t.live && t.live.row) && !(t.data.meta.is_free === 0 || t.data.meta.is_free === 1 || t.data.meta.is_free === true || t.data.meta.is_free === false)) t.isFree = B.defFree; });
    paintUp();
  });
  var onUp = function (ev) {
    var x;
    if ((x = ev.target.closest("[data-bk-render]"))) { renderTest(find(x.getAttribute("data-bk-render"))); return; }
    if ((x = ev.target.closest("#bkRender"))) {
      var dn = B.tests.filter(function (t) { return t.status === "done"; }).map(function (t) { return t.id; });
      if (dn.length && RD()) RD().show(dn, { host: $("bkUpSide") });
      return;
    }
    if ((x = ev.target.closest("[data-bk='clearup']"))) { if (!B.busy) { if (RD()) RD().closeIn($("bkUpSide")); B.tests = []; B.ran = false; B.fields = {}; paintUp(); } return; }
    if ((x = ev.target.closest("[data-bkfield] [data-v]"))) {
      if (B.busy) return;
      var fname = x.parentNode.getAttribute("data-bkfield"), had = !!B.fields[fname];
      B.fields[fname] = x.getAttribute("data-v");
      var open = false;
      B.tests.forEach(function (t) { (t.newFields || []).forEach(function (f) { if (!B.fields[f.name] && t.status !== "done") open = true; }); });
      if (open && !had) { paintUp(); return; }                       // baaki field bhi chuno, phir ek saath check
      B.tests.forEach(function (t) {
        if (t.status === "done" || t.status === "uploading" || !t.data) return;
        if ((t.newFields || []).length) { t.status = "recheck"; t.fail = null; }
      });
      analyzeAll(); return;
    }
    if ((x = ev.target.closest("[data-bk-free] [data-v]"))) {
      if (x.disabled) return;
      var t1 = find(x.parentNode.getAttribute("data-bk-free")); t1.isFree = Number(x.getAttribute("data-v")); t1.freeSet = true; paintRow(t1); return;
    }
    if ((x = ev.target.closest("[data-bk-ow] [data-v]"))) {
      if (x.disabled) return;
      var t2 = find(x.parentNode.getAttribute("data-bk-ow")); t2.owOn = x.getAttribute("data-v") === "1"; paintRow(t2); return;
    }
    if ((x = ev.target.closest("[data-bk-open]"))) {
      var t3 = find(x.getAttribute("data-bk-open"));
      if (wide()) {
        if (RD()) RD().closeIn($("bkUpSide"));            // render open → back to the details of the clicked test
        B.pane = t3.key;
        document.querySelectorAll("#bkList .bk-row").forEach(function (r) { r.classList.toggle("is-active", r.getAttribute("data-key") === t3.key); });
        paintPane();
      } else { t3.open = !t3.open; paintRow(t3); }
      return;
    }
    if ((x = ev.target.closest("[data-bk-remove]"))) { var k = x.getAttribute("data-bk-remove"); B.tests = B.tests.filter(function (t) { return t.key !== k; }); if (B.pane === k) { B.pane = null; if (RD()) RD().closeIn($("bkUpSide")); } paintUp(); return; }
    if ((x = ev.target.closest("[data-bk-recheck]"))) { var t4 = find(x.getAttribute("data-bk-recheck")); t4.status = "recheck"; t4.fail = null; analyzeAll(); return; }
    if ((x = ev.target.closest("[data-bk-retry]"))) { retryTest(find(x.getAttribute("data-bk-retry")), x); return; }
    if ((x = ev.target.closest("#bkUpFmt [data-fmt]"))) { B.upFmt = x.getAttribute("data-fmt"); paintFoot(); return; }
    if (ev.target.closest("#bkGo")) { confirmUpload(); return; }
    if (ev.target.closest("#bkUpDl")) {
      var ids = B.tests.filter(function (t) { return t.status === "done"; }).map(function (t) { return t.id; });
      downloadZip(ids, B.upFmt, $("bkUpDl"), "up").then(function (r) { var el = $("bkUpDlRes"); if (el && r) el.innerHTML = dlResHtml(r); });
    }
  };
  $("bkList").addEventListener("click", onUp);
  $("bkUpSide").addEventListener("click", onUp);
  $("upSheet").addEventListener("click", function (ev) {
    var b = ev.target.closest("[data-bktag] [data-v]");
    if (!b) return;
    B.tagOk = b.getAttribute("data-v") === "1";
    b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    var box = $("bkTagAsk") && $("bkTagAsk").querySelector(".up-box");
    if (box) { box.classList.remove("warn"); box.classList.add("info"); }
    bkSync();
  });
  $("upSheet").addEventListener("change", function (ev) {
    var id = ev.target.id;
    if (id === "bkAgree") bkSync();
    else if (id === "bkDelAgree") delSheetOk();
    else if (id === "bkDelBk") { B.delBk = ev.target.checked; }
    else if (id === "bkDelR2") { B.delR2 = ev.target.checked; if (!B.delR2) B.delD1 = false; repaintDelSheet(); }
    else if (id === "bkDelD1") { B.delD1 = ev.target.checked; repaintDelSheet(); }
  });
}
function paintGroupBtn(gEl) {
  var b = gEl.querySelector("[data-bk-g]"); if (!b) return;
  var grp = B.groups[+b.getAttribute("data-bk-g")];
  b.textContent = (grp.items.every(function (it) { return B.sel[it.id]; }) ? "Unselect" : "Select") + " these";
}

function boot() {
  A = root.MMHUpAdmin;
  if (!A || !$("upTabBulk") || !root.MMHZip) { console.error("admin-bulk: admin-upload.js / mmh-zip.js / #upTabBulk missing"); return; }
  bind();
  paintMode();
}
function relayout() { paintUp(); }
root.MMHBulk = { show: show, relayout: relayout, _state: B };
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
else boot();
})(typeof globalThis !== "undefined" ? globalThis : this);

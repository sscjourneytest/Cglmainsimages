/* ── MMH app glue: push notifications + save/share (native app only) ──────
   Browser: completely inert (first line returns). Inside the Android app:
   · from the 2nd app open: home-page bottom sheet asking for notifications
     (7/14-day snooze, max 3) · Notifications page status card (Turn on /
     Open settings) · in-front notifications show a top banner
   · granted → FCM register → token subscribed to topic mmh_all via
     /api/subscribe-topic (same design as the old RSM app)
   · notification tap → opens the notification's path
   · window.mmhSaveOrShare(name, blobOrDataUrl, mime):
       images → gallery directly · other files → Download/MockMatrixHub if
       storage permission granted · otherwise system share sheet (which
       itself offers Save to Files / Drive)
   ──────────────────────────────────────────────────────────────────────── */
/* ── Legacy exam links → query pages (app has no /exams/<exam>/ folders any more) ──
   /exams/cgl/  or  /exams/cgl/index.html?filter=…  →  /exams/mocks.html?cgl&b=ssc&filter=…
   Used for: old links still in live JSONs (e.g. home-config on the website), notification
   paths, and any <a> pointing at an old folder. Runs in the browser too (harmless). */
(function () {
    var SSC = { cgl: 1, chsl: 1, mts: 1, cpo: 1, steno: 1, 'selection-post': 1, gd: 1 };
    var RAIL = { ntpcg: 1, 'ntpc-ug': 1, 'group-d': 1, alp: 1 };
    var CHAP = { 'ssc-sub': 1, 'ssc-sub-top': 1 };
    function map(url) {
        try {
            var u = new URL(String(url), location.href);
            var hostOk = u.origin === location.origin || /(^|\.)mockmatrixhub\.in$/i.test(u.hostname);
            var m = /^\/exams\/([a-z0-9-]+)\/(?:index\.html)?$/i.exec(u.pathname);
            if (!hostOk || !m) return null;
            var ex = m[1].toLowerCase(), page, b;
            if (ex === 'exam-ssc-sub') { page = 'chapter-wise-exam.html'; b = 'ssc'; }
            else if (CHAP[ex]) { page = 'chapters-wise.html'; b = 'ssc'; }
            else if (SSC[ex]) { page = 'mocks.html'; b = 'ssc'; }
            else if (RAIL[ex]) { page = 'mocks.html'; b = 'railway'; }
            else return '/exams/index.html';                    // folder gone, unknown exam → exams index
            var f = u.searchParams.get('filter');
            return '/exams/' + page + '?' + ex + '&b=' + b + (f ? '&filter=' + encodeURIComponent(f) : '') + (u.hash || '');
        } catch (e) { return null; }
    }
    window.mmhMapExamUrl = function (url) { return map(url) || url; };
    document.addEventListener('click', function (e) {
        if (e.defaultPrevented || e.button > 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
        var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
        if (!a) return;
        var to = map(a.getAttribute('href'));
        if (!to) return;
        e.preventDefault();
        location.href = to;
    }, true);
})();

(function () {
    function isNative() {
        try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { return false; }
    }
    function P(name) {
        try { return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[name]) || null; } catch (e) { return null; }
    }
    if (!isNative()) return;

    /* toast */
    function toast(msg) {
        var t = document.getElementById('mmhPluginToast');
        if (!t) {
            t = document.createElement('div'); t.id = 'mmhPluginToast';
            t.style.cssText = 'position:fixed;left:50%;bottom:96px;transform:translateX(-50%);background:rgba(17,24,39,.92);color:#fff;padding:10px 16px;border-radius:12px;font:600 13px/1.3 system-ui,sans-serif;z-index:4000;box-shadow:0 8px 24px rgba(0,0,0,.35);max-width:86vw;text-align:center;display:none';
            document.body.appendChild(t);
        }
        t.textContent = msg; t.style.display = 'block';
        clearTimeout(t._h); t._h = setTimeout(function () { t.style.display = 'none'; }, 2600);
    }
    window.mmhToast = toast;

    /* ── push (t244) ───────────────────────────────────────────────────────
       · NO prompt on the first app open. From the 2nd open: a bottom-sheet popup
         on the HOME page only (never on test pages), only on a clear screen.
       · "Not now" → asked again after 7 days, then after 14 days (max 3 popups).
         Swiping the Android dialog away = undecided (asked again after 3 days).
       · Android dialog "Don't allow" twice → state "denied" → no more popups;
         the Notifications page shows "Open settings" (app notification settings).
       · Notifications page: status card — off → Turn on · blocked → Open settings ·
         on → small "Notifications are on" line. Re-checked when the app comes back.
       · App open in front: a clean top banner instead of the old debug toast.
       ──────────────────────────────────────────────────────────────────── */
    var Push = P('PushNotifications');
    var ASKED = 'mmh_notif_asked', SUB = 'mmh_notif_subscribed', ASK = 'mmh_notif_ask', OPENS = 'mmh_app_opens';
    var DAY = 86400000, SNOOZE = [7, 14], MAX_ASK = 3;
    var COPY = {
        title: 'Never miss a new mock',
        text: 'Allow notifications to get new mock updates and new app updates.',
        rows: [
            ['mock', 'New mock updates', 'New mocks, live tests & PYQs as soon as they are added'],
            ['app', 'New app updates', 'Know when a new version of the app is ready'],
            ['shield', 'No promotional messages', 'No ads, no spam — only useful updates']
        ]
    };
    var ICO = {
        bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8.5a6 6 0 0 1 12 0c0 6.5 2.5 8 2.5 8h-17S6 15 6 8.5z"/><path d="M10 20a2.2 2.2 0 0 0 4 0"/></svg>',
        bellOff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.6 4A6 6 0 0 1 18 8.5c0 3.2.6 5.2 1.3 6.4M17 16.5H3.5S6 15 6 8.5c0-.6.1-1.2.3-1.8"/><path d="M10 20a2.2 2.2 0 0 0 4 0M3 3l18 18"/></svg>',
        mock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3.5" width="14" height="17" rx="2.4"/><path d="M8.5 8.5h7M8.5 12h7M8.5 15.5h4"/></svg>',
        app: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6.5" y="2.5" width="11" height="19" rx="2.6"/><path d="M12 14.5V8.5M9.5 11 12 8.5l2.5 2.5"/><path d="M10.5 18.5h3"/></svg>',
        shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 19 5.8v5.4c0 4.6-3 8.1-7 9.8-4-1.7-7-5.2-7-9.8V5.8L12 3z"/><path d="m9 12 2.2 2.2L15.5 10"/></svg>',
        check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.2 4.2L19 7"/></svg>',
        gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
        x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
    };
    function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
    function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

    /* app opens: one per app start (sessionStorage dies with the WebView) */
    (function countOpen() {
        try {
            if (sessionStorage.getItem('mmh_open_counted')) return;
            sessionStorage.setItem('mmh_open_counted', '1');
            lsSet(OPENS, String((parseInt(lsGet(OPENS), 10) || 0) + 1));
        } catch (e) {}
    })();
    function opens() { return parseInt(lsGet(OPENS), 10) || 0; }
    function askState() {
        var s = null;
        try { s = JSON.parse(lsGet(ASK) || 'null'); } catch (e) {}
        if (!s || typeof s !== 'object') {
            s = { n: 0, next: 0 };
            if (lsGet(ASKED)) s.n = 1;                     // old card already said "Not now" once → one more chance now
        }
        return s;
    }
    function saveAsk(s) { lsSet(ASK, JSON.stringify(s)); lsSet(ASKED, '1'); }

    /* ── styles (injected once; home + Notifications page + any page with a banner) ── */
    function css() {
        if (document.getElementById('mmhNotifCss')) return;
        var st = document.createElement('style');
        st.id = 'mmhNotifCss';
        st.textContent = [
            '.mnp-ov{position:fixed;inset:0;z-index:3400;display:flex;align-items:flex-end;justify-content:center;background:rgba(2,6,23,.58);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);opacity:0;transition:opacity .22s ease;overscroll-behavior:contain}',
            '.mnp-ov.open{opacity:1}',
            '.mnp-box{position:relative;width:100%;max-width:min(460px,100vw);box-sizing:border-box;background:var(--surface,#fff);color:var(--text,#0b1220);border:1px solid var(--border,#e5eaf3);border-bottom:0;border-radius:24px 24px 0 0;box-shadow:0 -18px 50px rgba(2,6,23,.28);padding:0 0 env(safe-area-inset-bottom,0);transform:translateY(103%);transition:transform .36s cubic-bezier(.22,1,.36,1);font-family:inherit;overflow:hidden}',
            '.mnp-ov.open .mnp-box{transform:none}',
            '.mnp-grab{width:40px;height:4px;border-radius:99px;margin:10px auto 0;background:var(--border-strong,#d6deeb)}',
            '.mnp-x{position:absolute;top:12px;right:12px;width:34px;height:34px;border-radius:50%;border:0;background:var(--surface-2,#f1f5f9);color:var(--text-3,#7c8aa5);display:grid;place-items:center;cursor:pointer}',
            '.mnp-x svg{width:16px;height:16px}',
            '.mnp-hero{position:relative;display:grid;place-items:center;padding:20px 0 6px}',
            '.mnp-hero::before{content:"";position:absolute;top:6px;left:50%;width:220px;height:120px;transform:translateX(-50%);background:radial-gradient(closest-side,rgba(84,112,255,.20),transparent);pointer-events:none}',
            '.mnp-bell{position:relative;width:76px;height:76px;border-radius:24px;display:grid;place-items:center;color:#fff;background:linear-gradient(145deg,#6a82ff 0%,#3550f0 55%,#6d3df5 100%);box-shadow:0 14px 30px rgba(61,90,254,.38),inset 0 1px 0 rgba(255,255,255,.28)}',
            '.mnp-bell svg{width:38px;height:38px;transform-origin:50% 8%;animation:mnpRing 2.6s ease-in-out .5s infinite}',
            '.mnp-bell i{position:absolute;top:-5px;right:-5px;min-width:22px;height:22px;padding:0 5px;box-sizing:border-box;border-radius:99px;background:#ef4444;border:3px solid var(--surface,#fff);color:#fff;font:800 11px/16px system-ui,sans-serif;font-style:normal;text-align:center}',
            '@keyframes mnpRing{0%,60%,100%{transform:rotate(0)}8%{transform:rotate(14deg)}16%{transform:rotate(-12deg)}24%{transform:rotate(9deg)}32%{transform:rotate(-6deg)}40%{transform:rotate(3deg)}}',
            '.mnp-body{padding:12px 20px 4px;text-align:center}',
            '.mnp-body h3{margin:0;font-size:19px;font-weight:800;letter-spacing:-.3px;line-height:1.25;color:var(--text,#0b1220)}',
            '.mnp-body p{margin:7px auto 0;max-width:340px;font-size:13.5px;line-height:1.5;color:var(--text-2,#41506b)}',
            '.mnp-rows{list-style:none;margin:16px 0 0;padding:0;border:1px solid var(--border,#e5eaf3);border-radius:18px;overflow:hidden;text-align:left;background:var(--surface,#fff)}',
            '.mnp-rows li{display:flex;gap:12px;align-items:center;padding:11px 13px}',
            '.mnp-rows li+li{border-top:1px solid var(--border,#e5eaf3)}',
            '.mnp-ri{flex:0 0 auto;width:36px;height:36px;border-radius:11px;display:grid;place-items:center}',
            '.mnp-ri svg{width:19px;height:19px}',
            '.mnp-ri.mock{background:rgba(61,90,254,.11);color:#3d5afe}',
            '.mnp-ri.app{background:rgba(124,77,255,.12);color:#7c4dff}',
            '.mnp-ri.shield{background:rgba(16,185,129,.13);color:#059669}',
            '.mnp-rt{min-width:0;font-size:12.3px;line-height:1.4;color:var(--text-3,#7c8aa5)}',
            '.mnp-rt b{display:block;font-size:13.5px;font-weight:700;color:var(--text,#0b1220);margin-bottom:1px}',
            '.mnp-note{margin:12px 0 0;font-size:11.5px;color:var(--text-3,#7c8aa5)}',
            '.mnp-acts{display:flex;gap:10px;padding:14px 20px 18px}',
            '.mnp-btn{flex:1 1 0;height:50px;border-radius:14px;border:0;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:inherit;font-size:15px;font-weight:800;line-height:1;white-space:nowrap;-webkit-tap-highlight-color:transparent;transition:transform .12s}',
            '.mnp-btn:active{transform:scale(.97)}',
            '.mnp-btn svg{width:18px;height:18px}',
            '.mnp-btn.ghost{background:var(--surface-2,#f1f5f9);color:var(--text-2,#41506b);border:1px solid var(--border,#e5eaf3)}',
            '.mnp-btn.primary{flex-grow:1.9;color:#fff;background:linear-gradient(180deg,#5470ff 0%,#3550f0 100%);box-shadow:0 8px 20px rgba(61,90,254,.34),inset 0 1px 0 rgba(255,255,255,.22)}',
            'body.dark-mode .mnp-ri.mock{color:#8ea0ff}body.dark-mode .mnp-ri.app{color:#b39dff}body.dark-mode .mnp-ri.shield{color:#34d399}',
            'body.dark-mode .mnp-ov{background:rgba(0,0,0,.66)}',
            '@media (min-width:768px){.mnp-ov{align-items:center}.mnp-box{border-radius:24px;border-bottom:1px solid var(--border,#e5eaf3);transform:translateY(24px) scale(.97);opacity:0;transition:transform .3s cubic-bezier(.22,1,.36,1),opacity .2s}.mnp-ov.open .mnp-box{opacity:1}.mnp-grab{display:none}}',
            /* Notifications page status card */
            '.mns{display:flex;gap:12px;align-items:flex-start;margin:0 0 14px;padding:14px;border-radius:18px;background:var(--surface,#fff);border:1px solid var(--border,#e5eaf3);box-shadow:0 1px 2px rgba(15,23,42,.04),0 10px 26px -14px rgba(15,23,42,.14)}',
            '.mns-ico{flex:0 0 auto;width:42px;height:42px;border-radius:13px;display:grid;place-items:center}',
            '.mns-ico svg{width:22px;height:22px}',
            '.mns.off .mns-ico{background:rgba(245,158,11,.14);color:#b45309}',
            '.mns.blocked .mns-ico{background:rgba(225,29,72,.10);color:#dc2643}',
            '.mns-txt{flex:1 1 auto;min-width:0}',
            '.mns-txt>b{display:block;font-size:14.5px;font-weight:800;color:var(--text,#0b1220)}',
            '.mns-txt>span{display:block;margin-top:3px;font-size:12.5px;line-height:1.45;color:var(--text-2,#41506b)}',
            '.mns-steps{margin:7px 0 0;padding-left:18px;font-size:12px;line-height:1.6;color:var(--text-3,#7c8aa5)}',
            '.mns-steps b{font-weight:700;color:var(--text-2,#41506b)}',
            '.mns-btn{margin-top:11px;height:40px;padding:0 16px;border-radius:12px;border:0;cursor:pointer;display:inline-flex;align-items:center;gap:7px;font-family:inherit;font-size:13.5px;font-weight:800;line-height:1;color:#fff;background:linear-gradient(180deg,#5470ff 0%,#3550f0 100%);box-shadow:0 6px 16px rgba(61,90,254,.30)}',
            '.mns-btn svg{width:16px;height:16px}',
            '.mns.on{align-items:center;padding:10px 14px;box-shadow:none;background:rgba(16,185,129,.08);border-color:rgba(16,185,129,.28)}',
            '.mns.on .mns-ico{width:30px;height:30px;border-radius:50%;background:#10b981;color:#fff}.mns.on .mns-ico svg{width:15px;height:15px}',
            '.mns.on .mns-txt>b{font-size:13.5px}.mns.on .mns-txt>span{margin-top:1px;font-size:12px}',
            'body.dark-mode .mns.off .mns-ico{color:#fbbf24}body.dark-mode .mns.blocked .mns-ico{color:#fb7185}',
            '.mns.unk .mns-ico{background:rgba(61,90,254,.10);color:#3550f0}body.dark-mode .mns.unk .mns-ico{color:#8fa2ff}',
            '.mns-diag{margin-top:9px;padding:8px 10px;border-radius:10px;background:rgba(100,116,139,.10);font:11px/1.5 ui-monospace,monospace;color:var(--text-2,#41506b);word-break:break-all;user-select:text;-webkit-user-select:text}',
            /* in-app banner (app open in front) */
            '.mnb{position:fixed;left:10px;right:10px;top:calc(10px + env(safe-area-inset-top,0px));z-index:4100;display:flex;gap:11px;align-items:center;max-width:520px;margin:0 auto;padding:11px 10px 11px 12px;border-radius:18px;background:var(--surface,#fff);color:var(--text,#0b1220);border:1px solid var(--border,#e5eaf3);box-shadow:0 16px 40px rgba(2,6,23,.26);transform:translateY(-140%);transition:transform .34s cubic-bezier(.22,1,.36,1);cursor:pointer;font-family:inherit}',
            '.mnb.open{transform:none}',
            '.mnb img{flex:0 0 auto;width:40px;height:40px;border-radius:11px;background:#fff;border:1px solid var(--border,#e5eaf3)}',
            '.mnb-t{flex:1 1 auto;min-width:0}',
            '.mnb-t b{display:block;font-size:13.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
            '.mnb-t>span{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:2px;font-size:12.3px;line-height:1.38;color:var(--text-2,#41506b)}',
            '.mnb-k{display:block;font-size:10.5px;font-weight:800;letter-spacing:.4px;text-transform:uppercase;color:var(--primary,#3d5afe);margin-bottom:1px}',
            '.mnb-x{flex:0 0 auto;width:30px;height:30px;border-radius:50%;border:0;background:transparent;color:var(--text-3,#7c8aa5);display:grid;place-items:center;cursor:pointer}.mnb-x svg{width:15px;height:15px}'
        ].join('\n');
        document.head.appendChild(st);
    }

    /* Subscribe a token to topic mmh_all via the worker. The "subscribed"
       flag is stored ONLY on success — a failed attempt must never be
       remembered, so the next page load retries (old RSM behaviour). */
    var _retryTimer = null;
    function subscribeToken(token) {
        return fetch('https://mmh-notify-worker.mockmatrixsupport.workers.dev/api/subscribe-topic', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: token })
        }).then(function (r) {
            if (r.ok) {
                try { localStorage.setItem(SUB, token); localStorage.removeItem('mmh_push_last_err'); } catch (e) {}
            } else {
                try { localStorage.setItem('mmh_push_last_err', 'subscribe http ' + r.status + ' @' + new Date().toISOString()); } catch (e) {}
                /* one automatic retry after 15s (covers a brief network blip) */
                if (!_retryTimer) _retryTimer = setTimeout(function () { _retryTimer = null; subscribeToken(token); }, 15000);
            }
        });
    }
    function register() {
        try {
            var reg = Push.register();
            if (reg && typeof reg.catch === 'function') reg.catch(function (err) { console.warn('Push.register rejected:', err); });
        } catch (e) { console.warn('Push.register threw:', e); }
    }
    /* t264: Android's answer is read STRICTLY. An error, an answer without a
       known state, or no answer in 6 s = 'unknown' — NEVER 'prompt' (that made
       the popup + "off" card show with permission already granted, and the
       Turn on button did nothing). Raw answers are kept for the 5-tap diag. */
    var PERM_OK = { 'granted': 1, 'denied': 1, 'prompt': 1, 'prompt-with-rationale': 1 };
    function diagSet(tag, txt) { lsSet('mmh_push_diag_' + tag, txt + ' @' + new Date().toISOString()); }
    function rawTxt(v) { try { return typeof v === 'string' ? v : JSON.stringify(v); } catch (e) { return String(v); } }
    function errTxt(e) { return e ? ((e.code ? e.code + ': ' : '') + (e.message || e.errorMessage || rawTxt(e))) : 'empty error'; }
    function normState(r) {
        var v = typeof r === 'string' ? r : (r && (r.receive || (r.data && r.data.receive)));
        return PERM_OK[v] ? v : 'unknown';
    }
    function readPerm(fn, tag, ms) {
        return new Promise(function (res) {
            var done = false, fin = function (st, txt) { if (done) return; done = true; diagSet(tag, txt); res(st); };
            var t = setTimeout(function () { fin('unknown', 'no answer in ' + (ms / 1000) + 's'); }, ms);
            try {
                Promise.resolve(fn()).then(function (r) { clearTimeout(t); fin(normState(r), 'ok ' + rawTxt(r)); },
                    function (e) { clearTimeout(t); fin('unknown', 'error ' + errTxt(e)); });
            } catch (e) { clearTimeout(t); fin('unknown', 'threw ' + errTxt(e)); }
        });
    }
    function permState() {
        if (!Push) return Promise.resolve('unsupported');
        return readPerm(function () { return Push.checkPermissions(); }, 'check', 6000);
    }

    /* ── banner when a notification arrives while the app is open ── */
    function isTestPage() { return /(^|\/)test\.html$/i.test(location.pathname) || /\/live-test\/test/i.test(location.pathname); }
    function showBanner(title, body, path) {
        if (isTestPage()) return;                        // never disturb a running test
        css();
        var old = document.getElementById('mmhNotifBanner'); if (old) old.remove();
        var b = document.createElement('div');
        b.id = 'mmhNotifBanner'; b.className = 'mnb'; b.setAttribute('role', 'status');
        b.innerHTML = '<img src="/logo.png" alt=""><div class="mnb-t"><div class="mnb-k">Mock Matrix Hub · now</div><b>' + esc(title) + '</b>' + (body ? '<span>' + esc(body) + '</span>' : '') + '</div>' +
            '<button type="button" class="mnb-x" aria-label="Close">' + ICO.x + '</button>';
        document.body.appendChild(b);
        requestAnimationFrame(function () { requestAnimationFrame(function () { b.classList.add('open'); }); });
        var hide = function () { b.classList.remove('open'); setTimeout(function () { b.remove(); }, 380); };
        var t = setTimeout(hide, 6000);
        b.querySelector('.mnb-x').onclick = function (e) { e.stopPropagation(); clearTimeout(t); hide(); };
        b.onclick = function () { clearTimeout(t); hide(); if (path) location.href = window.mmhMapExamUrl ? window.mmhMapExamUrl(path) : path; else location.href = '/notifications.html'; };
        var y0 = null;                                   // swipe up = dismiss
        b.addEventListener('touchstart', function (e) { y0 = e.touches[0].clientY; }, { passive: true });
        b.addEventListener('touchmove', function (e) { if (y0 !== null && e.touches[0].clientY - y0 < -24) { y0 = null; clearTimeout(t); hide(); } }, { passive: true });
    }
    window.mmhNotifBanner = showBanner;

    if (Push) {
        Push.addListener('registration', function (t) {
            if (t && t.value) subscribeToken(t.value).catch(function () {});
        });
        Push.addListener('registrationError', function (e) {
            try {
                console.warn('push registration error', e);
                localStorage.setItem('mmh_push_last_err', 'registrationError ' + JSON.stringify(e) + ' @' + new Date().toISOString());
            } catch (_) {}
        });
        /* App open in front: Android gives the message here INSTEAD of the tray → our banner. */
        Push.addListener('pushNotificationReceived', function (n) {
            try {
                var d = (n && n.data) || {};
                var title = (n && n.title) ? n.title : (d.title || 'New update');
                var body = (n && n.body) ? n.body : (d.body || '');
                localStorage.setItem('mmh_push_last_recv', title + ' @' + new Date().toISOString());
                showBanner(title, body, d.path || '');
            } catch (e) {}
        });
        Push.addListener('pushNotificationActionPerformed', function (a) {
            try {
                var p = a && a.notification && a.notification.data && a.notification.data.path;
                if (p) window.location.href = (window.mmhMapExamUrl ? window.mmhMapExamUrl(p) : p);
            } catch (e) {}
        });
        /* Every page load: permission granted → register again (self-healing topic subscribe). */
        var boot = function () {
            permState().then(function (state) {
                if (state === 'granted' || state === 'unknown') { register(); return; }   // t264: unknown = no popup
                if (isHome()) schedulePrompt(state);
            });
            if (isNotifPage()) paintStatus();
        };
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
        /* back from phone settings → check again */
        var App = P('App');
        if (App && App.addListener) {
            try {
                App.addListener('resume', function () {
                    permState().then(function (s) {
                        if (s === 'granted' && lsGet('mmh_notif_wait_settings')) {
                            try { localStorage.removeItem('mmh_notif_wait_settings'); } catch (e) {}
                            register(); toast('Notifications are on ✓');
                        }
                        if (isNotifPage()) paintStatus();
                    });
                });
            } catch (e) {}
        }
    }

    function isHome() { var p = window.location.pathname; return p === '/' || p === '/index.html' || p === ''; }
    function isNotifPage() { return /\/notifications\.html$/i.test(window.location.pathname); }

    /* ask the Android dialog; result: 'granted' | 'denied' | 'prompt-with-rationale' | 'prompt' (swiped away) */
    function askSystem() {
        if (!Push) return Promise.resolve('unsupported');
        return readPerm(function () { return Push.requestPermissions(); }, 'request', 120000).then(function (s) {
            if (s === 'granted') register();
            return s;
        });
    }
    /* phone settings → this app → Notifications (capacitor-native-settings); fallback: app info */
    function openSettings() {
        var NS = P('NativeSettings');
        lsSet('mmh_notif_wait_settings', '1');
        if (!NS || !NS.openAndroid) {
            toast('Phone Settings → Apps → Mock Matrix Hub → Notifications → Allow');
            return Promise.resolve(false);
        }
        return NS.openAndroid({ option: 'app_notification' }).catch(function () {
            return NS.openAndroid({ option: 'application_details' });
        }).then(function () { return true; }, function () {
            toast('Phone Settings → Apps → Mock Matrix Hub → Notifications → Allow');
            return false;
        });
    }
    window.mmhOpenNotifSettings = openSettings;

    /* ── home popup: 2nd app open onwards, clear screen only ── */
    function blocked() {
        var de = document.documentElement, b = document.body;
        if (!b || de.classList.contains('mmh-auth-active') || b.classList.contains('home-booting')) return true;
        if (document.getElementById('mmhNotifPrompt')) return true;
        var sb = document.getElementById('appSidebar');
        if (sb && sb.classList.contains('show') && window.innerWidth < 992) return true;
        var ids = ['mmhAppUpdateOverlay', 'tgPopupOverlay', 'expiryExpiredOverlay', 'mmhSaleOverlay', 'pwaInstallModal', 'mmhAuthOverlay'];
        for (var i = 0; i < ids.length; i++) if (visible(document.getElementById(ids[i]))) return true;
        var others = document.querySelectorAll('.modal-overlay, .sync-modal-overlay, .rq-sheet-layer');
        for (var j = 0; j < others.length; j++) if (!others[j].classList.contains('mnp-hold') && visible(others[j])) return true;
        return false;
    }
    function visible(el) {
        if (!el) return false;
        var d = el.style ? el.style.display : '';
        if (d === 'none' || el.hidden) return false;
        if (d && d !== 'none') return true;
        var cs = window.getComputedStyle ? getComputedStyle(el) : null;
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return false;
        return el.offsetHeight > 0;
    }
    function schedulePrompt(state) {
        if (state !== 'prompt' && state !== 'prompt-with-rationale') return;   // denied → only the Notifications page
        if (opens() < 2) return;                                                // never on the first app open
        var s = askState();
        if (s.n >= MAX_ASK || Date.now() < (s.next || 0)) return;
        var tries = 0;
        var tryShow = function () {
            if (!isHome()) return;
            if (blocked()) { if (++tries < 20) setTimeout(tryShow, 1500); return; }  // wait max ~30 s, else next time
            permState().then(function (now) {                                  // t264: re-check the phone setting first
                if (now === 'granted') { register(); return; }
                if (now !== 'prompt' && now !== 'prompt-with-rationale') return;
                if (isHome() && !blocked()) showPrompt();
            });
        };
        setTimeout(tryShow, 3500);                                              // let the home page settle first
    }
    function showPrompt() {
        if (document.getElementById('mmhNotifPrompt')) return;
        css();
        var s = askState();
        s.n = (s.n || 0) + 1; s.next = Date.now() + SNOOZE[Math.min(s.n - 1, SNOOZE.length - 1)] * DAY;
        saveAsk(s);                                     // counted when SHOWN (a closed app = "Not now")
        var ov = document.createElement('div');
        ov.id = 'mmhNotifPrompt'; ov.className = 'mnp-ov';
        ov.innerHTML =
            '<span class="sync-modal-overlay mnp-hold" style="display:block;visibility:hidden;position:absolute;width:0;height:0;padding:0;margin:0;inset:auto;overflow:hidden;pointer-events:none;background:none"></span>' +
            '<div class="mnp-box" role="dialog" aria-modal="true" aria-labelledby="mnpTitle">' +
              '<div class="mnp-grab"></div>' +
              '<button type="button" class="mnp-x" data-mnp="later" aria-label="Close">' + ICO.x + '</button>' +
              '<div class="mnp-hero"><div class="mnp-bell">' + ICO.bell + '<i>1</i></div></div>' +
              '<div class="mnp-body">' +
                '<h3 id="mnpTitle">' + esc(COPY.title) + '</h3>' +
                '<p>' + esc(COPY.text) + '</p>' +
                '<ul class="mnp-rows">' + COPY.rows.map(function (r) {
                    return '<li><span class="mnp-ri ' + r[0] + '">' + ICO[r[0]] + '</span><span class="mnp-rt"><b>' + esc(r[1]) + '</b>' + esc(r[2]) + '</span></li>';
                }).join('') + '</ul>' +
                '<div class="mnp-note">You can turn it off anytime in phone settings.</div>' +
              '</div>' +
              '<div class="mnp-acts">' +
                '<button type="button" class="mnp-btn ghost" data-mnp="later">Not now</button>' +
                '<button type="button" class="mnp-btn primary" data-mnp="allow">' + ICO.bell + '<span>Allow notifications</span></button>' +
              '</div>' +
            '</div>';
        document.body.appendChild(ov);
        requestAnimationFrame(function () { requestAnimationFrame(function () { ov.classList.add('open'); }); });
        var close = function () { ov.classList.remove('open'); setTimeout(function () { ov.remove(); }, 360); };
        ov.addEventListener('click', function (e) {
            var a = e.target.closest('[data-mnp]');
            if (!a && e.target === ov) { close(); return; }                     // tap outside = Not now
            if (!a) return;
            if (a.getAttribute('data-mnp') === 'later') { close(); return; }
            close();
            askSystem().then(function (res) {
                var st = askState();
                if (res === 'granted') { st.n = MAX_ASK; st.next = 0; saveAsk(st); toast('Notifications are on ✓'); return; }
                if (res === 'unknown') { st.n = MAX_ASK; saveAsk(st); openSettings(); return; }   // t264
                if (res === 'prompt') { st.n = Math.max(0, st.n - 1); st.next = Date.now() + 3 * DAY; saveAsk(st); return; }   // swiped away = undecided
                if (res === 'denied') { st.n = MAX_ASK; saveAsk(st); }
                toast('Okay — you can turn it on anytime from the Notifications page');
            });
        });
        var y0 = null, box = ov.querySelector('.mnp-box');                       // drag down = close
        box.addEventListener('touchstart', function (e) { y0 = e.touches[0].clientY; }, { passive: true });
        box.addEventListener('touchmove', function (e) { if (y0 !== null && e.touches[0].clientY - y0 > 70) { y0 = null; close(); } }, { passive: true });
    }
    window.mmhShowNotifPrompt = showPrompt;              // (preview / debugging)

    /* t264: 5 quick taps on the status card → Android's raw answers (for debugging) */
    function showDiag(el) {
        permState().then(function (s) {
            var box = el.querySelector('.mns-diag');
            if (!box) { box = document.createElement('div'); box.className = 'mns-diag'; (el.querySelector('.mns-txt') || el).appendChild(box); }
            box.textContent = 'state: ' + s + ' | plugin: ' + (Push ? 'yes' : 'no') + ' | settings plugin: ' + (P('NativeSettings') ? 'yes' : 'no') +
                ' | check: ' + (lsGet('mmh_push_diag_check') || '-') + ' | request: ' + (lsGet('mmh_push_diag_request') || '-') +
                ' | last error: ' + (lsGet('mmh_push_last_err') || '-');
        });
    }

    /* ── Notifications page: status card on top of the list ── */
    function paintStatus() {
        css();
        var host = document.querySelector('.pg-wrap') || document.querySelector('.screen-scroll') || document.body;
        var el = document.getElementById('mmhNotifState');
        if (!el) {
            el = document.createElement('div'); el.id = 'mmhNotifState';
            host.insertBefore(el, host.firstChild);
        }
        permState().then(function (s) {
            if (s === 'granted') {
                el.className = 'mns on';
                el.innerHTML = '<span class="mns-ico">' + ICO.check + '</span><div class="mns-txt"><b>Notifications are on</b><span>Only new mocks &amp; app updates · no promotional messages</span></div>';
                return;
            }
            if (s === 'denied') {
                el.className = 'mns blocked';
                el.innerHTML = '<span class="mns-ico">' + ICO.bellOff + '</span><div class="mns-txt"><b>Notifications are blocked</b>' +
                    '<span>You turned them off for this app. Turn them on in phone settings to get new mock updates and new app updates.</span>' +
                    '<ol class="mns-steps"><li>Tap <b>Open settings</b></li><li>Turn on <b>Allow notifications</b></li><li>Come back — done</li></ol>' +
                    '<button type="button" class="mns-btn" data-mns="settings">' + ICO.gear + '<span>Open settings</span></button></div>';
                return;
            }
            if (s === 'unknown') {                                              // t264
                el.className = 'mns unk';
                el.innerHTML = '<span class="mns-ico">' + ICO.bell + '</span><div class="mns-txt"><b>Notification setting</b>' +
                    '<span>Make sure notifications are allowed for Mock Matrix Hub to get new mock updates and new app updates.</span>' +
                    '<button type="button" class="mns-btn" data-mns="settings">' + ICO.gear + '<span>Open settings</span></button></div>';
                return;
            }
            el.className = 'mns off';
            el.innerHTML = '<span class="mns-ico">' + ICO.bellOff + '</span><div class="mns-txt"><b>Notifications are off</b>' +
                '<span>Turn on to get new mock updates and new app updates. No promotional messages.</span>' +
                '<button type="button" class="mns-btn" data-mns="allow">' + ICO.bell + '<span>Turn on notifications</span></button></div>';
        });
        if (!el._bound) {
            el._bound = true;
            el.addEventListener('click', function (e) {
                var b = e.target.closest('[data-mns]');
                if (!b) {                                                         // t264: 5 quick taps on the card = diag
                    var now = Date.now();
                    if (!el._t0 || now - el._t0 > 3000) { el._t0 = now; el._taps = 0; }
                    if (++el._taps >= 5) { el._t0 = 0; showDiag(el); }
                    return;
                }
                permState().then(function (s) {                                  // always the CURRENT phone setting
                    if (s === 'granted') { register(); paintStatus(); return; }
                    if (s === 'denied' || s === 'unknown' || b.getAttribute('data-mns') === 'settings') { openSettings(); return; }
                    askSystem().then(function (res) {
                        if (res === 'granted') toast('Notifications are on ✓');
                        else if (res === 'denied') toast('Blocked — use Open settings to turn them on');
                        else if (res === 'unknown') { openSettings(); return; }   // t264: never "nothing happens"
                        paintStatus();
                    });
                });
            });
        }
    }

    /* ── save / share files ── */
    function dataUrlToBase64(d) { return String(d).split(',')[1]; }
    function blobToBase64(blob) {
        return new Promise(function (res, rej) {
            var r = new FileReader();
            r.onload = function () { res(String(r.result).split(',')[1]); };
            r.onerror = rej; r.readAsDataURL(blob);
        });
    }
    function cacheUri(FS, filename, b64) {
        return FS.writeFile({ path: filename, data: b64, directory: 'CACHE', recursive: true })
            .then(function () { return FS.getUri({ path: filename, directory: 'CACHE' }); })
            .then(function (u) { return u.uri; });
    }
    async function mmhSaveOrShare(filename, payload, mime) {
        var b64 = typeof payload === 'string' ? dataUrlToBase64(payload) : await blobToBase64(payload);
        var FS = P('Filesystem'), Media = P('Media'), Share = P('Share');
        /* 1) images → gallery directly (no runtime permission needed) */
        if (Media && Media.savePhoto && mime && mime.indexOf('image/') === 0 && FS) {
            try {
                var uri0 = await cacheUri(FS, filename, b64);
                await Media.savePhoto({ path: uri0, albumIdentifier: 'Mock Matrix Hub' });
                toast('Saved to gallery ✓'); return;
            } catch (e) { /* fall through */ }
        }
        /* 2) other files → public Downloads when storage permission granted */
        if (FS) {
            try {
                var perm = await FS.requestPermissions();
                if (perm && (perm.publicStorage === 'granted' || perm.publicStorage === 'limited')) {
                    await FS.writeFile({ path: 'Download/MockMatrixHub/' + filename, data: b64, directory: 'EXTERNAL', recursive: true });
                    toast('Saved to Download/MockMatrixHub ✓'); return;
                }
            } catch (e) { /* fall through */ }
        }
        /* 3) share sheet (offers Save to Files / Drive / apps) */
        if (Share && FS) {
            try {
                var uri = await cacheUri(FS, filename, b64);
                await Share.share({ title: 'Mock Matrix Hub', text: filename, files: [uri], dialogTitle: 'Save or share' });
                return;
            } catch (e) { /* fall through */ }
        }
        toast('Could not save on this device');
    }
    window.mmhSaveOrShare = mmhSaveOrShare;

    window.mmhShare = async function (opts) {
        var Share = P('Share');
        if (Share) { try { await Share.share(opts); return; } catch (e) { return; } }
        if (navigator.share) { try { await navigator.share(opts); } catch (e) {} }
    };
})();

/* ═══════════════════════════════════════════════════════════════════════════
   mmh-page-reload.js — t212/t213 (APP only)
   "Page load nahi hua" card + Reload button, in the middle of the page.

   Shows ONLY when the page has nothing to show:
     • an engine reports a hard failure  → window.mmhPageFail.show()
       (exam / chapter / live data could not be fetched, no offline copy), or
     • safety net: the page is still on its loading skeleton after the wait
       (offline 5 s, online 20 s), or the page is blank after a JS error.
   It never shows while real content (APK copy / live copy) is on screen, and
   it stays away when the page already shows its own Try again / Retry button.

   Loaded on every app page EXCEPT the home page and the test.html pages.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.mmhPageFail) return;

    var ID = 'mmhPageFail';
    var SKELETON = '.skeleton-card,.skeleton-line,.skeleton,.skel,.shimmer,[class*="skeleton-"],[class^="skeleton"]';
    var OWN_RETRY = /^(try again|retry|reload)\b/i;
    var shownBy = '';          // 'engine' | 'watch' | ''
    var started = Date.now();

    var ICO_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8.8a15 15 0 0 1 4.2-2.6M9.8 5.2A15 15 0 0 1 22 8.8"/><path d="M5 12.9a10 10 0 0 1 3.4-2.1M14.6 10.6A10 10 0 0 1 19 12.9"/><path d="M8.5 16.4a5 5 0 0 1 7 0"/><path d="M12 20h.01"/><path d="M3 3l18 18"/></svg>';
    var ICO_ERR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 8v5"/><path d="M12 16.5h.01"/><path d="M21 3v6h-6"/></svg>';
    var ICO_RELOAD = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4.5V11h-6.5"/></svg>';

    function css() {
        if (document.getElementById(ID + 'Css')) return;
        var s = document.createElement('style');
        s.id = ID + 'Css';
        s.textContent =
            '#' + ID + '{position:fixed;left:0;right:0;z-index:60;display:flex;align-items:center;justify-content:center;padding:24px;' +
            'background:var(--bg,#f3f5fb);font-family:inherit;-webkit-tap-highlight-color:transparent;animation:mmhPfIn .22s ease both}' +
            '@keyframes mmhPfIn{from{opacity:0}to{opacity:1}}' +
            '#' + ID + ' .pf-card{width:100%;max-width:340px;text-align:center;color:var(--text,#0e1428)}' +
            '#' + ID + ' .pf-ico{width:68px;height:68px;margin:0 auto 16px;border-radius:50%;display:grid;place-items:center;' +
            'background:var(--primary-soft,rgba(61,90,254,.10));color:var(--primary,#3d5afe)}' +
            '#' + ID + ' .pf-ico svg{width:32px;height:32px}' +
            '#' + ID + ' .pf-title{font-size:17px;font-weight:700;margin:0 0 6px;line-height:1.3}' +
            '#' + ID + ' .pf-sub{font-size:13.5px;line-height:1.5;margin:0 auto;max-width:290px;opacity:.68}' +
            '#' + ID + ' .pf-btn{margin-top:20px;display:inline-flex;align-items:center;justify-content:center;gap:8px;min-width:150px;height:46px;' +
            'padding:0 26px;border:0;border-radius:999px;cursor:pointer;font:inherit;font-size:14.5px;font-weight:700;letter-spacing:.2px;color:#fff;' +
            'background:var(--primary,#3d5afe);box-shadow:0 8px 20px rgba(61,90,254,.30);transition:transform .12s ease}' +
            '#' + ID + ' .pf-btn:active{transform:scale(.96)}' +
            '#' + ID + ' .pf-btn svg{width:18px;height:18px}' +
            '#' + ID + ' .pf-btn.busy svg{animation:mmhPfSpin .8s linear infinite}' +
            '@keyframes mmhPfSpin{to{transform:rotate(360deg)}}' +
            'body.dark-mode #' + ID + '{background:var(--bg,#0a0f1e)}' +
            'body.dark-mode #' + ID + ' .pf-card{color:var(--text,#eef1fb)}';
        (document.head || document.documentElement).appendChild(s);
    }

    function chain(x, y) {
        var out = [], el = document.elementFromPoint(x, y);
        while (el && el !== document.body && el !== document.documentElement) { out.push(el); el = el.parentElement; }
        return out;
    }
    // Card sits between the page header and the bottom dock (both stay usable).
    function place(box) {
        var w = window.innerWidth, h = window.innerHeight, top = 0, bottom = 0;
        box.style.display = 'none';
        try {
            // header = the tallest top-anchored block (< 1/3 screen) under the top edge
            chain(w / 2, 3).forEach(function (el) {
                var r = el.getBoundingClientRect();
                if (r.top <= 4 && r.height > 20 && r.height < h / 3 && r.bottom > top) top = Math.round(r.bottom);
            });
            if (!top) {
                var hs = document.querySelectorAll('.appbar,.screen-header,header');
                for (var i = 0; i < hs.length; i++) {
                    var q = hs[i].getBoundingClientRect();
                    if (q.top <= 4 && q.height > 20 && q.height < h / 3) { top = Math.round(q.bottom); break; }
                }
            }
            // bottom dock = a fixed / sticky block (< 1/3 screen) on the bottom edge
            chain(w / 2, h - 3).forEach(function (el) {
                var p = getComputedStyle(el).position, f = el.getBoundingClientRect();
                if ((p === 'fixed' || p === 'sticky') && f.height < h / 3 && f.top > h * 0.6) bottom = Math.max(bottom, Math.round(h - f.top));
            });
        } catch (e) {}
        box.style.top = top + 'px';
        box.style.bottom = bottom + 'px';
        box.style.display = 'flex';
    }

    /* ── Header back arrow while the page failed / has no data (t213) ──────
       The first-screen arrow on the exam pages is only shown + wired after
       the data loads. On a failure it would stay hidden (or do nothing), so
       here it is made visible and sent to the page's PARENT — never
       history.back() (in the app WebView that can do nothing → stuck).   */
    var BACK_SEL = '.nav-back,#backBtn,.ws-back-btn,a.icon-btn[aria-label^="Back"],button[aria-label^="Back to previous"]';
    var ARROW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>';
    function parentUrl() {
        var path = location.pathname || '/';
        if (path.indexOf('/exams/') === 0) {
            try { if (window.MMHExam && typeof MMHExam.home === 'function') return MMHExam.home(); } catch (e) {}
            return '/exams/index.html';
        }
        var parts = path.split('/').filter(Boolean);           // ["series","portal.html"]
        if (parts.length >= 2 && !/^index\.html?$/i.test(parts[parts.length - 1])) return '/' + parts.slice(0, -1).join('/') + '/index.html';
        return '/index.html';
    }
    function goParent() {   /* t255: drill pages → parent, other pages → where the user came from */
        if (window.MMHNav) { if (/^\/(exams|pdfs|series)\//.test(location.pathname)) MMHNav.up(parentUrl()); else MMHNav.back(parentUrl()); }
        else location.href = parentUrl();
    }
    function headerOf(el) { return el && el.closest('header,.appbar,.screen-header,.ws-appbar'); }
    function onTop(el) {
        if (!el) return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 20 && r.top <= 4 && r.top > -20;
    }
    function ensureBack() {
        try {
            var list = document.querySelectorAll(BACK_SEL), btn = null;
            for (var i = 0; i < list.length; i++) {
                if (list[i].id === 'backTop' || list[i].closest('#' + ID)) continue;
                if (onTop(headerOf(list[i]))) { btn = list[i]; break; }
            }
            if (!btn) {                                       // page has no arrow at all → add one
                var bars = document.querySelectorAll('.appbar,.ws-appbar,.screen-header,header'), bar = null;
                for (var j = 0; j < bars.length; j++) if (onTop(bars[j])) { bar = bars[j]; break; }
                if (!bar) return null;
                if (bar.querySelector(':scope > .appbar')) bar = bar.querySelector(':scope > .appbar');
                btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'icon-btn nav-back';
                btn.setAttribute('aria-label', 'Back to previous page');
                btn.innerHTML = ARROW;
                bar.insertBefore(btn, bar.firstChild);
            }
            btn.hidden = false;
            if (btn.style.display === 'none') btn.style.display = '';
            if (getComputedStyle(btn).display === 'none') btn.style.setProperty('display', 'grid', 'important');
            btn.style.visibility = 'visible';
            btn.style.pointerEvents = 'auto';
            btn.setAttribute('data-mmh-safe-back', '1');
            return btn;
        } catch (e) { return null; }
    }
    // capture phase → runs before the page's own (possibly unwired / data-dependent) handler
    document.addEventListener('click', function (e) {
        var b = e.target && e.target.closest && e.target.closest('[data-mmh-safe-back="1"]');
        if (!b) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        goParent();
    }, true);

    function show(opts) {
        opts = opts || {};
        var mk = function () {
            css();
            var off = navigator.onLine === false;
            var box = document.getElementById(ID);
            if (!box) {
                box = document.createElement('div');
                box.id = ID;
                box.setAttribute('role', 'alert');
                document.body.appendChild(box);
            }
            box.innerHTML =
                '<div class="pf-card">' +
                  '<div class="pf-ico">' + (off ? ICO_OFF : ICO_ERR) + '</div>' +
                  '<h3 class="pf-title">' + (opts.title || (off ? "You're offline" : "Couldn't load this page")) + '</h3>' +
                  '<p class="pf-sub">' + (opts.msg || (off
                      ? 'Connect to the internet, then tap Reload.'
                      : 'Internet is slow or something went wrong. Tap Reload to try again.')) + '</p>' +
                  '<button type="button" class="pf-btn">' + ICO_RELOAD + '<span>Reload</span></button>' +
                '</div>';
            box.querySelector('.pf-btn').addEventListener('click', function () {
                this.classList.add('busy');
                this.disabled = true;
                if (typeof opts.retry === 'function') { hide(); try { opts.retry(); } catch (e) { location.reload(); } }
                else location.reload();
            });
            shownBy = opts._by || 'engine';
            ensureBack();
            place(box);
        };
        if (document.body) mk(); else document.addEventListener('DOMContentLoaded', mk);
    }
    function hide() {
        var box = document.getElementById(ID);
        if (box) box.remove();
        shownBy = '';
        Array.prototype.forEach.call(document.querySelectorAll('[data-mmh-safe-back]'), function (b) { b.removeAttribute('data-mmh-safe-back'); });
    }

    /* ── Safety net ─────────────────────────────────────────────────────── */
    function visible(el) {
        if (!el || el.closest('#' + ID)) return false;
        var r = el.getBoundingClientRect();
        if (r.width < 8 || r.height < 6 || r.bottom < 0 || r.top > window.innerHeight) return false;
        var cs = getComputedStyle(el);
        return cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity || '1') > 0.05;
    }
    function skeletonOnScreen() {
        var list = document.querySelectorAll(SKELETON);
        for (var i = 0; i < list.length; i++) if (visible(list[i])) return true;
        return false;
    }
    function pageHasOwnRetry() {
        var b = document.querySelectorAll('button,a');
        for (var i = 0; i < b.length; i++) {
            if (b[i].closest('#' + ID)) continue;
            if (OWN_RETRY.test((b[i].textContent || '').trim()) && visible(b[i])) return true;
        }
        return false;
    }
    function blankPage() {   // only used after a JS error
        var t = (document.body && document.body.innerText || '').replace(/\s+/g, ' ').trim();
        return t.length < 40;
    }
    var errSeen = false;
    function check() {
        if (document.hidden) return;
        var skel = skeletonOnScreen(), blank = !skel && errSeen && blankPage();
        var stuck = skel || blank;
        if (shownBy === 'watch' && (!stuck || pageHasOwnRetry())) { hide(); return; }   // content arrived later
        if (shownBy) return;
        if (!stuck || pageHasOwnRetry()) return;
        var waited = Date.now() - started;
        var need = blank ? 3000 : (navigator.onLine === false ? 5000 : 20000);
        if (waited >= need) show({ _by: 'watch' });
    }
    function startWatch() {
        started = Date.now();
        setInterval(check, 1000);
    }
    window.addEventListener('error', function (e) {
        // uncaught JS error, or a script / css that failed to load
        var t = e && e.target;
        if (e instanceof ErrorEvent || (t && (t.tagName === 'SCRIPT' || t.tagName === 'LINK'))) errSeen = true;
    }, true);
    window.addEventListener('unhandledrejection', function () { errSeen = true; });
    window.addEventListener('resize', function () { var b = document.getElementById(ID); if (b) place(b); });
    window.addEventListener('pageshow', function (e) { if (e.persisted) { hide(); started = Date.now(); } });

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startWatch);
    else startWatch();

    // noData(): file does not exist → page shows its own "No mocks / Coming soon"; only fix the back arrow
    window.mmhPageFail = { show: show, hide: hide, ensureBack: ensureBack, parentUrl: parentUrl, noData: function () { if (document.body) ensureBack(); else document.addEventListener('DOMContentLoaded', ensureBack); } };
})();

// ═══════════════════════════════════════════════════════════════════════════
//  Check Reports (admin)  —  /admin-reports/index.html
//
//  Same look as the user's Reported page (reported.css, q-render cards, dock,
//  Telegram chat). Three tabs:
//    Under review  questions with at least one report not edited yet (edited = 0)
//    Updated       questions whose reports are all edited (edited = 1)
//    Chats         every reporter (Telegram chat list) → 1 report: chat opens
//                  directly · more: topics (one per question) → chat
//
//  Data: admin Worker v3 (admin.mockmatrixhub.in), header X-Admin-Key = the
//  admin password (localStorage mmh_admin_pw — same key the old editor used).
//    GET  /inbox?offset=N          → { rows[], next_offset, counts? }
//    POST /bodies {quids[≤50]}     → { questions, base, source, missing }
//    POST /reply  {uid,quid,text,r?} → { at, thread }
//    POST /q      {quid,full,base,uid?,message?} → save (rules, 409, purge, edited=1)
//    POST /purge  {quids}          → retry cache clear
//    POST /delete {items:[{uid,quid}]≤100} → report rows deleted (bank question untouched)
//
//  Delete: long-press a card (Under review / Updated) → selection mode (same
//  contextual bar as the saved page) → tap more cards → Delete → confirm.
//  A card = one question → EVERY report row (uid + quid) of that card is deleted.
//
//  Admin "unread" = user messages after the last one the admin opened on THIS
//  device (localStorage mmh_ar_read_v1, key uid|quid → messages seen). No D1 column.
//  Drafts: localStorage mmh_ed_draft:<quid> {text, base, at} (same as the old editor).
//
//  The preview build sets window.MMH_AR_API (mock) before this file loads.
// ═══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const R = window.MMHRules;
const PW_KEY    = "mmh_admin_pw";
const READ_KEY  = "mmh_ar_read_v1";
const DRAFT_KEY = q => "mmh_ed_draft:" + q;
const ROLES     = ["admin", "owner", "subowner"];
const PAGE      = 10;          // cards per "Load more"
const MSG_MAX   = 1000;
const BODY_MAX  = 50;          // /bodies per call

function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
// testing only: a LOCAL Worker (wrangler dev / Miniflare) may replace the live one — never another site,
// so the admin password can only ever go to admin.mockmatrixhub.in or this computer
const ADMIN_URL = (function () {
  const o = (lsGet("mmh_admin_api_override") || "").replace(/\/+$/, "");
  return /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o) ? o : "https://admin.mockmatrixhub.in";
})();

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// ── icons ────────────────────────────────────────────────────────────────────
const IC = {
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  reply: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-12.3 7.5L3 21l2-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  flag:  '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 2.8a1 1 0 0 1 1 1V4h11.6a.8.8 0 0 1 .65 1.27L15.9 8.6l2.35 3.33a.8.8 0 0 1-.65 1.27H6V21a1 1 0 1 1-2 0V3.8a1 1 0 0 1 1-1z"/></svg>',
  info:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.6v.1"/></svg>',
  edit:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>',
  inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l2.6-7.2A2 2 0 0 1 7.5 4.5h9a2 2 0 0 1 1.9 1.3L21 13v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5z"/><path d="M3 13h5l1.5 2.5h5L16 13h5"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19.5c.6-3.2 2.7-5 5.5-5s4.9 1.8 5.5 5M16 5.2a3.2 3.2 0 0 1 0 5.8M17.6 14.8c1.8.6 2.9 2.2 3.3 4.7"/></svg>',
  copy:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><rect x="8.5" y="8.5" width="11" height="11" rx="2.2"/><path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/></svg>',
  draft: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8L14 3.5z"/><path d="M14 3.5V8h4.5M9 13h6M9 16.5h4"/></svg>',
  hash:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><path d="M9.5 3.5 7.5 20.5M16.5 3.5l-2 17M4 9h16.5M3.5 15H20"/></svg>',
  back2: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>',
  tick:  '<svg viewBox="0 0 16 11" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 6l3.4 3.4L12 2"/></svg>',
  tick2: '<svg viewBox="0 0 18 11" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1 6l3.4 3.4L11.5 2M8.2 8.6l.8.8L16.5 2"/></svg>',
  wait:  '<svg viewBox="0 0 16 11" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="8" cy="5.5" r="4.2"/><path d="M8 3.3v2.4l1.6 1"/></svg>',
  fail:  '<svg viewBox="0 0 16 11" fill="currentColor"><circle cx="8" cy="5.5" r="5"/><path d="M8 2.8v3.3M8 7.6v.4" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>',
  back:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.8 1.8 0 0 0 1.8 1.6h5.6a1.8 1.8 0 0 0 1.8-1.6L17.5 7M10 11v6M14 11v6"/></svg>'
};

// ══════════════════════════════════════════════════════════════════════════
//  REAL API (admin Worker, password header)
// ══════════════════════════════════════════════════════════════════════════
const REAL_API = (function () {
  let pending = "";                       // password being tried at the gate (saved only if it works)
  const key = () => pending || lsGet(PW_KEY) || "";
  function authErr() { const e = new Error("unauthorized"); e.auth = true; return e; }
  async function call(method, path, body) {
    const k = key();
    if (!k) throw authErr();
    const r = await fetch(ADMIN_URL + path, {
      method: method,
      headers: Object.assign({ "X-Admin-Key": k }, body !== undefined ? { "Content-Type": "application/json" } : {}),
      body: body === undefined ? undefined : JSON.stringify(body),
      cache: "no-store", referrerPolicy: "no-referrer"
    });
    let d = null;
    try { d = await r.json(); } catch (e) {}
    if (r.status === 401) throw authErr();
    if (!r.ok || !d || d.ok === false) {
      const e = new Error((d && (d.error || (d.errors && d.errors.join(" · ")))) || ("HTTP " + r.status));
      e.status = r.status; e.data = d;
      throw e;
    }
    return d;
  }
  return {
    setPending(p) { pending = p || ""; },
    inbox(offset)  { return call("GET", "/inbox?offset=" + (offset | 0)); },
    bodies(quids)  { return call("POST", "/bodies", { quids: quids }); },
    reply(uid, quid, text, r) { return call("POST", "/reply", r == null ? { uid: uid, quid: quid, text: text } : { uid: uid, quid: quid, text: text, r: r }); },
    save(p)        { return call("POST", "/q", p); },
    purge(quids)   { return call("POST", "/purge", { quids: quids }); },
    nochange(quid, message) { return call("POST", "/nochange", { quid: quid, message: message }); },
    del(items)     { return call("POST", "/delete", { items: items }); }
  };
})();
const API = window.MMH_AR_API || REAL_API;

// ══════════════════════════════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════════════════════════════
const S = {
  tab: "review",                 // review | updated | chats
  rows: [],                      // every report row from /inbox
  next: null,                    // /inbox next_offset
  counts: null,
  bodies: {},                    // quid -> { body, base, source } | { missing:true }
  preview: {},                   // quid -> bank body of the LOCAL draft (card shows it)
  shown: { review: PAGE, updated: PAGE },
  read: {},                      // "uid|quid" -> messages the admin has seen
  lang: "en",
  wide: false,
  pane: "empty",                 // ≥992px: empty | details | editor | chat
  sideQuid: "",
  sheetQuid: "",
  chat: null,                    // { uid, quid }
  replyTo: null,
  person: null,                  // Chats tab: uid whose topics are open
  search: "",
  edit: null,                    // editor state (one question at a time)
  confirm: null,
  sel: null,                     // selection mode: Set of quids (cards) to delete · null = off
  selBack: false,                // our own history.back() after leaving selection → ignore that popstate
  loaded: false,
  paintSeq: 0
};
try { S.lang = localStorage.getItem("quiz_lang") || "en"; } catch (e) {}
if (["en", "hi", "bilingual"].indexOf(S.lang) < 0) S.lang = "en";
try { S.read = JSON.parse(lsGet(READ_KEY) || "{}") || {}; } catch (e) { S.read = {}; }

// ══════════════════════════════════════════════════════════════════════════
//  DATA HELPERS
// ══════════════════════════════════════════════════════════════════════════
function toMs(at) {
  if (at == null || at === "") return 0;
  const n = Number(at);
  if (!isNaN(n)) return n < 1e12 ? n * 1000 : n;
  const d = Date.parse(at);
  return isNaN(d) ? 0 : d;
}
const keyOf = r => r.uid + "|" + r.quid;
// "No change needed": an admin chat message with k:"ok" (question NOT edited). The user sees it as a reply.
const isOk = r => !r.edited && r.chat.some(m => m && m.from === "admin" && m.k === "ok");
const isDone = r => r.edited || isOk(r);
const NOCHANGE_MSG = "Humne is question ko check kiya — question sahi hai, isme koi change ki zaroorat nahi hai. Report karne ke liye dhanyavaad! 🙏";
function normRow(r) {
  r.uid = Number(r.uid);
  r.edited = r.edited === true || r.edited === 1;
  r.seen = r.seen === true || r.seen === 1;
  if (!Array.isArray(r.chat)) r.chat = [];
  return r;
}
function lastAtOf(r) {
  const m = r.chat[r.chat.length - 1];
  return toMs(m && m.at) || toMs(r.last_at) || toMs(r.reported_at);
}
const isReport = m => m && m.from !== "admin" && (m.reason != null || m.details != null);
function firstMsg(r) { return r.chat.find(isReport) || null; }
function reasonOf(r) { const f = firstMsg(r); return (f && f.reason) || "Reported"; }
function nameOf(r) { return (r.name && String(r.name).trim()) || ("User #" + r.uid); }
function firstName(n) { return String(n || "").trim().split(/\s+/)[0] || n; }
function initials(n) {
  const p = String(n || "?").replace(/[^\p{L}\p{N} ]/gu, " ").trim().split(/\s+/).filter(Boolean);
  if (!p.length) return "?";
  return ((p[0][0] || "") + (p.length > 1 ? p[p.length - 1][0] : (p[0][1] || ""))).toUpperCase();
}
const avClass = uid => "ar-av-" + (Math.abs(Number(uid) || 0) % 7);   // Telegram's 7 avatar colours

// admin unread (this device): user messages after the last one the admin opened
function readMark(r) {
  const k = keyOf(r);
  if (typeof S.read[k] === "number") return S.read[k];
  // never opened on this device → everything after the last admin message is new
  for (let i = r.chat.length - 1; i >= 0; i--) if (r.chat[i] && r.chat[i].from === "admin") return i + 1;
  return 0;
}
function unreadOf(r) {
  let n = 0;
  for (let i = readMark(r); i < r.chat.length; i++) if (r.chat[i] && r.chat[i].from !== "admin" && !r.chat[i]._st) n++;
  return n;
}
function markRead(r) {
  if (!r) return;
  const n = r.chat.filter(m => !m._st || m._st === "sent").length;
  if (S.read[keyOf(r)] === n) return;
  S.read[keyOf(r)] = n;
  lsSet(READ_KEY, JSON.stringify(S.read));
}
function pruneRead() {
  const live = new Set(S.rows.map(keyOf));
  let ch = false;
  Object.keys(S.read).forEach(k => { if (!live.has(k)) { delete S.read[k]; ch = true; } });
  if (ch) lsSet(READ_KEY, JSON.stringify(S.read));
}

// one card per QUESTION (several users can report the same quid)
function groups() {
  const m = new Map();
  S.rows.forEach(r => {
    let g = m.get(r.quid);
    if (!g) { g = { quid: r.quid, rows: [], review: false, lastAt: 0, unread: 0 }; m.set(r.quid, g); }
    g.rows.push(r);
  });
  m.forEach(g => {
    g.rows.sort((a, b) => lastAtOf(b) - lastAtOf(a));
    g.review = g.rows.some(r => !isDone(r));
    g.lastAt = lastAtOf(g.rows[0]);
    g.unread = g.rows.reduce((s, r) => s + unreadOf(r), 0);
  });
  return Array.from(m.values()).sort((a, b) => b.lastAt - a.lastAt);
}
function groupOf(quid) { return groups().find(g => g.quid === quid) || null; }
function tabGroups(tab) { return groups().filter(g => tab === "review" ? g.review : !g.review); }
function people() {
  const m = new Map();
  S.rows.forEach(r => {
    let p = m.get(r.uid);
    if (!p) { p = { uid: r.uid, name: "", rows: [], lastAt: 0, unread: 0 }; m.set(r.uid, p); }
    p.rows.push(r);
  });
  m.forEach(p => {
    p.rows.sort((a, b) => lastAtOf(b) - lastAtOf(a));
    const named = p.rows.find(r => r.name && String(r.name).trim());
    p.name = named ? String(named.name).trim() : "User #" + p.uid;
    p.lastAt = lastAtOf(p.rows[0]);
    p.unread = p.rows.reduce((s, r) => s + unreadOf(r), 0);
  });
  return Array.from(m.values()).sort((a, b) => b.lastAt - a.lastAt);
}
function personOf(uid) { return people().find(p => p.uid === uid) || null; }
function findRow(uid, quid) { return S.rows.find(r => r.uid === uid && r.quid === quid) || null; }

function questionObj(quid, row) {
  const b = S.preview[quid] || (S.bodies[quid] && S.bodies[quid].body);
  if (!b) return null;
  const q = Object.assign({}, b);
  q.quid = quid;
  q.id = (row && row.local_id) || quid;            // test.html: id = local id (image slots)
  return q;
}
async function ensureBodies(quids) {
  const need = Array.from(new Set(quids)).filter(q => !(q in S.bodies));
  for (let i = 0; i < need.length; i += BODY_MAX) {
    const part = need.slice(i, i + BODY_MAX);
    const d = await API.bodies(part);
    part.forEach(q => {
      if (d.questions && d.questions[q]) S.bodies[q] = { body: d.questions[q], base: (d.base || {})[q] || "", source: (d.source || {})[q] || null };
      else S.bodies[q] = { missing: true };
    });
  }
}
function plainText(html) {
  const d = document.createElement("div");
  d.innerHTML = String(html || "");
  return (d.textContent || "").replace(/\s+/g, " ").trim();
}
const TEX_SYM = { theta:"θ", alpha:"α", beta:"β", gamma:"γ", delta:"δ", pi:"π", phi:"φ", lambda:"λ", mu:"μ", sigma:"σ", omega:"ω",
  angle:"∠", circ:"°", degree:"°", times:"×", div:"÷", cdot:"·", pm:"±", le:"≤", leq:"≤", ge:"≥", geq:"≥", ne:"≠", neq:"≠",
  infty:"∞", Rightarrow:"⇒", rightarrow:"→", therefore:"∴", because:"∵", triangle:"△", sqrt:"√", left:"", right:"", quad:" ", qquad:" " };
const SUP = { "0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹","n":"ⁿ" };
function texToText(t) {
  let s = String(t || "");
  s = s.replace(/\\\(|\\\)|\\\[|\\\]|\$\$/g, " ");
  s = s.replace(/\\sqrt\s*\{([^{}]*)\}/g, "√($1)").replace(/√\(([A-Za-z0-9.]+)\)/g, "√$1");
  const part = x => /^[A-Za-z0-9.√\\]+$/.test(x.trim()) ? x.trim() : "(" + x.trim() + ")";
  for (let i = 0; i < 3; i++) s = s.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, (m, a, b) => part(a) + "/" + part(b));
  s = s.replace(/\^\s*\{?\s*\\circ\s*\}?/g, "°");
  s = s.replace(/\\(?:operatorname|text|mathrm|mathbf|textbf)\s*\{([^{}]*)\}/g, "$1");
  s = s.replace(/\^\{?([0-9n])\}?/g, (m, d) => SUP[d] || m);
  s = s.replace(/\\([A-Za-z]+)/g, (m, w) => (w in TEX_SYM ? TEX_SYM[w] : w) + " ");
  s = s.replace(/[{}]/g, "").replace(/\\[,;! ]/g, " ");
  return s.replace(/\s+([,.?)])/g, "$1").replace(/\s+/g, " ").trim();
}
function questionPreview(quid, fallback) {
  const q = questionObj(quid);
  if (!q) return fallback || "Question";
  const t = typeof mmhQuestionDisplay === "function" ? mmhQuestionDisplay(q.question, S.lang === "bilingual" ? "en" : S.lang, "").text : "";
  return texToText(plainText(t)).slice(0, 140) || fallback || "Question";
}
function msgPreview(m) {
  if (!m) return "Message";
  if (isReport(m)) return "Report · " + (m.reason || "Reported") + (m.details ? " — " + m.details : "");
  return String(m.text || "").replace(/\s+/g, " ").trim() || "Message";
}

// ── dates ────────────────────────────────────────────────────────────────────
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
function dayKey(ms) { const d = new Date(ms); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); }
function dayLabel(ms) {
  const d = new Date(ms), now = new Date();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ms) === dayKey(now.getTime())) return "Today";
  if (dayKey(ms) === dayKey(y.getTime())) return "Yesterday";
  return d.getDate() + " " + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? " " + d.getFullYear() : "");
}
function timeLabel(ms) {
  const d = new Date(ms);
  let h = d.getHours(); const m = d.getMinutes();
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return h + ":" + String(m).padStart(2, "0") + " " + ap;
}
function shortDate(ms) {
  if (!ms) return "";
  const d = new Date(ms), now = new Date();
  const lbl = dayLabel(ms);
  if (lbl === "Today" || lbl === "Yesterday") return lbl;
  return d.getDate() + " " + MONTHS[d.getMonth()].slice(0, 3) + (d.getFullYear() !== now.getFullYear() ? " " + d.getFullYear() : "");
}
function fullDate(ms) {
  if (!ms) return "—";
  const d = new Date(ms);
  return d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear() + ", " + timeLabel(ms);
}
// Telegram chat list: today → time · this week → weekday · older → date
function listTime(ms) {
  if (!ms) return "";
  const now = Date.now();
  if (dayKey(ms) === dayKey(now)) return timeLabel(ms);
  if (now - ms < 6 * 86400000) return DAYS[new Date(ms).getDay()];
  const d = new Date(ms);
  return d.getDate() + " " + MONTHS[d.getMonth()].slice(0, 3) + (d.getFullYear() !== new Date().getFullYear() ? " " + d.getFullYear() : "");
}
function agoText(ms) {
  const s = Math.max(0, (Date.now() - ms) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + " min ago";
  if (s < 86400) return Math.floor(s / 3600) + " h ago";
  return shortDate(ms);
}

// ══════════════════════════════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════════════════════════════
let toastT = 0;
function toast(msg, ms) {
  const t = $("rqToast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove("show"), ms || 2600);
}
function langSelect() {
  const o = (v, t) => '<option value="' + v + '"' + (S.lang === v ? " selected" : "") + '>' + t + '</option>';
  return '<div class="lang-container"><span class="lang-label">Select Language:</span>' +
         '<select class="card-lang-dropdown" aria-label="Language">' +
         o("en", "English") + o("hi", "Hindi") + o("bilingual", "Bilingual") + '</select></div>';
}
function hasDraft(quid) {
  try { const d = JSON.parse(lsGet(DRAFT_KEY(quid)) || "null"); return !!(d && typeof d.text === "string"); } catch (e) { return false; }
}
// admin status of a question
function gStatus(g) {
  if (!g.review) return g.rows.some(r => r.edited) ? "edited" : "nochange";
  return g.rows.some(r => r.chat.some(m => m.from === "admin")) ? "replied" : "new";
}
const GST = {
  new:     { chip: "New",      ico: IC.clock, cls: "is-review"  },
  replied: { chip: "Replied",  ico: IC.reply, cls: "is-replied" },
  edited:  { chip: "Edited",   ico: IC.check, cls: "is-fixed"   },
  nochange:{ chip: "No change", ico: IC.check, cls: "is-fixed"  }
};
function statusChip(st) { return '<span class="rq-status ' + GST[st].cls + '">' + GST[st].ico + '<span>' + GST[st].chip + '</span></span>'; }
function headExtra(g) {
  const n = g.rows.length;
  return '<span class="ar-chips">' + statusChip(gStatus(g)) +
      (n > 1 ? '<span class="ar-chip" title="' + n + ' users reported this question">' + IC.users + '<span>' + n + '</span></span>' : "") +
      (hasDraft(g.quid) ? '<span class="ar-chip is-draft" title="Local draft on this device">' + IC.draft + '<span>Draft</span></span>' : "") +
    '</span>' +
    '<span class="ar-head-right">' + langSelect() +
      '<button type="button" class="icon-btn ar-head-edit" data-act="edit" aria-label="Edit question" title="Edit question">' + IC.edit + '</button>' +
    '</span>';
}
function metaStrip(g) {
  const r = g.rows[0];
  const b = S.bodies[g.quid];
  const bits = [r.quiz_id, r.section, r.local_id].filter(Boolean).map(x => '<span>' + esc(x) + '</span>').join("");
  return '<div class="ar-meta tex2jax_ignore">' +
    '<button type="button" class="ar-quid" data-copy="' + esc(g.quid) + '" title="Copy quid">' + esc(g.quid) + IC.copy + '</button>' +
    bits + (b && b.source ? '<span class="ar-src">' + esc(b.source) + '</span>' : "") +
    (S.preview[g.quid] ? '<span class="ar-prev">Local preview</span>' : "") +
  '</div>';
}
function cardFor(g, index, extra) {
  const row = g.rows[0];
  const q = questionObj(g.quid, row);
  if (!q || typeof mmhRenderCard !== "function") {
    const c = document.createElement("div");
    c.className = "quiz-card mmh-card";
    c.innerHTML = '<div class="mmh-card-head"><div class="mmh-card-num">' + index + '</div>' +
      '<div class="mmh-card-head-extra">' + extra + '</div></div>' +
      '<div class="rq-missing">' + (S.bodies[g.quid] && S.bodies[g.quid].missing ? "This question is not in the question bank (D1)." : "Loading question…") + '</div>';
    return c;
  }
  return mmhRenderCard(q, {
    lang: S.lang, quizId: row.quiz_id || "", index: index, total: 0,
    mode: "solution", allowSolution: false, solutionOpen: true, showPercent: false,
    onPick: null, headExtra: extra
  });
}

// ══════════════════════════════════════════════════════════════════════════
//  SELECT + DELETE (long-press a card → select more → Delete)
// ══════════════════════════════════════════════════════════════════════════
function shownQuids() { return Array.from(document.querySelectorAll("#rqList .ar-cell")).map(c => c.getAttribute("data-quid")); }
function selRows() {
  const out = [];
  (S.sel ? Array.from(S.sel) : []).forEach(q => { const g = groupOf(q); if (g) g.rows.forEach(r => out.push(r)); });
  return out;
}
function enterSel(quid) {
  if (S.tab === "chats" || !groupOf(quid)) return;
  if (!S.sel) {
    S.sel = new Set();
    try { history.pushState({ ar: "sel" }, "", location.href); } catch (e) {}
  }
  S.sel.add(quid);
  try { if (navigator.vibrate) navigator.vibrate(18); } catch (e) {}
  try { const ws = window.getSelection && window.getSelection(); if (ws) ws.removeAllRanges(); } catch (e) {}
  paintSel();
}
function toggleSel(quid) {
  if (!S.sel || !quid) return;
  if (S.sel.has(quid)) S.sel.delete(quid); else S.sel.add(quid);
  if (!S.sel.size) { exitSel(); return; }
  paintSel();
}
function exitSel(fromPop) {
  if (!S.sel) return;
  S.sel = null;
  paintSel();
  if (!fromPop && history.state && history.state.ar === "sel") { S.selBack = true; history.back(); }
}
function paintSel() {
  const on = !!S.sel;
  document.body.classList.toggle("select-mode", on);
  $("arSelBar").hidden = !on;
  document.querySelectorAll("#rqList .ar-cell").forEach(c => c.classList.toggle("is-selected", on && S.sel.has(c.getAttribute("data-quid"))));
  if (!on) return;
  const n = S.sel.size, reps = selRows().length;
  $("arSelCount").textContent = String(n);
  $("arSelWord").textContent = "selected" + (reps !== n ? " · " + reps + " reports" : "");   // n = questions (cards); 1 card can hold many reporters
  const shown = shownQuids();
  const all = $("arSelAll");
  all.textContent = shown.length && shown.every(q => S.sel.has(q)) ? "Clear all" : "Select all";
  all.disabled = !shown.length;
  $("arSelDel").disabled = !n;
}
function selectAll() {
  if (!S.sel) return;
  const shown = shownQuids();
  if (shown.length && shown.every(q => S.sel.has(q))) { exitSel(); return; }
  shown.forEach(q => S.sel.add(q));
  paintSel();
}
function askDelete() {
  if (!S.sel || !S.sel.size) return;
  // the open editor belongs to a selected card → close it first (asks if there are unsaved edits)
  if (S.edit && S.sel.has(S.edit.quid) && !closeEditor()) return;
  const quids = Array.from(S.sel).filter(q => groupOf(q));
  const rows = selRows();
  if (!rows.length) { exitSel(); return; }
  S.confirm = { mode: "delete", quids: quids };
  const li = quids.slice(0, 8).map(q => {
    const g = groupOf(q);
    return '<li><b>' + esc(questionPreview(q, q).slice(0, 70)) + '</b><br><small>' + esc(q) + ' · ' +
      esc(g.rows.map(nameOf).join(", ")) + ' (' + g.rows.length + (g.rows.length === 1 ? " report" : " reports") + ')</small></li>';
  }).join("") + (quids.length > 8 ? '<li><small>+ ' + (quids.length - 8) + ' more</small></li>' : "");
  $("arConfirmTitle").textContent = "Delete " + rows.length + (rows.length === 1 ? " report?" : " reports?");
  $("arConfirmGo").textContent = "Delete " + rows.length;
  $("arConfirmGo").classList.add("ar-btn-danger");
  $("arConfirmBody").innerHTML =
    '<div class="rq-hero ar-hero-del"><div class="rq-hero-ico">' + IC.trash + '</div><div><div class="rq-hero-title">Deleted for good</div>' +
      '<div class="rq-hero-sub">Each report row (user + question) is removed from D1 with its whole chat. This cannot be undone.</div></div></div>' +
    '<div class="rq-sec-label">' + quids.length + (quids.length === 1 ? " question" : " questions") + '</div><ul class="ar-what ar-del-list">' + li + '</ul>' +
    '<div class="rq-sec-label">What happens</div><ul class="ar-what">' +
      '<li><b>' + rows.length + (rows.length === 1 ? " report row" : " report rows") + '</b> deleted (reported_questions)</li>' +
      '<li>The users will not see these reports on their Reported page any more</li>' +
      '<li><b>Question bank (D1)</b> — not touched, the questions stay as they are</li>' +
    '</ul>';
  $("arConfirm").hidden = false;
}
async function doDelete() {
  const quids = S.confirm.quids, go = $("arConfirmGo");
  const items = [];
  quids.forEach(q => { const g = groupOf(q); if (g) g.rows.forEach(r => items.push({ uid: r.uid, quid: q })); });
  go.disabled = true; go.textContent = "Deleting…";
  let done = 0, err = null;
  for (let i = 0; i < items.length; i += 100) {
    const part = items.slice(i, i + 100);
    try { await API.del(part); }
    catch (e) { err = e; break; }
    // every asked row is gone now (deleted here, or already deleted before)
    const gone = new Set(part.map(x => x.uid + "|" + x.quid));
    S.rows = S.rows.filter(r => !gone.has(keyOf(r)));
    done += part.length;
  }
  go.disabled = false;
  closeConfirm();
  if (done) {
    const left = new Set(S.rows.map(r => r.quid));
    const dead = quids.filter(q => !left.has(q));
    dead.forEach(q => { lsDel(DRAFT_KEY(q)); delete S.preview[q]; });
    if (S.edit && dead.indexOf(S.edit.quid) >= 0) closeEditor(true);
    if (S.chat && dead.indexOf(S.chat.quid) >= 0 && !$("rqChat").hidden) closeChatUI(true);
    if (S.sheetQuid && dead.indexOf(S.sheetQuid) >= 0) closeSheetUI();
    if (S.wide && S.sideQuid && dead.indexOf(S.sideQuid) >= 0) closeSide();
    pruneRead();
  }
  exitSel();
  paintAll(true);
  if (err) {
    if (err.auth) return lockOut();
    toast((done ? "Deleted " + done + " · " : "") + "Could not delete: " + (err.message || "network error"), 3600);
  } else toast("Deleted " + done + (done === 1 ? " report" : " reports"), 2600);
}
function bindSelect() {
  const list = $("rqList");
  let lp = null, swallow = false;
  const cancel = () => { if (lp) { clearTimeout(lp.t); lp = null; } };
  list.addEventListener("pointerdown", e => {
    cancel();
    swallow = false;                  // a new touch = a new gesture: only the click of the long-press itself is eaten
    if (S.tab === "chats" || (e.pointerType === "mouse" && e.button !== 0)) return;
    const cell = e.target.closest(".ar-cell");
    if (!cell || e.target.closest("#arEditor, select, input, textarea, a")) return;
    lp = { x: e.clientX, y: e.clientY, t: setTimeout(() => {
      lp = null; swallow = true;
      const q = cell.getAttribute("data-quid");
      if (S.sel) toggleSel(q); else enterSel(q);
    }, 480) };
  });
  list.addEventListener("pointermove", e => { if (lp && Math.hypot(e.clientX - lp.x, e.clientY - lp.y) > 10) cancel(); });
  ["pointerup", "pointercancel", "pointerleave"].forEach(t => list.addEventListener(t, () => {
    cancel();
    if (swallow) setTimeout(() => { swallow = false; }, 450);     // the click that follows a long-press
  }));
  $("rqScroll").addEventListener("scroll", cancel, { passive: true });
  list.addEventListener("contextmenu", e => { if (S.sel || swallow) e.preventDefault(); });
  // capture: in selection mode a tap toggles the card and NOTHING inside it reacts (Details, Chat, Edit …)
  list.addEventListener("click", e => {
    if (swallow) { swallow = false; e.preventDefault(); e.stopPropagation(); return; }
    if (!S.sel) return;
    const cell = e.target.closest(".ar-cell");
    if (!cell || e.target.closest("#arEditor")) return;
    e.preventDefault(); e.stopPropagation();
    toggleSel(cell.getAttribute("data-quid"));
  }, true);
  $("arSelClose").addEventListener("click", () => exitSel());
  $("arSelAll").addEventListener("click", selectAll);
  $("arSelDel").addEventListener("click", askDelete);
}

// ══════════════════════════════════════════════════════════════════════════
//  GATE (password first)
// ══════════════════════════════════════════════════════════════════════════
function showGate(kind, err) {
  document.body.classList.add("ar-locked");
  $("arLock").hidden = true;
  const field = $("arGateField"), btn = $("arGateBtn"), note = $("arGateNote");
  if (kind === "denied" || kind === "login") {
    $("arGateTitle").textContent = kind === "denied" ? "Admins only" : "Please log in";
    $("arGateText").textContent = kind === "denied"
      ? "This page is only for admin accounts."
      : "Log in with your admin account first.";
    field.hidden = true; note.hidden = true;
    btn.textContent = kind === "denied" ? "Go to home" : "Log in";
    btn.setAttribute("data-go", kind === "denied" ? "/" : "/?login&redirect=" + encodeURIComponent(location.pathname));
  } else {
    $("arGateTitle").textContent = "Admin access";
    $("arGateText").textContent = "Enter the admin password to load all reported questions.";
    field.hidden = false; note.hidden = false;
    btn.textContent = "Unlock"; btn.removeAttribute("data-go");
    setTimeout(() => { try { $("arPw").focus(); } catch (e) {} }, 60);
  }
  const e = $("arGateErr");
  e.hidden = !err; e.textContent = err || "";
}
function showApp() {
  document.body.classList.remove("ar-locked");
  $("arLock").hidden = false;
  placeLayout();
}
async function unlock(pw) {
  const btn = $("arGateBtn");
  btn.disabled = true; btn.textContent = "Checking…";
  $("arGateErr").hidden = true;
  API.setPending(pw);
  try {
    await loadInbox(true);
    lsSet(PW_KEY, pw);
    API.setPending("");
    $("arPw").value = "";
    showApp();
    afterLoad();
  } catch (e) {
    API.setPending("");
    showGate("pw", e && e.auth ? "Wrong password. Try again." : "Could not connect to the admin server. Check internet and try again.");
  } finally {
    btn.disabled = false; if (!btn.getAttribute("data-go")) btn.textContent = "Unlock";
  }
}
async function profileRole() {
  for (let i = 0; i < 30 && typeof getLocalProfile !== "function"; i++) await new Promise(r => setTimeout(r, 100));
  if (typeof getLocalProfile !== "function") return "unknown";     // the password still protects the data
  const p = getLocalProfile();
  if (!p || (!p.id && !p.username)) return "none";
  return ROLES.indexOf(p.role) >= 0 ? "admin" : "user";
}

// ══════════════════════════════════════════════════════════════════════════
//  LOAD
// ══════════════════════════════════════════════════════════════════════════
async function loadInbox(reset) {
  const d = await API.inbox(reset ? 0 : (S.next || 0));
  const rows = (d.rows || []).map(normRow);
  if (reset) {
    S.rows = rows;
    S.bodies = {};
    S.shown = { review: PAGE, updated: PAGE };
  } else {
    const have = new Set(S.rows.map(keyOf));
    S.rows = S.rows.concat(rows.filter(r => !have.has(keyOf(r))));
  }
  S.next = d.next_offset != null ? d.next_offset : null;
  if (d.counts) S.counts = d.counts;
  S.loaded = true;
  pruneRead();
}
function afterLoad() {
  paintAll(false);
  // link from Telegram: ?quid=Q…&uid=123 → that question (and that reporter's chat)
  const qs = new URLSearchParams(location.search);
  const quid = (qs.get("quid") || "").trim();
  const uid = /^[1-9][0-9]{0,14}$/.test(qs.get("uid") || "") ? Number(qs.get("uid")) : null;
  const g = quid ? groupOf(quid) : null;
  if (g) {
    switchTab(g.review ? "review" : "updated", true);
    if (uid && findRow(uid, quid)) openChat(uid, quid);
    else openDetails(quid);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  PAINT — intro, dock, badges
// ══════════════════════════════════════════════════════════════════════════
function paintIntro() {
  const T = $("rqTitle"), Sb = $("rqSub");
  if (!S.loaded) { Sb.textContent = "Loading reports…"; return; }
  if (S.tab === "chats") {
    const ps = people(), un = ps.filter(p => p.unread).length;
    T.textContent = "Chats";
    Sb.textContent = ps.length ? ps.length + (ps.length === 1 ? " reporter" : " reporters") + (un ? " · " + un + " unread" : "") : "No chats yet";
    return;
  }
  const gs = tabGroups(S.tab);
  const nr = gs.reduce((s, g) => s + g.rows.filter(r => S.tab === "review" ? !isDone(r) : true).length, 0);
  if (S.tab === "review") {
    T.textContent = "Under review";
    Sb.textContent = gs.length ? gs.length + (gs.length === 1 ? " question · " : " questions · ") + nr + (nr === 1 ? " report" : " reports") + " waiting" : "Nothing to review";
  } else {
    T.textContent = "Updated";
    Sb.textContent = gs.length ? gs.length + (gs.length === 1 ? " question" : " questions") + " done · edited or no change" : "No edited questions yet";
  }
}
function setBadge(el, n) { el.hidden = !n; el.textContent = n > 99 ? "99+" : String(n); }
function paintBadges() {
  const gs = groups();
  setBadge($("arBadgeReview"), gs.filter(g => g.review && g.unread).length);
  setBadge($("arBadgeUpdated"), gs.filter(g => !g.review && g.unread).length);
  setBadge($("arBadgeChats"), people().filter(p => p.unread).length);
}
function paintDock() {
  document.querySelectorAll("#rqDock .ex-dock-item").forEach(btn => {
    const on = btn.getAttribute("data-tab") === S.tab;
    btn.classList.toggle("active", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  });
  document.body.classList.toggle("ar-tab-chats", S.tab === "chats");
}
function paintAll(keepScroll) {
  paintIntro(); paintBadges(); paintDock();
  if (S.tab === "chats") paintChats(keepScroll); else paintCards(keepScroll);
}

// ══════════════════════════════════════════════════════════════════════════
//  CARDS (Under review / Updated)
// ══════════════════════════════════════════════════════════════════════════
function skeleton() {
  const one = '<div class="rq-skel"><div class="rq-skel-head"></div><div class="rq-skel-body">' +
    '<div class="rq-skel-line" style="width:92%"></div><div class="rq-skel-line" style="width:70%"></div>' +
    '<div class="rq-skel-line" style="width:84%"></div><div class="rq-skel-line" style="width:55%;margin:0"></div></div></div>';
  $("rqList").innerHTML = one + one;
  $("rqList").hidden = false; $("arChats").hidden = true;
  $("rqMore").hidden = true; $("rqEnd").hidden = true;
}
function emptyState() {
  const rev = S.tab === "review";
  const other = tabGroups(rev ? "updated" : "review").length;
  return '<div class="rq-empty"><div class="rq-empty-ico">' + (rev ? IC.check : IC.inbox) + '</div>' +
    '<h3>' + (rev ? "All caught up" : "No edited questions yet") + '</h3>' +
    '<p>' + (rev ? "No report is waiting. New reports from the tests will show up here." : "When you update a reported question on D1 it moves here.") + '</p>' +
    (other ? '<button type="button" class="rq-btn rq-btn-soft" data-go-tab="' + (rev ? "updated" : "review") + '">See ' + other + (rev ? " updated" : " under review") + '</button>' : '') +
    '</div>';
}
function lastLine(g) {
  // newest message across this question's reports
  let best = null, row = null;
  g.rows.forEach(r => { const m = r.chat[r.chat.length - 1]; if (m && (!best || toMs(m.at) > toMs(best.at))) { best = m; row = r; } });
  if (!best) return "";
  const who = best.from === "admin" ? "You" : firstName(nameOf(row));
  return '<div class="rq-bar-reply"><b' + (best.from === "admin" ? ' class="is-you"' : "") + '>' + esc(who) + ':</b> ' + esc(msgPreview(best).slice(0, 170)) + '</div>';
}
function barFor(g) {
  const latest = g.rows[0];
  const more = g.rows.length - 1;
  const unread = g.unread;
  const editing = S.edit && S.edit.quid === g.quid;
  return '<div class="rq-bar ar-bar tex2jax_ignore">' +
    '<div class="rq-bar-main">' +
      '<div class="rq-bar-line">' +
        '<span class="rq-bar-ico">' + IC.flag + '</span>' +
        '<span class="rq-bar-reason">' + esc(reasonOf(latest)) + '</span>' +
        (more > 0 ? '<span class="ar-more">+' + more + ' more</span>' : "") +
        (g.lastAt ? '<span class="rq-bar-sep"></span><span class="rq-bar-time">' + esc(shortDate(g.lastAt)) + '</span>' : "") +
        (unread ? '<span class="rq-new">NEW</span>' : "") +
      '</div>' + lastLine(g) +
    '</div>' +
    '<div class="rq-bar-actions">' +
      '<button type="button" class="rq-btn" data-act="details">' + IC.info + '<span>Details</span></button>' +
      '<button type="button" class="rq-btn ' + (unread ? "rq-btn-primary" : "rq-btn-soft") + '" data-act="chat">' + IC.reply + '<span>Chat</span>' +
        (unread ? '<span class="rq-count">' + unread + '</span>' : "") + '</button>' +
      '<button type="button" class="rq-btn ar-btn-edit' + (editing ? " is-on" : "") + '" data-act="edit">' + IC.edit + '<span>' + (editing ? "Editing" : "Edit") + '</span></button>' +
    '</div></div>';
}
async function paintCards(keepScroll) {
  const seq = ++S.paintSeq;
  const box = $("rqList"), sc = $("rqScroll");
  $("arChats").hidden = true; box.hidden = false;
  const y = keepScroll ? sc.scrollTop : 0;
  if (!S.loaded) { skeleton(); return; }
  const list = tabGroups(S.tab);
  const page = list.slice(0, S.shown[S.tab]);
  const need = page.map(g => g.quid).filter(q => !(q in S.bodies));
  if (need.length) {
    if (!keepScroll) skeleton();
    try { await ensureBodies(need); } catch (e) { if (e && e.auth) return lockOut(); toast("Could not load questions. Try again."); }
    if (seq !== S.paintSeq) return;          // a newer paint started meanwhile
  }
  box.innerHTML = "";
  if (!page.length) box.innerHTML = emptyState();
  else {
    const frag = document.createDocumentFragment();
    page.forEach((g, i) => {
      const cell = document.createElement("div");
      cell.className = "q-cell rq-cell ar-cell" + (g.unread ? " is-new" : "") + (S.edit && S.edit.quid === g.quid ? " is-editing" : "") +
        (S.sel && S.sel.has(g.quid) ? " is-selected" : "");
      cell.setAttribute("data-quid", g.quid);
      const card = cardFor(g, i + 1, headExtra(g));
      const head = card.querySelector(".mmh-card-head");
      if (head) head.insertAdjacentHTML("afterend", metaStrip(g));
      card.insertAdjacentHTML("beforeend", barFor(g));
      const hx = card.querySelector(".mmh-card-head-extra");
      if (hx) hx.insertAdjacentHTML("afterbegin", '<span class="sel-box card-sel-box" aria-hidden="true">' + IC.check + '</span>');
      cell.appendChild(card);
      frag.appendChild(cell);
    });
    box.appendChild(frag);
  }
  const canMore = list.length > page.length || (S.next != null);
  $("rqMore").hidden = !canMore;
  $("rqEnd").hidden = canMore || !page.length;
  $("rqEnd").textContent = "That's all.";
  if (typeof renderMath === "function") renderMath();
  sc.scrollTop = y;
  markActive();
  placeEditor();
  if (S.sel) paintSel();
}
async function loadMore() {
  const btn = $("rqMoreBtn");
  btn.disabled = true; btn.textContent = "Loading…";
  try {
    if (S.tab === "chats") { await loadInbox(false); paintAll(true); return; }
    const total = tabGroups(S.tab).length;
    if (S.shown[S.tab] < total) S.shown[S.tab] += PAGE;
    else if (S.next != null) { await loadInbox(false); S.shown[S.tab] += PAGE; }
    await paintCards(true);
    paintIntro(); paintBadges();
  } catch (e) { if (e && e.auth) return lockOut(); toast("Could not load. Try again."); }
  finally { btn.disabled = false; btn.textContent = "Load more"; }
}

function switchTab(tab, quiet) {
  if (["review", "updated", "chats"].indexOf(tab) < 0) return;
  if (S.sel) exitSel();
  if (tab === S.tab && !quiet) { $("rqScroll").scrollTo({ top: 0, behavior: "smooth" }); return; }
  if (S.edit && S.edit.quid && !quiet) {
    const g = groupOf(S.edit.quid);
    const home = g ? (g.review ? "review" : "updated") : "";
    if (home !== tab && !closeEditor()) return;      // editor stays with its card
  }
  if (!$("rqChat").hidden) closeChatUI(true);
  if (S.wide) closeSide();
  S.person = null;
  S.tab = tab;
  try { const u = new URL(location.href); u.searchParams.set("tab", tab); history.replaceState(history.state, "", u.pathname + u.search + u.hash); } catch (e) {}
  $("rqScroll").scrollTop = 0;
  paintAll(false);
  paintPaneEmpty();
}
function cellOf(quid) { return $("rqList").querySelector('.rq-cell[data-quid="' + quid + '"]'); }

// ══════════════════════════════════════════════════════════════════════════
//  DETAILS — question meta + every report of this question
// ══════════════════════════════════════════════════════════════════════════
function detailsHtml(g) {
  const st = gStatus(g);
  const r0 = g.rows[0];
  const b = S.bodies[g.quid] || {};
  const pending = g.rows.filter(r => !isDone(r)).length;
  const hero = {
    new:     ["Under review", pending + (pending === 1 ? " report" : " reports") + " waiting · not replied yet"],
    replied: ["Under review · replied", "You replied, but the question is not edited yet"],
    edited:  ["Edited on D1", "All " + g.rows.length + (g.rows.length === 1 ? " reporter sees" : " reporters see") + " “Question corrected”"],
    nochange:["No change needed", "Question is correct — not edited. Reporters got your message."]
  }[st];
  const heroCls = st === "edited" || st === "nochange" ? "is-fixed" : st === "replied" ? "is-replied" : "is-review";
  const kv = (k, v, cls) => '<div class="rq-kv-row"><div class="rq-kv-k">' + k + '</div><div class="rq-kv-v' + (cls ? " " + cls : "") + '">' + v + '</div></div>';
  let html =
    '<div class="rq-hero ' + heroCls + '"><div class="rq-hero-ico">' + GST[st].ico + '</div><div>' +
      '<div class="rq-hero-title">' + hero[0] + '</div><div class="rq-hero-sub">' + esc(hero[1]) + '</div></div></div>' +
    '<div class="rq-sec-label">Question meta</div>' +
    '<div class="rq-kv ar-kv">' +
      kv("Quid", '<button type="button" class="ar-quid" data-copy="' + esc(g.quid) + '">' + esc(g.quid) + IC.copy + '</button>') +
      kv("Quiz ID", esc(r0.quiz_id || "—"), "mono") +
      kv("Section", esc(r0.section || "—")) +
      kv("Local ID", esc(r0.local_id || "—"), "mono") +
      kv("Source", esc(b.source || "—"), b.source ? "mono" : "muted") +
      kv("D1 version", esc(b.base || "—"), "mono") +
    '</div>' +
    '<div class="rq-sec-label">Reports (' + g.rows.length + ')</div><div class="ar-reps">';
  g.rows.forEach(r => {
    const f = firstMsg(r) || {};
    const n = nameOf(r), un = unreadOf(r);
    const replied = r.chat.some(m => m.from === "admin");
    html += '<div class="ar-rep">' +
      '<div class="ar-rep-top"><span class="ar-av ' + avClass(r.uid) + '">' + esc(initials(n)) + '</span>' +
        '<div class="ar-rep-who"><b>' + esc(n) + '</b><small>' + esc(fullDate(toMs(r.reported_at) || toMs(f.at))) + '</small></div>' +
        '<button type="button" class="rq-btn ' + (un ? "rq-btn-primary" : "rq-btn-soft") + ' ar-rep-chat" data-chat-uid="' + r.uid + '" data-chat-quid="' + esc(r.quid) + '">' +
          IC.reply + '<span>Chat</span>' + (un ? '<span class="rq-count">' + un + '</span>' : "") + '</button></div>' +
      '<div class="ar-rep-reason">' + esc(f.reason || "Reported") + '</div>' +
      (f.details ? '<div class="ar-rep-details">' + esc(f.details) + '</div>' : '<div class="ar-rep-details muted">No details written</div>') +
      '<div class="ar-rep-tags">' +
        (r.edited ? '<span class="ar-tag ok">Edited</span>' : isOk(r) ? '<span class="ar-tag ok">No change</span>' : '<span class="ar-tag wait">Pending</span>') +
        (replied ? '<span class="ar-tag">Replied</span>' : "") +
        (r.edited || replied ? (r.seen ? '<span class="ar-tag">Seen by user</span>' : '<span class="ar-tag">Not seen yet</span>') : "") +
        '<span class="ar-tag">' + r.chat.length + (r.chat.length === 1 ? " message" : " messages") + '</span>' +
      '</div></div>';
  });
  return html + '</div>';
}
function detailsFoot(g, inSheet) {
  const one = g.rows.length === 1;
  return (inSheet && !one ? '<button type="button" class="rq-btn rq-btn-block" data-close>Close</button>' : "") +
    (one ? '<button type="button" class="rq-btn rq-btn-soft rq-btn-block" data-chat-uid="' + g.rows[0].uid + '" data-chat-quid="' + esc(g.quid) + '">' + IC.reply + 'Chat</button>' : "") +
    '<button type="button" class="rq-btn rq-btn-primary rq-btn-block" data-edit-quid="' + esc(g.quid) + '">' + IC.edit + 'Edit question</button>';
}
function openDetails(quid, push) {
  const g = groupOf(quid);
  if (!g) return;
  if (S.wide) { openSide(quid); return; }
  S.sheetQuid = quid;
  $("rqSheetBody").innerHTML = detailsHtml(g);
  $("rqSheetFoot").innerHTML = detailsFoot(g, true);
  $("rqSheetBody").scrollTop = 0;
  $("rqSheet").hidden = false;
  if (push !== false) history.pushState({ ar: "sheet", quid: quid }, "", location.pathname + location.search + location.hash);
}
function closeSheetUI() { $("rqSheet").hidden = true; S.sheetQuid = ""; }
function closeSheet() {
  if ($("rqSheet").hidden) return;
  if (history.state && history.state.ar === "sheet") history.back();
  else closeSheetUI();
}

// ══════════════════════════════════════════════════════════════════════════
//  RIGHT PANE (≥992px) — empty · details · editor · chat
// ══════════════════════════════════════════════════════════════════════════
function setPane(mode) {
  S.pane = mode;
  $("rqPaneEmpty").hidden = mode !== "empty";
  $("rqPaneDetails").hidden = mode !== "details";
  $("arPaneEditor").hidden = mode !== "editor";
  document.body.classList.toggle("ar-pane-editor", S.wide && mode === "editor");
}
function paintPaneEmpty() {
  $("rqPaneEmptyText").textContent = S.tab === "chats" ? "Select a chat to start messaging" : "Select a question to see its reports, edit it or chat";
}
function markActive() {
  document.querySelectorAll("#rqList .rq-cell").forEach(c =>
    c.classList.toggle("is-active", S.wide && !!S.sideQuid && c.getAttribute("data-quid") === S.sideQuid));
}
function openSide(quid) {
  const g = groupOf(quid);
  if (!g) return;
  if (!$("rqChat").hidden) closeChatUI(true);
  if (S.edit && S.edit.quid !== quid && !closeEditor()) return;
  S.sideQuid = quid;
  $("rqPaneSub").textContent = quid + " · " + g.rows.length + (g.rows.length === 1 ? " report" : " reports");
  $("rqPaneBody").innerHTML = detailsHtml(g);
  $("rqPaneFoot").innerHTML = detailsFoot(g, false);
  $("rqPaneBody").scrollTop = 0;
  setPane("details");
  markActive();
}
function closeSide() {
  if (!$("rqChat").hidden) closeChatUI(true);
  if (S.edit && !closeEditor()) return;
  S.sideQuid = "";
  setPane("empty");
  markActive();
}
function placeLayout() {
  const was = S.wide;
  S.wide = window.matchMedia("(min-width:992px) and (hover:hover) and (pointer:fine)").matches;
  document.body.classList.toggle("rq-wide", S.wide);
  const hdr = document.querySelector(".exam-page-container > .screen-header");
  if (hdr) document.documentElement.style.setProperty("--rq-hdr", hdr.offsetHeight + "px");
  const chat = $("rqChat");
  const home = S.wide ? $("rqPaneScreen") : document.body;
  if (chat.parentNode !== home) {
    if (!chat.hidden) closeChatUI(true);
    if (!$("rqSheet").hidden) closeSheetUI();
    if (history.state && history.state.ar) history.replaceState(null, "", location.pathname + location.search);
    home.appendChild(chat);
    if (was !== S.wide) {
      S.sideQuid = ""; setPane(S.wide && S.edit ? "editor" : "empty");
      if (S.loaded) paintAll(true);
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  CHATS TAB — people (Telegram chat list) → topics (one per question)
// ══════════════════════════════════════════════════════════════════════════
const SEC_ABBR = { maths: "MA", math: "MA", quant: "QA", reasoning: "RE", english: "EN", gk: "GK", gs: "GS", ga: "GA", science: "SC", computer: "CO", hindi: "HI" };
function secAbbr(s) { const k = String(s || "").toLowerCase(); return SEC_ABBR[k] || (k.slice(0, 2).toUpperCase() || "Q"); }
function secClass(s) { let h = 0; String(s || "").split("").forEach(c => { h = (h * 31 + c.charCodeAt(0)) | 0; }); return "ar-tc-" + (Math.abs(h) % 7); }
function lastText(r) {
  const m = r.chat[r.chat.length - 1];
  if (!m) return "";
  return (m.from === "admin" ? '<span class="ar-you">You: </span>' : "") + esc(msgPreview(m).slice(0, 120));
}
function personRow(p) {
  const multi = p.rows.length > 1;
  const r = p.rows[0];
  const active = S.chat && S.chat.uid === p.uid && (S.wide || false);
  return '<button type="button" class="ar-row' + (active || S.person === p.uid ? " is-active" : "") + '" data-person="' + p.uid + '">' +
    '<span class="ar-av ' + avClass(p.uid) + '">' + esc(initials(p.name)) + '</span>' +
    '<span class="ar-row-main">' +
      '<span class="ar-row-top">' +
        (multi ? '<span class="ar-forum" title="Several questions">' + IC.hash + '</span>' : "") +
        '<b class="ar-row-name">' + esc(p.name) + '</b>' +
        (r.chat.length && r.chat[r.chat.length - 1].from === "admin" ? '<span class="ar-row-tick' + (r.seen ? " read" : "") + '">' + (r.seen ? IC.tick2 : IC.tick) + '</span>' : "") +
        '<span class="ar-row-time">' + esc(listTime(p.lastAt)) + '</span>' +
      '</span>' +
      '<span class="ar-row-bot">' +
        '<span class="ar-row-text">' + (multi ? '<span class="ar-topic-n">' + p.rows.length + ' questions</span> · ' : "") + lastText(r) + '</span>' +
        (p.unread ? '<span class="ar-unread">' + p.unread + '</span>' : "") +
      '</span>' +
    '</span></button>';
}
function topicRow(r, i) {
  const active = S.chat && S.chat.uid === r.uid && S.chat.quid === r.quid;
  const un = unreadOf(r);
  const m = r.chat[r.chat.length - 1];
  return '<button type="button" class="ar-row ar-topic' + (active ? " is-active" : "") + '" data-topic-uid="' + r.uid + '" data-topic-quid="' + esc(r.quid) + '">' +
    '<span class="ar-tico ' + secClass(r.section) + '">' + esc(secAbbr(r.section)) + '</span>' +
    '<span class="ar-row-main">' +
      '<span class="ar-row-top">' +
        '<b class="ar-row-name">' + esc(questionPreview(r.quid, reasonOf(r))) + '</b>' +
        (m && m.from === "admin" ? '<span class="ar-row-tick' + (r.seen ? " read" : "") + '">' + (r.seen ? IC.tick2 : IC.tick) + '</span>' : "") +
        '<span class="ar-row-time">' + esc(listTime(lastAtOf(r))) + '</span>' +
      '</span>' +
      '<span class="ar-row-bot">' +
        '<span class="ar-row-text"><span class="ar-st ' + (isDone(r) ? "ok" : "wait") + '">' + (r.edited ? "Edited" : isOk(r) ? "No change" : esc(reasonOf(r))) + '</span> ' + lastText(r) + '</span>' +
        (un ? '<span class="ar-unread">' + un + '</span>' : "") +
      '</span>' +
    '</span></button>';
}
async function paintChats(keepScroll) {
  const seq = ++S.paintSeq;
  $("rqList").hidden = true; $("arChats").hidden = false;
  $("rqMore").hidden = S.next == null; $("rqEnd").hidden = true;
  const list = $("arChatList"), head = $("arTopicsHead"), sc = $("rqScroll");
  const y = keepScroll ? sc.scrollTop : 0;
  if (!S.loaded) { list.innerHTML = ""; return; }
  const p = S.person != null ? personOf(S.person) : null;
  if (p) {
    // topics of one reporter (Telegram forum)
    $("arChats").classList.add("is-topics");
    head.hidden = false;
    head.innerHTML = '<button type="button" class="icon-btn ar-topics-back" data-topics-back aria-label="Back to chats">' + IC.back2 + '</button>' +
      '<span class="ar-av ' + avClass(p.uid) + '">' + esc(initials(p.name)) + '</span>' +
      '<div class="ar-topics-who"><b>' + esc(p.name) + '</b><small>' + p.rows.length + ' reported questions · ' +
        (p.unread ? p.unread + " unread" : "all read") + '</small></div>';
    const need = p.rows.map(r => r.quid).filter(q => !(q in S.bodies));
    list.innerHTML = p.rows.map(topicRow).join("");
    if (need.length) {
      try { await ensureBodies(need); } catch (e) { if (e && e.auth) return lockOut(); }
      if (seq !== S.paintSeq) return;
      list.innerHTML = p.rows.map(topicRow).join("");
    }
  } else {
    $("arChats").classList.remove("is-topics");
    head.hidden = true; head.innerHTML = "";
    const q = S.search.trim().toLowerCase();
    const ps = people().filter(x => !q || x.name.toLowerCase().indexOf(q) >= 0 || String(x.uid) === q);
    list.innerHTML = ps.length ? ps.map(personRow).join("")
      : '<div class="rq-empty"><div class="rq-empty-ico">' + IC.reply + '</div><h3>' + (q ? "No reporter found" : "No chats yet") + '</h3><p>' +
        (q ? "Try another name." : "Every user who reports a question shows up here.") + '</p></div>';
  }
  sc.scrollTop = y;
}
function openPerson(uid, push) {
  const p = personOf(uid);
  if (!p) return;
  if (p.rows.length === 1) { openChat(uid, p.rows[0].quid); return; }
  S.person = uid;
  if (!S.wide && push !== false) history.pushState({ ar: "person", uid: uid }, "", location.pathname + location.search + "#person=" + uid);
  $("rqScroll").scrollTop = 0;
  paintChats(false);
}
function closePerson() {
  if (S.person == null) return;
  if (!S.wide && history.state && history.state.ar === "person") { history.back(); return; }
  S.person = null;
  paintChats(false);
}

// ══════════════════════════════════════════════════════════════════════════
//  CHAT (admin side: admin = right / green, reporter = left / white)
// ══════════════════════════════════════════════════════════════════════════
const canReply = m => m && m._i != null && (!m._st || m._st === "sent");
function curRow() { return S.chat ? findRow(S.chat.uid, S.chat.quid) : null; }
function threadOf(r) { return (r ? r.chat : []).map((m, i) => Object.assign({}, m, { _i: m._st && m._st !== "sent" ? null : i, _ref: m })); }
function whoName(m, r) { return m.from === "admin" ? "You" : nameOf(r); }
function quoteHtml(thread, k, r) {
  const q = thread.find(x => x._i === k);
  if (!q) return "";
  return '<span class="rq-quote" data-jump="' + k + '"><b>' + esc(whoName(q, r)) + '</b><span>' + esc(msgPreview(q).slice(0, 160)) + '</span></span>';
}
function bubble(m, cls, inner, r) {
  const out = m.from === "admin";
  const ms = toMs(m.at);
  let tick = "";
  if (out) tick = m._st === "sending" ? IC.wait : m._st === "fail" ? IC.fail : (r.seen ? IC.tick2 : IC.tick);
  const rep = canReply(m);
  return '<div class="rq-msg ' + (out ? "out" : "in") + " " + cls + (m._st === "fail" ? " fail" : "") + '"' +
    (m._id ? ' data-mid="' + m._id + '"' : "") + (m._i != null ? ' data-i="' + m._i + '"' : "") + '>' +
    (rep ? '<button type="button" class="rq-reply-btn" data-reply="' + m._i + '" aria-label="Reply" title="Reply">' + IC.back + '</button>' +
           '<span class="rq-swipe-ico" aria-hidden="true">' + IC.back + '</span>' : "") +
    '<div class="rq-bubble">' + inner +
    (ms || tick ? '<span class="rq-spacer"></span><span class="rq-meta">' + (ms ? esc(timeLabel(ms)) : "") + tick + '</span>' : "") +
    '</div></div>' +
    (m._st === "fail" ? '<button type="button" class="rq-retry" data-retry-mid="' + m._id + '">Not sent · Tap to retry</button>' : "");
}
function paintChat(scrollBottom) {
  const r = curRow();
  if (!r) return;
  const thread = threadOf(r);
  const list = $("rqChatList");
  const side = x => x ? (x.from === "admin" ? "out" : "in") : "";
  let html = "", lastDay = "";
  thread.forEach((m, i) => {
    const ms = toMs(m.at);
    if (ms && dayKey(ms) !== lastDay) { lastDay = dayKey(ms); html += '<div class="rq-day"><span>' + esc(dayLabel(ms)) + '</span></div>'; }
    const prev = thread[i - 1], next = thread[i + 1];
    const nextDay = next && toMs(next.at) && ms && dayKey(toMs(next.at)) !== dayKey(ms);
    const firstInGroup = !prev || side(prev) !== side(m) || (ms && prev && toMs(prev.at) && dayKey(toMs(prev.at)) !== dayKey(ms));
    const tail = !next || side(next) !== side(m) || nextDay;
    const cls = (firstInGroup ? "first " : "") + (tail ? "tail" : "");
    const quote = m.r != null ? quoteHtml(thread, Number(m.r), r) : "";
    let inner;
    if (isReport(m)) {
      inner = '<span class="rq-name">' + esc(nameOf(r)) + '</span>' +
              '<span class="rq-report-head">' + IC.flag + 'Report</span>' +
              '<span class="rq-report-reason">' + esc(m.reason || "Reported") + '</span>' +
              (m.details ? '<span class="rq-report-details">' + esc(m.details) + '</span>' : "");
    } else {
      inner = (m.from !== "admin" && firstInGroup ? '<span class="rq-name">' + esc(nameOf(r)) + '</span>' : "") + quote + esc(m.text || "");
    }
    html += bubble(m, cls, inner, r);
    if (i === 0 && thread.length === 1 && !r.edited) {
      html += '<div class="rq-thread-hint"><span><b>New report</b>Reply here, or tap ✎ (top right) to edit the question. ' + esc(firstName(nameOf(r))) + ' sees your message in his Reported page.</span></div>';
    }
  });
  if (r.edited) html += '<div class="rq-sys"><span>' + IC.check + 'You corrected this question on D1</span></div>';
  list.innerHTML = html;
  paintReplyBar();
  const sc = $("rqChatScroll");
  if (scrollBottom) requestAnimationFrame(() => { sc.scrollTop = sc.scrollHeight; });
}
function paintQPanel() {
  const panel = $("rqQPanel");
  panel.innerHTML = "";
  const r = curRow();
  if (!r) return;
  const g = groupOf(r.quid);
  const card = cardFor(g, 1, langSelect());
  const head = card.querySelector(".mmh-card-head");
  if (head) head.insertAdjacentHTML("afterend", metaStrip(g));
  panel.appendChild(card);
  if (typeof renderMath === "function") renderMath();
}
function setQPanel(open) {
  $("rqQLayer").hidden = !open;
  $("rqPin").setAttribute("aria-expanded", open ? "true" : "false");
  if (open) paintQPanel();
}
function chatSub(r) {
  const p = personOf(r.uid);
  const multi = p && p.rows.length > 1;
  const idx = multi ? p.rows.indexOf(r) + 1 : 0;
  return (multi ? "Question " + idx + " of " + p.rows.length + " · " : "") + reasonOf(r) + (r.edited ? " · Edited" : isOk(r) ? " · No change" : "");
}
async function openChat(uid, quid, push) {
  const r = findRow(uid, quid);
  if (!r) return;
  if (!S.chat || S.chat.uid !== uid || S.chat.quid !== quid) S.replyTo = null;
  if (!$("rqChat").hidden) saveDraft();
  S.chat = { uid: uid, quid: quid };
  if (S.wide) {
    if (S.edit && !closeEditor()) { S.chat = null; return; }
    push = false;
    if (S.tab !== "chats") { S.sideQuid = quid; markActive(); }
    setPane("chat");
  }
  if (!$("rqSheet").hidden) closeSheetUI();
  const n = nameOf(r);
  const av = $("arChatAvatar");
  av.className = "rq-chat-avatar ar-av " + avClass(uid);
  av.textContent = initials(n);
  $("arChatName").textContent = n;
  $("rqChatSub").textContent = chatSub(r);
  $("rqPinText").textContent = questionPreview(quid, reasonOf(r) + " · " + quid);
  setQPanel(false);
  $("rqChat").hidden = false;
  if (!S.wide) document.body.classList.add("rq-chat-open");
  paintChat(true);
  markRead(r);
  refreshLists();
  const inp = $("rqInput");
  inp.value = loadDraft();
  autosize(); syncSend();
  if (push !== false) history.pushState({ ar: "chat", uid: uid, quid: quid }, "", location.pathname + location.search + "#chat=" + uid + "-" + quid);
  if (!(quid in S.bodies)) {
    try { await ensureBodies([quid]); } catch (e) { if (e && e.auth) return lockOut(); }
    if (S.chat && S.chat.quid === quid) $("rqPinText").textContent = questionPreview(quid, reasonOf(r));
  }
}
function closeChatUI(quiet) {
  saveDraft();
  S.replyTo = null;
  $("rqChat").hidden = true;
  document.body.classList.remove("rq-chat-open");
  setQPanel(false);
  S.chat = null;
  if (S.wide && S.pane === "chat") setPane("empty");
  if (!quiet) paintAll(true);
}
function closeChat() {
  if ($("rqChat").hidden) return;
  if (S.wide) {
    const q = S.chat && S.chat.quid;
    closeChatUI(true);
    if (S.tab !== "chats" && q) openSide(q);
    paintAll(true);
    return;
  }
  if (history.state && history.state.ar === "chat") history.back();
  else { closeChatUI(); history.replaceState(null, "", location.pathname + location.search); }
}
// unread badges / lists behind the chat follow the read marks
function refreshLists() {
  paintBadges(); paintIntro();
  if (S.tab === "chats") paintChats(true);
  else {
    // cards: only the bar + chip of the affected card (no full repaint → no MathJax flicker)
    document.querySelectorAll("#rqList .rq-cell").forEach(c => {
      const g = groupOf(c.getAttribute("data-quid"));
      const bar = c.querySelector(".ar-bar");
      if (!g || !bar) return;
      bar.outerHTML = barFor(g);
      c.classList.toggle("is-new", !!g.unread);
    });
    if (S.wide && S.pane === "details" && S.sideQuid) {
      const g = groupOf(S.sideQuid);
      if (g) $("rqPaneBody").innerHTML = detailsHtml(g);
    }
  }
}

// ── reply-to (Telegram) ─────────────────────────────────────────────────────
function setReply(i) {
  const m = threadOf(curRow()).find(x => x._i === i);
  if (!canReply(m)) return;
  S.replyTo = i;
  paintReplyBar();
  const inp = $("rqInput");
  try { inp.focus({ preventScroll: true }); inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) {}
}
function clearReply() { if (S.replyTo === null) return; S.replyTo = null; paintReplyBar(); }
function paintReplyBar() {
  const bar = $("rqReplyBar"), sc = $("rqChatScroll");
  const r = curRow();
  const m = S.replyTo === null ? null : threadOf(r).find(x => x._i === S.replyTo);
  const atBottom = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 48;
  if (!m) { S.replyTo = null; bar.hidden = true; }
  else {
    $("rqReplyName").textContent = "Reply to " + (m.from === "admin" ? "yourself" : nameOf(r));
    $("rqReplyText").textContent = msgPreview(m).slice(0, 160);
    bar.hidden = false;
  }
  if (atBottom) sc.scrollTop = sc.scrollHeight;
}
function jumpTo(i) {
  const el = $("rqChatList").querySelector('.rq-msg[data-i="' + i + '"]');
  if (!el) return;
  el.scrollIntoView({ block: "center", behavior: "smooth" });
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  setTimeout(() => el.classList.remove("flash"), 1200);
}
function bindSwipe(list) {
  const MAX = 84, GO = 56;
  let st = null;
  list.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) { st = null; return; }
    const row = e.target.closest(".rq-msg[data-i]");
    if (!row || !row.querySelector(".rq-swipe-ico")) { st = null; return; }
    const t = e.touches[0];
    st = { row: row, x: t.clientX, y: t.clientY, on: false, dead: false, ready: false,
           bub: row.querySelector(".rq-bubble"), ico: row.querySelector(".rq-swipe-ico") };
  }, { passive: true });
  list.addEventListener("touchmove", e => {
    if (!st || st.dead) return;
    const t = e.touches[0];
    const dx = t.clientX - st.x, dy = t.clientY - st.y;
    if (!st.on) {
      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) { st.dead = true; return; }
      if (dx < -10 && Math.abs(dx) > Math.abs(dy) * 1.2) { st.on = true; st.row.classList.add("swiping"); }
      else return;
    }
    if (e.cancelable) e.preventDefault();
    const pull = Math.max(-MAX, Math.min(0, dx));
    const eased = pull > -GO ? pull : -GO - (-pull - GO) * 0.35;
    st.bub.style.transform = "translateX(" + eased + "px)";
    const p = Math.min(1, -pull / GO);
    st.ico.style.opacity = String(p);
    st.ico.style.transform = "scale(" + (0.4 + 0.6 * p) + ")";
    const ready = -pull >= GO;
    if (ready !== st.ready) {
      st.ready = ready;
      st.row.classList.toggle("ready", ready);
      if (ready && navigator.vibrate) try { navigator.vibrate(8); } catch (e2) {}
    }
  }, { passive: false });
  const end = () => {
    if (!st) return;
    const s0 = st; st = null;
    if (!s0.on) return;
    s0.row.classList.remove("swiping", "ready");
    s0.bub.style.transform = ""; s0.ico.style.opacity = ""; s0.ico.style.transform = "";
    if (s0.ready) setReply(Number(s0.row.getAttribute("data-i")));
  };
  list.addEventListener("touchend", end);
  list.addEventListener("touchcancel", end);
}
function bindTrackpadSwipe(list) {
  const GO = 56, MAX = 84;
  let st = null, timer = 0;
  const finish = () => {
    if (!st) return;
    const s0 = st; st = null;
    s0.row.classList.remove("swiping", "ready");
    s0.bub.style.transform = ""; s0.ico.style.opacity = ""; s0.ico.style.transform = "";
    if (s0.ready) setReply(Number(s0.row.getAttribute("data-i")));
  };
  list.addEventListener("wheel", e => {
    if (!st) {
      if (Math.abs(e.deltaX) <= Math.abs(e.deltaY) || e.deltaX <= 0) return;
      const row = e.target.closest(".rq-msg[data-i]");
      if (!row || !row.querySelector(".rq-swipe-ico")) return;
      st = { row: row, pull: 0, ready: false, bub: row.querySelector(".rq-bubble"), ico: row.querySelector(".rq-swipe-ico") };
      row.classList.add("swiping");
    }
    e.preventDefault();
    st.pull = Math.max(0, Math.min(MAX, st.pull + e.deltaX * (e.deltaMode === 1 ? 16 : 1)));
    const eased = st.pull < GO ? st.pull : GO + (st.pull - GO) * 0.35;
    st.bub.style.transform = "translateX(" + (-eased) + "px)";
    const p = Math.min(1, st.pull / GO);
    st.ico.style.opacity = String(p); st.ico.style.transform = "scale(" + (0.4 + 0.6 * p) + ")";
    st.ready = st.pull >= GO; st.row.classList.toggle("ready", st.ready);
    clearTimeout(timer); timer = setTimeout(finish, 140);
  }, { passive: false });
}
// chat drafts (sessionStorage, per reporter + question)
const chatDraftKey = () => S.chat ? "mmh_ar_cdraft_" + S.chat.uid + "_" + S.chat.quid : "";
function loadDraft() { try { return sessionStorage.getItem(chatDraftKey()) || ""; } catch (e) { return ""; } }
function saveDraft() {
  if (!S.chat) return;
  try {
    const v = $("rqInput").value;
    if (v.trim()) sessionStorage.setItem(chatDraftKey(), v); else sessionStorage.removeItem(chatDraftKey());
  } catch (e) {}
}
function autosize() { const t = $("rqInput"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 132) + "px"; }
function syncSend() { $("rqSend").disabled = !$("rqInput").value.trim(); }

let midSeq = 0;
async function sendMessage(text, existing) {
  const r = curRow();
  if (!r) return;
  const uid = r.uid, quid = r.quid;
  let m = existing;
  if (!m) {
    m = { from: "admin", text: text, at: Math.floor(Date.now() / 1000), _st: "sending", _id: "m" + (++midSeq) };
    if (S.replyTo !== null) m.r = S.replyTo;
    r.chat.push(m);
    clearReply();
  } else m._st = "sending";
  paintChat(true);
  try {
    const d = await API.reply(uid, quid, m.text, m.r);
    m._st = "sent"; if (d && d.at) m.at = d.at; delete m._id;
    if (d && Array.isArray(d.thread)) {
      const pending = r.chat.filter(x => x._st && x !== m && x._st !== "sent");
      r.chat = d.thread.concat(pending);
    }
    r.seen = false;                         // the user has a new admin message to see
  } catch (e) {
    if (e && e.auth) return lockOut();
    m._st = "fail";
  }
  if (S.chat && S.chat.uid === uid && S.chat.quid === quid) { paintChat(true); markRead(r); }
  refreshLists();
}

// ══════════════════════════════════════════════════════════════════════════
//  EDITOR — Question JSON · live rules check · Save local · Update on D1
// ══════════════════════════════════════════════════════════════════════════
function edDirty() { return !!S.edit && $("arJson").value !== S.edit.savedText; }
function gutter(ta, gut, errLine) {
  const n = ta.value.split("\n").length; let s = "";
  for (let i = 1; i <= n; i++) s += (i === errLine ? '<span class="err">' + i + "</span>" : i) + "\n";
  gut.innerHTML = s; gut.scrollTop = ta.scrollTop;
}
function readDraft(quid) { try { const d = JSON.parse(lsGet(DRAFT_KEY(quid)) || "null"); return d && typeof d.text === "string" ? d : null; } catch (e) { return null; } }
async function openEditor(quid) {
  if (S.edit && S.edit.quid === quid) { placeEditor(true); return; }
  if (S.edit && !closeEditor()) return;
  const g = groupOf(quid);
  if (!g) return;
  // the editor lives with the card: switch to the card's tab first
  const home = g.review ? "review" : "updated";
  if (S.tab !== home) switchTab(home, true);
  if (!$("rqChat").hidden) closeChatUI(true);
  if (!$("rqSheet").hidden) closeSheetUI();
  try { await ensureBodies([quid]); } catch (e) { if (e && e.auth) return lockOut(); toast("Could not load the question."); return; }
  const b = S.bodies[quid];
  if (!b || b.missing) { toast("This question is not in the question bank (D1)."); return; }
  const text = JSON.stringify(R.expand(b.body), null, 2);
  S.edit = { quid: quid, original: b.body, originalText: R.stringify(b.body), originalPretty: text, base: b.base, source: b.source,
             savedText: text, parsed: null, check: null, view: "full" };
  // a local draft → keep it as the "saved" text and preview, the admin decides
  const d = readDraft(quid);
  $("arJson").value = text;
  $("arJson").scrollTop = 0;
  $("arEdQuid").textContent = quid;
  $("arMsg").value = "";
  const to = $("arTo");
  to.innerHTML = (g.rows.length > 1 ? '<option value="all">All ' + g.rows.length + ' reporters</option>' : "") +
    g.rows.map(r => '<option value="' + r.uid + '">' + esc(nameOf(r)) + '</option>').join("") +
    '<option value="none">No message</option>';
  to.value = g.rows.length > 1 ? "all" : String(g.rows[0].uid);
  setEdView("full");
  paintDraftBanner(d);
  liveCheck();
  if (S.wide) { S.sideQuid = quid; setPane("editor"); markActive(); }
  await paintCards(true);
  placeEditor(true);
}
function paintDraftBanner(d) {
  const bn = $("arEdDraft");
  if (!S.edit || !d || d.text === $("arJson").value) { bn.hidden = true; bn.innerHTML = ""; return; }
  const old = d.base !== S.edit.base;
  bn.className = "ar-ed-draft" + (old ? " is-old" : "");
  bn.innerHTML = '<span>' + IC.draft + (old ? "<b>Draft is for an OLDER version</b> — the question changed on D1 after it" : "<b>Local draft</b> on this device") +
    ' · saved ' + esc(agoText(d.at)) + '</span>' +
    '<span class="ar-ed-draft-btns"><button type="button" class="ar-tool is-primary" data-draft="use">Use draft</button>' +
    '<button type="button" class="ar-tool" data-draft="discard">Discard</button></span>';
  bn.hidden = false;
}
function placeEditor(scroll) {
  const ed = $("arEditor");
  document.body.classList.toggle("ar-editing", !!S.edit);
  if (!S.edit) { ed.hidden = true; if (ed.parentNode !== document.body) document.body.appendChild(ed); return; }
  ed.hidden = false;
  if (S.wide) {
    if (ed.parentNode !== $("arPaneEditor")) $("arPaneEditor").appendChild(ed);
    setPane("editor");
    // the card on the left is the live preview → bring it into view (e.g. opened from a chat)
    const wc = cellOf(S.edit.quid);
    if (scroll && wc) setTimeout(() => wc.scrollIntoView({ block: "start", behavior: "smooth" }), 60);
  } else {
    const cell = cellOf(S.edit.quid);
    const card = cell && cell.querySelector(".mmh-card");
    if (card && ed.parentNode !== card) card.appendChild(ed);
    else if (!card && ed.parentNode !== document.body) { document.body.appendChild(ed); ed.hidden = true; }
    if (scroll && cell) setTimeout(() => cell.querySelector(".ar-bar").scrollIntoView({ block: "start", behavior: "smooth" }), 60);
  }
  gutter($("arJson"), $("arGut"));
}
function closeEditor(force) {
  if (!S.edit) return true;
  if (!force && edDirty() && !confirm("Close the editor? Changes since the last “Save local” will be lost.")) return false;
  const q = S.edit.quid;
  S.edit = null;
  placeEditor();
  if (S.wide && S.pane === "editor") { setPane("empty"); S.sideQuid = ""; }
  const cell = cellOf(q);
  if (cell) { cell.classList.remove("is-editing"); const g = groupOf(q); const bar = cell.querySelector(".ar-bar"); if (g && bar) bar.outerHTML = barFor(g); }
  markActive();
  return true;
}
function setEdView(v) {
  if (!S.edit) return;
  S.edit.view = v;
  document.querySelectorAll("[data-edview]").forEach(b => b.classList.toggle("on", b.getAttribute("data-edview") === v));
  $("arCodeFull").hidden = v !== "full"; $("arEdToolsFull").hidden = v !== "full";
  $("arCodeBank").hidden = v !== "bank"; $("arEdToolsBank").hidden = v !== "bank";
  if (v === "bank") paintBank();
}
function liveCheck() {
  if (!S.edit) return;
  const text = $("arJson").value;
  const p = R.parseJSON(text);
  const sx = $("arSyntax");
  S.edit.parsed = null; S.edit.check = null;
  if (!p.ok) {
    sx.className = "ar-syntax bad";
    sx.innerHTML = '<span>JSON syntax error' + (p.line ? " at line " + p.line + ", column " + p.col : "") + ' — ' + esc(p.error) + '</span>' +
      (p.line ? '<button type="button" class="ar-tool" data-goline="' + p.line + '" data-gocol="' + (p.col || 1) + '">Go to line</button>' : "") +
      (p.hint ? '<small>' + esc(p.hint) + '</small>' : "");
    gutter($("arJson"), $("arGut"), p.line);
    paintChecks(null); paintEdState(); return;
  }
  gutter($("arJson"), $("arGut"));
  S.edit.parsed = p.value;
  S.edit.check = R.check(p.value, S.edit.original);
  const c = S.edit.check;
  const same = c.ok && c.text === S.edit.originalText;
  sx.className = "ar-syntax " + (c.ok ? "ok" : "warn");
  sx.innerHTML = '<span>' + (c.ok ? (same ? "JSON OK · all rules passed · same as D1" : "JSON OK · all rules passed · " + changedKeys(S.edit.original, c.body).length + " field(s) changed")
                                   : "JSON syntax OK · " + c.errors.length + " rule error(s) below") + '</span>';
  paintChecks(c); paintEdState();
  if (S.edit.view === "bank") paintBank();
}
function paintChecks(c) {
  const box = $("arChecks");
  if (!c) { box.innerHTML = ""; return; }
  const grp = (cls, title, items) => items.length ? '<div class="ar-grp ' + cls + '"><b>' + title + ' (' + items.length + ')</b><ul>' +
    items.map(t => '<li>' + esc(t) + '</li>').join("") + '</ul></div>' : "";
  box.innerHTML = grp("g-err", "Errors — fix before Update", c.errors) +
                  grp("g-warn", "Warnings — check, Update still allowed", c.warnings) +
                  grp("g-fix", "Auto-fixed in the Q-Bank JSON", c.fixes);
}
function paintBank() {
  const c = S.edit && S.edit.check;
  const ta = $("arBank");
  if (!c || !c.ok) { ta.value = c ? "// fix the errors first — nothing would be saved" : "// fix the JSON syntax first"; $("arEdBankInfo").textContent = ""; }
  else {
    ta.value = JSON.stringify(c.body, null, 2);
    $("arEdBankInfo").textContent = (c.text === S.edit.originalText ? "same as D1 · " : "changed · ") + (c.bytes / 1024).toFixed(1) + " KB";
  }
  gutter(ta, $("arGutBank"));
}
function changedKeys(a, b) {
  const ks = new Set(Object.keys(a || {}).concat(Object.keys(b || {}))), out = [];
  ks.forEach(k => { if (JSON.stringify((a || {})[k]) !== JSON.stringify((b || {})[k])) out.push(k); });
  return out;
}
function paintEdState() {
  if (!S.edit) return;
  const st = $("arEdState");
  const c = S.edit.check;
  const dirty = edDirty();
  const changed = c && c.ok && c.text !== S.edit.originalText;
  let cls = "", txt = "= D1";
  if (!S.edit.parsed) { cls = "bad"; txt = "JSON error"; }
  else if (dirty) { cls = "warn"; txt = "Unsaved"; }
  else if (changed || (c && !c.ok)) { cls = "draft"; txt = "Saved local"; }
  st.className = "ar-ed-state " + cls; st.textContent = txt;
  $("arEdUpdate").disabled = !(c && c.ok);
  // No change: only while the JSON is still the D1 version and someone is still waiting
  const g = groupOf(S.edit.quid);
  $("arEdNoChange").disabled = !(c && c.ok && !changed && !dirty && g && g.rows.some(r => !isDone(r)));
}
function setFull(obj, msg) { $("arJson").value = JSON.stringify(obj, null, 2); liveCheck(); if (msg) toast(msg); }
function saveLocal() {
  if (!S.edit) return;
  liveCheck();
  if (!S.edit.parsed) { toast("Not saved — fix the JSON syntax first."); return; }
  const text = $("arJson").value;
  const quid = S.edit.quid;
  const c = S.edit.check;
  if (c && c.ok && c.text === S.edit.originalText) {
    lsDel(DRAFT_KEY(quid)); delete S.preview[quid];
    S.edit.savedText = text;
    toast("Same as D1 — nothing to keep. Draft cleared.");
  } else {
    lsSet(DRAFT_KEY(quid), JSON.stringify({ text: text, base: S.edit.base, at: Date.now() }));
    S.edit.savedText = text;
    try { S.preview[quid] = c && c.ok ? c.body : R.compact(S.edit.parsed); } catch (e) { delete S.preview[quid]; }
    toast("Saved on this device · card shows the preview");
  }
  $("arEdDraft").hidden = true;
  paintEdState();
  repaintCard(quid);
}
// one card again (the editor is moved out first so it survives, then put back)
function repaintCard(quid) {
  const cell = cellOf(quid);
  if (!cell) return;
  const g = groupOf(quid);
  const ed = $("arEditor");
  if (ed.parentNode && cell.contains(ed)) document.body.appendChild(ed);
  const idx = Array.prototype.indexOf.call($("rqList").children, cell) + 1;
  const card = cardFor(g, idx, headExtra(g));
  const head = card.querySelector(".mmh-card-head");
  if (head) head.insertAdjacentHTML("afterend", metaStrip(g));
  card.insertAdjacentHTML("beforeend", barFor(g));
  cell.innerHTML = ""; cell.appendChild(card);
  if (typeof renderMath === "function") renderMath();
  placeEditor();
}
function msgTarget() {
  const v = $("arTo").value;
  const text = $("arMsg").value.trim().slice(0, MSG_MAX);
  if (v === "none" || !text) return { uid: null, text: "", label: "" };
  if (v === "all") return { uid: null, text: text, label: "all reporters" };
  const r = findRow(Number(v), S.edit.quid);
  return { uid: Number(v), text: text, label: r ? nameOf(r) : "reporter" };
}
function askUpdate() {
  if (!S.edit) return;
  liveCheck();
  const c = S.edit.check;
  if (!c) { toast("Fix the JSON syntax first."); return; }
  if (!c.ok) { toast("Fix the rule errors first."); $("arChecks").scrollIntoView({ block: "center", behavior: "smooth" }); return; }
  const g = groupOf(S.edit.quid);
  const t = msgTarget();
  const changed = c.text !== S.edit.originalText;
  if (!changed && !t.text) { toast("Nothing changed — same as D1."); return; }
  const keys = changedKeys(S.edit.original, c.body);
  S.confirm = { changed: changed, t: t };
  const li = s => '<li>' + s + '</li>';
  let html = "";
  if (changed) {
    html += '<div class="rq-sec-label">Changed fields (' + keys.length + ')</div><div class="ar-keys">' + keys.map(k => '<span>' + esc(k) + '</span>').join("") + '</div>';
    if (c.warnings.length) html += '<div class="ar-grp g-warn"><b>Warnings (' + c.warnings.length + ')</b><ul>' + c.warnings.map(w => '<li>' + esc(w) + '</li>').join("") + '</ul></div>';
    if (c.fixes.length) html += '<div class="ar-grp g-fix"><b>Auto-fixed (' + c.fixes.length + ')</b><ul>' + c.fixes.map(w => '<li>' + esc(w) + '</li>').join("") + '</ul></div>';
  } else {
    html += '<div class="rq-hero is-replied"><div class="rq-hero-ico">' + IC.reply + '</div><div><div class="rq-hero-title">Question is the same as D1</div><div class="rq-hero-sub">Only the message will be sent. The question stays under review.</div></div></div>';
  }
  html += '<div class="rq-sec-label">What happens</div><ul class="ar-what">' +
    (changed ? li("<b>D1 bank</b> updated — safe: if someone saved in between, nothing is overwritten") +
               li("<b>Cache</b> of this question cleared (now + again after 15 s)") +
               li("<b>All " + g.rows.length + (g.rows.length === 1 ? " reporter" : " reporters") + "</b> → Updated · “Question corrected”") : "") +
    (t.text ? li("<b>Message</b> → " + esc(t.label) + ': “' + esc(t.text.slice(0, 140)) + (t.text.length > 140 ? "…" : "") + '”') : (changed ? li("No message") : "")) +
    '</ul>';
  $("arConfirmTitle").textContent = changed ? "Update on D1?" : "Send message only?";
  $("arConfirmGo").textContent = changed ? "Update on D1" : "Send message";
  $("arConfirmBody").innerHTML = html;
  $("arConfirm").hidden = false;
}
function askNoChange() {
  if (!S.edit) return;
  const g = groupOf(S.edit.quid);
  const wait = g ? g.rows.filter(r => !isDone(r)) : [];
  if (!wait.length) { toast("Nobody is waiting on this question."); return; }
  const text = $("arMsg").value.trim().slice(0, MSG_MAX) || NOCHANGE_MSG;
  S.confirm = { mode: "nochange", text: text };
  $("arConfirmTitle").textContent = "No change needed?";
  $("arConfirmGo").textContent = "Yes, no change";
  $("arConfirmBody").innerHTML =
    '<div class="rq-hero is-fixed"><div class="rq-hero-ico">' + IC.check + '</div><div><div class="rq-hero-title">Question is correct</div>' +
      '<div class="rq-hero-sub">D1 is not touched. The report moves to the Updated tab (“No change”).</div></div></div>' +
    '<div class="rq-sec-label">What happens</div><ul class="ar-what">' +
      '<li><b>D1 bank</b> — nothing changes, no cache purge</li>' +
      '<li><b>' + wait.length + (wait.length === 1 ? " reporter" : " reporters") + '</b> (' + esc(wait.map(nameOf).join(", ")) + ') get this message — they see it as an admin reply</li>' +
      '<li><b>Message</b>: “' + esc(text.slice(0, 160)) + (text.length > 160 ? "…" : "") + '”' + ($("arMsg").value.trim() ? "" : " <small>(default — type in the message box to change it)</small>") + '</li>' +
    '</ul>';
  $("arConfirm").hidden = false;
}
async function doNoChange() {
  const quid = S.edit.quid, go = $("arConfirmGo");
  go.disabled = true; go.textContent = "Sending…";
  try {
    const d = await API.nochange(quid, S.confirm.text);
    const byUid = new Map((d.rows || []).map(x => [Number(x.uid), x.chat]));
    S.rows.forEach(r => {
      if (r.quid !== quid || !byUid.has(r.uid)) return;
      if (Array.isArray(byUid.get(r.uid))) r.chat = byUid.get(r.uid);
      r.seen = false; markRead(r);
    });
    closeConfirm();
    $("arMsg").value = "";
    lsDel(DRAFT_KEY(quid)); delete S.preview[quid];
    closeEditor(true);
    toast("Marked “No change” · " + byUid.size + (byUid.size === 1 ? " reporter" : " reporters") + " notified", 3200);
    paintAll(true);
  } catch (e) {
    closeConfirm();
    if (e && e.auth) return lockOut();
    toast("Could not send: " + (e && e.message || "network error"), 3600);
  } finally { go.disabled = false; }
}
function closeConfirm() { $("arConfirm").hidden = true; S.confirm = null; $("arConfirmGo").classList.remove("ar-btn-danger"); }
async function doUpdate() {
  if (S.confirm && S.confirm.mode === "delete") return doDelete();
  if (!S.edit || !S.confirm) return;
  if (S.confirm.mode === "nochange") return doNoChange();
  const { changed, t } = S.confirm;
  const quid = S.edit.quid;
  const go = $("arConfirmGo");
  go.disabled = true; go.textContent = changed ? "Updating…" : "Sending…";
  try {
    if (!changed) {
      const g = groupOf(quid);
      const targets = t.uid ? g.rows.filter(r => r.uid === t.uid) : g.rows;
      for (const r of targets) {
        const d = await API.reply(r.uid, quid, t.text, null);
        if (d && Array.isArray(d.thread)) r.chat = d.thread;
        r.seen = false; markRead(r);
      }
      closeConfirm();
      $("arMsg").value = "";
      toast("Message sent to " + t.label);
      refreshLists();
      return;
    }
    const d = await API.save({ quid: quid, full: S.edit.parsed, base: S.edit.base, uid: t.uid, message: t.text || undefined });
    closeConfirm();
    if (!d.changed) { toast("D1 already has this version — nothing changed."); return; }
    S.bodies[quid] = { body: d.body, base: d.base, source: S.edit.source };
    const byUid = new Map((d.rows || []).map(x => [Number(x.uid), x.chat]));
    S.rows.forEach(r => {
      if (r.quid !== quid) return;
      r.edited = true; r.seen = false;
      if (byUid.has(r.uid) && Array.isArray(byUid.get(r.uid))) r.chat = byUid.get(r.uid);
      if (t.text) markRead(r);
    });
    lsDel(DRAFT_KEY(quid)); delete S.preview[quid];
    closeEditor(true);
    if (!d.purged) {
      toast("Saved on D1 — cache clear failed, retrying…", 3200);
      try { const p = await API.purge([quid]); toast(p.purged ? "Saved on D1 · cache cleared" : "Saved on D1 · cache NOT cleared — try Refresh later", 3600); } catch (e) {}
    } else {
      toast("Updated on D1 · cache cleared · " + d.reports_marked + (d.reports_marked === 1 ? " reporter" : " reporters") + " notified", 3200);
    }
    paintAll(true);
  } catch (e) {
    if (e && e.auth) { closeConfirm(); return lockOut(); }
    closeConfirm();
    if (e && e.status === 409) {
      lsSet(DRAFT_KEY(quid), JSON.stringify({ text: $("arJson").value, base: S.edit.base, at: Date.now() }));
      S.edit.savedText = $("arJson").value; paintEdState();
      toast("Someone changed this question on D1 meanwhile. Your edit is saved locally — Refresh, then “Use draft”.", 5200);
    } else if (e && e.status === 400 && e.data && e.data.errors) {
      paintChecks({ errors: e.data.errors, warnings: e.data.warnings || [], fixes: e.data.fixes || [] });
      toast("The server found rule errors — see the list.");
    } else toast("Could not update: " + (e && e.message || "network error"), 3600);
  } finally {
    go.disabled = false;
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  EVENTS
// ══════════════════════════════════════════════════════════════════════════
function setLang(l) {
  if (["en", "hi", "bilingual"].indexOf(l) < 0 || l === S.lang) return;
  S.lang = l;
  try { localStorage.setItem("quiz_lang", l); } catch (e) {}
  paintAll(true);
  if (!$("rqQLayer").hidden) paintQPanel();
  if (S.chat) $("rqPinText").textContent = questionPreview(S.chat.quid);
}
function lockOut() {
  lsDel(PW_KEY);
  if (S.sel) exitSel();
  if (S.edit) { closeEditor(true); }
  if (!$("rqChat").hidden) closeChatUI(true);
  S.rows = []; S.bodies = {}; S.loaded = false;
  showGate("pw", "The password is not valid any more. Enter it again.");
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Copied " + t); }
  catch (e) {
    const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); toast("Copied " + t); } catch (e2) {}
    ta.remove();
  }
}
function goLine(line, col) {
  const ta = $("arJson"), lines = ta.value.split("\n");
  let pos = 0; for (let i = 0; i < line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
  pos += Math.max(0, (col || 1) - 1);
  ta.focus(); ta.setSelectionRange(pos, pos + 1);
  ta.scrollTop = Math.max(0, (line - 6) * 19.2);
}

function bind() {
  $("rqBack").addEventListener("click", () => {
    if (S.edit && !closeEditor()) return;
    if (window.MMHNav) { MMHNav.back("/index.html"); return; } /* t255 */
    const ref = document.referrer;
    if (history.length > 1 && ref && ref.indexOf(location.origin) === 0) history.back();
    else location.href = "/";
  });
  // gate
  $("arGateForm").addEventListener("submit", e => {
    e.preventDefault();
    const go = $("arGateBtn").getAttribute("data-go");
    if (go) { location.href = go; return; }
    const pw = $("arPw").value;
    if (!pw) { $("arGateErr").hidden = false; $("arGateErr").textContent = "Type the password."; return; }
    unlock(pw);
  });
  $("arPwEye").addEventListener("click", () => {
    const i = $("arPw"); i.type = i.type === "password" ? "text" : "password";
    $("arPwEye").classList.toggle("on", i.type === "text");
  });
  $("arLock").addEventListener("click", () => {
    if (S.edit && !closeEditor()) return;
    if (!confirm("Lock this page? The admin password will be removed from this device.")) return;
    lsDel(PW_KEY);
    if (S.sel) exitSel();
    if (!$("rqChat").hidden) closeChatUI(true);
    closeSide();
    S.rows = []; S.bodies = {}; S.loaded = false;
    showGate("pw");
  });
  $("rqRefresh").addEventListener("click", async () => {
    const b = $("rqRefresh");
    if (b.classList.contains("spin")) return;
    if (S.edit && edDirty() && !confirm("Refresh? Changes since the last “Save local” will be lost.")) return;
    b.classList.add("spin");
    try {
      const keep = S.edit ? S.edit.quid : "";
      if (S.edit) closeEditor(true);
      await loadInbox(true);
      paintAll(false);
      if (keep) openEditor(keep);
      if (S.wide && S.pane === "details" && S.sideQuid) openSide(S.sideQuid);
      if (S.chat) paintChat(false);
    } catch (e) { if (e && e.auth) lockOut(); else toast("Could not refresh. Try again."); }
    b.classList.remove("spin");
  });
  $("rqDock").addEventListener("click", e => {
    const b = e.target.closest(".ex-dock-item");
    if (b) switchTab(b.getAttribute("data-tab"));
  });
  $("rqMoreBtn").addEventListener("click", loadMore);
  bindSelect();

  // cards
  $("rqList").addEventListener("click", e => {
    const go = e.target.closest("[data-go-tab]");
    if (go) { switchTab(go.getAttribute("data-go-tab")); return; }
    const cp = e.target.closest("[data-copy]");
    if (cp) { copyText(cp.getAttribute("data-copy")); return; }
    const a = e.target.closest("[data-act]");
    if (!a || e.target.closest("#arEditor")) return;
    const cell = a.closest(".rq-cell");
    const quid = cell && cell.getAttribute("data-quid");
    if (!quid) return;
    const act = a.getAttribute("data-act");
    if (act === "details") openDetails(quid);
    else if (act === "edit") { if (S.edit && S.edit.quid === quid) closeEditor(); else openEditor(quid); }
    else if (act === "chat") {
      const g = groupOf(quid);
      if (!g) return;
      if (g.rows.length === 1) openChat(g.rows[0].uid, quid);
      else openDetails(quid);                 // several reporters → pick one in Details
    }
  });
  document.addEventListener("change", e => {
    if (e.target && e.target.classList && e.target.classList.contains("card-lang-dropdown")) setLang(e.target.value);
  });

  // details (sheet + pane): chat with a reporter, edit, copy
  const detailsClick = e => {
    const cp = e.target.closest("[data-copy]");
    if (cp) { copyText(cp.getAttribute("data-copy")); return; }
    const c = e.target.closest("[data-chat-uid]");
    if (c) {
      const uid = Number(c.getAttribute("data-chat-uid")), quid = c.getAttribute("data-chat-quid");
      if (!S.wide && history.state && history.state.ar === "sheet") {
        closeSheetUI();
        history.replaceState({ ar: "chat", uid: uid, quid: quid }, "", location.pathname + location.search + "#chat=" + uid + "-" + quid);
        openChat(uid, quid, false);
      } else openChat(uid, quid);
      return;
    }
    const ed = e.target.closest("[data-edit-quid]");
    if (ed) {
      const q = ed.getAttribute("data-edit-quid");
      if (!S.wide && history.state && history.state.ar === "sheet") { closeSheetUI(); history.back(); setTimeout(() => openEditor(q), 30); }
      else openEditor(q);
      return;
    }
    if (e.target.closest("[data-close]")) closeSheet();
  };
  $("rqSheet").addEventListener("click", detailsClick);
  $("rqPaneDetails").addEventListener("click", detailsClick);
  $("rqPaneClose").addEventListener("click", closeSide);
  const mq = window.matchMedia("(min-width:992px) and (hover:hover) and (pointer:fine)");
  if (mq.addEventListener) mq.addEventListener("change", placeLayout); else if (mq.addListener) mq.addListener(placeLayout);

  // chats tab
  $("arSearch").addEventListener("input", () => { S.search = $("arSearch").value; paintChats(false); });
  $("arChats").addEventListener("click", e => {
    if (e.target.closest("[data-topics-back]")) { closePerson(); return; }
    const p = e.target.closest("[data-person]");
    if (p) { openPerson(Number(p.getAttribute("data-person"))); return; }
    const t = e.target.closest("[data-topic-uid]");
    if (t) openChat(Number(t.getAttribute("data-topic-uid")), t.getAttribute("data-topic-quid"));
  });

  // chat
  $("rqChatBack").addEventListener("click", closeChat);
  $("arChatEdit").addEventListener("click", () => {
    const r = curRow();
    if (!r) return;
    const q = r.quid;
    if (!S.wide && history.state && history.state.ar === "chat") { closeChatUI(true); history.back(); setTimeout(() => openEditor(q), 30); }
    else { closeChatUI(true); openEditor(q); }
  });
  $("rqPin").addEventListener("click", () => setQPanel($("rqQLayer").hidden));
  $("rqQLayer").addEventListener("click", e => { if (e.target.closest("[data-qclose]")) setQPanel(false); else { const cp = e.target.closest("[data-copy]"); if (cp) copyText(cp.getAttribute("data-copy")); } });
  const inp = $("rqInput");
  inp.addEventListener("input", () => { autosize(); syncSend(); });
  inp.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(hover:hover) and (pointer:fine)").matches) {
      e.preventDefault();
      $("rqComposer").requestSubmit ? $("rqComposer").requestSubmit() : $("rqSend").click();
    }
  });
  $("rqComposer").addEventListener("submit", e => {
    e.preventDefault();
    const text = inp.value.trim().slice(0, MSG_MAX);
    if (!text) return;
    inp.value = ""; autosize(); syncSend();
    try { sessionStorage.removeItem(chatDraftKey()); } catch (e2) {}
    sendMessage(text);
    inp.focus();
  });
  $("rqChatList").addEventListener("click", e => {
    const rb = e.target.closest("[data-reply]");
    if (rb) { setReply(Number(rb.getAttribute("data-reply"))); return; }
    const jq = e.target.closest("[data-jump]");
    if (jq) { jumpTo(Number(jq.getAttribute("data-jump"))); return; }
    const b = e.target.closest("[data-retry-mid]");
    if (b) { const r = curRow(); const m = r && r.chat.find(x => x._id === b.getAttribute("data-retry-mid")); if (m) sendMessage(m.text, m); }
  });
  bindSwipe($("rqChatList"));
  bindTrackpadSwipe($("rqChatList"));
  $("rqReplyCancel").addEventListener("click", () => { clearReply(); $("rqInput").focus(); });
  $("rqReplyJump").addEventListener("click", () => { if (S.replyTo !== null) jumpTo(S.replyTo); });

  // editor
  const ta = $("arJson");
  let tmr = 0;
  ta.addEventListener("input", () => { clearTimeout(tmr); tmr = setTimeout(liveCheck, 200); gutter(ta, $("arGut")); paintEdState(); });
  ta.addEventListener("scroll", () => { $("arGut").scrollTop = ta.scrollTop; });
  $("arBank").addEventListener("scroll", () => { $("arGutBank").scrollTop = $("arBank").scrollTop; });
  ta.addEventListener("keydown", e => { if (e.key === "Tab") { e.preventDefault(); document.execCommand("insertText", false, "  "); } });
  document.querySelectorAll("[data-edview]").forEach(b => b.addEventListener("click", () => setEdView(b.getAttribute("data-edview"))));
  $("arEdClose").addEventListener("click", () => closeEditor());
  $("arEdFormat").addEventListener("click", () => { if (S.edit && S.edit.parsed) setFull(S.edit.parsed, "Formatted."); else toast("Cannot format — fix the syntax error first."); });
  $("arEdClearSol").addEventListener("click", () => {
    if (!S.edit || !S.edit.parsed) { toast("Fix the syntax error first."); return; }
    const q = S.edit.parsed; q.solution_text = { en: "", hi: "" }; q.solution_image = ""; if ("solution_video" in q) q.solution_video = "";
    setFull(q, "Solution cleared (text + image + video).");
  });
  $("arEdReset").addEventListener("click", () => {
    if (!S.edit) return;
    if (!confirm("Throw away all edits and go back to the D1 version?")) return;
    $("arJson").value = S.edit.originalPretty; S.edit.savedText = S.edit.originalPretty;
    lsDel(DRAFT_KEY(S.edit.quid)); delete S.preview[S.edit.quid];
    $("arEdDraft").hidden = true;
    liveCheck(); repaintCard(S.edit.quid); toast("Back to the D1 version.");
  });
  $("arEdCopy").addEventListener("click", () => { copyText($("arBank").value).then(() => toast("Q-Bank JSON copied")); });
  $("arEdSave").addEventListener("click", saveLocal);
  $("arEdUpdate").addEventListener("click", askUpdate);
  $("arEdNoChange").addEventListener("click", askNoChange);
  $("arEditor").addEventListener("click", e => {
    const gl = e.target.closest("[data-goline]");
    if (gl) { goLine(Number(gl.getAttribute("data-goline")), Number(gl.getAttribute("data-gocol"))); return; }
    const dr = e.target.closest("[data-draft]");
    if (dr && S.edit) {
      const d = readDraft(S.edit.quid);
      if (dr.getAttribute("data-draft") === "use" && d) {
        $("arJson").value = d.text; S.edit.savedText = d.text; liveCheck();
        try { const c = S.edit.check; S.preview[S.edit.quid] = c && c.ok ? c.body : R.compact(S.edit.parsed); } catch (e2) {}
        repaintCard(S.edit.quid); toast("Draft restored · card shows the preview");
      } else { lsDel(DRAFT_KEY(S.edit.quid)); delete S.preview[S.edit.quid]; repaintCard(S.edit.quid); }
      $("arEdDraft").hidden = true;
      paintEdState();
    }
  });
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s" && S.edit) { e.preventDefault(); saveLocal(); }
  });
  $("arConfirm").addEventListener("click", e => { if (e.target.closest("[data-cclose]")) closeConfirm(); });
  $("arConfirmGo").addEventListener("click", doUpdate);

  // hardware / browser back
  window.addEventListener("popstate", () => {
    const st = history.state;
    if (S.selBack) { S.selBack = false; if (!(st && st.ar === "sel")) return; }
    if (S.sel && !(st && st.ar === "sel")) { exitSel(true); return; }   // phone back = leave selection
    if (!$("rqSheet").hidden && !(st && st.ar === "sheet")) closeSheetUI();
    if (!$("rqChat").hidden && !(st && st.ar === "chat")) closeChatUI(true);
    if (S.person != null && !(st && (st.ar === "person" || st.ar === "chat"))) { S.person = null; }
    if (st && st.ar === "person" && S.tab === "chats") S.person = st.uid;
    if (st && st.ar === "chat" && $("rqChat").hidden && findRow(st.uid, st.quid)) { openChat(st.uid, st.quid, false); return; }
    paintAll(true);
  });
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    if (!$("arConfirm").hidden) { closeConfirm(); return; }
    if (S.sel) { exitSel(); return; }
    if (!$("rqChat").hidden && S.replyTo !== null) { clearReply(); return; }
    if (!$("rqQLayer").hidden) setQPanel(false);
    else if (!$("rqSheet").hidden) closeSheet();
    else if (!$("rqChat").hidden) closeChat();
    else if (S.person != null) closePerson();
    else if (S.wide && S.sideQuid && S.pane === "details") closeSide();
  });
  window.addEventListener("pagehide", saveDraft);
  window.addEventListener("beforeunload", e => { if (edDirty()) { e.preventDefault(); e.returnValue = ""; } });
}

// ══════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════
async function boot() {
  if (!R) { console.error("mmh-rules.js missing"); }
  bind();
  placeLayout();
  const qs = new URLSearchParams(location.search);
  if (["updated", "chats"].indexOf(qs.get("tab")) >= 0) S.tab = qs.get("tab");
  paintDock(); paintPaneEmpty();
  const role = await profileRole();
  if (role === "none") { showGate("login"); return; }
  if (role === "user") { showGate("denied"); return; }
  if (!lsGet(PW_KEY)) { showGate("pw"); return; }
  showApp();
  skeleton();
  try { await loadInbox(true); afterLoad(); }
  catch (e) {
    if (e && e.auth) { lsDel(PW_KEY); showGate("pw", "The saved password is not valid any more. Enter it again."); return; }
    $("rqList").innerHTML = '<div class="rq-empty"><div class="rq-empty-ico">' + IC.info + '</div><h3>Could not load</h3>' +
      '<p>Check your internet connection and try again.</p><button type="button" class="rq-btn rq-btn-primary" onclick="location.reload()">Try again</button></div>';
  }
}

// ── phones + keyboard: the chat header must never scroll away ───────────────
// The chat is a fixed full-screen layer (header · messages · composer).
// Chrome / Android: <meta viewport … interactive-widget=resizes-content> makes the page
// itself shrink above the keyboard, so the layer simply gets shorter (nothing to do here).
// iOS Safari & browsers without it: only the VISIBLE area (visualViewport) shrinks and the
// page is panned up → pin the layer to the visible area. The newest message stays in view.
function keyboardFit() {
  const vv = window.visualViewport, el = document.getElementById("rqChat"), sc = document.getElementById("rqChatScroll");
  if (!el || !sc) return;
  let stick = true;
  sc.addEventListener("scroll", () => { stick = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 48; }, { passive: true });
  function fit() {
    const full = document.documentElement.clientHeight;
    const on = vv && !el.hidden && !document.body.classList.contains("rq-wide") && vv.scale < 1.01 && vv.height < full - 1;
    if (on) { el.style.top = vv.offsetTop + "px"; el.style.height = vv.height + "px"; el.style.bottom = "auto"; }
    else if (el.style.height) { el.style.top = ""; el.style.height = ""; el.style.bottom = ""; }
    if (stick && !el.hidden) sc.scrollTop = sc.scrollHeight;
  }
  if (vv) { vv.addEventListener("resize", fit); vv.addEventListener("scroll", fit); }
  window.addEventListener("resize", fit);
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { boot(); keyboardFit(); });
else { boot(); keyboardFit(); }
})();

/* ══════════════════════════════════════════════════════════════════════════
   mmh-upload-core.js — Upload Test: everything that is NOT screen code
   (same file in the app/website page and inlined into the standalone HTML;
    also loaded by the node tests). Needs mmh-rules.js (window.MMHRules) first.

   • Exam tag from the quiz id  = exact port of qb_build.py fresh_tag_parts()
     + fresh_tag_text() (bank build v6.2). Added ONLY to questions that have no
     exam tag yet (trailing tag = qb_build split_trailing_tag; a tag inside the
     text also counts). If English has a tag and Hindi not → Hindi gets the same.
   • prepare(data, opts) → what POST /tests/upload needs:
       meta, sections in R2 shape with items [localId, quid | "#k", c?, n?, {x}?],
       new[k] = bank body text of new question k (mmh-rules check = bank build).
     A question that already has a quid (item [localId, quid] or an object with
     "quid") is NOT sent again — D1 only checks that the quid exists.
   • items = qb_build.build_definitions(): marks only when they differ from meta,
     5th element {quiz_id} only when the question's quiz_id differs.
   • assemble(structure, bodies) = qb_build.assemble() → the full test JSON the
     user's browser builds (with "quid" in every question).
   • diff(old, new) → what changes in R2 for an existing test (confirm screen).
   ══════════════════════════════════════════════════════════════════════════ */
(function (root) {
"use strict";

var R = root.MMHRules;
var QUID_RE = /^Q[1-9]\d{9}$/;
var ID_RE = /^[A-Za-z0-9_-]{1,100}$/;
var SECTION_RE = /^[A-Za-z0-9](?:[A-Za-z0-9 _&().-]{0,58}[A-Za-z0-9)])?$/;
var PART_RE = /^PART-\d+$/;
var has = Object.prototype.hasOwnProperty;
function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }
function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }

/* ───────────────────────── exam tag (qb_build.py v6.2) ───────────────────────── */
var FM = "(JAN(?:UARY)?|FEB(?:RUARY)?|MAR(?:CH)?|APR(?:IL)?|MAY|JUNE?|JULY?|AUG(?:UST)?|SEPT?(?:EMBER)?|OCT(?:OBER)?|NOV(?:EMBER)?|DEC(?:EMBER)?)";
var FMON = { JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 };
var B = "(?:^|-)", E = "(?=-|$)";
var FDATES = [
  [B + "((?:19|20)\\d{2})-(\\d{1,2})-" + FM + E, "ydm"],
  [B + "(\\d{1,2})-" + FM + "-((?:19|20)\\d{2})" + E, "dmy"],
  [B + "(\\d{1,2})-(\\d{1,2})-((?:19|20)\\d{2})" + E, "dnY"],
  [B + "(\\d{2})-(\\d{1,2})-" + FM + E, "Ydm"],
  [B + "(\\d{2})-(\\d{1,2})" + FM + E, "Ydm"],
  [B + "(\\d{1,2})-?" + FM + E, "dm"]
];
var FRESH_NAME = { GD: "GD Constable", STENO: "Steno", NTPCG: "NTPC G" };
var FRESH_LEVEL = { GRAD: "(Graduate)", GRADUATE: "(Graduate)", HSL: "(12th)", MATRIC: "(10th)" };
var FRESH_UPPER = ["SSC", "RRB", "CGL", "CHSL", "CPO", "MTS", "GD", "NTPC", "UG", "G", "ALP", "CBT", "JE", "DP",
                   "HCM", "AWO", "TPO", "IMPS", "RPF", "SI"];

function pyTitle(w) {                       // Python str.title() for A-Z / 0-9 words
  return w.toLowerCase().replace(/(^|[^a-z])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); });
}
function cut(s, m) { return s.slice(0, m.index) + "-" + s.slice(m.index + m[0].length); }

function freshTagParts(quizId) {
  var u = String(quizId == null ? "" : quizId).trim().toUpperCase();
  var p = { name: "", tier: null, cbt: null, set: null, day: null, month: null, year: null, shift: null };
  var rest = u, m, i;
  for (i = 0; i < FDATES.length; i++) {
    m = new RegExp(FDATES[i][0]).exec(rest);
    if (!m) continue;
    var o = FDATES[i][1], y, d, mo;
    if (o === "ydm") { y = +m[1]; d = +m[2]; mo = FMON[m[3].slice(0, 3)]; }
    else if (o === "dmy") { d = +m[1]; mo = FMON[m[2].slice(0, 3)]; y = +m[3]; }
    else if (o === "dnY") { d = +m[1]; mo = +m[2]; y = +m[3]; }
    else if (o === "Ydm") { y = 2000 + +m[1]; d = +m[2]; mo = FMON[m[3].slice(0, 3)]; }
    else { y = null; d = +m[1]; mo = FMON[m[2].slice(0, 3)]; }
    if (!(d >= 1 && d <= 31 && mo >= 1 && mo <= 12)) continue;
    p.day = d; p.month = mo; p.year = y;
    rest = cut(rest, m);
    break;
  }
  m = /SHIFT-?(\d)/.exec(rest) || /(?:^|-)(\d)(?:ST|ND|RD|TH)-?SHIFT/.exec(rest) || /(?:^|-)S(\d)(?=-|$)/.exec(rest);
  if (m) p.shift = +m[1];
  rest = rest.replace(/SHIFT-?\d|(?:^|-)\d(?:ST|ND|RD|TH)-?SHIFT|(?:^|-)S\d(?=-|$)/g, "-");
  if (p.day) rest = rest.replace(new RegExp("(?:^|-)0?" + p.day + "-?" + FM + E, "g"), "-");
  m = /(?:^|-)(?:T|TIER-?)(\d)(?=-|$)/.exec(rest);
  if (m) { p.tier = +m[1]; rest = cut(rest, m); }
  m = /(?:^|-)CBT-?(\d)(?=-|$)/.exec(rest);
  if (m) { p.cbt = +m[1]; rest = cut(rest, m); }
  m = /(?:^|-)SET-?([A-Z0-9])(?=-|$)/.exec(rest);
  if (m) { p.set = m[1]; rest = cut(rest, m); }
  var words = [];
  rest.split("-").filter(Boolean).forEach(function (w) {
    if (/^(?:19|20)\d{2}$/.test(w)) p.year = p.year || +w;
    else if (/^\d{2}$/.test(w) && words.length === 1) p.year = p.year || 2000 + +w;
    else words.push(w);
  });
  if (words.length && (words[0] === "SSC" || words[0] === "RRB")) words = words.slice(1);
  var out = [];
  words.forEach(function (w) {
    if (has.call(FRESH_LEVEL, w)) out.push(FRESH_LEVEL[w]);
    else if (has.call(FRESH_NAME, w) && !out.length) out.push(FRESH_NAME[w]);
    else if (FRESH_UPPER.indexOf(w) !== -1 || /^[IVX]+$/.test(w) || !/[A-Z]/.test(w)) out.push(w);
    else out.push(pyTitle(w));
  });
  p.name = out.join(" ");
  return p;
}
function pad2(n) { return (n < 10 ? "0" : "") + n; }
function freshTagText(org, p) {
  if (!p || !p.name || !(p.day || p.year)) return null;
  var bits = [org, p.name];
  if (p.tier) bits.push("Tier " + p.tier);
  if (p.cbt) bits.push("CBT " + p.cbt);
  if (p.day) bits.push(pad2(p.day) + "/" + pad2(p.month) + (p.year ? "/" + pad2(p.year % 100) : ""));
  else bits.push(String(p.year));
  if (p.shift) bits.push("Shift " + p.shift);
  if (p.set) bits.push("Set " + p.set);
  return bits.join(" ");
}
/** SSC / RRB from the quiz id (the bank build took it from the repo folder ssc/ or rrb/). "" = unknown
 *  (JE, IMPS, … → the admin picks SSC / RRB in the tool). */
function guessOrg(quizId) {
  var u = String(quizId || "").toUpperCase();
  if (/^(?:RRB|NTPC|NTPCG|ALP|GROUP-D|GROUPD|TECHNICIAN|RPF)(?:-|$)/.test(u) || /^RRB-/.test(u)) return "RRB";
  if (/^(?:SSC|CGL|CHSL|MTS|CPO|GD|STENO|SELECTION-POST|SP|DP|PHASE)(?:-|$)/.test(u)) return "SSC";
  return "";
}
/** → { org, tag, parts, noYear } for the quiz id (tag null = cannot be made). */
function tagForQuiz(quizId, org) {
  var o = org === undefined ? guessOrg(quizId) : org;
  var p = freshTagParts(quizId);
  return { org: o, parts: p, tag: o ? freshTagText(o, p) : null, noYear: !!(p.day && !p.year) };
}

// qb_build.py split_trailing_tag + TAG_LIKE
var TAG_LIKE = /(?:19|20)\d{2}|shift|tier/i;
var TRAIL = "(?:\\s|<br\\s*/?>|&lt;br\\s*/?&gt;|&nbsp;|\\\\n)*";
var TRAIL_TAG_RE = new RegExp("^([\\s\\S]*?)" + TRAIL + "\\[([^\\[\\]]{3,160})\\]" + TRAIL + "$", "i");
function splitTrailingTag(text) {
  if (typeof text !== "string" || text.indexOf("[") === -1) return [text, null];
  var m = TRAIL_TAG_RE.exec(text);
  if (!m || !TAG_LIKE.test(m[2])) return [text, null];
  return [m[1], m[2].trim()];
}
// an exam tag INSIDE the text (qb_build is_any_exam_tag: known exam word + a year / date / shift / tier)
var ANY_EXAM = /\b(?:ssc|rrb|ntpc|alp|group[\s-]?d|technician|cgl|chsl|cpo|mts|gd|steno(?:grapher)?|selection post|phase|dp)\b/i;
var ANY_WHEN = /\b(?:19|20)\d{2}\b|\b\d{1,2}\/\d{1,2}(?:\/\d{2,4})?\b|\bshift\b|\btier\b/i;
function unesc(s) {
  return String(s).replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
}
function insideTag(text) {
  if (typeof text !== "string" || text.indexOf("[") === -1) return null;
  var re = /\[([^\[\]]{3,160})\]/g, m, s = unesc(text);
  while ((m = re.exec(s))) if (ANY_EXAM.test(m[1]) && ANY_WHEN.test(m[1])) return m[1].trim();
  return null;
}
function isBlank(v) { return R.isBlank(v); }
/** tag already in the question → { tag, where:"end"|"inside" } or null (qb_build find_tag). */
function findTag(q) {
  var qv = q.question, langs = isObj(qv) ? ["en", "hi"] : [null], i, t;
  for (i = 0; i < langs.length; i++) {
    t = splitTrailingTag(langs[i] ? qv[langs[i]] : qv)[1];
    if (t) return { tag: t, where: "end" };
  }
  for (i = 0; i < langs.length; i++) {
    t = insideTag(langs[i] ? qv[langs[i]] : qv);
    if (t) return { tag: t, where: "inside" };
  }
  return null;
}
/** question (copy) with the exam tag rules applied → { q, action: "kept"|"added"|"hi-added"|"none" } */
function applyTag(q0, tag) {
  var q = clone(q0), qv = q.question, f = findTag(q);
  if (f) {
    // qb_build same_tag_in_hi: English ends with a tag, Hindi has text but no tag → Hindi gets the same tag
    if (isObj(qv) && !isBlank(qv.en) && !isBlank(qv.hi) && typeof qv.hi === "string") {
      var te = splitTrailingTag(qv.en)[1], th = splitTrailingTag(qv.hi)[1];
      if (te && !th) { qv.hi = qv.hi + " [" + te + "]"; return { q: q, action: "hi-added", tag: te }; }
    }
    return { q: q, action: "kept", tag: f.tag };
  }
  if (!tag) return { q: q, action: "none", tag: null };
  // qb_build add_tag
  if (isObj(qv)) {
    ["en", "hi"].forEach(function (l) { if (!isBlank(qv[l]) && typeof qv[l] === "string") qv[l] = qv[l] + " [" + tag + "]"; });
  } else if (typeof qv === "string" && !isBlank(qv)) q.question = qv + " [" + tag + "]";
  return { q: q, action: "added", tag: tag };
}

/* ───────────────────────── test JSON → upload payload ───────────────────────── */
function sectionList(v) {
  if (Array.isArray(v)) return v;
  if (isObj(v) && Array.isArray(v.questions)) return v.questions;
  return null;
}
/** qb_build validate() + R2 name rules → error text or null */
function validateTest(data) {
  if (!isObj(data)) return "Top level is not an object { … }";
  if (!isObj(data.meta)) return "\"meta\" is missing";
  var secs = data.sections;
  if (!isObj(secs) || !Object.keys(secs).length) return "\"sections\" is missing or empty";
  var names = Object.keys(secs);
  for (var i = 0; i < names.length; i++) {
    var n = names[i], qs = sectionList(secs[n]);
    if (!SECTION_RE.test(n) || n.toLowerCase() === "meta") return "Section name \"" + n + "\" cannot be an R2 file name (A-Z a-z 0-9 space _ & ( ) . - , max 60)";
    if (qs === null) return "Section \"" + n + "\" is not a list / {questions:[]}";
    for (var j = 0; j < qs.length; j++) {
      var q = qs[j];
      if (Array.isArray(q)) { if (q.length < 2) return "Section \"" + n + "\" item " + (j + 1) + " is not [localId, quid]"; continue; }
      if (!isObj(q) || !has.call(q, "id")) return "Section \"" + n + "\" item " + (j + 1) + " is not a question with an \"id\"";
    }
  }
  return null;
}
function sameMark(a, b) { return a === b; }
/* marks: number OR text — "2", " 0.5 ", "+2", "-0.25", ".5", "1/3", "2/3" → number · "" → empty (= meta marks) · null stays null.
   → { ok, v (number | null | undefined = empty) } · ok:false = text that is not a number */
var MARK_NUM_RE = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/, MARK_FRAC_RE = /^([+-]?\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/;
function toMark(v) {
  if (v === null || v === undefined) return { ok: true, v: v };
  if (typeof v === "number") return { ok: isFinite(v), v: v };
  if (typeof v !== "string") return { ok: false, v: v };
  var s = v.trim().replace(/,/g, ".");
  if (s === "") return { ok: true, v: undefined };
  if (MARK_NUM_RE.test(s)) return { ok: true, v: Number(s) };
  var f = MARK_FRAC_RE.exec(s);
  if (f && Number(f[2]) !== 0) return { ok: true, v: Number(f[1]) / Number(f[2]) };
  return { ok: false, v: v };
}
function markErr(k, v) { return k + " " + JSON.stringify(v).slice(0, 30) + ": must be a number — 2, 0.5, \"2\", \"0.5\" or \"1/3\""; }
/** question copy with number marks ("" → the meta marks). errs gets the bad ones. */
function marksOf(q, meta, errs) {
  var o = q;
  ["correct_score", "negative_score"].forEach(function (k) {
    if (!has.call(q, k)) return;
    var m = toMark(q[k]);
    if (!m.ok) { errs.push(markErr(k, q[k])); return; }
    var v = m.v === undefined ? (meta[k] === undefined ? null : meta[k]) : m.v;
    if (v !== q[k]) { if (o === q) o = Object.assign({}, q); o[k] = v; }
  });
  return o;
}
/** qb_build build_definitions item for an object question */
function itemFor(q, quidOrNew, meta, mid) {
  var item = [q.id, quidOrNew], extras = {}, ex = false;
  if (!has.call(q, "quiz_id")) { extras.quiz_id = null; ex = true; }
  else if (q.quiz_id !== mid) { extras.quiz_id = q.quiz_id; ex = true; }
  var c = q.correct_score, n = q.negative_score;
  if (!(sameMark(c, meta.correct_score) && sameMark(n, meta.negative_score) && has.call(q, "correct_score") && has.call(q, "negative_score")) || ex) {
    item.push(has.call(q, "correct_score") ? (c === undefined ? null : c) : null, has.call(q, "negative_score") ? (n === undefined ? null : n) : null);
  }
  if (ex) item.push(extras);
  return item;
}
function normKey(q) {
  function t(v) {
    var s = isObj(v) ? v.en : v;
    if (typeof s !== "string") return "";
    s = splitTrailingTag(s)[0];
    return unesc(s.replace(/<[^>]*>/g, " ")).toLowerCase().replace(/\s+/g, " ").trim();
  }
  var k = t(q.question);
  if (!k) return null;
  return k + "\u241f" + [1, 2, 3, 4, 5].map(function (i) { return t(q["option_" + i]); }).join("\u241e");
}

/**
 * data = parsed test JSON. opts = { quizId, tag (exam tag text or "" = none), fields ({name: "keep"|"remove"} for NEW fields) }
 *   → also newFields[] = [{ name, nw, old, sample, choice }] — non-standard field names found (choice null = not answered yet)
 * → { ok, error?, quizId, meta, kind, names, sections, newBodies[], rows[], counts, problems:{errors[], warnings[]} }
 *   rows[i] = { sec, pos, lid, quid|null, newIndex|null, q (question shown), action, errors[], warnings[], fixes[], bytes }
 */
function prepare(data, opts) {
  opts = opts || {};
  var err = validateTest(data);
  if (err) return { ok: false, error: err };
  var quizId = String(opts.quizId || "").trim();
  if (!ID_RE.test(quizId)) return { ok: false, error: "Quiz id \"" + quizId + "\": only A-Z a-z 0-9 _ - (max 100)" };
  var meta = data.meta, mid = typeof meta.id === "string" && meta.id ? meta.id : quizId;
  var metaErr = [];
  ["correct_score", "negative_score"].forEach(function (k) {
    if (!has.call(meta, k)) return;
    var m = toMark(meta[k]);
    if (!m.ok) { metaErr.push("meta." + markErr(k, meta[k])); return; }
    if (m.v !== meta[k]) { if (meta === data.meta) meta = clone(data.meta); if (m.v === undefined) delete meta[k]; else meta[k] = m.v; }
  });
  var names = Object.keys(data.sections);
  var kind = names.every(function (n) { return PART_RE.test(n); }) ? "parts" : "full";
  var tag = opts.tag ? String(opts.tag).trim() : "";
  var rows = [], newBodies = [], sections = {}, errors = metaErr.slice(), warnings = [];
  var fieldOpts = { fields: isObj(opts.fields) ? opts.fields : {} }, nf = {};
  function scanFields(q, isNew) {                           // NEW (non-standard) field names → asked Keep / Remove
    if (!isObj(q)) return;
    Object.keys(q).forEach(function (k) {
      if (R.isKnownField(k)) return;
      var e = nf[k] || (nf[k] = { name: k, nw: 0, old: 0, sample: "", choice: fieldOpts.fields[k] || null });
      if (isNew) e.nw++; else e.old++;
      if (!e.sample) { var v = q[k]; e.sample = (typeof v === "string" ? v : JSON.stringify(v)).slice(0, 80); }
    });
  }
  var lidSeen = {}, dupKeys = {}, counts = { total: 0, nw: 0, old: 0, tagAdded: 0, tagKept: 0, tagHi: 0, tagNone: 0, bad: 0, warn: 0 };

  names.forEach(function (sname) {
    var sv = data.sections[sname], list = sectionList(sv), items = [];
    list.forEach(function (q, pos) {
      counts.total++;
      var row = { sec: sname, pos: pos, lid: null, quid: null, newIndex: null, q: null, action: "", errors: [], warnings: [], fixes: [], bytes: 0 };
      if (Array.isArray(q)) {                                   // R2 item [localId, quid, …]
        row.lid = q[0]; row.quid = q[1];
        if (!QUID_RE.test(String(q[1]))) row.errors.push("\"" + String(q[1]).slice(0, 20) + "\" is not a quid (Q + 10 digits)");
        var it = clone(q);
        [2, 3].forEach(function (i) {
          if (it.length <= i) return;
          var m = toMark(it[i]);
          if (!m.ok) row.errors.push(markErr(i === 2 ? "correct (3rd value)" : "negative (4th value)", it[i]));
          else it[i] = m.v === undefined ? (meta[i === 2 ? "correct_score" : "negative_score"] === undefined ? null : meta[i === 2 ? "correct_score" : "negative_score"]) : m.v;
        });
        items.push(it);
        counts.old++;
      } else if (has.call(q, "quid") && q.quid !== "" && q.quid != null) {   // full JSON with quid → D1 already has it
        row.lid = q.id; row.quid = String(q.quid); row.q = q;
        scanFields(q, false);
        if (!QUID_RE.test(row.quid)) row.errors.push("quid \"" + row.quid.slice(0, 20) + "\" is not Q + 10 digits");
        items.push(itemFor(marksOf(q, meta, row.errors), row.quid, meta, mid));
        counts.old++;
      } else {                                                  // NEW question → D1
        row.lid = q.id;
        var t = applyTag(q, tag);
        row.q = t.q; row.action = t.action; row.tag = t.tag;
        if (t.action === "added") counts.tagAdded++;
        else if (t.action === "kept") counts.tagKept++;
        else if (t.action === "hi-added") { counts.tagKept++; counts.tagHi++; }
        else counts.tagNone++;
        scanFields(q, true);
        var res = R.check(t.q, {}, fieldOpts);
        row.errors = res.errors.slice(); row.warnings = res.warnings.slice();
        var qm = marksOf(q, meta, row.errors);
        row.fixes = res.fixes.filter(function (f) { return !/^(id|quiz_id|correct_score|negative_score|hash): not stored/.test(f); });
        if (t.action === "none") row.warnings.push("no exam tag — and none could be made from the quiz id (type one in Exam tag)");
        if (t.action === "hi-added") row.fixes.push("question.hi: same exam tag as English added");
        if (res.ok) {
          row.newIndex = newBodies.length; row.bytes = res.bytes;
          newBodies.push(res.text);
          items.push(itemFor(qm, "#" + row.newIndex, meta, mid));
        } else items.push(itemFor(qm, "#?", meta, mid));
        var k = normKey(t.q);
        if (k) (dupKeys[k] = dupKeys[k] || []).push(row);
        counts.nw++;
      }
      var lk = String(row.lid);
      (lidSeen[lk] = lidSeen[lk] || []).push(row);
      rows.push(row);
    });
    sections[sname] = Array.isArray(sv) ? items : Object.keys(sv).reduce(function (o, key) {
      o[key] = key === "questions" ? items : clone(sv[key]); return o;
    }, {});
    if (!list.length) warnings.push("Section \"" + sname + "\" has no question");
  });
  Object.keys(dupKeys).forEach(function (k) {
    var g = dupKeys[k];
    if (g.length < 2) return;
    g.forEach(function (r) {
      r.warnings.push("same question + options as " + g.filter(function (x) { return x !== r; }).map(function (x) { return x.sec + " Q" + (x.pos + 1); }).join(", "));
    });
  });
  Object.keys(lidSeen).forEach(function (k) {
    var g = lidSeen[k];
    if (g.length > 1) g.forEach(function (r) { r.warnings.push("local id " + k + " is used " + g.length + " times in this test"); });
  });
  rows.forEach(function (r) {
    if (r.errors.length) { counts.bad++; r.errors.forEach(function (e) { errors.push(r.sec + " Q" + (r.pos + 1) + ": " + e); }); }
    if (r.warnings.length) counts.warn++;
  });
  var newFields = Object.keys(nf).map(function (k) { return nf[k]; });
  return { ok: errors.length === 0, quizId: quizId, meta: meta, mid: mid, kind: kind, names: names, sections: sections,
           newBodies: newBodies, rows: rows, counts: counts, problems: { errors: errors, warnings: warnings },
           newFields: newFields, fields: fieldOpts.fields };
}

/* ───────────────────────── R2 + bodies → full test JSON (qb_build assemble) ───────────────────────── */
var LANG_STD = ["question", "option_1", "option_2", "option_3", "option_4", "solution_text"];
var STR_STD = ["option_5", "option_image_1", "option_image_2", "option_image_3", "option_image_4",
               "option_image_5", "question_image", "solution_image", "solution_video"];
function restoreStd(q, slots) {
  LANG_STD.forEach(function (f) {
    if (f.indexOf("option_") === 0 && slots) return;
    var v = q[f];
    if (v === undefined || v === null) q[f] = { en: "", hi: "" };
    else if (isObj(v)) { if (!has.call(v, "en")) v.en = ""; if (!has.call(v, "hi")) v.hi = ""; }
  });
  if (slots) {
    for (var k = 1; k <= 5; k++) {
      var f = "option_" + k, v = q[f];
      if (slots.indexOf(k) !== -1) {
        if (v === undefined || v === null) q[f] = { en: "", hi: "" };
        else if (isObj(v)) { if (!has.call(v, "en")) v.en = ""; if (!has.call(v, "hi")) v.hi = ""; }
      } else if (v === undefined || v === null) q[f] = "";
    }
  }
  STR_STD.forEach(function (f) { if (!has.call(q, f)) q[f] = ""; });
}
function assemble(test, bodies) {
  var meta = test.meta, mid = typeof meta.id === "string" && meta.id ? meta.id : null, sections = {}, missing = [];
  Object.keys(test.sections).forEach(function (name) {
    var sv = test.sections[name], qs = [];
    sectionList(sv).forEach(function (it) {
      var lid = it[0], quid = it[1], b = bodies[quid];
      if (!b) { missing.push(quid); return; }
      var q = { id: lid, quid: quid };
      Object.keys(b).forEach(function (k) { if (k !== "option_slots") q[k] = clone(b[k]); });
      q.quiz_id = mid;
      var c, n;
      if (it.length >= 4) { c = it[2]; n = it[3]; } else { c = meta.correct_score; n = meta.negative_score; }
      if (c !== undefined && c !== null) q.correct_score = c;
      if (n !== undefined && n !== null) q.negative_score = n;
      if (it.length >= 5 && isObj(it[4])) Object.keys(it[4]).forEach(function (k) { if (it[4][k] === null) delete q[k]; else q[k] = it[4][k]; });
      restoreStd(q, Array.isArray(b.option_slots) ? b.option_slots : null);
      qs.push(q);
    });
    sections[name] = Array.isArray(sv) ? qs : Object.keys(sv).reduce(function (o, k) { o[k] = k === "questions" ? qs : sv[k]; return o; }, {});
  });
  return { test: { meta: meta, sections: sections }, missing: missing };
}

/* ───────────────────────── existing test: what changes ───────────────────────── */
/** old/new = { meta, sections } (R2 shape). → { same, rows:[{sec, pos, lid, oldQuid, newQuid, kind}], sections:{added[],removed[]}, meta:[keys], counts } */
function diff(oldS, newS) {
  var out = { rows: [], secAdded: [], secRemoved: [], metaKeys: [], counts: { same: 0, changed: 0, added: 0, removed: 0 } };
  var on = Object.keys((oldS && oldS.sections) || {}), nn = Object.keys(newS.sections);
  nn.forEach(function (n) { if (on.indexOf(n) === -1) out.secAdded.push(n); });
  on.forEach(function (n) { if (nn.indexOf(n) === -1) out.secRemoved.push(n); });
  nn.concat(out.secRemoved).forEach(function (n) {
    var a = oldS && oldS.sections[n] ? sectionList(oldS.sections[n]) || [] : [], b = newS.sections[n] ? sectionList(newS.sections[n]) : [];
    var len = Math.max(a.length, b.length);
    for (var i = 0; i < len; i++) {
      var x = a[i], y = b[i];
      if (x && y) {
        var same = String(x[0]) === String(y[0]) && x[1] === y[1] && JSON.stringify(x.slice(2)) === JSON.stringify(y.slice(2));
        if (same) { out.counts.same++; continue; }
        out.counts.changed++;
        out.rows.push({ sec: n, pos: i, kind: "changed", oldLid: x[0], newLid: y[0], oldQuid: x[1], newQuid: y[1],
                        marks: JSON.stringify(x.slice(2)) !== JSON.stringify(y.slice(2)) });
      } else if (y) { out.counts.added++; out.rows.push({ sec: n, pos: i, kind: "added", newLid: y[0], newQuid: y[1] }); }
      else { out.counts.removed++; out.rows.push({ sec: n, pos: i, kind: "removed", oldLid: x[0], oldQuid: x[1] }); }
    }
  });
  var om = (oldS && oldS.meta) || {}, nm = newS.meta || {};
  Object.keys(om).concat(Object.keys(nm)).forEach(function (k) {
    if (out.metaKeys.indexOf(k) === -1 && JSON.stringify(om[k]) !== JSON.stringify(nm[k])) out.metaKeys.push(k);
  });
  out.same = !out.rows.length && !out.secAdded.length && !out.secRemoved.length && !out.metaKeys.length;
  return out;
}
/** meta as R2 stores it (same rule as the Worker) */
function metaOut(meta, names, kind) {
  var m = clone(meta);
  if (kind === "full") m.section_order = names.slice();
  return m;
}


/* ───────────────────────── same test uploaded again: reuse the old quids ─────────────────────────
   A test that is already live is usually re-uploaded from the SAME source JSON (no quids in it).
   Without this every question would get a NEW quid → duplicates in D1. So every new question is
   matched to the live test by its local id (same section first, then anywhere):
     • body identical to D1           → old quid is reused (nothing new in D1)
     • body different (edited later)  → admin chooses: keep old quid (default — D1 keeps its
                                        corrected text) or make a new quid. */
var CMP_FIELDS = ["question", "option_1", "option_2", "option_3", "option_4", "option_5", "answer", "solution_text",
                  "question_image", "option_image_1", "option_image_2", "option_image_3", "option_image_4",
                  "option_image_5", "solution_image", "solution_video"];
function bodyText(obj) {
  var r = R.check(R.expand(obj), obj);               // own keys allowed (a field kept earlier is not "new")
  return r.ok ? r.text : JSON.stringify(obj);
}
/** P = prepare(); old = live R2 structure {sections}; oldBodies = {quid: bank body (compact)}.
 *  → [{ row, oldQuid, same, fields[] }] for every new question whose local id exists in the live test. */
function matchExisting(P, old, oldBodies) {
  var bySec = {}, any = {}, used = {}, out = [];
  Object.keys((old && old.sections) || {}).forEach(function (n) {
    (sectionList(old.sections[n]) || []).forEach(function (it) {
      var k = String(it[0]);
      (bySec[n + "\u0000" + k] = bySec[n + "\u0000" + k] || []).push(it[1]);
      (any[k] = any[k] || []).push(it[1]);
    });
  });
  P.rows.forEach(function (row) {
    if (row.newIndex === null || row.lid === null || row.lid === undefined) return;
    var k = String(row.lid), c = (bySec[row.sec + "\u0000" + k] || []).concat(any[k] || []), quid = null;
    for (var i = 0; i < c.length; i++) if (!used[c[i]]) { quid = c[i]; break; }
    if (!quid) return;
    used[quid] = 1;
    var ob = oldBodies[quid];
    if (!ob) { out.push({ row: row, oldQuid: quid, same: false, fields: ["not in D1"], missing: true }); return; }
    var nb = JSON.parse(P.newBodies[row.newIndex]), oe = R.expand(ob), ne = R.expand(nb);
    var same = bodyText(ob) === P.newBodies[row.newIndex];
    var fields = same ? [] : CMP_FIELDS.filter(function (f) { return JSON.stringify(oe[f] === undefined ? "" : oe[f]) !== JSON.stringify(ne[f] === undefined ? "" : ne[f]); });
    if (!same && !fields.length) fields = ["other fields"];
    out.push({ row: row, oldQuid: quid, same: same, fields: fields });
  });
  return out;
}
/** Existing test (update / overwrite): EVERY question must carry its quid — that is the only way to know
 *  which D1 question it is. → null when all have one, else [message, list] (first 12 questions without quid). */
function noQuidError(P) {
  var miss = (P && P.rows || []).filter(function (r) { return r.newIndex !== null; });
  if (!miss.length) return null;
  var list = miss.slice(0, 12).map(function (r) { return r.sec + " Q" + (r.pos + 1) + (r.lid !== null && r.lid !== undefined ? " (id " + r.lid + ")" : ""); });
  return [miss.length + (miss.length === 1 ? " question has" : " questions have") + " no quid. This test already exists, so every question needs its quid " +
          "(use the Full JSON / quid JSON of this test). New questions can't be added here.",
          "No quid: " + list.join(", ") + (miss.length > 12 ? " … +" + (miss.length - 12) + " more" : "")];
}
/** keep = {newIndex: oldQuid} → payload parts with those questions pointing at the old quid
 *  and the remaining new bodies renumbered #0…#n-1. */
function applyMatches(P, keep) {
  var map = {}, bodies = [];
  P.newBodies.forEach(function (b, i) {
    if (keep && keep[i]) map["#" + i] = keep[i];
    else { map["#" + i] = "#" + bodies.length; bodies.push(b); }
  });
  var sections = {};
  Object.keys(P.sections).forEach(function (n) {
    var sv = clone(P.sections[n]), list = sectionList(sv);
    list.forEach(function (it) { if (typeof it[1] === "string" && has.call(map, it[1])) it[1] = map[it[1]]; });
    sections[n] = sv;
  });
  return { sections: sections, newBodies: bodies, reused: Object.keys(keep || {}).length };
}
/** every image URL used by a body (fields + <img src> inside text) */
function imageUrls(body) {
  var urls = [], q = R.expand(body);
  function add(u) { u = String(u || "").trim(); if (/^https?:\/\//i.test(u) && urls.indexOf(u) === -1) urls.push(u); }
  ["question_image", "option_image_1", "option_image_2", "option_image_3", "option_image_4", "option_image_5", "solution_image"]
    .forEach(function (f) { add(q[f]); });
  var txt = JSON.stringify(q), re = /<img[^>]+src=\\?["']([^"'\\]+)\\?["']/gi, m;
  while ((m = re.exec(txt))) add(m[1]);
  return urls;
}
/** structure with real quids (Worker answer) → the "quid JSON" file = exactly what R2 keeps */
function quidJson(meta, structure) {
  var names = Object.keys(structure.sections);
  var kind = names.every(function (n) { return PART_RE.test(n); }) ? "parts" : "full";
  return { meta: metaOut(meta, names, kind), sections: clone(structure.sections) };
}

root.MMHUpload = {
  ID_RE: ID_RE, QUID_RE: QUID_RE, SECTION_RE: SECTION_RE,
  toMark: toMark, freshTagParts: freshTagParts, freshTagText: freshTagText, guessOrg: guessOrg, tagForQuiz: tagForQuiz,
  splitTrailingTag: splitTrailingTag, findTag: findTag, applyTag: applyTag,
  validateTest: validateTest, prepare: prepare, assemble: assemble, diff: diff, metaOut: metaOut, sectionList: sectionList,
  matchExisting: matchExisting, noQuidError: noQuidError, applyMatches: applyMatches, imageUrls: imageUrls, quidJson: quidJson, bodyText: bodyText
};
})(typeof globalThis !== "undefined" ? globalThis : this);

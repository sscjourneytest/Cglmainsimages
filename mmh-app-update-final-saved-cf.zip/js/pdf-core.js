/* ═══════════════════════════════════════════════════════════════════════
   MMH PDFs & Study Materials — CORE (app + website, same file)
   window.MMHPdf
   • Live JSON only (data.mockmatrixhub.in/data/pdfs/…) — never bundled.
     root  : library.json  → sections (free / paid) → boards (src → own file)
     board : free-ssc.json → folders at ANY depth → PDFs
   • A node with `items` or `src` is a FOLDER, anything else is a PDF.
   • One fetch per file per app session (sessionStorage), 10 s timeout.
   • Missing file (404 / HTML) → err.missing  → page shows "Coming soon".
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.MMHPdf) return;

    var DATA_BASE = window.MMH_PDF_DATA || 'https://data.mockmatrixhub.in/data/pdfs/';
    var ROOT_FILE = 'library.json';
    var TIMEOUT = 10000;
    var SS = 'mmh_pdfjson_v1:';
    var PLAY_URL = 'https://play.google.com/store/apps/details?id=in.mockmatrixhub.app';
    var DEF = {
        freeBase: 'https://free-file.mockmatrixhub.in/',
        api: 'https://file.mockmatrixhub.in/',
        shareBase: 'https://mockmatrixhub.in',
        expiryDays: 90          // max offline days for a downloaded premium PDF (Worker decides; NOT shown in the UI)
    };

    /* ── platform / user ─────────────────────────────────────────────── */
    function isApp() {
        try { return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()); } catch (e) { return false; }
    }
    function profile() {
        try { return (typeof getLocalProfile === 'function') ? getLocalProfile() : null; } catch (e) { return null; }
    }
    function uid() { var p = profile(); return p && (p.id || p.uid) ? String(p.id || p.uid).toLowerCase() : ''; }
    /* plan check for the UI only — the Worker is the real gate */
    function hasPlan(plan) {
        var p = profile();
        if (!p) return false;
        if (!plan || plan === 'premium') return !!p.is_paid;
        var list = p.plans || p.pdf_plans || [];
        return Array.isArray(list) && list.indexOf(plan) >= 0;
    }
    async function jwt() {
        var client = null;
        try { client = (typeof getClient === 'function') ? await getClient() : null; } catch (e) {}
        if (!client) throw Object.assign(new Error('login'), { code: 'login' });
        var res = (typeof getSessionOnce === 'function') ? await getSessionOnce(client) : await client.auth.getSession();
        var s = res && res.data ? res.data.session : null;
        if (!s || !s.access_token) throw Object.assign(new Error('login'), { code: 'login' });
        return s.access_token;
    }

    /* ── small utils ─────────────────────────────────────────────────── */
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function fmtBytes(n) {
        n = Number(n) || 0;
        if (n < 1024) return n + ' B';
        if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
        if (n < 1073741824) return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + ' MB';
        return (n / 1073741824).toFixed(2) + ' GB';
    }
    function fmtSize(node) {
        if (!node) return '';
        if (typeof node.size === 'string') return node.size;
        if (typeof node.size === 'number') return fmtBytes(node.size);
        return '';
    }
    var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    function fmtDate(d) {
        if (!d) return '';
        var t = (typeof d === 'number') ? new Date(d) : new Date(String(d).length === 10 ? d + 'T00:00:00' : d);
        if (isNaN(t)) return '';
        return t.getDate() + ' ' + MON[t.getMonth()] + ' ' + t.getFullYear();
    }
    function isNew(node) {
        if (!node || !node.updated) return false;
        var t = new Date(node.updated + 'T00:00:00').getTime();
        return !isNaN(t) && (Date.now() - t) < 7 * 86400000;
    }
    function qs(name) { try { return new URLSearchParams(location.search).get(name); } catch (e) { return null; } }

    /* ── icons ───────────────────────────────────────────────────────── */
    var S = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
    var I = {
        folder: '<svg ' + S + '><path d="M3.5 7.5A2 2 0 0 1 5.5 5.5h4l2 2.2h7a2 2 0 0 1 2 2v7.8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/></svg>',
        book: '<svg ' + S + '><path d="M5 4.5h10.5a3 3 0 0 1 3 3v12H8a3 3 0 0 1-3-3z"/><path d="M5 16.5a3 3 0 0 1 3-3h10.5"/></svg>',
        calendar: '<svg ' + S + '><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
        globe: '<svg ' + S + '><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.6 2.6 14.4 0 17M12 3.5c-2.6 2.6-2.6 14.4 0 17"/></svg>',
        math: '<svg ' + S + '><rect x="4.5" y="3.5" width="15" height="17" rx="2.5"/><path d="M8 7.5h8M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/></svg>',
        language: '<svg ' + S + '><path d="M4 6h8M8 4v2M5.5 6c.6 3.4 2.9 6 6 7.5M10.5 6c-.7 3.5-2.9 6.3-6 8"/><path d="M13 20l3.5-8 3.5 8M14.2 17.3h4.6"/></svg>',
        science: '<svg ' + S + '><path d="M9.5 3.5h5M10.5 3.5v5.2L5.4 17.6A2 2 0 0 0 7.1 20.5h9.8a2 2 0 0 0 1.7-2.9l-5.1-8.9V3.5"/><path d="M7.5 14h9"/></svg>',
        gk: '<svg ' + S + '><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1.1 1.3 1.1 2.2h5c0-.9.5-1.7 1.1-2.2A6 6 0 0 0 12 3z"/></svg>',
        notes: '<svg ' + S + '><path d="M7 3.5h7.5l4 4V19a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5z"/><path d="M14 3.5V8h4.5M8.5 12.5h7M8.5 16h5"/></svg>',
        star: '<svg ' + S + '><path d="m12 3.6 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.2-4.1 5.8-.8z"/></svg>',
        crown: '<svg ' + S + '><path d="M3.5 8.5 8 12l4-6 4 6 4.5-3.5-1.6 10H5.1L3.5 8.5zM5 21h14"/></svg>',
        layers: '<svg ' + S + '><path d="M4 7.5 12 3.5l8 4-8 4-8-4z"/><path d="M4 12l8 4 8-4M4 16.5l8 4 8-4"/></svg>',
        target: '<svg ' + S + '><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4"/></svg>',
        clock: '<svg ' + S + '><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>',
        file: '<svg ' + S + '><path d="M7 3.5h7.5l4 4V19a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5z"/><path d="M14 3.5V8h4.5"/></svg>',
        pages: '<svg ' + S + '><path d="M8 3.5h8.5l3 3V17a1.5 1.5 0 0 1-1.5 1.5H8A1.5 1.5 0 0 1 6.5 17V5A1.5 1.5 0 0 1 8 3.5z"/><path d="M6.5 7H5a1.5 1.5 0 0 0-1.5 1.5V20A1.5 1.5 0 0 0 5 21.5h9A1.5 1.5 0 0 0 15.5 20v-1.5"/></svg>',
        size: '<svg ' + S + '><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/></svg>',
        download: '<svg ' + S + '><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M4.5 15.5v3A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5v-3"/></svg>',
        open: '<svg ' + S + '><path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
        share: '<svg ' + S + '><circle cx="18" cy="5.5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="18.5" r="2.5"/><path d="M8.3 10.8l7.4-4.1M8.3 13.2l7.4 4.1"/></svg>',
        check: '<svg ' + S + '><circle cx="12" cy="12" r="9"/><path d="M8.2 12.3l2.6 2.6 5-5.4"/></svg>',
        tick: '<svg ' + S + '><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
        lock: '<svg ' + S + '><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>',
        shield: '<svg ' + S + '><path d="M12 2.9 19.4 5.7v5.5c0 4.7-3.1 8.3-7.4 9.9-4.3-1.6-7.4-5.2-7.4-9.9V5.7L12 2.9z"/><path d="m8.9 11.9 2.2 2.2 4-4.3"/></svg>',
        trash: '<svg ' + S + '><path d="M4.5 7h15M10 11v6M14 11v6M6 7l1 12.5A1.5 1.5 0 0 0 8.5 21h7a1.5 1.5 0 0 0 1.5-1.5L18 7M9 7V4.5A1.5 1.5 0 0 1 10.5 3h3A1.5 1.5 0 0 1 15 4.5V7"/></svg>',
        export: '<svg ' + S + '><path d="M12 15V3.5M7.5 8 12 3.5 16.5 8"/><path d="M5 12.5v6A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5v-6"/></svg>',
        refresh: '<svg ' + S + '><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4.5V11h-6.5"/></svg>',
        search: '<svg ' + S + '><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg>',
        x: '<svg ' + S + '><path d="M6 6l12 12M18 6L6 18"/></svg>',
        chev: '<svg ' + S + '><path d="M9 6l6 6-6 6"/></svg>',
        back: '<svg ' + S + ' stroke-width="2.2"><path d="M15 18l-6-6 6-6"/></svg>',
        free: '<svg ' + S + '><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3.5 13.5V3.5h10l7.1 7.1a2 2 0 0 1 0 2.8z"/><circle cx="8" cy="8" r="1.4"/></svg>',
        dlbox: '<svg ' + S + '><path d="M12 3.5v10M8 10l4 4 4-4"/><path d="M3.5 14.5 5 19a1.5 1.5 0 0 0 1.4 1h11.2a1.5 1.5 0 0 0 1.4-1l1.5-4.5"/></svg>',
        phone: '<svg ' + S + '><rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
        wifi: '<svg ' + S + '><path d="M2 8.8a15 15 0 0 1 4.2-2.6M9.8 5.2A15 15 0 0 1 22 8.8"/><path d="M5 12.9a10 10 0 0 1 3.4-2.1M14.6 10.6A10 10 0 0 1 19 12.9"/><path d="M8.5 16.4a5 5 0 0 1 7 0"/><path d="M12 20h.01"/><path d="M3 3l18 18"/></svg>',
        storage: '<svg ' + S + '><ellipse cx="12" cy="6" rx="7.5" ry="2.8"/><path d="M4.5 6v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8V6"/><path d="M4.5 12v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6"/></svg>',
        info: '<svg ' + S + '><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8h.01"/></svg>',
        moon: '<svg ' + S + '><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>',
        sun: '<svg ' + S + '><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/></svg>',
        zin: '<svg ' + S + '><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2M8.5 11h5M11 8.5v5"/></svg>',
        zout: '<svg ' + S + '><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2M8.5 11h5"/></svg>',
        fit: '<svg ' + S + '><path d="M4 9V5.5A1.5 1.5 0 0 1 5.5 4H9M15 4h3.5A1.5 1.5 0 0 1 20 5.5V9M20 15v3.5a1.5 1.5 0 0 1-1.5 1.5H15M9 20H5.5A1.5 1.5 0 0 1 4 18.5V15"/></svg>',
        menu: '<svg ' + S + ' stroke-width="2.3"><path d="M4.5 7h15M4.5 12h15M4.5 17h15"/></svg>',
        goto: '<svg ' + S + '><path d="M8 3.5h8.5l3 3V19a1.5 1.5 0 0 1-1.5 1.5H8A1.5 1.5 0 0 1 6.5 19V5A1.5 1.5 0 0 1 8 3.5Z"/><path d="M10 12h6M13.5 9.5 16 12l-2.5 2.5"/></svg>',
        up: '<svg ' + S + ' stroke-width="2.2"><path d="M6 15l6-6 6 6"/></svg>',
        down: '<svg ' + S + ' stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>',
        save: '<svg ' + S + '><path d="M6.5 3.5h8l4 4v11A1.5 1.5 0 0 1 17 20H7a1.5 1.5 0 0 1-1.5-1.5v-13A2 2 0 0 1 6.5 3.5Z"/><path d="M12 9v6.5M9.2 12.8 12 15.6l2.8-2.8"/></svg>',
        night: '<svg ' + S + '><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor"/></svg>',
        play: '<svg viewBox="30 336.7 120.9 129.2" aria-hidden="true"><path fill="#FFD400" d="M119.2,421.2c15.3-8.4,27-14.8,28-15.3c3.2-1.7,6.5-6.2,0-9.7c-2.1-1.1-13.4-7.3-28-15.3l-20.1,20.2L119.2,421.2z"/><path fill="#FF3333" d="M99.1,401.1l-64.2,64.7c1.5,0.2,3.2-0.2,5.2-1.3c4.2-2.3,48.8-26.7,79.1-43.3L99.1,401.1L99.1,401.1z"/><path fill="#00E676" d="M99.1,401.1l20.1-20.2c0,0-74.6-40.7-79.1-43.1c-1.7-1-3.6-1.3-5.3-1L99.1,401.1z"/><path fill="#2EA8FF" d="M99.1,401.1l-64.3-64.3c-2.6,0.6-4.8,2.9-4.8,7.6c0,7.5,0,107.5,0,113.8c0,4.3,1.7,7.4,4.9,7.7L99.1,401.1z"/></svg>'
    };
    function icon(name) { return I[name] || I.folder; }

    /* ── toast / theme ───────────────────────────────────────────────── */
    function toast(msg, type) {
        var root = document.getElementById('toastRoot');
        if (!root) { root = document.createElement('div'); root.id = 'toastRoot'; document.body.appendChild(root); }
        var t = document.createElement('div');
        t.className = 'toast';
        t.innerHTML = (type === 'error' ? '<svg class="error" ' + S + '><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5h.01"/></svg>'
            : '<svg class="success" ' + S + '><circle cx="12" cy="12" r="9"/><path d="M8.2 12.3l2.6 2.6 5-5.4"/></svg>') + '<span>' + esc(msg) + '</span>';
        root.appendChild(t);
        setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 260); }, 2600);
    }
    function theme() {
        var t = null; try { t = localStorage.getItem('mmh_theme'); } catch (e) {}
        if (t !== 'dark' && t !== 'light') t = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
        return t;
    }
    function applyTheme(t) {
        document.body.classList.toggle('dark-mode', t === 'dark');
        var m = document.querySelector('meta[name="theme-color"]');
        if (m) m.content = t === 'dark' ? '#121a30' : '#ffffff';
        Array.prototype.forEach.call(document.querySelectorAll('.theme-btn'), function (b) { b.innerHTML = t === 'dark' ? I.sun : I.moon; });
    }
    function wireTheme() {
        applyTheme(theme());
        Array.prototype.forEach.call(document.querySelectorAll('.theme-btn'), function (b) {
            b.addEventListener('click', function () {
                var n = theme() === 'dark' ? 'light' : 'dark';
                try { localStorage.setItem('mmh_theme', n); } catch (e) {}
                applyTheme(n);
            });
        });
    }

    /* ── live JSON ───────────────────────────────────────────────────── */
    var mem = {};
    function getJSON(file, opts) {
        opts = opts || {};
        var key = SS + file;
        if (!opts.fresh) {
            if (mem[file]) return Promise.resolve(mem[file]);
            try { var c = sessionStorage.getItem(key); if (c) { mem[file] = JSON.parse(c); return Promise.resolve(mem[file]); } } catch (e) {}
        }
        var url = DATA_BASE + file;
        var ctl = ('AbortController' in window) ? new AbortController() : null;
        var timer = setTimeout(function () { if (ctl) ctl.abort(); }, TIMEOUT);
        return fetch(url, { cache: 'no-cache', signal: ctl ? ctl.signal : undefined }).then(function (r) {
            clearTimeout(timer);
            var ct = (r.headers.get('content-type') || '').toLowerCase();
            if (r.status === 404 || r.status === 410 || (r.ok && ct.indexOf('text/html') >= 0)) {
                throw Object.assign(new Error('missing'), { missing: true });
            }
            if (!r.ok) throw Object.assign(new Error('http ' + r.status), { status: r.status });
            return r.text();
        }).then(function (txt) {
            var j;
            try { j = JSON.parse(txt); } catch (e) { throw Object.assign(new Error('bad json'), { bad: true }); }
            if (!j || typeof j !== 'object') throw Object.assign(new Error('bad json'), { bad: true });
            mem[file] = j;
            try { sessionStorage.setItem(key, JSON.stringify(j)); } catch (e) {}
            return j;
        }, function (e) {
            clearTimeout(timer);
            if (e && (e.missing || e.bad || e.status)) throw e;
            throw Object.assign(new Error('network'), { network: true, offline: navigator.onLine === false });
        });
    }
    /* folder = has items / src, or is a "coming soon" placeholder, or has no file/version (a PDF always has file (free) or v (paid)) */
    function isFolder(n) { return !!(n && (Array.isArray(n.items) || n.src || n.comingSoon || n.type === 'folder' || !(n.file || n.v))); }
    function cfg(root) {
        var o = {}; for (var k in DEF) o[k] = DEF[k];
        if (root) for (var k2 in DEF) if (root[k2] != null) o[k2] = root[k2];
        return o;
    }
    function ensureLoaded(node) {
        if (!node || !node.src || node._loaded) return Promise.resolve(node);
        return getJSON(node.src).then(function (j) {
            node.items = Array.isArray(j.items) ? j.items : [];
            if (j.notice && !node.notice) node.notice = j.notice;
            node._loaded = true;
            return node;
        }, function (e) {
            if (e && e.missing) { node.items = []; node._loaded = true; node._missing = true; return node; }
            throw e;
        });
    }
    function visible(list) { return (list || []).filter(function (n) { return n && !n.hidden && n.id; }); }
    function child(node, id) {
        var l = visible(node && node.items);
        for (var i = 0; i < l.length; i++) if (String(l[i].id) === String(id)) return l[i];
        return null;
    }
    /* resolve "free/ssc/cgl/2025" → { root, chain:[section, ssc, cgl, 2025], node, section } */
    function resolve(path) {
        var segs = String(path || '').split('/').map(function (s) { return s.trim(); }).filter(Boolean);
        return getJSON(ROOT_FILE).then(function (root) {
            root.items = Array.isArray(root.items) ? root.items : [];
            var chain = [], node = root, i = 0;
            function step() {
                if (i >= segs.length) return Promise.resolve();
                return ensureLoaded(node).then(function () {
                    var c = child(node, segs[i]);
                    if (!c) throw Object.assign(new Error('not found'), { notFound: true });
                    chain.push(c); node = c; i++;
                    return step();
                });
            }
            return step().then(function () { return ensureLoaded(node); }).then(function () {
                return { root: root, chain: chain, node: node, section: chain[0] || null, cfg: cfg(root) };
            });
        });
    }
    function pathOf(chain) { return chain.map(function (n) { return n.id; }).join('/'); }
    function sectionPaid(section) { return !!(section && (section.paid || section.id === 'paid')); }
    function planOf(node, section) { return (node && node.plan) || (section && section.plan) || 'premium'; }
    /* every node under `node` that is loaded: cb(n, trailNodes) */
    function walk(node, cb, trail) {
        trail = trail || [];
        visible(node.items).forEach(function (n) {
            cb(n, trail);
            if (Array.isArray(n.items)) walk(n, cb, trail.concat([n]));
        });
    }
    function countPdfs(node) {
        if (!isFolder(node)) return 1;
        if (!Array.isArray(node.items) || (node.src && !node._loaded)) return Number(node.count) || 0;
        var c = 0;
        visible(node.items).forEach(function (n) { c += isFolder(n) ? countPdfs(n) : 1; });
        return c;
    }
    function freeUrl(c, node) {
        if (!node || !node.file) return '';
        if (/^https?:\/\//i.test(node.file)) return node.file;
        return String(c.freeBase).replace(/\/+$/, '/') + String(node.file).split('/').map(encodeURIComponent).join('/');
    }
    function shareUrl(c, f, id) {
        var base = String((c && c.shareBase) || DEF.shareBase).replace(/\/+$/, '');
        return id ? base + '/pdfs/view.html?f=' + encodeURIComponent(f).replace(/%2F/g, '/') + '&id=' + encodeURIComponent(id)
            : base + '/pdfs/index.html?f=' + encodeURIComponent(f).replace(/%2F/g, '/');
    }
    function share(title, url) {
        var data = { title: title, text: title + ' — Mock Matrix Hub', url: url };
        if (window.mmhShare) return window.mmhShare(data).catch(function () {});
        if (navigator.share) return navigator.share(data).catch(function () {});
        if (navigator.clipboard) return navigator.clipboard.writeText(url).then(function () { toast('Link copied!'); }, function () {});
        return Promise.resolve();
    }

    /* ── sheet ───────────────────────────────────────────────────────── */
    function closeSheet() {
        var l = document.querySelector('.pdf-sheet-layer');
        if (l) l.remove();
        document.removeEventListener('keydown', escClose);
    }
    function escClose(e) { if (e.key === 'Escape') closeSheet(); }
    /* opts: { icon, iconCls, img, title, text, body (html), actions:[{label, cls, icon, href, onClick, keep}] } */
    function sheet(opts) {
        closeSheet();
        var l = document.createElement('div');
        l.className = 'pdf-sheet-layer';
        var acts = (opts.actions || []).map(function (a, i) {
            var inner = (a.icon ? icon(a.icon) : '') + '<span>' + esc(a.label) + '</span>';
            return a.href ? '<a class="pc-btn ' + (a.cls || 'ghost') + '" data-i="' + i + '" href="' + esc(a.href) + '"' + (a.blank ? ' target="_blank" rel="noopener"' : '') + '>' + inner + '</a>'
                : '<button type="button" class="pc-btn ' + (a.cls || 'ghost') + '" data-i="' + i + '">' + inner + '</button>';
        }).join('');
        l.innerHTML = '<div class="pdf-sheet-dim" data-close></div><div class="pdf-sheet" role="dialog" aria-modal="true">' +
            '<div class="grab"></div>' +
            (opts.img ? '<div class="s-ico"><img src="' + esc(opts.img) + '" alt=""></div>'
                : opts.icon ? '<div class="s-ico ' + (opts.iconCls || 'c-blue') + '">' + icon(opts.icon) + '</div>' : '') +
            (opts.title ? '<h3>' + esc(opts.title) + '</h3>' : '') +
            (opts.text ? '<p>' + opts.text + '</p>' : '') +
            (opts.body ? '<div class="s-body">' + opts.body + '</div>' : '') +
            (acts ? '<div class="s-acts">' + acts + '</div>' : '') + '</div>';
        document.body.appendChild(l);
        l.addEventListener('click', function (e) {
            if (e.target.hasAttribute('data-close')) { closeSheet(); return; }
            var b = e.target.closest('[data-i]');
            if (!b) return;
            var a = opts.actions[+b.getAttribute('data-i')];
            if (!a) return;
            if (a.onClick) { e.preventDefault(); var r = a.onClick(b); if (!a.keep && r !== false) closeSheet(); }
            else if (!a.href) closeSheet();
        });
        document.addEventListener('keydown', escClose);
        return l;
    }
    function fileBox(node, paid) {
        return '<div class="s-file"><div class="pc-thumb' + (paid ? '' : '') + '"' + (paid ? ' style="background:rgba(217,119,6,.09);color:#d97706;border-color:rgba(217,119,6,.18)"' : '') + '>' + I.file + '<b>PDF</b></div>' +
            '<div><div class="f-t">' + esc(node.title || '') + '</div><div class="f-s">' +
            [node.pages ? node.pages + ' pages' : '', fmtSize(node)].filter(Boolean).join(' · ') + '</div></div></div>';
    }
    /* website + premium → final click */
    function appOnlySheet(node) {
        return sheet({
            img: '/logo.png',
            title: 'Premium PDFs open only in the app',
            text: 'Premium PDFs can be accessed from the <b>official Mock Matrix Hub app</b> only. Download the app, log in with the same account and open it there.',
            body: (node ? fileBox(node, true) : '') +
                '<ul class="s-list"><li>' + I.check + 'Download once, read offline — no internet needed</li>' +
                '<li>' + I.check + 'Same login · same premium plan</li><li>' + I.check + 'All your PDFs in My Downloads</li></ul>',
            actions: [
                { label: '', cls: 'play', href: PLAY_URL, blank: true },
                { label: 'Not now', cls: 'ghost' }
            ]
        });
    }
    /* swap the generic play action markup for the store badge button */
    var _sheet = sheet;
    sheet = function (opts) {
        var l = _sheet(opts);
        var p = l.querySelector('a.pc-btn.play');
        if (p) { p.className = 'play-btn'; p.innerHTML = I.play + '<span><small>GET IT ON</small><b>Google Play</b></span>'; }
        return l;
    };
    function buySheet(node) {
        return sheet({
            icon: 'crown', iconCls: 'c-amber',
            title: 'Unlock Premium PDFs',
            text: 'This PDF is part of Premium. Buy a plan to open and download all Premium PDFs inside the app.',
            body: node ? fileBox(node, true) : '',
            actions: [{ label: 'Buy Premium', cls: 'buy', icon: 'crown', href: '/buy-premium.html' }, { label: 'Not now', cls: 'ghost' }]
        });
    }

    /* ── dock ────────────────────────────────────────────────────────── */
    function dock(active, count) {
        var el = document.getElementById('pdfDock');
        if (!el) return;
        var app = isApp();
        el.innerHTML =
            '<a href="/pdfs/index.html?f=free" class="' + (active === 'free' ? 'active' : '') + '">' + I.free + '<span>Free</span></a>' +
            '<a href="/pdfs/index.html?f=paid" class="' + (active === 'paid' ? 'active' : '') + '">' + I.crown + '<span>Premium</span></a>' +
            (app
                ? '<a href="/pdfs/downloads.html" class="' + (active === 'downloads' ? 'active' : '') + '">' + I.dlbox + (count ? '<span class="d-badge">' + count + '</span>' : '') + '<span>My Downloads</span></a>'
                : '<a href="' + PLAY_URL + '" target="_blank" rel="noopener" class="d-get">' + I.phone + '<span>Get the App</span></a>');
    }

    window.MMHPdf = {
        DATA_BASE: DATA_BASE, PLAY_URL: PLAY_URL, DEF: DEF,
        isApp: isApp, profile: profile, uid: uid, hasPlan: hasPlan, jwt: jwt,
        esc: esc, fmtBytes: fmtBytes, fmtSize: fmtSize, fmtDate: fmtDate, isNew: isNew, qs: qs,
        icon: icon, I: I, toast: toast, theme: theme, applyTheme: applyTheme, wireTheme: wireTheme,
        getJSON: getJSON, resolve: resolve, ensureLoaded: ensureLoaded, isFolder: isFolder, visible: visible, child: child,
        pathOf: pathOf, sectionPaid: sectionPaid, planOf: planOf, walk: walk, countPdfs: countPdfs, cfg: cfg,
        freeUrl: freeUrl, shareUrl: shareUrl, share: share,
        sheet: function (o) { return sheet(o); }, closeSheet: closeSheet, appOnlySheet: appOnlySheet, buySheet: buySheet, fileBox: fileBox,
        dock: dock
    };
})();

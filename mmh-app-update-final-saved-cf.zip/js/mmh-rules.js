/* MMH-RULES-START  (mmh-rules.js v1 — SAME file in the editor page and the admin Worker; keep both copies identical) */
/*
 * MMH question-bank body rules = exact JS port of qbank-action/.github/scripts/qb_build.py
 *   is_blank, ws, clean_lang, deep_clean, clean_body, body_problems, attach_option_slots
 * plus the editor helpers:
 *   expand(body)   bank body  -> COMPLETE question JSON (same shape test.html builds: every standard field present)
 *   compact(full)  COMPLETE JSON -> bank body (option_slots + clean_body)  = what goes into D1
 *   check(full, originalBody) -> { ok, body, text, errors[], warnings[], fixes[] }
 *   stringify(body) -> compact JSON text, same bytes as Python json.dumps(ensure_ascii=False, separators=(",",":"))
 *   parseJSON(text) -> { ok, value } | { ok:false, error, line, col }
 *
 * IMPORTANT ("empty" rule): a value is removed ONLY if the WHOLE value is empty —
 *   "", spaces, or nothing but <br> / &nbsp; / <p></p> / empty tags like <span></span>.
 *   Text that has real content keeps every <br>, <span>, &nbsp; exactly as written. Nothing inside text is changed.
 */
(function (root) {
  "use strict";

  // Python str.isspace() set (= Python re "\s" on str) — JS "\s" differs slightly, so spell it out
  var W = "\\t\\n\\x0b\\x0c\\r\\x1c-\\x1f \\x85\\xa0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000";
  var RE_ALL_WS = new RegExp("^[" + W + "]*$");
  var RE_WS_RUN = new RegExp("[" + W + "]+", "g");
  var RE_TRIM = new RegExp("^[" + W + "]+|[" + W + "]+$", "g");
  var RE_EMPTY_HTML = new RegExp("(?:<br[" + W + "]*/?>|&lt;br[" + W + "]*/?&gt;|&nbsp;|<p>[" + W + "]*</p>|[" + W + "])+", "gi");
  var RE_TAGS = /<\/?[a-zA-Z][^<>]*>|&lt;\/?[a-zA-Z][\s\S]*?&gt;/g;

  var QUID_RE = /^Q[1-9]\d{9}$/;
  var IMG_BASE = "https://raw.githubusercontent.com/mockmatrixhub/mmhimg/main/";
  var NOT_IN_BODY = ["id", "quiz_id", "correct_score", "negative_score", "hash"];   // allowed in a JSON, never stored in D1
  var DROPPED_FIELDS = ["difficulty_level"];
  var EDITOR_ONLY = ["quid", "option_slots"];          // never typed by hand: quid = the row key, option_slots = computed
  var LANG_STD = ["question", "option_1", "option_2", "option_3", "option_4", "solution_text"];
  var STR_STD = ["option_5", "option_image_1", "option_image_2", "option_image_3", "option_image_4",
                 "option_image_5", "question_image", "solution_image", "solution_video"];
  var IMAGE_FIELDS = ["question_image", "option_image_1", "option_image_2", "option_image_3",
                      "option_image_4", "option_image_5", "solution_image"];
  var LANG_FIELDS = ["question", "option_1", "option_2", "option_3", "option_4", "option_5", "solution_text", "comprehension"];
  var STRING_FIELDS = IMAGE_FIELDS.concat(["solution_video", "topic", "topic_tag", "topic_tag_id", "sortingparam", "deleted"]);
  var ALLOWED = LANG_FIELDS.concat(STRING_FIELDS, ["answer"]);
  var MAX_BYTES = 1000000, WARN_BYTES = 100 * 1024;   // D1 row limit is 2 MB; the bank already has some 200+ KB questions
  var has = Object.prototype.hasOwnProperty;

  function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }
  function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }
  function pyStrip(s) { return s.replace(RE_TRIM, ""); }

  // ---- qb_build.is_blank ----
  function isBlank(v) {
    if (v === null || v === undefined) return true;
    if (typeof v === "string") {
      if (RE_ALL_WS.test(v)) return true;
      var low = v.toLowerCase();
      if (low.indexOf("<img") !== -1 || low.indexOf("&lt;img") !== -1) return false;
      if (v.replace(RE_EMPTY_HTML, "") === "") return true;
      return v.replace(RE_TAGS, "").replace(RE_EMPTY_HTML, "") === "";   // only empty markup -> blank
    }
    if (Array.isArray(v)) return v.length === 0;
    if (isObj(v)) return Object.keys(v).length === 0;
    return false;
  }
  function isLangObj(v) {
    if (!isObj(v)) return false;
    var k = Object.keys(v);
    return k.length > 0 && k.every(function (x) { return x === "en" || x === "hi"; });
  }
  function ws(s) { return pyStrip(String(s).replace(RE_WS_RUN, " ")); }

  // ---- qb_build.clean_lang ----
  function cleanLang(o) {
    var en = o.en, hi = o.hi, enOk = !isBlank(en), hiOk = !isBlank(hi);
    if (enOk && hiOk) {
      if (typeof en === "string" && typeof hi === "string" && ws(en) === ws(hi)) return { en: en };
      return { en: en, hi: hi };
    }
    if (enOk) return { en: en };
    if (hiOk) return { hi: hi };
    return null;
  }
  // ---- qb_build.deep_clean ----
  function deepClean(v) {
    if (isLangObj(v)) return cleanLang(v);
    if (isObj(v)) {
      var out = {}, n = 0;
      Object.keys(v).forEach(function (k) {
        var c = deepClean(v[k]);
        if (c !== null && !isBlank(c)) { out[k] = c; n++; }
      });
      return n ? out : null;
    }
    if (Array.isArray(v)) {
      var arr = [];
      v.forEach(function (x) { var c = deepClean(x); if (c !== null && !isBlank(c)) arr.push(c); });
      return arr.length ? arr : null;
    }
    return isBlank(v) ? null : v;
  }
  // ---- qb_build.clean_body ----
  function cleanBody(q) {
    var b = {};
    Object.keys(q).forEach(function (k) {
      var v = q[k];
      if (NOT_IN_BODY.indexOf(k) !== -1 || DROPPED_FIELDS.indexOf(k) !== -1) return;
      if (k === "deleted" && (v === "0" || v === 0)) return;     // Python: str(v) == "0" (a list [0] is NOT "0")
      if (k === "answer" && typeof v === "number") v = String(v);   // 3 -> "3", 2.5 -> "2.5" (same as Python)
      var c = deepClean(v);
      if (c !== null && !isBlank(c)) b[k] = c;
    });
    return b;
  }
  // ---- qb_build.body_problems ----
  function bodyProblems(b) {
    var probs = [];
    NOT_IN_BODY.concat(DROPPED_FIELDS).forEach(function (k) { if (has.call(b, k)) probs.push("forbidden key " + k); });
    (function walk(v, path) {
      if (isLangObj(v) && has.call(v, "en") && has.call(v, "hi") && ws(v.en) === ws(v.hi)) probs.push(path + ": en == hi");
      if (isObj(v)) {
        if (!Object.keys(v).length) probs.push(path + ": empty object");
        Object.keys(v).forEach(function (k) { walk(v[k], path + "." + k); });
      } else if (Array.isArray(v)) {
        if (!v.length) probs.push(path + ": empty list");
        v.forEach(function (x, i) { walk(x, path + "[" + i + "]"); });
      } else if (isBlank(v)) probs.push(path + ": empty value");
    })(b, "body");
    return probs;
  }
  // ---- qb_build.attach_option_slots (test.html shows option_k only if q[option_k] is truthy) ----
  function truthy(v) { return !(v === null || v === undefined || v === false || v === "" || v === 0); }
  function shownSlots(full) {
    var s = [];
    for (var k = 1; k <= 5; k++) if (truthy(full["option_" + k])) s.push(k);
    return s;
  }

  // ---- bank body -> COMPLETE JSON (test.html mmhAssembleQuiz restoreStd, without id/quid/quiz_id/marks) ----
  function fillLang(v) {
    if (v === undefined || v === null) return { en: "", hi: "" };
    if (isObj(v)) { if (!has.call(v, "en")) v.en = ""; if (!has.call(v, "hi")) v.hi = ""; }
    return v;
  }
  function expand(body) {
    var b = isObj(body) ? body : {}, q = {}, slots = Array.isArray(b.option_slots) ? b.option_slots : null;
    Object.keys(b).forEach(function (k) { if (k !== "option_slots") q[k] = clone(b[k]); });
    LANG_STD.forEach(function (f) { if (!(slots && f.indexOf("option_") === 0)) q[f] = fillLang(q[f]); });
    if (slots) {
      for (var k = 1; k <= 5; k++) {
        var f = "option_" + k;
        if (slots.indexOf(k) !== -1) q[f] = fillLang(q[f]);
        else if (q[f] === undefined || q[f] === null) q[f] = "";
      }
    }
    STR_STD.forEach(function (f) { if (!has.call(q, f)) q[f] = ""; });
    if (!has.call(q, "answer")) q.answer = "";
    return q;
  }
  // ---- COMPLETE JSON -> bank body (exactly what the build does with a raw question) ----
  function compact(full) {
    var raw = {};
    Object.keys(full).forEach(function (k) { if (EDITOR_ONLY.indexOf(k) === -1) raw[k] = full[k]; });
    var shown = shownSlots(raw);
    if (shown.join() !== "1,2,3,4") raw.option_slots = shown;
    return cleanBody(raw);
  }

  // ---- JSON text, same bytes as Python json.dumps(o, ensure_ascii=False, separators=(",",":")) ----
  function stringify(o) { return JSON.stringify(o); }
  function byteLen(s) {
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(s).length;
    return unescape(encodeURIComponent(s)).length;
  }

  // ---- JSON syntax check with line / column ----
  function parseJSON(text) {
    try { return { ok: true, value: JSON.parse(text) }; }
    catch (e) {
      var msg = String(e && e.message || e), pos = -1, m;
      if ((m = /position (\d+)/i.exec(msg))) pos = +m[1];
      var line = 0, col = 0;
      if ((m = /line (\d+) column (\d+)/i.exec(msg))) { line = +m[1]; col = +m[2]; }
      else if (pos >= 0) {
        var before = text.slice(0, pos).split("\n");
        line = before.length; col = before[before.length - 1].length + 1;
      }
      var hint = "";
      if (/,\s*[}\]]/.test(text)) hint = "Tip: a comma before } or ] is not allowed in JSON.";
      else if (/'[^']*'\s*:/.test(text)) hint = "Tip: JSON needs double quotes \" not single quotes '.";
      return { ok: false, error: msg, line: line, col: col, hint: hint };
    }
  }

  // ---- exam tag at the end of a question (test.html extractExamTag) ----
  function examTag(s) {
    if (typeof s !== "string") return null;
    var m = /\s*\[([^\[\]]{3,160})\]\s*(?:<br\s*\/?>\s*)*$/i.exec(s);
    return m ? m[1].trim() : null;
  }
  function langText(v, lang) { return isObj(v) ? (typeof v[lang] === "string" ? v[lang] : "") : (typeof v === "string" && lang === "en" ? v : ""); }

  // ---- full check: syntax already OK, value = COMPLETE JSON the editor holds ----
  // opts.fields = { name: "keep" | "remove" } — the admin's answer for a NEW (non-standard) field.
  // Not answered → error + name in result.unknown (the Upload Test page then asks Keep / Remove).
  function isKnownField(k) {
    return ALLOWED.indexOf(k) !== -1 || NOT_IN_BODY.indexOf(k) !== -1 || DROPPED_FIELDS.indexOf(k) !== -1 || EDITOR_ONLY.indexOf(k) !== -1;
  }
  function check(full, original, opts) {
    var errors = [], warnings = [], fixes = [], unknown = [], drop = [];
    var orig = isObj(original) ? original : {};
    var choose = (opts && isObj(opts.fields)) ? opts.fields : {};
    if (!isObj(full)) {
      errors.push("The question must be a JSON object { … }.");
      return { ok: false, body: null, text: "", errors: errors, warnings: warnings, fixes: fixes };
    }
    Object.keys(full).forEach(function (k) {
      var v = full[k];
      if (NOT_IN_BODY.indexOf(k) !== -1 || DROPPED_FIELDS.indexOf(k) !== -1) { fixes.push(k + ": not stored in the bank → removed"); return; }
      if (k === "quid") { fixes.push("quid: is the row key, not part of the body → removed"); return; }
      if (k === "option_slots") { fixes.push("option_slots: worked out automatically from option_1…option_5 → your value ignored"); return; }
      if (ALLOWED.indexOf(k) === -1 && !has.call(orig, k)) {
        if (choose[k] === "remove") { fixes.push(k + ": new field → removed (you chose Remove)"); drop.push(k); return; }
        if (choose[k] === "keep") { fixes.push(k + ": new field → kept as it is (you chose Keep)"); return; }
        unknown.push(k);
        errors.push(opts && opts.fields ? "New field \"" + k + "\" — not a standard field (typo?). Choose Keep or Remove."
                                        : "Unknown field \"" + k + "\" (typo?). Allowed: " + ALLOWED.join(", "));
        return;
      }
      if (LANG_FIELDS.indexOf(k) !== -1) {
        if (isObj(v)) {
          Object.keys(v).forEach(function (l) {
            if (l !== "en" && l !== "hi") errors.push(k + "." + l + ": only \"en\" and \"hi\" are allowed inside " + k);
            else if (v[l] !== null && typeof v[l] !== "string") errors.push(k + "." + l + ": must be text in \"…\"");
            else if (typeof v[l] === "string" && v[l] !== "" && isBlank(v[l])) fixes.push(k + "." + l + ": only spaces / <br> / &nbsp; / empty tags → treated as empty, removed");
          });
          if (isLangObj(v) && !isBlank(v.en) && !isBlank(v.hi) && typeof v.en === "string" && typeof v.hi === "string" && ws(v.en) === ws(v.hi))
            fixes.push(k + ": Hindi is the same as English → only \"en\" is stored (Hindi view shows English)");
        } else if (v !== null && typeof v !== "string") errors.push(k + ": must be {\"en\": \"…\", \"hi\": \"…\"} or text");
        else if (typeof v === "string" && v !== "" && isBlank(v)) fixes.push(k + ": only spaces / <br> / &nbsp; / empty tags → treated as empty, removed");
      } else if (k === "answer") {
        if (typeof v === "number") fixes.push("answer: number " + v + " → text \"" + v + "\"");
        else if (v !== null && typeof v !== "string") errors.push("answer: must be \"1\" … \"5\"");
      } else if (STRING_FIELDS.indexOf(k) !== -1) {
        if (v !== null && typeof v !== "string") errors.push(k + ": must be text in \"…\"");
        else if (k === "deleted" && v === "0") fixes.push("deleted: \"0\" is the default → removed");
        else if (typeof v === "string" && v !== "" && isBlank(v)) fixes.push(k + ": only spaces / <br> / &nbsp; → treated as empty, removed");
      }
    });
    if (errors.length) return { ok: false, body: null, text: "", errors: errors, warnings: warnings, fixes: fixes, unknown: unknown };
    if (drop.length) { var f2 = {}; Object.keys(full).forEach(function (k) { if (drop.indexOf(k) === -1) f2[k] = full[k]; }); full = f2; }

    var body = compact(full), text = stringify(body), shown = shownSlots(full);

    // answer
    var ans = body.answer;
    if (ans === undefined) errors.push("answer is empty — set \"answer\": \"1\" … \"5\"");
    else if (!/^[1-5]$/.test(String(ans))) errors.push("answer \"" + ans + "\" is not 1 … 5");
    else if (shown.indexOf(+ans) === -1) errors.push("answer is " + ans + " but option_" + ans + " is hidden (it is \"\" — use {\"en\": \"…\"} to show it)");
    // images
    IMAGE_FIELDS.forEach(function (f) {
      var v = body[f];
      if (v === undefined) return;
      var low = v.toLowerCase();
      if (!/^https:\/\//i.test(v.trim()) && low.indexOf("<img") === -1) errors.push(f + ": must be an https:// link (or <img …>)");
      else if (v.indexOf(IMG_BASE) !== 0 && low.indexOf("<img") === -1) warnings.push(f + ": image is not on mmhimg (" + IMG_BASE + ")");
    });
    var bytes = byteLen(text);
    if (bytes > MAX_BYTES) errors.push("Question is too big: " + Math.round(bytes / 1024) + " KB (max " + Math.round(MAX_BYTES / 1024) + " KB)");
    else if (bytes > WARN_BYTES) warnings.push("Question is big: " + Math.round(bytes / 1024) + " KB");
    bodyProblems(body).forEach(function (p) { errors.push("Self-check: " + p); });

    // warnings
    if (has.call(orig, "answer") && ans !== undefined && String(orig.answer) !== String(ans))
      warnings.push("ANSWER CHANGED " + orig.answer + " → " + ans + ": scores of old attempts are NOT recalculated");
    var qv = body.question;
    if (isBlank(langText(qv, "en")) && isBlank(langText(qv, "hi")) && body.question_image === undefined && body.comprehension === undefined)
      warnings.push("question has no text and no question_image");
    var tEn = examTag(langText(qv, "en")), tHi = examTag(langText(qv, "hi"));
    if (tEn && !isBlank(langText(qv, "hi")) && !tHi) warnings.push("question.en ends with the exam tag [" + tEn + "] but question.hi has no tag");
    if (shown.length < 2) warnings.push("only " + shown.length + " option(s) shown");
    shown.forEach(function (k) {
      var v = body["option_" + k];
      if (v === undefined && body["option_image_" + k] === undefined) warnings.push("option_" + k + " is shown but has no text and no option_image_" + k);
    });
    IMAGE_FIELDS.forEach(function (f) {
      var o = orig[f];
      if (typeof o === "string" && body[f] === undefined && /\/q-\d+-image\d\.(?:jpg|jpeg|png|webp)$/i.test(o.trim()))
        warnings.push(f + " removed — but the file still exists on mmhimg at the auto path, so test.html can STILL show it in that test. Delete/rename the file on mmhimg too.");
    });
    return { ok: errors.length === 0, body: errors.length ? null : body, text: errors.length ? "" : text,
             bytes: bytes, errors: errors, warnings: warnings, fixes: fixes, unknown: unknown };
  }

  // ---- SHA-256 (hex, first 16 chars) of a text — the "base" version stamp ----
  function sha16(text) {
    var c = (typeof crypto !== "undefined" && crypto.subtle) ? crypto : null;
    if (!c) return Promise.reject(new Error("WebCrypto missing"));
    return c.subtle.digest("SHA-256", new TextEncoder().encode(text)).then(function (buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ("0" + x.toString(16)).slice(-2); }).join("").slice(0, 16);
    });
  }

  root.MMHRules = {
    VERSION: 1, QUID_RE: QUID_RE, IMG_BASE: IMG_BASE, ALLOWED: ALLOWED, LANG_FIELDS: LANG_FIELDS, isKnownField: isKnownField,
    isBlank: isBlank, ws: ws, cleanLang: cleanLang, deepClean: deepClean, cleanBody: cleanBody,
    bodyProblems: bodyProblems, shownSlots: shownSlots, expand: expand, compact: compact,
    stringify: stringify, parseJSON: parseJSON, check: check, examTag: examTag, sha16: sha16, byteLen: byteLen
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
/* MMH-RULES-END */

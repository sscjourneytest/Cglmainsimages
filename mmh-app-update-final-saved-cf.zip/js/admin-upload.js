/* ═══════════════════════════════════════════════════════════════════════════
   Upload Test — admin page (app + website /admin-upload/, and the standalone file)

   Upload tab   pick / paste a test JSON → settings (quiz id, Free/Paid, exam tag)
                → every question checked in the browser with the SAME rules as the
                bank build (mmh-rules.js + mmh-upload-core.js) → "Check & Upload":
                  1. dry run on the admin Worker (next quid, does the id exist?)
                  2. confirm sheet (new test: summary · live test: matches + diff)
                  3. upload → D1 rows (new questions only) → R2 files → tests row
                → quid JSON / full JSON download, retry if R2 / tests failed.
   Tests tab    open a live test: Free ⇄ Paid, Hide / Show, download quid / full JSON.
   History tab  what this device uploaded / changed (localStorage, last 60).

   Same password as Check Reports (localStorage mmh_admin_pw), same header, gate,
   dock, sheet and question card (q-render.js).
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
"use strict";

const R = window.MMHRules, U = window.MMHUpload;
const PW_KEY = "mmh_admin_pw";
const HIST_KEY = "mmh_up_history_v1";
const HIST_MAX = 60;
const ROLES = ["admin", "owner", "subowner"];
const PAGE = 60;                         // question rows per "Show more"
const BODY_MAX = 50;                     // /bodies quids per call
const STANDALONE = !!window.MMH_UP_STANDALONE;

function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }

// testing only: a LOCAL Worker may replace the live one — never another site
const ADMIN_URL = (function () {
  const o = (lsGet("mmh_admin_api_override") || "").replace(/\/+$/, "");
  return /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o) ? o : "https://admin.mockmatrixhub.in";
})();

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// big screen (mouse + ≥992px) = Check Reports layout: content left, side pane right (admin-upload.css)
const WIDE_MQ = window.matchMedia ? window.matchMedia("(min-width:992px) and (hover:hover) and (pointer:fine)") : null;
function wide() { return !!(WIDE_MQ && WIDE_MQ.matches); }
function syncHdr() {
  const h = document.querySelector(".screen-header");
  if (h) document.body.style.setProperty("--up-hdr", h.getBoundingClientRect().height + "px");
}
const IC = {
  file:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8L14 3.5z"/><path d="M14 3.5V8h4.5M9 13h6M9 16.5h4"/></svg>',
  x:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  chev:  '<svg class="up-q-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
  ok:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.4l2.8 2.8 5.4-5.8"/></svg>',
  bad:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.3v.2"/></svg>',
  down:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11.5M7.5 11 12 15.5 16.5 11"/><path d="M4.5 16v2.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V16"/></svg>',
  up:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15.5V4M7.5 8.5 12 4l4.5 4.5"/><path d="M4 14.5v4A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5v-4"/></svg>',
  retry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
  render: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4" width="17" height="16" rx="2.4"/><path d="M7.5 9h9M7.5 12.5h9M7.5 16h5"/></svg>',
  stack: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7.5 12 3.5l8 4-8 4-8-4z"/><path d="M4 12l8 4 8-4M4 16.5l8 4 8-4"/></svg>',
  eye:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeOff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18M10.6 5.6A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-2.6 3.4M6.5 6.9C3.9 8.6 2.5 12 2.5 12S6 18.5 12 18.5c1.6 0 3-.4 4.2-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>',
  tag:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 12.2V4.5a1 1 0 0 1 1-1h7.7l8.3 8.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-8.6-8z"/><circle cx="8" cy="8" r="1.4"/></svg>',
  code:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 7 3.5 12l5 5M15.5 7l5 5-5 5"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6.5h16M9.5 6.5V4.5h5v2M6.5 6.5l.9 13a1.5 1.5 0 0 0 1.5 1.4h6.2a1.5 1.5 0 0 0 1.5-1.4l.9-13M10 10.5v6.5M14 10.5v6.5"/></svg>',
  db:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5.5" rx="7.5" ry="2.8"/><path d="M4.5 5.5v13c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-13M4.5 12c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8"/></svg>'
};

// ══════════════════════════════════════════════════════════════════════════
//  REAL API (admin Worker v4, password header)
// ══════════════════════════════════════════════════════════════════════════
const REAL_API = (function () {
  let pending = "";
  const key = () => pending || lsGet(PW_KEY) || "";
  function authErr() { const e = new Error("unauthorized"); e.auth = true; return e; }
  async function call(method, path, body) {
    const k = key();
    if (!k) throw authErr();
    let r;
    try {
      r = await fetch(ADMIN_URL + path, {
        method: method,
        headers: Object.assign({ "X-Admin-Key": k }, body !== undefined ? { "Content-Type": "application/json" } : {}),
        body: body === undefined ? undefined : JSON.stringify(body),
        cache: "no-store", referrerPolicy: "no-referrer"
      });
    } catch (e) { const x = new Error("Could not reach the admin server. Check internet and try again."); x.net = true; throw x; }
    let d = null;
    try { d = await r.json(); } catch (e) {}
    if (r.status === 401) throw authErr();
    if (!r.ok || !d || d.ok === false) {
      const e = new Error((d && (d.error || (d.errors && d.errors.slice(0, 3).join(" · ")))) || ("HTTP " + r.status));
      e.status = r.status; e.data = d || {};
      throw e;
    }
    return d;
  }
  return {
    setPending(p) { pending = p || ""; },
    // cheapest call that needs the password: unknown id → 404 notFound (= password OK)
    async ping() {
      try { await call("GET", "/tests/get?id=MMH-PASSWORD-CHECK"); return true; }
      catch (e) { if (e.status === 404 && e.data && e.data.notFound) return true; throw e; }
    },
    get(id)            { return call("GET", "/tests/get?id=" + encodeURIComponent(id)); },
    upload(p)          { return call("POST", "/tests/upload", p); },
    flag(id, is_free)  { return call("POST", "/tests/flag", { id: id, is_free: is_free }); },
    hide(id)           { return call("POST", "/tests/hide", { id: id }); },
    show(id, is_free)  { return call("POST", "/tests/show", { id: id, is_free: is_free }); },
    // admin Worker v6: R2 folder + tests row (+ bank rows when d1)
    delTest(id, o)     { return call("POST", "/tests/delete", Object.assign({ id: id, confirm: id }, o || {})); },
    bodies(quids)      { return call("POST", "/bodies", { quids: quids }); },
    // Bulk tab (admin Worker v5)
    list(prefix, cursor) { return call("GET", "/tests/list?prefix=" + encodeURIComponent(prefix) + (cursor ? "&cursor=" + encodeURIComponent(cursor) : "")); },
    exportTest(id)     { return call("GET", "/tests/export?id=" + encodeURIComponent(id)); },
    // admin Worker v7: bulk check — every quiz id in ONE call · bank bodies 1000 per call
    check(ids)         { return call("POST", "/tests/check", { ids: ids }); },
    testBodies(quids)  { return call("POST", "/tests/bodies", { quids: quids }); }
  };
})();
const API = window.MMH_UP_API || REAL_API;

// ══════════════════════════════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════════════════════════════
const S = {
  tab: "bulk",
  file: null,            // { name, size }
  data: null,            // parsed JSON
  quizId: "", isFree: 0, org: "SSC", tag: "", tagTouched: false,
  tagOk: null, Pn: null,  // tagOk: exam tag lagana hai? null = abhi poocha nahi · Pn = prepare() bina tag ke
  fields: {},            // NEW (non-standard) field → "keep" | "remove" (admin ne chuna) — har nayi file pe reset
  P: null,               // MMHUpload.prepare() result
  filter: "all", shown: PAGE, open: {}, code: {}, lang: "en",
  imgs: {}, imgRun: false, imgDone: false,
  oldBodies: {},         // quid -> bank body (Load from D1 / matching / full JSON)
  dry: null, match: null, keep: {}, busy: false,
  result: null,          // last upload result (ok or failed)
  test: null             // Tests tab: { id, row, hidden, r2 }
};

// ══════════════════════════════════════════════════════════════════════════
//  SMALL HELPERS
// ══════════════════════════════════════════════════════════════════════════
let toastT = 0;
function toast(msg, ms) {
  const t = $("rqToast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove("show"), ms || 2600);
}
function kb(n) { return n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(1) + " KB" : (n / 1048576).toFixed(2) + " MB"; }
function quidPlus(q, n) { return "Q" + (Number(String(q).slice(1)) + n); }
function plain(v) {
  const s = typeof v === "string" ? v : (v && (v.en || v.hi)) || "";
  return String(s).replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&").replace(/\\[()[\]]/g, "").replace(/\s+/g, " ").trim();
}
function timeAgo(t) {
  const d = new Date(t), now = Date.now(), s = (now - t) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + " min ago";
  if (s < 86400 && d.getDate() === new Date().getDate()) return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  return d.toLocaleDateString([], { day: "numeric", month: "short" }) + ", " + d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
// ver = 1, 2, 3 … or a unix time (Show / upload over a hidden test) → readable either way
function verTxt(v) {
  v = Number(v);
  if (!(v > 1e9)) return "ver " + v;
  const d = new Date(v * 1000);
  return "ver " + d.toLocaleDateString([], { day: "numeric", month: "short" }) + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
function plural(n, a, b) { return n + " " + (n === 1 ? a : (b || a + "s")); }
function freeTxt(v) { return Number(v) === 1 ? "Free" : "Paid"; }
/* NEW field box: list = P.newFields-like [{name, nw, old, sample, choice}], attr = click attribute.
   Shown when a JSON has a field that is not a standard bank field → admin chooses Keep or Remove
   (instead of only an error). Keep = stored in D1 as it is · Remove = left out of the body. */
function fieldsBoxHtml(list, attr, note) {
  if (!list || !list.length) return "";
  const open = list.filter(f => !f.choice).length;
  return '<div class="up-box ' + (open ? "warn" : "info") + ' up-fields"><h4>' + (list.length === 1 ? "Naya field mila" : list.length + " naye fields mile") +
    " — rakhna hai ya hatana hai?</h4><p>Ye bank ke standard fields me nahi " + (list.length === 1 ? "hai" : "hain") + " (typo bhi ho sakta hai). " +
    "<b>Rakho</b> → question ke saath D1 me waisa hi save hoga · <b>Hatao</b> → upload se pehle nikal diya jayega." + (note ? " " + note : "") + "</p>" +
    list.map(f => {
      const n = (f.nw || 0) + (f.old || 0);
      return '<div class="up-field-row"><div class="up-field-txt"><code>' + esc(f.name) + "</code> · " + plural(n, "question") +
        (f.sample ? '<span class="up-field-eg">e.g. "' + esc(f.sample) + '"</span>' : "") + "</div>" +
        '<div class="up-seg up-field-seg" ' + attr + '="' + esc(f.name) + '"><button type="button" data-v="keep" class="' + (f.choice === "keep" ? "on" : "") + '">Rakho</button>' +
        '<button type="button" data-v="remove" class="' + (f.choice === "remove" ? "on" : "") + '">Hatao</button></div></div>';
    }).join("") + "</div>";
}
function busyBtn(btn, on, txt) {
  if (!btn) return;
  if (on) { btn._html = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="up-spin"></span><span>' + esc(txt || "Please wait…") + "</span>"; }
  else { btn.disabled = false; if (btn._html) btn.innerHTML = btn._html; }
}
function isNative() { try { return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()); } catch (e) { return false; } }
function saveFile(name, obj) {
  const text = typeof obj === "string" ? obj : JSON.stringify(obj, null, 1);
  saveBlob(name, new Blob([text], { type: "application/json" }), "application/json");
}
function saveBlob(name, blob, mime) {
  if (isNative() && typeof window.mmhSaveOrShare === "function") { window.mmhSaveOrShare(name, blob, mime); return; }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  toast("Downloaded " + name);
}
async function fetchBodies(quids, onProgress) {
  const need = [...new Set(quids)].filter(q => !(q in S.oldBodies));
  for (let i = 0; i < need.length; i += BODY_MAX) {
    const part = need.slice(i, i + BODY_MAX);
    const d = await API.bodies(part);
    part.forEach(q => { S.oldBodies[q] = d.questions && d.questions[q] ? d.questions[q] : null; });
    if (onProgress) onProgress(Math.min(i + BODY_MAX, need.length), need.length);
  }
  return S.oldBodies;
}

// ── history (this device) ────────────────────────────────────────────────
function histAll() { try { return JSON.parse(lsGet(HIST_KEY) || "[]") || []; } catch (e) { return []; } }
function histAdd(e) {
  const h = histAll();
  h.unshift(Object.assign({ t: Date.now() }, e));
  if (S.hsSel != null) S.hsSel = S.hsSel + 1 < HIST_MAX ? S.hsSel + 1 : null;   // keep the same entry selected
  lsSet(HIST_KEY, JSON.stringify(h.slice(0, HIST_MAX)));
  paintRecent();
  if (S.tab === "history") paintHistory();
}

// ══════════════════════════════════════════════════════════════════════════
//  GATE
// ══════════════════════════════════════════════════════════════════════════
function showGate(kind, err) {
  document.body.classList.add("ar-locked");
  $("arLock").hidden = true;
  const field = $("arGateField"), btn = $("arGateBtn"), note = $("arGateNote");
  if (kind === "denied" || kind === "login") {
    $("arGateTitle").textContent = kind === "denied" ? "Admins only" : "Please log in";
    $("arGateText").textContent = kind === "denied" ? "This page is only for admin accounts." : "Log in with your admin account first.";
    field.hidden = true; note.hidden = true;
    btn.textContent = kind === "denied" ? "Go to home" : "Log in";
    btn.setAttribute("data-go", kind === "denied" ? "/" : "/?login&redirect=" + encodeURIComponent(location.pathname));
  } else {
    $("arGateTitle").textContent = "Admin access";
    $("arGateText").textContent = "Enter the admin password to upload tests.";
    field.hidden = false; note.hidden = false;
    btn.textContent = "Unlock"; btn.removeAttribute("data-go");
    setTimeout(() => { try { $("arPw").focus(); } catch (e) {} }, 60);
  }
  const e = $("arGateErr");
  e.hidden = !err; e.textContent = err || "";
}
function showApp() {
  document.body.classList.remove("ar-locked");
  $("arLock").hidden = false;
  paintAll();
}
async function unlock(pw) {
  const btn = $("arGateBtn");
  btn.disabled = true; btn.textContent = "Checking…";
  $("arGateErr").hidden = true;
  API.setPending(pw);
  try {
    await API.ping();
    lsSet(PW_KEY, pw);
    API.setPending("");
    $("arPw").value = "";
    showApp();
  } catch (e) {
    API.setPending("");
    showGate("pw", e && e.auth ? "Wrong password. Try again." : "Could not connect to the admin server. Check internet and try again.");
  } finally {
    btn.disabled = false; if (!btn.getAttribute("data-go")) btn.textContent = "Unlock";
  }
}
function authLost() {
  lsDel(PW_KEY);
  closeSheet();
  showGate("pw", "The saved password is not valid any more. Enter it again.");
}
async function profileRole() {
  if (STANDALONE) return "unknown";
  for (let i = 0; i < 30 && typeof getLocalProfile !== "function"; i++) await new Promise(r => setTimeout(r, 100));
  if (typeof getLocalProfile !== "function") return "unknown";     // the password still protects everything
  const p = getLocalProfile();
  if (!p || (!p.id && !p.username)) return "none";
  return ROLES.indexOf(p.role) >= 0 ? "admin" : "user";
}

// ══════════════════════════════════════════════════════════════════════════
//  TABS
// ══════════════════════════════════════════════════════════════════════════
function setTab(t) {
  S.tab = t;
  document.querySelectorAll("#upDock .ex-dock-item").forEach(b => {
    const on = b.getAttribute("data-tab") === t;
    b.classList.toggle("active", on); b.setAttribute("aria-pressed", on ? "true" : "false");
  });
  $("upTabUpload").hidden = t !== "upload";
  $("upTabTests").hidden = t !== "tests";
  $("upTabHistory").hidden = t !== "history";
  if ($("upTabBulk")) $("upTabBulk").hidden = t !== "bulk";
  paintBar();
  if (t === "bulk" && window.MMHBulk) window.MMHBulk.show();
  if (t === "history") paintHistory();
  if (t === "tests") paintRecent();
  $("rqScroll").scrollTop = 0;
}
function paintAll() { paintUpload(); paintRecent(); paintBar(); }

// ══════════════════════════════════════════════════════════════════════════
//  STEP 1 · LOAD
// ══════════════════════════════════════════════════════════════════════════
function jsonError(text, e) {
  const m = /position (\d+)/i.exec(String(e && e.message));
  let where = "";
  if (m) {
    const pos = +m[1], before = text.slice(0, pos), line = before.split("\n").length, col = pos - before.lastIndexOf("\n");
    where = " (line " + line + ", column " + col + ")";
  }
  return "This is not valid JSON" + where + ".\n" + String(e && e.message || e);
}
function readFile(f) {
  if (!f) return;
  if (f.size > 40 * 1048576) { loadError("File is " + kb(f.size) + " — the limit is 40 MB."); return; }
  const fr = new FileReader();
  fr.onload = () => loadText(String(fr.result || ""), f.name, f.size);
  fr.onerror = () => loadError("Could not read the file.");
  fr.readAsText(f);
}
function loadError(msg) {
  const e = $("upLoadErr");
  e.textContent = msg; e.hidden = false;
}
function loadText(text, name, size) {
  $("upLoadErr").hidden = true;
  let data;
  try { data = JSON.parse(text.replace(/^\uFEFF/, "")); }
  catch (e) { loadError(jsonError(text, e)); return; }
  const shape = U.validateTest(data);
  if (shape) { loadError(shape); return; }
  S.file = { name: name || "pasted.json", size: size || text.length };
  S.data = data;
  const fromName = String(name || "").replace(/\.json$/i, "").replace(/\.(quid|full)$/i, "");
  S.quizId = (typeof data.meta.id === "string" && U.ID_RE.test(data.meta.id)) ? data.meta.id : (U.ID_RE.test(fromName) ? fromName : "");
  S.isFree = Number(data.meta.is_free) === 1 ? 1 : 0;
  S.org = U.guessOrg(S.quizId) || "SSC";
  S.tagTouched = false;
  S.tag = (U.tagForQuiz(S.quizId, S.org).tag) || "";
  S.fields = {};
  S.filter = "all"; S.shown = PAGE; S.open = {}; S.code = {};
  S.imgs = {}; S.imgDone = false; S.result = null;
  $("upPaste").hidden = true; $("upPasteBtn").hidden = false;
  recompute();
  if (!S.quizId) setTimeout(() => { try { $("upId").focus(); } catch (e) {} }, 80);
}
function clearFile() {
  S.file = null; S.data = null; S.P = null; S.result = null; S.dry = null;
  $("upFile").value = "";
  paintUpload(); paintBar();
}
function recompute() {
  if (S.result && S.result.ok) S.result = null;
  S.P = S.data ? U.prepare(S.data, { quizId: S.quizId, tag: S.tag, fields: S.fields }) : null;
  S.Pn = null; S.tagOk = null;
  S.dry = null; S.match = null; S.keep = {};
  paintUpload(); paintBar();
}

// ══════════════════════════════════════════════════════════════════════════
//  PAINT · UPLOAD TAB
// ══════════════════════════════════════════════════════════════════════════
function paintUpload() {
  const has = !!S.data;
  $("upDrop").hidden = has; $("upPasteBtn").hidden = has || !$("upPaste").hidden;
  document.querySelector("#upPick .up-or").hidden = has || !$("upPaste").hidden;
  $("upFileRow").hidden = !has;
  $("upSetup").hidden = !has;
  $("upCheck").hidden = !has;
  $("upEmpty").hidden = has || !!S.result;
  paintResult();
  if (!has) return;
  const P = S.P;
  $("upFileRow").innerHTML =
    '<span class="up-file-ico">' + IC.file + '</span>' +
    '<span class="up-file-txt"><div class="up-file-name">' + esc(S.file.name) + '</div>' +
    '<div class="up-file-sub">' + kb(S.file.size) + ' · ' + esc(String(S.data.meta.title || S.data.meta.name || "no title")) + '</div></span>' +
    '<button type="button" class="icon-btn" id="upClear" aria-label="Remove file" title="Choose another file">' + IC.x + '</button>';
  paintSetup();
  paintCheck();
}
function paintSetup() {
  const P = S.P;
  const id = $("upId");
  if (document.activeElement !== id) id.value = S.quizId;
  const okId = U.ID_RE.test(S.quizId);
  $("upIdHint").className = "up-hint" + (okId ? "" : " bad");
  $("upIdHint").innerHTML = okId
    ? "R2 folder <b>" + esc(S.quizId) + "/</b> · tests row id <b>" + esc(S.quizId) + "</b>"
    : (S.quizId ? "Only A-Z a-z 0-9 _ - (max 100)" : "Type the quiz id (meta.id is missing)");
  document.querySelectorAll("#upFree button").forEach(b => {
    const on = Number(b.getAttribute("data-v")) === S.isFree;
    b.classList.toggle("on", on); b.setAttribute("aria-checked", on ? "true" : "false");
  });
  $("upOrg").value = S.org;
  const tag = $("upTag");
  if (document.activeElement !== tag) tag.value = S.tag;
  const info = $("upTagInfo");
  if (P && P.ok !== undefined && P.counts) {
    const c = P.counts, nw = c.nw;
    let t;
    if (!nw) t = "No new question — the tag is not used.";
    else if (!S.tag) t = '<span class="warn">No tag. ' + (c.tagNone ? plural(c.tagNone, "question") + " will have no exam tag." : "") + "</span>";
    else t = "<b>" + c.tagAdded + "</b> get this tag · <b>" + c.tagKept + "</b> already have one" + (c.tagHi ? " (" + c.tagHi + " Hindi copied)" : "") +
      (c.tagAdded ? " · upload par poochega" : "");
    const g = U.tagForQuiz(S.quizId, S.org);
    if (S.tag && g.noYear && !S.tagTouched) t += ' · <span class="warn">no year in the quiz id</span>';
    info.innerHTML = t;
  } else info.textContent = "";
  const facts = [];
  if (P && P.kind) {
    facts.push('<span class="up-fact">Kind <b>' + (P.kind === "parts" ? "parts" : "full") + "</b></span>");
    facts.push('<span class="up-fact"><b>' + P.names.length + "</b> " + (P.names.length === 1 ? "section" : "sections") + "</span>");
    facts.push('<span class="up-fact">Marks <b>+' + esc(S.data.meta.correct_score ?? "?") + " / −" + esc(S.data.meta.negative_score ?? "?") + "</b></span>");
    if (S.data.meta.timer_minutes) facts.push('<span class="up-fact"><b>' + esc(S.data.meta.timer_minutes) + "</b> min</span>");
  }
  $("upFacts").innerHTML = facts.join("");
}
function rowFlags(r) {
  const imgBad = rowImages(r).some(u => S.imgs[u] === "bad");
  return { bad: r.errors.length > 0, warn: r.warnings.length > 0 || imgBad, imgBad: imgBad, nw: r.quid === null, tag: r.action === "added" };
}
function rowBody(r) {
  if (r.newIndex !== null && S.P.newBodies[r.newIndex]) return JSON.parse(S.P.newBodies[r.newIndex]);
  if (r.quid && S.oldBodies[r.quid]) return S.oldBodies[r.quid];
  return null;
}
function rowImages(r) {
  if (r._imgs) return r._imgs;
  const b = rowBody(r) || r.q;
  r._imgs = b ? U.imageUrls(b) : [];
  return r._imgs;
}
const FILTERS = [
  ["all", "All", () => true],
  ["bad", "Errors", f => f.bad],
  ["warn", "Warnings", f => f.warn],
  ["new", "New", f => f.nw],
  ["old", "Already in D1", f => !f.nw],
  ["tag", "Tag added", f => f.tag]
];
function paintCheck() {
  const P = S.P;
  if (!P) return;
  if (!P.ok && P.error) {
    $("upStats").innerHTML = "";
    $("upProblems").hidden = false; $("upProblems").className = "up-problems";
    $("upProblems").innerHTML = "<h4>Cannot check</h4>" + esc(P.error);
    $("upList").innerHTML = ""; $("upFilter").innerHTML = ""; $("upMore").hidden = true;
    return;
  }
  const c = P.counts;
  const flags = P.rows.map(rowFlags);
  const warnN = flags.filter(f => f.warn).length, imgBad = flags.filter(f => f.imgBad).length;
  $("upStats").innerHTML =
    '<div class="up-stat"><b>' + c.total + '</b><span>Questions</span></div>' +
    '<div class="up-stat new"><b>' + c.nw + '</b><span>New → D1</span></div>' +
    '<div class="up-stat old"><b>' + c.old + '</b><span>Have quid</span></div>' +
    (c.bad ? '<div class="up-stat bad"><b>' + c.bad + '</b><span>Errors</span></div>'
           : warnN ? '<div class="up-stat warn"><b>' + warnN + '</b><span>Warnings</span></div>'
           : '<div class="up-stat ok"><b>✓</b><span>All OK</span></div>');
  let fb = $("upFields");
  if (!fb) { fb = document.createElement("div"); fb.id = "upFields"; $("upProblems").parentNode.insertBefore(fb, $("upProblems")); }
  fb.innerHTML = fieldsBoxHtml((P.newFields || []).filter(f => f.nw > 0).map(f => ({ name: f.name, nw: f.nw, sample: f.sample, choice: f.choice })), "data-ufield");
  const errs = P.problems.errors, warns = P.problems.warnings;
  const pb = $("upProblems");
  if (errs.length) {
    pb.hidden = false; pb.className = "up-problems";
    const fOpen = (P.newFields || []).some(f => f.nw > 0 && !f.choice);
    pb.innerHTML = "<h4>" + plural(c.bad, "question") + (c.bad === 1 ? " breaks" : " break") + " the bank rules — " + (fOpen ? "naye field ke liye upar Rakho / Hatao chuno" : "fix the JSON and load it again") + "</h4><ul>" +
      errs.slice(0, 6).map(e => "<li>" + esc(e) + "</li>").join("") + (errs.length > 6 ? "<li>… " + (errs.length - 6) + " more (filter: Errors)</li>" : "") + "</ul>";
  } else if (warns.length) {
    pb.hidden = false; pb.className = "up-problems warn";
    pb.innerHTML = "<h4>Check</h4><ul>" + warns.map(e => "<li>" + esc(e) + "</li>").join("") + "</ul>";
  } else pb.hidden = true;

  $("upFilter").innerHTML = FILTERS.map(f => {
    const n = flags.filter(f[2]).length;
    if (f[0] !== "all" && !n && S.filter !== f[0]) return "";
    return '<button type="button" data-filter="' + f[0] + '" class="' + (S.filter === f[0] ? "on" : "") + '">' + f[1] + "<i>" + n + "</i></button>";
  }).join("");
  const imgsTotal = new Set([].concat(...P.rows.map(rowImages))).size;
  $("upImgBtn").hidden = !imgsTotal;
  if (!S.imgRun) $("upImgTxt").textContent = S.imgDone ? (imgBad ? imgBad + " with broken image" : "Images OK ✓") : "Check " + plural(imgsTotal, "image");
  $("upLang").value = S.lang;
  paintList(flags);
}
function paintList(flags) {
  const P = S.P, fn = (FILTERS.find(f => f[0] === S.filter) || FILTERS[0])[2];
  const list = $("upList");
  const pick = [];
  P.rows.forEach((r, i) => { if (fn(flags[i])) pick.push(i); });
  let html = "", sec = null, n = 0;
  const secCount = {};
  P.rows.forEach(r => { secCount[r.sec] = (secCount[r.sec] || 0) + 1; });
  for (const i of pick) {
    if (n >= S.shown) break;
    const r = P.rows[i];
    if (r.sec !== sec) { sec = r.sec; html += '<div class="up-sec">' + esc(sec) + " <span>· " + plural(secCount[sec], "question") + "</span></div>"; }
    html += rowHtml(r, i, flags[i]);
    n++;
  }
  if (!pick.length) html = '<div class="up-more-note">Nothing here.</div>';
  list.innerHTML = html;
  $("upMore").hidden = pick.length <= S.shown;
  // render the open cards
  list.querySelectorAll(".up-q.open").forEach(el => renderOpenCard(el));
  if (list.querySelector(".up-q.open") && typeof renderMath === "function") renderMath();
}
function rowHtml(r, i, f) {
  const b = rowBody(r) || r.q || {};
  const q = b.question !== undefined ? b.question : (b.q !== undefined ? b.q : "");
  let text = plain(q && typeof q === "object" ? (S.lang === "hi" ? (q.hi || q.en) : (q.en || q.hi)) : q);
  if (!text && r.quid && !r.q) text = "Question " + r.quid + " (in D1)";
  const tags = [];
  tags.push(f.nw ? '<span class="up-b up-b-new">NEW</span>' : '<span class="up-b up-b-old">' + esc(String(r.quid).slice(-6)) + "</span>");
  if (f.tag) tags.push('<span class="up-b up-b-tag">TAG+</span>');
  if (f.imgBad) tags.push('<span class="up-b up-b-img">IMG ✕</span>');
  if (r.errors.length) tags.push('<span class="up-b up-b-bad">✕ ' + r.errors.length + "</span>");
  else if (r.warnings.length) tags.push('<span class="up-b up-b-warn">! ' + r.warnings.length + "</span>");
  const open = !!S.open[i];
  return '<div class="up-q' + (f.bad ? " bad" : f.warn ? " warn" : "") + (open ? " open" : "") + '" data-i="' + i + '">' +
    '<button type="button" class="up-q-head" data-open="' + i + '" aria-expanded="' + open + '">' +
      '<span class="up-q-no">Q' + (r.pos + 1) + "</span>" +
      '<span class="up-q-txt">' + esc(text || "—") + "</span>" +
      '<span class="up-q-tags">' + tags.join("") + "</span>" + IC.chev +
    "</button>" + (open ? '<div class="up-q-body">' + rowBodyHtml(r, i) + "</div>" : "") + "</div>";
}
function rowBodyHtml(r, i) {
  const meta = [];
  meta.push("local id <b>" + esc(r.lid == null ? "—" : r.lid) + "</b>");
  if (r.quid) meta.push("quid <b>" + esc(r.quid) + "</b> (already in D1)");
  else if (r.newIndex !== null) meta.push("new quid <b>" + (S.dry ? esc(quidPlus(S.dry.next_quid, newPos(r.newIndex))) : "after Check") + "</b>");
  if (r.bytes) meta.push("<b>" + kb(r.bytes) + "</b> in D1");
  const is = [];
  r.errors.forEach(e => is.push('<li class="e">' + esc(e) + "</li>"));
  r.warnings.forEach(e => is.push('<li class="w">' + esc(e) + "</li>"));
  rowImages(r).filter(u => S.imgs[u] === "bad").forEach(u => is.push('<li class="w">image does not load: ' + esc(u) + "</li>"));
  if (r.action === "added") is.push('<li class="t">exam tag added: [' + esc(r.tag) + "]</li>");
  if (r.action === "kept" || r.action === "hi-added") is.push('<li class="t">has its own exam tag: [' + esc(r.tag || "") + "]</li>");
  groupFixes(r.fixes).forEach(e => is.push('<li class="f">' + esc(e) + "</li>"));
  const needD1 = r.quid && !(r.quid in S.oldBodies);
  return '<div class="up-q-meta">' + meta.join("") + "</div>" +
    (is.length ? '<ul class="up-issues">' + is.join("") + "</ul>" : "") +
    (needD1 ? '<div class="up-q-actions"><button type="button" class="rq-btn" data-d1="' + i + '">' + IC.db + "<span>Load from D1</span></button></div>"
            : '<div class="up-q-card" data-card="' + i + '"></div>') +
    '<div class="up-q-actions">' +
      (rowBody(r) ? '<button type="button" class="rq-btn" data-code="' + i + '">' + IC.code + "<span>" + (S.code[i] ? "Hide" : "Show") + " Q-Bank JSON</span></button>" : "") +
    "</div>" +
    (S.code[i] && rowBody(r) ? '<pre class="up-code">' + esc(JSON.stringify(rowBody(r), null, 1)) + "</pre>" : "");
}
// "option_1: X", "option_2: X" … → "option_1, option_2: X"
function groupFixes(list) {
  const order = [], by = {};
  list.forEach(f => {
    const m = /^([a-z_0-9.]+): (.*)$/i.exec(f);
    if (!m) { order.push(f); return; }
    if (!by[m[2]]) { by[m[2]] = []; order.push({ msg: m[2] }); }
    by[m[2]].push(m[1]);
  });
  return order.map(o => (typeof o === "string" ? o : by[o.msg].join(", ") + ": " + o.msg));
}
// position of a new body among the bodies that are really sent (after "keep old quid")
function newPos(idx) {
  let n = 0;
  for (let k = 0; k < idx; k++) if (!S.keep[k]) n++;
  return n;
}
function displayQ(r) {
  const b = rowBody(r);
  const q = b ? R.expand(JSON.parse(JSON.stringify(b))) : JSON.parse(JSON.stringify(r.q || {}));
  q.id = r.lid; q.quiz_id = S.quizId;
  if (r.q && r.q.correct_score !== undefined) q.correct_score = r.q.correct_score; else if (q.correct_score === undefined) q.correct_score = S.data.meta.correct_score;
  if (r.q && r.q.negative_score !== undefined) q.negative_score = r.q.negative_score; else if (q.negative_score === undefined) q.negative_score = S.data.meta.negative_score;
  ["option_1", "option_2", "option_3", "option_4", "question", "solution_text"].forEach(k => { if (q[k] === undefined) q[k] = { en: "", hi: "" }; });
  return q;
}
function renderOpenCard(el) {
  const i = +el.getAttribute("data-i"), r = S.P.rows[i];
  const box = el.querySelector("[data-card]");
  if (!box || typeof mmhRenderCard !== "function") return;
  try {
    const card = mmhRenderCard(displayQ(r), {
      lang: S.lang, quizId: S.quizId, index: r.pos + 1, total: 0,
      mode: "solution", allowSolution: false, solutionOpen: true, showPercent: false, onPick: null, headExtra: ""
    });
    box.innerHTML = ""; box.appendChild(card);
  } catch (e) { box.innerHTML = '<div class="up-err">Preview failed: ' + esc(e.message) + "</div>"; }
}

// ── image check (browser loads every image once) ─────────────────────────
function checkImages() {
  if (S.imgRun || !S.P) return;
  const urls = [...new Set([].concat(...S.P.rows.map(rowImages)))].filter(u => !S.imgs[u] || S.imgs[u] === "bad");
  if (!urls.length) { S.imgDone = true; paintCheck(); return; }
  S.imgRun = true;
  let done = 0, next = 0;
  const txt = $("upImgTxt"), btn = $("upImgBtn");
  btn.disabled = true;
  function one() {
    if (next >= urls.length) return Promise.resolve();
    const u = urls[next++];
    return new Promise(res => {
      const im = new Image(); let fin = false;
      const end = ok => { if (fin) return; fin = true; S.imgs[u] = ok ? "ok" : "bad"; done++; txt.textContent = "Checking " + done + "/" + urls.length + "…"; res(); };
      const t = setTimeout(() => end(false), 15000);
      im.onload = () => { clearTimeout(t); end(im.naturalWidth > 0); };
      im.onerror = () => { clearTimeout(t); end(false); };
      im.referrerPolicy = "no-referrer";
      im.src = u;
    }).then(one);
  }
  Promise.all([one(), one(), one(), one(), one(), one()]).then(() => {
    S.imgRun = false; S.imgDone = true; btn.disabled = false;
    const bad = Object.keys(S.imgs).filter(u => S.imgs[u] === "bad").length;
    toast(bad ? plural(bad, "image") + " did not load" : "All " + urls.length + " images load ✓", 3200);
    if (bad && S.filter === "all") S.filter = "warn";
    paintCheck(); paintBar();
  });
}

// ══════════════════════════════════════════════════════════════════════════
//  UPLOAD BAR
// ══════════════════════════════════════════════════════════════════════════
function paintBar() {
  const show = S.tab === "upload" && !!S.data && !document.body.classList.contains("ar-locked");
  $("upBar").hidden = !show;
  document.body.classList.toggle("up-has-bar", show);
  if (!show) return;
  const P = S.P, go = $("upGo");
  let txt, ok = false;
  if (S.result && S.result.ok) {
    $("upBarTxt").innerHTML = "<b>" + esc(S.result.payload.id) + "</b><br>Uploaded ✓ · " + esc(verTxt(S.result.res.ver));
    $("upGoTxt").textContent = "New upload";
    go.disabled = false; go.dataset.mode = "new";
    return;
  }
  $("upGoTxt").textContent = "Check & Upload"; go.dataset.mode = "";
  if (!U.ID_RE.test(S.quizId)) txt = '<span class="bad">Type a valid quiz id</span>';
  else if (!P || P.error) txt = '<span class="bad">' + esc(P && P.error || "Cannot check") + "</span>";
  else if (!P.ok && (P.newFields || []).some(f => f.nw > 0 && !f.choice)) txt = '<span class="bad">Naya field mila — Rakho ya Hatao chuno</span>';
  else if (!P.ok) txt = '<span class="bad">' + plural(P.counts.bad, "question") + " with errors — fix the JSON</span>";
  else {
    ok = true;
    txt = "<b>" + esc(S.quizId) + "</b><br>" + plural(P.counts.nw, "new question") + " → D1 · " + P.counts.old + " with quid · " + freeTxt(S.isFree);
  }
  $("upBarTxt").innerHTML = txt;
  if (!S.busy) go.disabled = !ok;
}

// ══════════════════════════════════════════════════════════════════════════
//  CHECK & UPLOAD
// ══════════════════════════════════════════════════════════════════════════
function tagAsk() { return !!(S.P && S.P.counts && S.P.counts.tagAdded > 0); }   // kuch naye Qs ko auto tag milega?
function upP() {                                   // "Nahi" chuna → wahi file bina auto exam tag ke
  if (S.tagOk !== false || !tagAsk()) return S.P;
  if (!S.Pn) S.Pn = U.prepare(S.data, { quizId: S.quizId, tag: "", fields: S.fields });
  return S.Pn.ok ? S.Pn : S.P;
}
function tagAskHtml() {
  if (!tagAsk()) return "";
  const c = S.P.counts;
  return '<div class="up-h5">Exam tag</div><div class="up-box ' + (S.tagOk === null ? "warn" : "info") + '"><h4>Exam tag generate karna hai?</h4><p><b>' + c.tagAdded +
    "</b> naye " + (c.tagAdded === 1 ? "question" : "questions") + " me exam tag nahi hai. Haan → in sab ke end me lagega: <code>[" + esc(S.tag) + "]</code>" +
    (c.tagKept ? "<br><b>" + c.tagKept + "</b> me pehle se tag hai — wo waisa hi rahega (dobara nahi banega)." : "") + "</p></div>" +
    '<div class="up-seg up-tagok" data-tagok><button type="button" data-v="1" class="' + (S.tagOk === true ? "on" : "") + '">Haan, tag lagao</button>' +
    '<button type="button" data-v="0" class="' + (S.tagOk === false ? "on" : "") + '">Nahi, bina tag</button></div>';
}
function basePayload() {
  const P = upP();
  const a = U.applyMatches(P, S.keep);
  return { id: S.quizId, is_free: S.isFree, meta: P.meta, sections: a.sections, new: a.newBodies, _reused: a.reused };
}
function stripLocal(p) { const o = Object.assign({}, p); delete o._reused; return o; }
function failText(e) {
  const d = e && e.data || {};
  if (d.missing && d.missing.length) return "These quids are not in D1: " + d.missing.slice(0, 8).join(", ") + (d.missing.length > 8 ? " …" : "");
  if (d.errors && d.errors.length) return d.errors.slice(0, 6).join("\n");
  return (e && e.message) || "Failed";
}
async function go() {
  if (S.busy || !S.P || !S.P.ok) return;
  const btn = $("upGo");
  S.busy = true; busyBtn(btn, true, "Checking…");
  try {
    S.keep = {}; S.match = null;
    let dry = await API.upload(Object.assign(stripLocal(basePayload()), { dry: true }));
    if (dry.exists) {
      // test already on R2 → updating it: every question must carry its quid (no local-id guessing)
      const nq = U.noQuidError(S.P);
      if (nq) { S.dry = null; showFail({ message: nq.join("\n"), data: {} }, "quid"); return; }
    }
    S.dry = dry; S.tagOk = null;
    openConfirm();
  } catch (e) {
    if (e && e.auth) { authLost(); return; }
    showFail(e, "check");
  } finally {
    S.busy = false; busyBtn(btn, false); paintBar();
  }
}

// ── confirm sheet ────────────────────────────────────────────────────────
let sheetOk = null;
function openSheet(title, body, okTxt, onOk, danger) {
  $("upSheetTitle").textContent = title;
  $("upSheetBody").innerHTML = body;
  const ok = $("upSheetOk");
  ok.textContent = okTxt; ok.disabled = false;
  ok.classList.toggle("ar-btn-danger", !!danger);
  sheetOk = onOk;
  $("upSheet").hidden = false;
}
function closeSheet() { $("upSheet").hidden = true; sheetOk = null; }

function confirmHtml() {
  const P = S.P, d = S.dry, p = basePayload(), nNew = p.new.length;
  const first = nNew ? d.next_quid : null, last = nNew ? quidPlus(d.next_quid, nNew - 1) : null;
  const live = d.exists && d.row, hidden = d.exists && !d.row;
  let h = tagAskHtml();
  if (live) h += '<div class="up-box warn"><h4>This test is already live</h4><p>' + esc(verTxt(d.row.ver)) + " · " + freeTxt(d.row.is_free) + " · " + esc(d.row.kind) +
    ". Uploading replaces its R2 files. Users get the new version (cache keys change with ver).</p></div>";
  else if (hidden) h += '<div class="up-box warn"><h4>Files for this id are already on R2 (test hidden)</h4><p>Uploading replaces them and makes the test live again.</p></div>';
  else h += '<div class="up-box info"><h4>New test</h4><p>Nothing with this id exists yet.</p></div>';
  h += '<dl class="up-sum">' +
    "<dt>Quiz id</dt><dd><code>" + esc(S.quizId) + "</code></dd>" +
    "<dt>Access</dt><dd>" + freeTxt(S.isFree) + (live && Number(d.row.is_free) !== S.isFree ? ' <span class="up-b up-b-warn">was ' + freeTxt(d.row.is_free) + "</span>" : "") + "</dd>" +
    "<dt>Questions</dt><dd>" + P.counts.total + " in " + plural(P.names.length, "section") + " · " + (P.kind) + "</dd>" +
    "<dt>D1 (bank)</dt><dd>" + (nNew ? plural(nNew, "new row") + ' <code>' + first + "</code> → <code>" + last + "</code>" : "nothing new") +
      (P.counts.old + p._reused ? "<br>" + (P.counts.old + p._reused) + " use an existing quid" : "") + "</dd>" +
    "<dt>R2</dt><dd>meta.json + " + plural(P.names.length, "section file") + (d.old && d.old.names ? stale(d.old.names, P.names) : "") + "</dd>" +
    "<dt>tests row</dt><dd>" + (live ? verTxt(d.row.ver) + " → " + verTxt(d.row.ver + 1) : hidden ? "created again (ver = now)" : "new · ver 1") + "</dd></dl>";
  if (S.match && S.match.length) h += matchHtml();
  if (d.exists && d.old) h += diffHtml(p);
  if (d.exists) h += '<label class="up-check"><input type="checkbox" id="upAgree"> <span>I checked the differences — replace the live test.</span></label>';
  return h;
}
function stale(oldNames, names) {
  const gone = oldNames.filter(n => names.indexOf(n) === -1);
  return gone.length ? '<br><span class="up-b up-b-warn">deleted</span> ' + gone.map(esc).join(", ") : "";
}
function matchHtml() {
  const same = S.match.filter(m => m.same), diff = S.match.filter(m => !m.same && !m.missing);
  let h = '<div class="up-h5">Same local id as the live test</div>';
  h += '<div class="up-box ' + (diff.length ? "warn" : "ok") + '"><p><b>' + same.length + "</b> identical to D1 → old quid reused (no duplicate)." +
    (diff.length ? "<br><b>" + diff.length + "</b> different from D1 (D1 may have been corrected later). Choose for each:" : "") + "</p></div>";
  if (diff.length) {
    h += '<div class="up-drows">' + diff.slice(0, 40).map(m => {
      const k = m.row.newIndex, keep = !!S.keep[k];
      return '<div class="up-match"><div class="w"><b>' + esc(m.row.sec) + " Q" + (m.row.pos + 1) + " · id " + esc(m.row.lid) + "</b><span>" + esc(m.oldQuid) + " · differs: " + esc(m.fields.join(", ")) + "</span></div>" +
        '<div class="up-seg" data-keep="' + k + '"><button type="button" data-v="old" class="' + (keep ? "on" : "") + '">Keep D1</button><button type="button" data-v="new" class="' + (keep ? "" : "on") + '">New quid</button></div></div>';
    }).join("") + (diff.length > 40 ? '<div class="up-more-note">… ' + (diff.length - 40) + " more keep D1</div>" : "") + "</div>";
  }
  return h;
}
function diffHtml(p) {
  const P = S.P, d = S.dry;
  const newS = { meta: U.metaOut(P.meta, P.names, P.kind), sections: p.sections };
  const df = U.diff(d.old, newS);
  const c = df.counts;
  let h = '<div class="up-h5">Live test → this upload</div>';
  if (df.same) return h + '<div class="up-box ok"><p>No difference — the R2 files stay the same (ver still goes up).</p></div>';
  h += '<div class="up-dcount"><div><b>' + c.same + '</b><span>Same</span></div><div class="ch"><b>' + c.changed + '</b><span>Changed</span></div>' +
    '<div class="ad"><b>' + c.added + '</b><span>Added</span></div><div class="rm"><b>' + c.removed + "</b><span>Removed</span></div></div>";
  const lines = [];
  if (df.secAdded.length) lines.push(['<span class="up-b up-b-tag">+ section</span>', df.secAdded.map(esc).join(", ")]);
  if (df.secRemoved.length) lines.push(['<span class="up-b up-b-bad">− section</span>', df.secRemoved.map(esc).join(", ")]);
  if (df.metaKeys.length) lines.push(['<span class="up-b up-b-warn">meta</span>', df.metaKeys.map(esc).join(", ")]);
  const q = v => (/^#\d+$/.test(String(v)) ? "<ins>NEW " + esc(quidPlus(d.next_quid, +String(v).slice(1))) + "</ins>" : esc(v));
  df.rows.slice(0, 60).forEach(r => {
    const where = esc(r.sec) + " Q" + (r.pos + 1);
    if (r.kind === "changed") {
      const parts = [];
      if (String(r.oldLid) !== String(r.newLid)) parts.push("id <s>" + esc(r.oldLid) + "</s> " + esc(r.newLid));
      if (r.oldQuid !== r.newQuid) parts.push("<s>" + esc(r.oldQuid) + "</s> " + q(r.newQuid));
      if (r.marks) parts.push("marks changed");
      lines.push([where, parts.join(" · ")]);
    } else if (r.kind === "added") lines.push([where, "<ins>+</ins> id " + esc(r.newLid) + " · " + q(r.newQuid)]);
    else lines.push([where, "<s>removed · id " + esc(r.oldLid) + " · " + esc(r.oldQuid) + "</s>"]);
  });
  h += '<div class="up-drows">' + lines.map(l => '<div class="up-drow"><span class="w">' + l[0] + '</span><span class="v">' + l[1] + "</span></div>").join("") +
    (df.rows.length > 60 ? '<div class="up-more-note">… ' + (df.rows.length - 60) + " more rows</div>" : "") + "</div>";
  return h;
}
function openConfirm() {
  const d = S.dry;
  const title = d.exists ? (d.row ? "Replace live test?" : "Upload over hidden files?") : "Upload new test?";
  openSheet(title, confirmHtml(), d.exists ? "Replace" : "Upload now", doUpload, false);
  syncAgree();
}
function syncAgree() {
  const a = $("upAgree"), ok = $("upSheetOk");
  ok.disabled = (a ? !a.checked : false) || (tagAsk() && S.tagOk === null);
}
async function doUpload() {
  const d = S.dry, ok = $("upSheetOk");
  const p = stripLocal(basePayload());
  if (d.exists) { p.replace = true; p.expect_ver = d.row ? d.row.ver : 0; }
  busyBtn(ok, true, "Uploading…");
  $("upSheet").querySelectorAll("[data-close]").forEach(b => { b.disabled = true; });
  try {
    const res = await API.upload(p);
    closeSheet();
    S.result = { ok: true, res: res, payload: p, meta: S.P.meta, replaced: !!d.exists };
    histAdd({ act: d.exists ? "replace" : "upload", id: p.id, ok: true, ver: res.ver, first: res.first || null, last: res.last || null,
              nw: p.new.length, old: S.P.counts.total - p.new.length, free: p.is_free, kind: res.row && res.row.kind, tag: tagAsk() ? (S.tagOk ? 1 : 0) : undefined });
    toast("Uploaded ✓  " + verTxt(res.ver) + (tagAsk() ? (S.tagOk ? " · exam tag added" : " · no exam tag") : ""), 3200);
  } catch (e) {
    closeSheet();
    if (e && e.auth) { authLost(); return; }
    showFail(e, "upload", p);
  } finally {
    busyBtn(ok, false);
    $("upSheet").querySelectorAll("[data-close]").forEach(b => { b.disabled = false; });
    paintUpload(); paintBar();
    if (S.result) $("upResult").scrollIntoView({ block: "start", behavior: "smooth" });
  }
}
function showFail(e, when, p) {
  const d = (e && e.data) || {};
  S.result = { ok: false, err: e, data: d, payload: p || null, meta: S.P && S.P.meta, when: when };
  if (when === "upload") histAdd({ act: "upload", id: S.quizId, ok: false, stage: d.stage || "", error: failText(e).slice(0, 160) });
  paintUpload();
  $("upResult").scrollIntoView({ block: "start", behavior: "smooth" });
}

// ── result card ──────────────────────────────────────────────────────────
function paintResult() {
  const el = $("upResult"), r = S.result;
  el.hidden = !r;
  if (!r) return;
  el.className = "up-card up-result " + (r.ok ? "ok" : "bad");
  if (r.ok) {
    const x = r.res, n = r.payload.new.length;
    el.innerHTML = '<div class="up-res-head"><span class="up-res-ico">' + IC.ok + '</span><div><h3>' + (r.replaced ? "Replaced" : "Uploaded") + " · " + esc(verTxt(x.ver)) + "</h3>" +
      "<p><code class=\"up-mono\">" + esc(r.payload.id) + "</code> is live · " + freeTxt(x.row && x.row.is_free) + " · " + esc(x.row && x.row.kind) + "</p></div></div>" +
      '<dl class="up-sum"><dt>New in D1</dt><dd>' + (n ? plural(n, "question") + " <code>" + esc(x.first) + "</code> → <code>" + esc(x.last) + "</code>" : "none") + "</dd>" +
      "<dt>Existing quids</dt><dd>" + (S.P ? S.P.counts.total - n : 0) + "</dd><dt>R2</dt><dd>meta.json + " + plural(Object.keys(x.structure.sections).length, "section file") + "</dd></dl>" +
      '<div class="up-box info"><p>Keep the <b>quid JSON</b>: uploading it again later sends nothing new to D1 (R2 only).</p></div>' +
      '<div class="up-btns"><button type="button" class="rq-btn rq-btn-primary" data-dl="quid">' + IC.down + "<span>Quid JSON</span></button>" +
      '<button type="button" class="rq-btn" data-dl="full">' + IC.down + "<span>Full JSON (with quids)</span></button>" +
      '<button type="button" class="rq-btn" data-open-test="' + esc(r.payload.id) + '">' + IC.stack + "<span>Open in Tests</span></button>" +
      '<button type="button" class="rq-btn rq-btn-soft up-render-btn" data-render="' + esc(r.payload.id) + '">' + IC.render + "<span>Render Questions</span></button></div>";
    return;
  }
  const d = r.data, st = d.stage;
  const canRetry = (st === "r2" || st === "tests") && d.structure;
  let head = "Upload failed", sub = failText(r.err);
  if (r.when === "check") head = d.stage === "check" ? "The Worker rejected the test" : "Check failed";
  if (r.when === "quid") head = "Quid missing — this test already exists";
  if (st === "d1") { head = "Nothing was saved"; sub = (r.err.status === 409 ? "Someone saved questions at the same moment. Press Check & Upload again. " : "") + failText(r.err); }
  if (canRetry) { head = st === "r2" ? "Questions saved in D1 — R2 upload failed" : "D1 + R2 done — tests row failed"; sub = "The new quids are fixed now. Press Retry (nothing new goes to D1). " + failText(r.err); }
  if (r.err && r.err.status === 409 && d.exists) { head = "Test changed meanwhile"; sub = "Somebody else updated this test. Press Check & Upload again to see the new state."; }
  el.innerHTML = '<div class="up-res-head"><span class="up-res-ico">' + IC.bad + "</span><div><h3>" + esc(head) + '</h3><p style="white-space:pre-wrap">' + esc(sub) + "</p></div></div>" +
    (canRetry ? '<dl class="up-sum"><dt>Quids</dt><dd><code>' + esc(d.first || "—") + "</code> → <code>" + esc(d.last || "—") + "</code></dd></dl>" +
      '<div class="up-btns"><button type="button" class="rq-btn rq-btn-primary" id="upRetry">' + IC.retry + "<span>Retry</span></button>" +
      '<button type="button" class="rq-btn" data-dl="quid">' + IC.down + "<span>Quid JSON (keep it!)</span></button></div>" : "");
}
async function retry() {
  const r = S.result, d = r.data, btn = $("upRetry");
  const p = { id: r.payload.id, is_free: r.payload.is_free, meta: r.payload.meta, sections: d.structure.sections, new: [] };
  busyBtn(btn, true, "Retrying…");
  try {
    const dry = await API.upload(Object.assign({}, p, { dry: true }));
    if (dry.exists) { p.replace = true; p.expect_ver = dry.row ? dry.row.ver : 0; }
    const res = await API.upload(p);
    S.result = { ok: true, res: res, payload: p, meta: p.meta, replaced: !!r.payload.replace };
    histAdd({ act: "retry", id: p.id, ok: true, ver: res.ver, first: d.first || null, last: d.last || null, nw: 0, old: 0, free: p.is_free, kind: res.row && res.row.kind });
    toast("Done ✓  " + verTxt(res.ver));
  } catch (e) {
    if (e && e.auth) { authLost(); return; }
    toast(failText(e), 4200);
  } finally { busyBtn(btn, false); paintUpload(); }
}
async function downloadResult(kind, btn) {
  const r = S.result;
  const structure = r.ok ? r.res.structure : r.data.structure;
  const id = r.payload.id;
  const qj = U.quidJson(r.meta, structure);
  if (kind === "quid") { saveFile(id + ".quid.json", qj); return; }
  // full JSON: new bodies are here; existing quids come from D1
  const map = (r.ok ? r.res.quids : r.data.quids) || {};
  const bodies = {};
  Object.keys(map).forEach(k => { const i = +k.slice(1); if (r.payload.new[i]) bodies[map[k]] = JSON.parse(r.payload.new[i]); });
  const need = [];
  Object.keys(qj.sections).forEach(n => U.sectionList(qj.sections[n]).forEach(it => { if (!bodies[it[1]]) need.push(it[1]); }));
  busyBtn(btn, true, "Loading…");
  try {
    if (need.length) await fetchBodies(need, (a, b) => { btn.querySelector("span:last-child").textContent = "D1 " + a + "/" + b; });
    need.forEach(q => { if (S.oldBodies[q]) bodies[q] = S.oldBodies[q]; });
    const a = U.assemble(qj, bodies);
    if (a.missing.length) toast(plural(a.missing.length, "quid") + " missing in D1 — left out", 4000);
    saveFile(id + ".full.json", a.test);
  } catch (e) { if (e && e.auth) authLost(); else toast(failText(e), 4000); }
  finally { busyBtn(btn, false); }
}

// ══════════════════════════════════════════════════════════════════════════
//  TESTS TAB
// ══════════════════════════════════════════════════════════════════════════
function paintRecent() {
  const ids = [];
  histAll().forEach(h => { if (h.id && ids.indexOf(h.id) === -1 && ids.length < 8) ids.push(h.id); });
  $("tsRecent").innerHTML = ids.map(id => '<button type="button" data-open-test="' + esc(id) + '">' + esc(id) + "</button>").join("");
}
async function openTest(id) {
  id = String(id || "").trim();
  if (!U.ID_RE.test(id)) { toast("Quiz id: only A-Z a-z 0-9 _ -"); return; }
  setTab("tests");
  $("tsId").value = id;
  $("tsEmpty").hidden = true;
  $("tsCard").innerHTML = '<div class="up-card"><div class="up-more-note"><span class="up-spin" style="display:inline-block;vertical-align:middle"></span> Loading ' + esc(id) + "…</div></div>";
  try {
    const d = await API.get(id);
    S.test = { id: id, row: d.row, hidden: d.hidden, r2: d.r2 };
  } catch (e) {
    if (e && e.auth) { authLost(); return; }
    if (e.status === 404) S.test = { id: id, notFound: true };
    else { $("tsCard").innerHTML = '<div class="up-card"><div class="up-err">' + esc(failText(e)) + "</div></div>"; return; }
  }
  paintTest();
}
function paintTest() {
  const t = S.test, el = $("tsCard");
  $("tsEmpty").hidden = !!t;
  if (!t) { el.innerHTML = ""; return; }
  if (t.notFound) {
    el.innerHTML = '<div class="up-card"><div class="ts-head"><span class="ts-ico">' + IC.stack + '</span><div><div class="ts-title">' + esc(t.id) +
      '</div><div class="ts-sub">Not found — no tests row and no files on R2.</div></div></div></div>';
    return;
  }
  const r2 = t.r2 || {}, names = r2.names || [], row = t.row;
  const chips = [];
  chips.push(row ? '<span class="up-chip live">Live</span>' : '<span class="up-chip is-hidden">Hidden</span>');
  if (row) { chips.push('<span class="up-chip ' + (row.is_free ? "free" : "paid") + '">' + freeTxt(row.is_free) + "</span>"); chips.push('<span class="up-chip">' + esc(row.kind) + "</span>"); chips.push('<span class="up-chip">' + esc(verTxt(row.ver)) + "</span>"); }
  let total = 0;
  const secs = names.map(n => { const l = r2.sections && r2.sections[n] ? U.sectionList(r2.sections[n]) || [] : []; total += l.length; return '<div class="ts-sec"><b>' + esc(n) + "</b><span>" + plural(l.length, "question") + "</span></div>"; });
  const title = r2.meta && (r2.meta.title || r2.meta.name);
  el.innerHTML = '<div class="up-card"><div class="ts-head"><span class="ts-ico">' + IC.stack + '</span><div style="min-width:0"><div class="ts-title">' + esc(t.id) + "</div>" +
    '<div class="ts-sub">' + esc(title || "") + (title ? " · " : "") + (r2.meta ? plural(total, "question") : "no files on R2") + '</div><div class="ts-chips">' + chips.join("") + "</div></div></div>" +
    (secs.length ? '<div class="ts-secs">' + secs.join("") + "</div>" : "") +
    (!row && r2.meta ? '<div class="up-box warn" style="margin-top:12px"><p>Hidden: users cannot open it. R2 files and D1 questions are kept — Show makes it live again with a fresh cache.</p></div>' : "") +
    '<div class="up-btns">' +
      (r2.meta ? '<button type="button" class="rq-btn rq-btn-soft up-render-btn" data-render="' + esc(t.id) + '">' + IC.render + "<span>Render Questions</span></button>" : "") +
      (r2.meta ? '<button type="button" class="rq-btn rq-btn-primary" data-tact="update">' + IC.up + "<span>Reupload / Update Qs</span></button>" : "") +
      (r2.meta ? '<button type="button" class="rq-btn" data-tdl="quid">' + IC.down + "<span>Quid JSON</span></button>" +
                 '<button type="button" class="rq-btn" data-tdl="full">' + IC.down + "<span>Full JSON</span></button>" : "") +
      (row ? '<button type="button" class="rq-btn" data-tact="flag">' + IC.tag + "<span>Make " + (row.is_free ? "Paid" : "Free") + "</span></button>" +
             '<button type="button" class="rq-btn" data-tact="hide">' + IC.eyeOff + "<span>Hide</span></button>"
           : (r2.meta ? '<button type="button" class="rq-btn rq-btn-primary" data-tact="show">' + IC.eye + "<span>Show</span></button>" : "")) +
      '<button type="button" class="rq-btn up-del-btn" data-tact="delete">' + IC.trash + "<span>Delete</span></button>" +
    "</div></div>";
}
function testAction(act) {
  const t = S.test;
  if (!t) return;
  if (act === "update") { updStart(); return; }
  if (act === "delete") { delStart(); return; }
  if (act === "flag") {
    const to = t.row.is_free ? 0 : 1;
    openSheet("Make it " + freeTxt(to) + "?", '<dl class="up-sum"><dt>Quiz id</dt><dd><code>' + esc(t.id) + "</code></dd><dt>Access</dt><dd>" + freeTxt(t.row.is_free) + " → <b>" + freeTxt(to) + "</b></dd></dl>" +
      '<div class="up-box info"><p>' + (to ? "Every logged-in user can open it now." : "Only paid users can open it now. Free users get “paid test”.") + " Questions and R2 files stay the same.</p></div>",
      "Make " + freeTxt(to), () => runTest(() => API.flag(t.id, to), "flag", { free: to }));
  } else if (act === "hide") {
    openSheet("Hide this test?", '<dl class="up-sum"><dt>Quiz id</dt><dd><code>' + esc(t.id) + "</code></dd><dt>Now</dt><dd>Live · " + freeTxt(t.row.is_free) + " · " + esc(verTxt(t.row.ver)) + "</dd></dl>" +
      '<div class="up-box warn"><h4>Users cannot open it after this</h4><p>Only the tests row is removed. R2 files and D1 questions stay — Show brings it back.</p></div>',
      "Hide", () => runTest(() => API.hide(t.id), "hide", {}), true);
  } else if (act === "show") {
    openSheet("Show this test?", '<dl class="up-sum"><dt>Quiz id</dt><dd><code>' + esc(t.id) + "</code></dd></dl>" +
      '<div class="up-field"><span class="up-label">Access</span><div class="up-seg" id="tsShowFree"><button type="button" data-v="0" class="on">Paid</button><button type="button" data-v="1">Free</button></div></div>',
      "Show", () => {
        const on = document.querySelector("#tsShowFree button.on");
        const f = on ? Number(on.getAttribute("data-v")) : 0;
        return runTest(() => API.show(t.id, f), "show", { free: f });
      });
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  TESTS TAB · Reupload / Update Qs
//  JSON for THIS test → EVERY question must carry its quid (else the file is
//  rejected: U.noQuidError) → text differs from D1 = UPDATE that
//  quid in D1 (same quid: reports / saved / attempts keep pointing at it) →
//  new questions get new quids → R2 replaced (ver + 1). Same pure code as the
//  Bulk upload (MMHBulkCore.planTest / payloadOf) → admin Worker v5 overwrite.
// ══════════════════════════════════════════════════════════════════════════
const UD = { t: null, step: "pick", file: null, err: [], dry: null, prog: "", fail: null, agreed: false, fields: {}, src: null, ask: null };
function updStart() {
  const t = S.test;
  if (!t || !t.r2 || !t.r2.meta) return;
  if (!window.MMHBulkCore) { toast("Bulk module not loaded — reload the page"); return; }
  UD.t = { id: t.id, P: null, plan: null, live: { row: t.row, r2: t.r2, hidden: t.hidden }, isFree: t.row ? Number(t.row.is_free) : 0 };
  UD.step = "pick"; UD.file = null; UD.err = []; UD.dry = null; UD.prog = ""; UD.fail = null; UD.agreed = false; UD.owOn = true;
  UD.fields = {}; UD.src = null; UD.ask = null;
  openSheet("Reupload / Update Qs", "", "Update test", updOk, false);
  updPaint();
}
function updPaint() {
  const body = $("upSheetBody"), ok = $("upSheetOk"), t = UD.t;
  if (!body || !t) return;
  const st = body.scrollTop;
  body.innerHTML = updHtml();
  body.scrollTop = st;
  ok.textContent = UD.step === "failed" ? "Retry" : "Update test";
  ok.disabled = !(UD.step === "failed" || (UD.step === "ready" && UD.agreed));
}
function updHead() {
  const t = UD.t, row = t.live.row, r2 = t.live.r2;
  let total = 0; (r2.names || []).forEach(n => { total += (U.sectionList(r2.sections[n]) || []).length; });
  return '<dl class="up-sum"><dt>Quiz id</dt><dd><code>' + esc(t.id) + "</code></dd>" +
    "<dt>Now</dt><dd>" + (row ? "Live · " + freeTxt(row.is_free) + " · " + esc(verTxt(row.ver)) : "Hidden (R2 files only)") + " · " + plural(total, "question") + "</dd></dl>";
}
function updHtml() {
  const t = UD.t;
  let h = updHead();
  if (UD.step === "pick") {
    h += '<div class="up-box info"><h4>What this does</h4><p>Choose a JSON of <b>this test</b>. <b>Every question must have its quid</b> ' +
      "— the quid tells which D1 question it is. A file with even one question without quid is rejected.</p><ul class=\"ud-list\">" +
      "<li><b>Changed question</b> → updated in D1 under the <b>same quid</b> (reports, saved lists, attempts stay linked).</li>" +
      "<li><b>Removed</b> → only taken out of this test (D1 keeps it). New questions can't be added here.</li>" +
      "<li>R2 files are replaced, ver + 1 → users get the new version. Changed quids are purged from the cache.</li></ul>" +
      '<p class="ud-tip">Easiest: <b>Full JSON</b> button → edit the questions → upload that file here.</p></div>' +
      '<label class="up-drop ud-drop"><input type="file" id="udFile" accept=".json,application/json" hidden>' +
      '<span class="up-drop-ico">' + IC.up + '</span><span class="up-drop-title">Choose JSON for ' + esc(t.id) + "</span>" +
      '<span class="up-drop-sub">Full JSON (with quids) · quid JSON</span></label>';
    if (UD.err.length) h += '<div class="up-box bad"><h4>Can\'t use this file</h4><p style="white-space:pre-wrap">' + UD.err.map(esc).join("\n") + "</p></div>";
    return h;
  }
  h += updFileRow();
  if (UD.step === "fields") return h + fieldsBoxHtml(UD.ask, "data-udfield", "Dono me se ek chuno — phir file apne aap dobara check hogi.");
  if (UD.step === "checking") return h + '<div class="up-more-note ud-wait"><span class="up-spin"></span> Checking against D1 and R2… ' + esc(UD.prog) + "</div>";
  if (UD.step === "failed") return h + updFailHtml();
  return h + updPlanHtml();
}
function updFileRow() {
  return '<div class="up-file ud-file"><span class="up-file-ico">' + IC.file + '</span><span class="up-file-txt"><div class="up-file-name">' + esc(UD.file.name) +
    '</div><div class="up-file-sub">' + kb(UD.file.size) + "</div></span>" +
    (UD.step === "ready" ? '<button type="button" class="rq-btn ud-change" data-udpick>Change file</button>' : "") + "</div>";
}
function updPlanHtml() {
  const t = UD.t, plan = t.plan, d = UD.dry, P = t.P;
  const a = U.applyMatches(P, plan.keep), nNew = a.newBodies.length, ow = plan.ow;
  const first = nNew ? d.next_quid : null, last = nNew ? quidPlus(d.next_quid, nNew - 1) : null;
  let h = '<div class="up-h5">D1 · question bank</div>';
  h += '<div class="up-dcount ud-count"><div class="ch"><b>' + ow.length + '</b><span>Update</span></div><div><b>' + plan.same + '</b><span>Same as D1</span></div>' +
    '<div class="ad"><b>' + nNew + '</b><span>New quid</span></div><div><b>' + P.counts.total + "</b><span>In file</span></div></div>";
  if (ow.length) {
    h += '<div class="up-seg ud-seg" data-udow><button type="button" data-v="1" class="' + (UD.owOn ? "on" : "") + '">Update D1 (' + ow.length + ")</button>" +
      '<button type="button" data-v="0" class="' + (UD.owOn ? "" : "on") + '">Keep D1 text</button></div>';
    h += '<div class="up-drows">' + ow.slice(0, 50).map(o => '<div class="up-drow"><span class="w">' + esc(o.where) + '</span><span class="v"><code>' + esc(o.quid) + "</code> · " +
      (UD.owOn ? "<ins>update</ins> " : "<s>keep D1</s> ") + esc(o.fields.join(", ")) + "</span></div>").join("") +
      (ow.length > 50 ? '<div class="up-more-note">… ' + (ow.length - 50) + " more</div>" : "") + "</div>";
  } else h += '<div class="up-box ok"><p>No question text differs from D1 — nothing to update in D1.' + (nNew ? "" : " Only R2 is written again.") + "</p></div>";
  if (nNew) h += '<p class="ud-note">New quids <code>' + esc(first) + "</code> → <code>" + esc(last) + "</code></p>";
  // R2 structure: live → this file
  const newS = { meta: U.metaOut(P.meta, P.names, P.kind), sections: a.sections };
  const df = U.diff(d.old || t.live.r2, newS), c = df.counts;
  h += '<div class="up-h5">R2 · test structure</div>';
  h += df.same ? '<div class="up-box ok"><p>Same structure (order, quids, marks) — files written again, ver + 1.</p></div>'
    : '<div class="up-dcount"><div><b>' + c.same + '</b><span>Same</span></div><div class="ch"><b>' + c.changed + '</b><span>Changed</span></div>' +
      '<div class="ad"><b>' + c.added + '</b><span>Added</span></div><div class="rm"><b>' + c.removed + "</b><span>Removed</span></div></div>";
  const row = t.live.row;
  h += '<dl class="up-sum"><dt>Access</dt><dd>' + freeTxt(t.isFree) + " (unchanged)</dd><dt>tests row</dt><dd>" + (row ? verTxt(row.ver) + " → " + verTxt(row.ver + 1) : "created again (ver = now)") + "</dd></dl>";
  h += '<label class="up-check"><input type="checkbox" id="udAgree"' + (UD.agreed ? " checked" : "") + "> <span>I checked — update this test" +
    (ow.length && UD.owOn ? " and " + plural(ow.length, "question") + " in D1" : "") + ".</span></label>";
  return h;
}
function updFailHtml() {
  const f = UD.fail, d = f.data || {};
  const done = (d.overwritten ? plural(d.overwritten, "question") + " already updated in D1. " : "") + (d.first ? "New quids " + d.first + " → " + d.last + " are saved. " : "");
  return '<div class="up-box bad"><h4>' + (d.stage === "r2" ? "D1 saved — R2 upload failed" : "D1 + R2 done — tests row failed") + '</h4><p style="white-space:pre-wrap">' +
    esc(done + "Press Retry: it sends the same structure again with nothing new for D1 (no duplicate quids, no second overwrite).\n" + failText(f.err)) + "</p></div>";
}
async function updFile(f) {
  if (!f) return;
  if (f.size > 40 * 1048576) { UD.err = ["File is " + kb(f.size) + " — the limit is 40 MB."]; updPaint(); return; }
  const text = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result || "")); fr.onerror = () => rej(new Error("read")); fr.readAsText(f); })
    .catch(() => null);
  if (text == null) { UD.err = ["Could not read the file."]; updPaint(); return; }
  await updAnalyze(f.name, f.size, text);
}
async function updAnalyze(name, size, text) {
  const C = window.MMHBulkCore, t = UD.t;
  UD.err = []; UD.dry = null; UD.agreed = false; UD.owOn = true; t.P = null; t.plan = null;
  if (!UD.src || UD.src.text !== text) UD.fields = {};
  UD.src = { name: name, size: size, text: text }; UD.ask = null;
  let data;
  try { data = JSON.parse(text.replace(/^\uFEFF/, "")); } catch (e) { UD.err = [jsonError(text, e)]; UD.step = "pick"; updPaint(); return; }
  const shape = U.validateTest(data);
  if (shape) { UD.err = [shape]; UD.step = "pick"; updPaint(); return; }
  const mid = data.meta && typeof data.meta.id === "string" ? data.meta.id.trim() : "";
  if (mid && mid !== t.id) { UD.err = ["This file is for " + mid + " (meta.id), not " + t.id + ".", "Open that test, or fix meta.id in the file."]; UD.step = "pick"; updPaint(); return; }
  UD.file = { name: name, size: size }; UD.step = "checking"; UD.prog = ""; updPaint();
  try {
    const org = U.guessOrg(t.id) || "SSC";
    const P = U.prepare(data, { quizId: t.id, tag: U.tagForQuiz(t.id, org).tag || "", fields: UD.fields });
    t.P = P;
    if (P.error) throw { msg: P.error };
    const openNew = (P.newFields || []).filter(f => f.nw > 0 && !f.choice);
    if (openNew.length) { UD.ask = P.newFields.filter(f => f.nw > 0); UD.step = "fields"; updPaint(); return; }
    if (!P.ok) throw { list: P.problems.errors.slice(0, 12) };
    const nq = U.noQuidError(P);
    if (nq) throw { list: nq };
    const need = C.neededQuids(P, t.live.r2), bank = {};
    for (let i = 0; i < need.length; i += BODY_MAX) {
      const part = need.slice(i, i + BODY_MAX), d = await API.bodies(part);
      part.forEach(q => { bank[q] = d.questions && d.questions[q] ? { body: d.questions[q], base: d.base && d.base[q] } : null; });
      UD.prog = "D1 " + Math.min(i + BODY_MAX, need.length) + "/" + need.length; updPaint();
    }
    const ask = C.fieldsToAsk(P, bank);                          // fields D1 already has for that quid are not asked
    if (ask.some(f => !f.choice)) { UD.ask = ask; UD.step = "fields"; updPaint(); return; }
    t.plan = C.planTest(P, t.live.r2, bank);
    if (t.plan.errors.length) throw { list: t.plan.errors.slice(0, 12) };
    UD.dry = await API.upload(C.payloadOf(t, true, true));
    if (UD.dry.overwrite_stale && UD.dry.overwrite_stale.length) throw { msg: UD.dry.overwrite_stale.length + " question(s) changed in D1 while checking — choose the file again" };
    UD.step = "ready";
  } catch (e) {
    if (e && e.auth) { closeSheet(); authLost(); return; }
    UD.step = "pick"; UD.err = e && e.list ? e.list : [e && e.msg ? e.msg : failText(e)];
  }
  updPaint();
}
async function updOk() {
  if (UD.step === "failed") return updRetry();
  if (UD.step !== "ready" || !UD.agreed) return;
  const C = window.MMHBulkCore, t = UD.t, ok = $("upSheetOk");
  const p = C.payloadOf(t, UD.owOn, false);
  busyBtn(ok, true, "Updating…");
  $("upSheet").querySelectorAll("[data-close]").forEach(b => { b.disabled = true; });
  try {
    const res = await API.upload(p);
    closeSheet();
    const n = res.overwritten || 0, sk = (res.overwrite_skipped || []).length;
    histAdd({ act: "update", id: t.id, ok: true, ver: res.ver, first: res.first || null, last: res.last || null, nw: p.new.length,
              old: t.P.counts.total - p.new.length, ow: n, free: p.is_free, kind: res.row && res.row.kind });
    toast("Updated ✓  " + verTxt(res.ver) + (n ? " · " + plural(n, "question") + " updated in D1" : ""), 3600);
    if (sk) setTimeout(() => toast(plural(sk, "question") + " skipped — changed in D1 by someone meanwhile", 4500), 3700);
    else if (n && res.purged === false) setTimeout(() => toast("D1 updated — cache purge failed (Purge in Check Reports, or wait for the cache)", 5000), 3700);
    await openTest(t.id);
  } catch (e) {
    if (e && e.auth) { closeSheet(); authLost(); return; }
    const d = (e && e.data) || {};
    histAdd({ act: "update", id: t.id, ok: false, stage: d.stage || "", error: failText(e).slice(0, 160) });
    if ((d.stage === "r2" || d.stage === "tests") && d.structure) { UD.fail = { err: e, data: d, payload: p }; UD.step = "failed"; }
    else if (e && e.status === 409) { UD.step = "pick"; UD.err = ["The test or a question changed meanwhile — choose the file again to see the new state."]; }
    else { UD.step = "pick"; UD.err = [failText(e)]; }
    updPaint();
  } finally {
    busyBtn(ok, false);
    $("upSheet").querySelectorAll("[data-close]").forEach(b => { b.disabled = false; });
    if (!$("upSheet").hidden) updPaint();
  }
}
async function updRetry() {
  const f = UD.fail, d = f.data, ok = $("upSheetOk");
  const p = { id: f.payload.id, is_free: f.payload.is_free, meta: f.payload.meta, sections: d.structure.sections, new: [] };
  busyBtn(ok, true, "Retrying…");
  try {
    const dry = await API.upload(Object.assign({}, p, { dry: true }));
    if (dry.exists) { p.replace = true; p.expect_ver = dry.row ? dry.row.ver : 0; }
    const res = await API.upload(p);
    closeSheet();
    histAdd({ act: "retry", id: p.id, ok: true, ver: res.ver, first: d.first || null, last: d.last || null, nw: 0, old: 0, ow: d.overwritten || 0, free: p.is_free, kind: res.row && res.row.kind });
    toast("Done ✓  " + verTxt(res.ver));
    await openTest(p.id);
  } catch (e) {
    if (e && e.auth) { closeSheet(); authLost(); return; }
    toast(failText(e), 4200);
  } finally { busyBtn(ok, false); if (!$("upSheet").hidden) updPaint(); }
}

// ══════════════════════════════════════════════════════════════════════════
//  TESTS TAB · Delete (admin Worker v6 · POST /tests/delete)
// ══════════════════════════════════════════════════════════════════════════
const TD = { dry: null, r2: true, d1: false, err: "", busy: false };
async function delStart() {
  const t = S.test;
  Object.assign(TD, { dry: null, r2: true, d1: false, err: "", busy: false });
  openSheet("Delete this test?", '<div class="up-more-note"><span class="up-spin" style="display:inline-block;vertical-align:middle"></span> Checking ' + esc(t.id) + "…</div>", "Delete", delGo, true);
  $("upSheetOk").disabled = true;
  try { TD.dry = await API.delTest(t.id, { dry: true }); }
  catch (e) {
    if (e && e.auth) { closeSheet(); authLost(); return; }
    TD.err = delErr(e);
  }
  if (!$("upSheet").hidden && sheetOk === delGo) delPaint();
}
function delErr(e) {
  if (e && e.status === 404 && !(e.data && e.data.notFound)) return "The admin Worker has no Delete route yet — deploy admin Worker v6 first.";
  return failText(e);
}
function delPaint() {
  const t = S.test, d = TD.dry, row = t.row, ok = $("upSheetOk");
  if (!d) { $("upSheetBody").innerHTML = '<div class="up-box bad"><h4>Cannot delete</h4><p>' + esc(TD.err || "Failed") + "</p></div>"; ok.disabled = true; return; }
  const nQ = d.quids, shared = d.in_d1;
  let h = '<dl class="up-sum"><dt>Quiz id</dt><dd><code>' + esc(t.id) + "</code></dd>" +
    "<dt>Now</dt><dd>" + (d.row ? "Live · " + freeTxt(d.row.is_free) + " · " + esc(verTxt(d.row.ver)) : "Hidden (no tests row)") + "</dd>" +
    "<dt>R2 folder</dt><dd><code>" + esc(t.id) + "/</code> · " + plural(d.r2_objects, "file") + "</dd>" +
    "<dt>Questions</dt><dd>" + plural(nQ, "quid") + (nQ ? " · " + shared + " in D1" : "") + "</dd></dl>";
  if (t.r2 && t.r2.meta) h += '<div class="up-del-backup"><span>Want a backup first?</span><button type="button" class="rq-btn" data-tdl="full">' + IC.down + "<span>Full JSON</span></button></div>";
  h += '<label class="up-check up-del-opt"><input type="checkbox" id="tdR2"' + (TD.r2 ? " checked" : "") + '><span>Delete this test folder from R2' +
       '<small>All ' + plural(d.r2_objects, "file") + " in <code>" + esc(t.id) + "/</code>" + (d.row ? " + its tests row. Users cannot open it any more." : ".") + "</small></span></label>";
  h += '<label class="up-check up-del-opt' + (TD.r2 ? "" : " is-off") + '"><input type="checkbox" id="tdD1"' + (TD.d1 ? " checked" : "") + (TD.r2 && nQ ? "" : " disabled") + '><span>Also delete related quids from D1' +
       "<small>" + (nQ ? plural(shared, "row") + " in the bank <code>questions</code> table." : "This test has no quids.") + "</small></span></label>";
  h += '<div class="up-box ' + (TD.d1 ? "bad" : "warn") + ' up-del-warn"><h4>' + IC.bad + "<span>Only if no other test uses these questions</span></h4>" +
       "<p>Questions are shared by quid. If any other test (full mock, sectional, PART…) loads even one of these quids, that test will show missing questions after this. " +
       "Saved lists and reports of these questions stop opening too. D1 rows cannot be brought back — download Full JSON first.</p></div>";
  if (TD.err) h += '<div class="up-box bad"><p>' + esc(TD.err) + "</p></div>";
  const st = $("upSheetBody").scrollTop;
  $("upSheetBody").innerHTML = h;
  $("upSheetBody").scrollTop = st;
  ok.disabled = !TD.r2 || TD.busy;
  ok.textContent = !TD.r2 ? "Tick option 1 to delete" : TD.d1 && nQ ? "Delete test + " + plural(shared, "D1 row") : "Delete test";
}
async function delGo() {
  const t = S.test, d = TD.dry;
  if (!t || !d || !TD.r2 || TD.busy) return;
  const ok = $("upSheetOk");
  TD.busy = true; TD.err = "";
  busyBtn(ok, true, "Deleting…");
  try {
    const r = await API.delTest(t.id, { d1: TD.d1, expect_ver: d.row ? d.row.ver : 0 });
    busyBtn(ok, false); TD.busy = false;
    closeSheet();
    histAdd({ act: "delete", id: t.id, ok: true, r2n: r.r2_deleted, row: !!r.row_deleted, d1: !!r.d1, d1n: r.d1_deleted || 0, quids: r.quids, purged: r.purged });
    toast("Deleted ✓ · " + plural(r.r2_deleted, "R2 file") + (r.d1 ? " · " + plural(r.d1_deleted || 0, "D1 row") : ""), 3600);
    if (r.d1 && r.purged === false) setTimeout(() => toast("D1 rows deleted but cache purge failed — old copies may show for a while", 5000), 3800);
    S.test = null; $("tsId").value = "";
    paintTest(); paintRecent();
  } catch (e) {
    busyBtn(ok, false); TD.busy = false;
    if (e && e.auth) { closeSheet(); authLost(); return; }
    histAdd({ act: "delete", id: t.id, ok: false, stage: e.data && e.data.stage, error: delErr(e) });
    if (e.status === 409 || (e.data && (e.data.row_deleted || e.data.stage === "d1" || e.data.stage === "r2"))) {
      // something changed / half done → fresh counts, the admin presses Delete again
      TD.err = delErr(e);
      try { TD.dry = await API.delTest(t.id, { dry: true }); } catch (x) { if (x.status === 404) { closeSheet(); S.test = null; paintTest(); toast("Already deleted"); return; } }
    } else TD.err = delErr(e);
    if (!$("upSheet").hidden) delPaint();
  }
}

async function runTest(fn, act, extra) {
  const ok = $("upSheetOk");
  busyBtn(ok, true, "Saving…");
  try {
    const d = await fn();
    closeSheet();
    histAdd(Object.assign({ act: act, id: S.test.id, ok: true, ver: d.row && d.row.ver }, extra));
    toast(act === "hide" ? "Hidden ✓" : act === "show" ? "Live again ✓" : "Now " + freeTxt(extra.free) + " ✓");
    await openTest(S.test.id);
  } catch (e) {
    closeSheet();
    if (e && e.auth) { authLost(); return; }
    toast(failText(e), 4200);
  } finally { busyBtn(ok, false); }
}
async function testDownload(kind, btn) {
  const t = S.test, r2 = t.r2;
  const qj = { meta: r2.meta, sections: {} };
  r2.names.forEach(n => { qj.sections[n] = r2.sections[n]; });
  if (kind === "quid") { saveFile(t.id + ".quid.json", qj); return; }
  const need = [];
  r2.names.forEach(n => (U.sectionList(r2.sections[n]) || []).forEach(it => need.push(it[1])));
  busyBtn(btn, true, "Loading…");
  try {
    await fetchBodies(need, (a, b) => { const s = btn.querySelector("span:last-child"); if (s) s.textContent = "D1 " + a + "/" + b; });
    const bodies = {};
    need.forEach(q => { if (S.oldBodies[q]) bodies[q] = S.oldBodies[q]; });
    const a = U.assemble(qj, bodies);
    if (a.missing.length) toast(plural(a.missing.length, "quid") + " missing in D1 — left out", 4000);
    saveFile(t.id + ".full.json", a.test);
  } catch (e) { if (e && e.auth) authLost(); else toast(failText(e), 4000); }
  finally { busyBtn(btn, false); }
}

// ══════════════════════════════════════════════════════════════════════════
//  HISTORY TAB
// ══════════════════════════════════════════════════════════════════════════
const ACT = {
  upload: ["Uploaded", IC.up], replace: ["Replaced", IC.up], retry: ["Retry done", IC.retry], update: ["Updated (Reupload)", IC.up],
  flag: ["Access changed", IC.tag], hide: ["Hidden", IC.eyeOff], show: ["Shown again", IC.eye], delete: ["Deleted", IC.trash]
};
function paintHistory() {
  const h = histAll();
  $("hsSub").textContent = h.length ? plural(h.length, "entry", "entries") + " · this device only" : "Uploads and changes made from this device";
  $("hsClear").hidden = !h.length;
  if (S.hsSel != null && !h[S.hsSel]) S.hsSel = null;
  paintHsPane(h);
  if (!h.length) {
    $("hsList").innerHTML = '<div class="up-empty"><div class="rq-empty-ico">' + IC.stack + "</div><h3>No history yet</h3><p>Every upload, Free/Paid change, hide and show from this device is listed here.</p></div>";
    return;
  }
  $("hsList").innerHTML = h.map((e, i) => {
    const a = ACT[e.act] || [e.act, IC.stack];
    let sub;
    if (!e.ok) sub = "Failed" + (e.stage ? " at " + e.stage : "") + " · " + esc(e.error || "");
    else if (e.act === "upload" || e.act === "replace" || e.act === "retry") {
      sub = a[0] + " · " + esc(verTxt(e.ver)) + " · " + (e.nw ? plural(e.nw, "new quid") + " " + esc(e.first) + "…" + esc(String(e.last).slice(-4)) : "no new quid") + " · " + freeTxt(e.free) + (e.ow ? " · " + plural(e.ow, "question") + " overwritten" : "") + (e.bulk ? " · bulk" : "");
    } else if (e.act === "flag") sub = "Now " + freeTxt(e.free);
    else if (e.act === "show") sub = a[0] + " · " + freeTxt(e.free) + (e.ver ? " · " + esc(verTxt(e.ver)) : "");
    else if (e.act === "delete") sub = a[0] + " · R2 " + plural(e.r2n || 0, "file") + " · " + (e.d1 ? plural(e.d1n || 0, "D1 row") + " deleted" : "D1 kept");
    else sub = a[0];
    const cls = !e.ok ? "fail" : e.act;
    return '<button type="button" class="hs-item ' + cls + (S.hsSel === i ? " is-active" : "") + '" data-hs="' + i + '" data-open-test="' + esc(e.id) + '"><span class="hs-ico">' + (e.ok ? a[1] : IC.bad) + '</span>' +
      '<span class="hs-txt"><div class="hs-id">' + esc(e.id) + '</div><div class="hs-sub">' + sub + '</div></span><span class="hs-time">' + esc(timeAgo(e.t)) + "</span></button>";
  }).join("");
}

/** big screens: one history entry in the side pane */
function paintHsPane(h) {
  const e = S.hsSel != null ? h[S.hsSel] : null;
  $("hsEmpty").hidden = !!e;
  $("hsPane").hidden = !e;
  if (!e) { $("hsPane").innerHTML = ""; return; }
  const a = ACT[e.act] || [e.act, IC.stack], up = e.act === "upload" || e.act === "replace" || e.act === "retry" || e.act === "update";
  const rows = [];
  const kv = (k, v) => rows.push("<dt>" + k + "</dt><dd>" + v + "</dd>");
  kv("When", esc(new Date(e.t).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" })) + ' <span class="hs-ago">· ' + esc(timeAgo(e.t)) + "</span>");
  kv("Result", e.ok ? '<span class="up-chip live">Done</span>' : '<span class="up-chip is-hidden">Failed' + (e.stage ? " at " + esc(e.stage) : "") + "</span>");
  if (e.ver) kv("Version", esc(verTxt(e.ver)));
  if (up && e.ok) {
    kv("New in D1", e.nw ? plural(e.nw, "question") + (e.first ? " <code>" + esc(e.first) + "</code> → <code>" + esc(e.last) + "</code>" : "") : "none");
    if (e.old != null) kv("Existing quids", String(e.old));
    if (e.ow) kv("Overwritten", plural(e.ow, "question") + " (D1 text replaced)");
    if (e.kind) kv("Kind", esc(e.kind));
  }
  if (e.free != null) kv("Access", freeTxt(e.free));
  if (e.act === "delete" && e.ok) {
    kv("R2", plural(e.r2n || 0, "file") + " deleted" + (e.row ? " + tests row" : ""));
    kv("D1", e.d1 ? plural(e.d1n || 0, "row") + " deleted of " + plural(e.quids || 0, "quid") + (e.purged === false ? " · cache purge failed" : "") : "kept (" + plural(e.quids || 0, "quid") + ")");
  }
  kv("From", e.bulk ? "Bulk upload" : e.act === "update" ? "Tests tab · Reupload / Update Qs" : up ? "Upload tab" : "Tests tab");
  $("hsPane").innerHTML = '<div class="up-side-head"><span class="hs-ico ' + (!e.ok ? "fail" : esc(e.act)) + '">' + (e.ok ? a[1] : IC.bad) + "</span><div>" +
      '<div class="up-side-title">' + esc(e.ok ? a[0] : "Failed") + '</div><div class="up-side-sub up-mono">' + esc(e.id) + "</div></div></div>" +
    '<dl class="up-sum">' + rows.join("") + "</dl>" +
    (!e.ok && e.error ? '<div class="up-box bad"><p>' + esc(e.error) + "</p></div>" : "") +
    '<div class="up-btns"><button type="button" class="rq-btn" data-open-test="' + esc(e.id) + '">' + IC.stack + "<span>Open in Tests</span></button>" +
    (e.act !== "hide" && e.act !== "delete" ? '<button type="button" class="rq-btn rq-btn-soft up-render-btn" data-render="' + esc(e.id) + '">' + IC.render + "<span>Render Questions</span></button>" : "") + "</div>";
}

// ══════════════════════════════════════════════════════════════════════════
//  EVENTS
// ══════════════════════════════════════════════════════════════════════════
let idT = 0, tagT = 0;
function bind() {
  $("arGateForm").addEventListener("submit", ev => {
    ev.preventDefault();
    const go = $("arGateBtn").getAttribute("data-go");
    if (go) { location.href = go; return; }
    const pw = $("arPw").value.trim();
    if (!pw) { $("arPw").focus(); return; }
    unlock(pw);
  });
  $("arPwEye").addEventListener("click", () => {
    const i = $("arPw"), on = i.type === "password";
    i.type = on ? "text" : "password"; $("arPwEye").classList.toggle("on", on);
  });
  $("arLock").addEventListener("click", () => { lsDel(PW_KEY); showGate("pw"); toast("Locked — password forgotten on this device"); });
  $("rqBack").addEventListener("click", () => { if (window.MMHNav) { MMHNav.back("/index.html"); return; } if (history.length > 1) history.back(); else location.href = "/"; });

  // dock
  $("upDock").addEventListener("click", ev => { const b = ev.target.closest("[data-tab]"); if (b) setTab(b.getAttribute("data-tab")); });

  // load
  $("upFile").addEventListener("change", ev => readFile(ev.target.files && ev.target.files[0]));
  // App (Capacitor WebView): its built-in file chooser turns accept=".json" into a MIME filter, and JSON files
  // saved from WhatsApp / Telegram / Drive are often "application/octet-stream" or "text/plain" → greyed out.
  // So in the app every file can be picked; loadText() checks that it really is a test JSON.
  const openAll = () => { if (isNative()) $("upFile").removeAttribute("accept"); };
  openAll(); $("upFile").addEventListener("click", openAll);
  const drop = $("upDrop");
  ["dragenter", "dragover"].forEach(t => drop.addEventListener(t, ev => { ev.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(t => drop.addEventListener(t, ev => { ev.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", ev => readFile(ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0]));
  $("upPasteBtn").addEventListener("click", () => { $("upPaste").hidden = false; paintUpload(); $("upPasteText").focus(); });
  $("upPasteCancel").addEventListener("click", () => { $("upPaste").hidden = true; $("upLoadErr").hidden = true; paintUpload(); });
  $("upPasteUse").addEventListener("click", () => {
    const t = $("upPasteText").value;
    if (!t.trim()) { $("upPasteText").focus(); return; }
    loadText(t, "pasted.json", new Blob([t]).size);
  });

  // settings
  $("upId").addEventListener("input", ev => {
    clearTimeout(idT);
    idT = setTimeout(() => {
      S.quizId = ev.target.value.trim();
      const g = U.guessOrg(S.quizId);
      if (!S.tagTouched) { if (g) S.org = g; S.tag = U.tagForQuiz(S.quizId, S.org).tag || ""; }
      recompute();
    }, 280);
  });
  $("upFree").addEventListener("click", ev => { const b = ev.target.closest("[data-v]"); if (!b) return; S.isFree = Number(b.getAttribute("data-v")); paintSetup(); paintBar(); });
  $("upOrg").addEventListener("change", ev => { S.org = ev.target.value; S.tagTouched = false; S.tag = U.tagForQuiz(S.quizId, S.org).tag || ""; recompute(); });
  $("upTag").addEventListener("input", ev => { clearTimeout(tagT); tagT = setTimeout(() => { S.tag = ev.target.value.trim(); S.tagTouched = true; recompute(); }, 350); });
  $("upTagReset").addEventListener("click", () => { S.tagTouched = false; S.tag = U.tagForQuiz(S.quizId, S.org).tag || ""; $("upTag").value = S.tag; recompute(); toast(S.tag ? "Tag made from the quiz id" : "Cannot make a tag from this quiz id"); });
  $("upLang").addEventListener("change", ev => { S.lang = ev.target.value; paintCheck(); });

  // check list
  $("upFilter").addEventListener("click", ev => { const b = ev.target.closest("[data-filter]"); if (!b) return; S.filter = b.getAttribute("data-filter"); S.shown = PAGE; paintCheck(); });
  $("upCheck").addEventListener("click", ev => {          // NEW field → Rakho / Hatao
    const uf = ev.target.closest("[data-ufield] [data-v]");
    if (uf) { S.fields[uf.parentNode.getAttribute("data-ufield")] = uf.getAttribute("data-v"); recompute(); }
  });
  $("upImgBtn").addEventListener("click", checkImages);
  $("upMoreBtn").addEventListener("click", () => { S.shown += PAGE; paintCheck(); });
  $("upList").addEventListener("click", async ev => {
    const o = ev.target.closest("[data-open]");
    if (o) { const i = +o.getAttribute("data-open"); S.open[i] = !S.open[i]; repaintRow(i); return; }
    const c = ev.target.closest("[data-code]");
    if (c) { const i = +c.getAttribute("data-code"); S.code[i] = !S.code[i]; repaintRow(i); return; }
    const d = ev.target.closest("[data-d1]");
    if (d) {
      const i = +d.getAttribute("data-d1"), r = S.P.rows[i];
      busyBtn(d, true, "Loading…");
      try { await fetchBodies([r.quid]); if (!S.oldBodies[r.quid]) toast(r.quid + " is not in D1", 3500); r._imgs = null; }
      catch (e) { if (e && e.auth) { authLost(); return; } toast(failText(e)); }
      repaintRow(i);
    }
  });

  // upload
  $("upGo").addEventListener("click", () => {
    if ($("upGo").dataset.mode === "new") { clearFile(); $("rqScroll").scrollTop = 0; return; }
    go();
  });
  document.addEventListener("click", ev => {
    if (ev.target.closest("#upClear")) { clearFile(); return; }
    const dl = ev.target.closest("[data-dl]");
    if (dl) { downloadResult(dl.getAttribute("data-dl"), dl); return; }
    if (ev.target.closest("#upRetry")) { retry(); return; }
    const hs = ev.target.closest("#hsList [data-hs]");
    if (hs && wide()) {
      S.hsSel = +hs.getAttribute("data-hs");
      document.querySelectorAll("#hsList .hs-item").forEach(b => b.classList.toggle("is-active", b === hs));
      paintHsPane(histAll());
      return;
    }
    const ot = ev.target.closest("[data-open-test]");
    if (ot) { openTest(ot.getAttribute("data-open-test")); return; }
    const td = ev.target.closest("[data-tdl]");
    if (td) { testDownload(td.getAttribute("data-tdl"), td); return; }
    const ta = ev.target.closest("[data-tact]");
    if (ta) { testAction(ta.getAttribute("data-tact")); return; }
  });

  // sheet
  $("upSheet").addEventListener("click", ev => {
    if (ev.target.closest("[data-close]") && !ev.target.closest("[data-close]").disabled) { closeSheet(); return; }
    const k = ev.target.closest("[data-keep] [data-v]");
    if (k) {
      const idx = +k.parentNode.getAttribute("data-keep"), m = S.match.find(x => x.row.newIndex === idx);
      if (k.getAttribute("data-v") === "old") S.keep[idx] = m.oldQuid; else delete S.keep[idx];
      const st = $("upSheetBody").scrollTop, agreed = $("upAgree") && $("upAgree").checked;
      $("upSheetBody").innerHTML = confirmHtml();
      if ($("upAgree")) $("upAgree").checked = agreed;
      $("upSheetBody").scrollTop = st; syncAgree();
      return;
    }
    const df = ev.target.closest("[data-udfield] [data-v]");
    if (df) {
      UD.fields[df.parentNode.getAttribute("data-udfield")] = df.getAttribute("data-v");
      UD.ask.forEach(f => { f.choice = UD.fields[f.name] || f.choice; });
      if (UD.ask.every(f => f.choice)) updAnalyze(UD.src.name, UD.src.size, UD.src.text); else updPaint();
      return;
    }
    const tk = ev.target.closest("[data-tagok] [data-v]");
    if (tk) {
      S.tagOk = tk.getAttribute("data-v") === "1";
      const st = $("upSheetBody").scrollTop, agreed = $("upAgree") && $("upAgree").checked;
      $("upSheetBody").innerHTML = confirmHtml();
      if ($("upAgree")) $("upAgree").checked = agreed;
      $("upSheetBody").scrollTop = st; syncAgree();
      return;
    }
    const uo = ev.target.closest("[data-udow] [data-v]");
    if (uo) { UD.owOn = uo.getAttribute("data-v") === "1"; UD.agreed = false; updPaint(); return; }
    if (ev.target.closest("[data-udpick]")) { const fi = document.createElement("input"); fi.type = "file"; fi.accept = ".json,application/json";
      fi.addEventListener("change", () => updFile(fi.files && fi.files[0])); fi.click(); return; }
    const sf = ev.target.closest("#tsShowFree [data-v]");
    if (sf) { sf.parentNode.querySelectorAll("button").forEach(b => b.classList.toggle("on", b === sf)); }
  });
  $("upSheet").addEventListener("change", ev => {
    if (ev.target.id === "upAgree") syncAgree();
    if (ev.target.id === "udAgree") { UD.agreed = ev.target.checked; $("upSheetOk").disabled = !UD.agreed; }
    if (ev.target.id === "udFile") updFile(ev.target.files && ev.target.files[0]);
    if (ev.target.id === "tdR2" || ev.target.id === "tdD1") {
      TD[ev.target.id === "tdR2" ? "r2" : "d1"] = ev.target.checked;
      if (!TD.r2) TD.d1 = false;
      delPaint();
    }
  });
  $("upSheetOk").addEventListener("click", () => { if (sheetOk) sheetOk(); });
  document.addEventListener("keydown", ev => { if (ev.key === "Escape" && !$("upSheet").hidden) closeSheet(); });

  // tests tab
  $("tsForm").addEventListener("submit", ev => { ev.preventDefault(); openTest($("tsId").value); });
  $("hsClear").addEventListener("click", () => {
    openSheet("Clear history?", '<div class="up-box info"><p>Only this list on this device is cleared. Tests, D1 and R2 do not change.</p></div>', "Clear", () => {
      lsDel(HIST_KEY); S.hsSel = null; closeSheet(); paintHistory(); paintRecent(); toast("History cleared");
    }, true);
  });
}
function repaintRow(i) {
  const old = document.querySelector('.up-q[data-i="' + i + '"]');
  if (!old) return;
  const r = S.P.rows[i];
  const tmp = document.createElement("div");
  tmp.innerHTML = rowHtml(r, i, rowFlags(r));
  const el = tmp.firstChild;
  old.replaceWith(el);
  if (el.classList.contains("open")) { renderOpenCard(el); if (typeof renderMath === "function") renderMath(); }
}

// ══════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════
function standaloneTheme() {
  if (typeof window.coreApplyTheme === "function") return;
  const sun = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
  const moon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
  function apply(t) {
    const dark = t === "dark";
    document.body.classList.toggle("dark-mode", dark);
    document.documentElement.setAttribute("data-theme", t);
    document.querySelectorAll(".theme-btn").forEach(b => { b.innerHTML = dark ? sun : moon; });
    lsSet("mmh_theme", t);
  }
  apply(lsGet("mmh_theme") || "light");
  document.querySelectorAll(".theme-btn").forEach(b => { b.onclick = () => apply(document.body.classList.contains("dark-mode") ? "light" : "dark"); });
}
async function boot() {
  if (!R || !U) { console.error("mmh-rules.js / mmh-upload-core.js missing"); }
  bind();
  syncHdr();
  window.addEventListener("resize", syncHdr);
  if (WIDE_MQ) {
    const f = () => { syncHdr(); if (S.tab === "history") paintHistory(); if (window.MMHBulk && window.MMHBulk.relayout) window.MMHBulk.relayout(); };
    if (WIDE_MQ.addEventListener) WIDE_MQ.addEventListener("change", f); else if (WIDE_MQ.addListener) WIDE_MQ.addListener(f);
  }
  if (STANDALONE) { $("rqBack").hidden = true; setTimeout(standaloneTheme, 0); }
  const qs = new URLSearchParams(location.search);
  setTab(["tests", "history", "bulk"].indexOf(qs.get("tab")) >= 0 ? qs.get("tab") : "bulk");   // t241: no single Upload tab
  const role = await profileRole();
  if (role === "none") { showGate("login"); return; }
  if (role === "user") { showGate("denied"); return; }
  if (!lsGet(PW_KEY)) { showGate("pw"); return; }
  showApp();
  // the saved password may have been changed on the Worker → find out now, not at upload time
  API.ping().catch(e => { if (e && e.auth) authLost(); });
  if (qs.get("id")) openTest(qs.get("id"));
}
// shared with admin-bulk.js (Bulk tab) — same API, sheet, toast, history
window.MMHUpAdmin = { API: API, IC: IC, esc: esc, toast: toast, kb: kb, plural: plural, freeTxt: freeTxt, verTxt: verTxt,
  busyBtn: busyBtn, isNative: isNative, saveBlob: saveBlob, openSheet: openSheet, closeSheet: closeSheet,
  histAdd: histAdd, authLost: authLost, failText: failText, wide: wide, fieldsBoxHtml: fieldsBoxHtml };
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
else boot();
})();

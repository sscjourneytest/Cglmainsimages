/* ═══════════════════════════════════════════════════════════════════════════
   EXAM-WISE CHAPTER PYQs  —  add-on for /exams/exam-ssc-sub/ only
   Flow:  Year → Exam → Subject → Mocks  (topic / subtopic chips exactly like
   SSC SUB — e.g. General Awareness → Ancient History → Stone Age).

   Loaded ONLY on exams/exam-ssc-sub/index.html, AFTER ssc-sub-engine.js and
   app-shell.js. It swaps in a few of their global functions (hub navigation,
   URL filter read/write, year/exam data loader, mock header) — the engine and
   app-shell files themselves are NOT modified, so SSC SUB, SSC TOP and every
   other exam page keep running exactly as before.

   Main JSON  (data/exam-ssc-sub-data.json):
     years : ["2026","2025"]
     exams : [ { id, title, subtitle, icon, logo, color, badge }, … ]   ← same
             fields as data/exam-categories.json items; ALL exams listed here
             are shown for every year
     files : { "2026": { "cgl": "CGL-2026-SSC-SUB.json", … }, … }
             exam present for that year  → opens its file
             exam missing for that year  → "Coming Soon · Tests not uploaded yet"
   Exam file (e.g. data/CGL-2026-SSC-SUB.json):
     { "data": { "Math": { "<topic>": [items] | {compact} }, … } }  — same as
     an SSC SUB year file (classic arrays or compact topics; GK may go one
     level deeper: subject → topic → subtopic → items).
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
'use strict';

/* ── exam icons: same keys as data/exam-categories.json (exams page) ─────── */
var _S = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
var EXAM_ICONS = {
    'landmark': '<svg ' + _S + '><path d="M2.8 20.5h18.4M4.5 20.5V9.8m15 10.7V9.8M8.7 20.5V9.8m6.6 10.7V9.8M2 9.8h20L12 3.2 2 9.8z"/></svg>',
    'train-front': '<svg ' + _S + '><rect x="5" y="2.8" width="14" height="13.4" rx="3.6"/><path d="M5 9.6h14M8.2 19.4 6.4 21.8m9.4-2.4 1.8 2.4M6.8 16.2h10.4"/><circle cx="9" cy="12.9" r=".9" fill="currentColor" stroke="none"/><circle cx="15" cy="12.9" r=".9" fill="currentColor" stroke="none"/></svg>',
    'book-open': '<svg ' + _S + '><path d="M12 6.6S10.2 5 7.7 5C5.8 5 4.2 5.6 3.2 6.2a1 1 0 0 0-.5.9v10.2a1 1 0 0 0 1.5.8c1-.6 2.5-1.1 4.4-1.1 2.4 0 4.4 1.4 4.4 1.4s1.6-1.4 4-1.4c1.9 0 3.4.5 4.4 1.1a1 1 0 0 0 1.5-.8V7.1a1 1 0 0 0-.5-.9c-1-.6-2.6-1.2-4.5-1.2-2.5 0-4.3 1.6-4.3 1.6zM12 6.6v11.6"/></svg>',
    'star': '<svg ' + _S + '><path d="m12 3.6 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.6 9.7l5.8-.8L12 3.6z"/></svg>',
    'grad-cap': '<svg ' + _S + '><path d="M12 3.8 2.6 8.7 12 13.6l9.4-4.9L12 3.8zM5.6 10.4v5c0 1.7 2.9 3.4 6.4 3.4s6.4-1.7 6.4-3.4v-5M21.4 8.7v5.6"/></svg>',
    'notebook': '<svg ' + _S + '><rect x="4.8" y="3.2" width="14.4" height="17.6" rx="2.4"/><path d="M9.2 3.2v17.6M12.6 8.2h3.4M12.6 12h3.4M12.6 15.8h3.4"/></svg>',
    'briefcase': '<svg ' + _S + '><rect x="3" y="7.4" width="18" height="12.6" rx="2.4"/><path d="M8.6 7.4V6a2 2 0 0 1 2-2h2.8a2 2 0 0 1 2 2v1.4M3 12.6h18M10.8 12.6v1.8h2.4v-1.8"/></svg>',
    'shield-check': '<svg ' + _S + '><path d="M12 2.9 19.4 5.7v5.5c0 4.7-3.1 8.3-7.4 9.9-4.3-1.6-7.4-5.2-7.4-9.9V5.7L12 2.9z"/><path d="m8.9 11.9 2.2 2.2 4-4.3"/></svg>',
    'shield-star': '<svg ' + _S + '><path d="M12 2.9 19.4 5.7v5.5c0 4.7-3.1 8.3-7.4 9.9-4.3-1.6-7.4-5.2-7.4-9.9V5.7L12 2.9z"/><path d="m12 7.9 1.2 2.4 2.6.4-1.9 1.8.5 2.6-2.4-1.3-2.4 1.3.5-2.6-1.9-1.8 2.6-.4L12 7.9z"/></svg>',
    'keyboard': '<svg ' + _S + '><rect x="2.6" y="5.8" width="18.8" height="12.4" rx="2.4"/><path d="M6.2 9.4h.01M9.6 9.4h.01M13 9.4h.01M16.4 9.4h.01M6.2 12.4h.01M17.8 12.4h.01M9.4 15.4h5.2"/></svg>',
    'id-badge': '<svg ' + _S + '><rect x="4.2" y="3.2" width="15.6" height="17.6" rx="2.4"/><circle cx="12" cy="9.4" r="2.6"/><path d="M7.6 17.2c.8-2.2 2.5-3.4 4.4-3.4s3.6 1.2 4.4 3.4"/></svg>',
    'tram': '<svg ' + _S + '><rect x="6" y="3.4" width="12" height="13.2" rx="3"/><path d="M6 9.2h12M9.2 16.6 7.4 21m9.2-4.4 1.8 4.4M12 3.4V1.4M9 1.4h6"/></svg>',
    'users': '<svg ' + _S + '><circle cx="9.2" cy="8" r="3.3"/><path d="M3.4 19.6c.7-3.4 2.9-5.2 5.8-5.2s5.1 1.8 5.8 5.2M15.8 5.1a3.3 3.3 0 0 1 0 5.8M17.6 14.9c2.1.6 3.4 2.3 3.9 4.7"/></svg>',
    'gauge': '<svg ' + _S + '><path d="M4 17.6a8.8 8.8 0 1 1 16 0"/><path d="m12 13.8 3.8-3.8"/><circle cx="12" cy="14.6" r="1.3" fill="currentColor" stroke="none"/><path d="M4 17.6h3.2M16.8 17.6H20"/></svg>',
    'layers': '<svg ' + _S + '><path d="m12 3.2 9 4.8-9 4.8-9-4.8 9-4.8z"/><path d="m3 12.2 9 4.8 9-4.8M3 16.2l9 4.8 9-4.8"/></svg>',
    'doc': '<svg ' + _S + '><path d="M6 2.8h7.6L19 8.2v13H6a1 1 0 0 1-1-1V3.8a1 1 0 0 1 1-1z"/><path d="M13.4 2.8v5.6H19M8.6 12.8h7M8.6 16.4h7"/></svg>'
};
/* default icon/colour per exam id when the JSON item doesn't set them */
var EXAM_ICON_MAP = {
    'cgl': { icon: 'grad-cap', color: 'blue' },      'chsl': { icon: 'notebook', color: 'violet' },
    'mts': { icon: 'briefcase', color: 'teal' },     'cpo': { icon: 'shield-check', color: 'slate' },
    'steno': { icon: 'keyboard', color: 'amber' },   'selection-post': { icon: 'id-badge', color: 'blue' },
    'gd': { icon: 'shield-star', color: 'teal' },    'ntpcg': { icon: 'train-front', color: 'blue' },
    'ntpc-ug': { icon: 'tram', color: 'violet' },    'group-d': { icon: 'users', color: 'teal' },
    'alp': { icon: 'gauge', color: 'amber' }
};
var COLOR_CYCLE = ['blue', 'violet', 'teal', 'amber', 'slate'];

var ICO = {
    calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    calc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7.5h7"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 15.5h.01M12 15.5h.01M15.5 15.5v.01"/></svg>',
    puzzle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3.5a2 2 0 0 1 4 0V5h3a2 2 0 0 1 2 2v3h1.5a2 2 0 0 1 0 4H19v3a2 2 0 0 1-2 2h-3v-1.5a2 2 0 0 0-4 0V19h-3a2 2 0 0 1-2-2v-3H3.5a2 2 0 0 1 0-4H5V7a2 2 0 0 1 2-2h3V3.5z"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.3 3.8 5.2 3.8 8.5s-1.3 6.2-3.8 8.5c-2.5-2.3-3.8-5.2-3.8-8.5s1.3-6.2 3.8-8.5z"/></svg>',
    book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6.5C10.2 5 7.8 4.5 4.5 4.5v13c3.3 0 5.7.5 7.5 2 1.8-1.5 4.2-2 7.5-2v-13c-3.3 0-5.7.5-7.5 2z"/><path d="M12 6.5v13"/></svg>',
    archive: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4" width="17" height="4.5" rx="1.5"/><path d="M5.5 8.5V18a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V8.5M10 12.5h4"/></svg>',
    clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5.5" y="4" width="13" height="17" rx="2.5"/><path d="M9 11h6M9 15h4"/></svg>',
    retry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4.5V11h-6.5"/></svg>'
};

/* ── helpers ─────────────────────────────────────────────────────────────── */
function J() {
    try { if (typeof EXAM_JSON !== 'undefined' && EXAM_JSON) return EXAM_JSON; } catch (e) {}
    return window.EXAM_JSON || null;
}
function CF() { return currentFilters; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function escJs(s) { return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'"); }
function exams() { var j = J(); return (j && Array.isArray(j.exams)) ? j.exams : []; }
function examById(id) {
    if (!id) return null;
    var low = String(id).toLowerCase();
    return exams().find(function (e) { return String(e.id).toLowerCase() === low; }) || null;
}
function examTitle(id) { var e = examById(id); return e ? (e.title || e.id) : (id || ''); }
function fileFor(year, id) {
    var j = J(), f = j && j.files && j.files[year];
    if (!f || !id) return null;
    var low = String(id).toLowerCase();
    var k = Object.keys(f).find(function (x) { return x.toLowerCase() === low; });
    var v = k ? f[k] : null;
    return (typeof v === 'string' && v.trim()) ? v.trim() : null;
}
function isAvailable(year, id) { var e = examById(id); return !!(e && !e.comingSoon && fileFor(year, id)); }
function years() {
    var j = J(), y = (j && j.years && j.years.length) ? j.years.slice() : Object.keys((j && j.files) || {});
    return y.sort(function (a, b) { return String(b).localeCompare(String(a), undefined, { numeric: true }); });
}
function countItems(node) {
    if (Array.isArray(node)) return node.length;
    if (node && typeof node === 'object') { var t = 0; Object.keys(node).forEach(function (k) { t += countItems(node[k]); }); return t; }
    return 0;
}
function iconFor(ex, idx) {
    var key = ex && ex.icon && EXAM_ICONS[String(ex.icon).replace(/^fa[srlbd]? fa-/, '')] ? String(ex.icon).replace(/^fa[srlbd]? fa-/, '') : null;
    var cfg = EXAM_ICON_MAP[String(ex && ex.id).toLowerCase()] || null;
    key = key || (cfg && cfg.icon) || 'doc';
    var color = (ex && ex.color) || (cfg && cfg.color) || COLOR_CYCLE[(idx || 0) % COLOR_CYCLE.length];
    return { html: EXAM_ICONS[key] || EXAM_ICONS.doc, color: color };
}
function icoHtml(ex, idx) {
    var ic = iconFor(ex, idx);
    if (ex && ex.logo) {
        return '<span class="nc-ico ' + ic.color + '" data-icon-html="' + encodeURIComponent(ic.html) + '">' +
            '<img class="nc-logo" src="' + esc(ex.logo) + '" alt="" loading="lazy" onerror="window._esLogoFailed(this)"></span>';
    }
    return '<span class="nc-ico ' + ic.color + '">' + ic.html + '</span>';
}
window._esLogoFailed = function (img) {
    try { var w = img.closest('.nc-ico'); if (w) w.innerHTML = decodeURIComponent(w.dataset.iconHtml || ''); } catch (e) { if (img && img.remove) img.remove(); }
};
function subjectIcon(name) {
    var n = String(name).toLowerCase();
    if (n.indexOf('math') >= 0) return { ico: ICO.calc, cls: 'blue' };
    if (n.indexOf('reason') >= 0) return { ico: ICO.puzzle, cls: 'violet' };
    if (n.indexOf('old') >= 0) return { ico: ICO.archive, cls: 'slate' };
    if (n.indexOf('english') >= 0) return { ico: ICO.book, cls: 'teal' };
    if (n.indexOf('general') >= 0 || n.indexOf('awareness') >= 0 || n === 'gk' || n === 'ga') return { ico: ICO.globe, cls: 'amber' };
    return { ico: ICO.clip, cls: 'blue' };
}
function setText(id, t) { var el = document.getElementById(id); if (el) el.textContent = t; }

/* ── URL filter: same format as SSC SUB, plus `exam`  ───────────────────────
   ?filter=year=2026,exam=cgl,subject=Math,topic=Percentage                  */
var KEYS = ['year', 'exam', 'subject', 'topic', 'subtopic'];
window._getUrlFilters = function () {
    var raw = new URLSearchParams(window.location.search).get('filter');
    if (!raw) return null;
    var split = new RegExp(',(?=(?:' + KEYS.join('|') + ')=)');
    var out = {};
    raw.split(split).forEach(function (pair) {
        var i = pair.indexOf('='); if (i === -1) return;
        var k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
        if (KEYS.indexOf(k) >= 0 && v) out[k] = v;
    });
    return Object.keys(out).length ? out : null;
};
function filterUrl(o) {
    var fs = KEYS.filter(function (k) { return o[k]; }).map(function (k) { return k + '=' + o[k]; }).join(',');
    /* keep ?exam-ssc-sub&b=ssc — only the filter part changes */
    var q = [window.MMHExam ? MMHExam.query() : '', fs ? 'filter=' + encodeURIComponent(fs) : ''].filter(Boolean).join('&');
    return window.location.pathname + (q ? '?' + q : '');
}
window._updateUrlFilter = function () {
    try { history.replaceState(history.state, '', filterUrl(CF())); } catch (e) {}
};

/* ── data loader: one file per (year, exam), cached in memory ────────────────
   The engine keeps reading EXAM_JSON.data[year]; we point that at the chosen
   exam's subjects, so renderMocks / chips / search work unchanged.          */
var CACHE = {}, LOADING = {};
function useExamData(year, id) {
    var j = J(); if (!j) return null;
    if (!j.data || typeof j.data !== 'object') j.data = {};
    var d = CACHE[year + '|' + String(id).toLowerCase()] || null;
    j.data[year] = d || {};
    return d;
}
function loadExam(year, id) {
    var j = J();
    if (!j || !year || !id) return Promise.resolve(null);
    var key = year + '|' + String(id).toLowerCase();
    if (CACHE[key]) return Promise.resolve(CACHE[key]);
    if (LOADING[key]) return LOADING[key];
    var file = fileFor(year, id);
    if (!file) return Promise.resolve(null);
    var url = _resolveYearDataUrl(EXAM_DATA_BASE_URL, EXAM_NAME_TOKEN, year, file);
    LOADING[key] = fetch(url).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + file);
        return r.json();
    }).then(function (fj) {
        var raw = _extractYearPayload(fj, year);
        var cfg = (fj && fj.config && fj.config.default) ? fj.config.default : ((j.config && j.config.default) ? j.config.default : {});
        CACHE[key] = _normalizeYearBranch(raw, cfg);
        return CACHE[key];
    }).catch(function (e) {
        console.error('[exam-ssc-sub] could not load', file, e);
        return null;
    }).then(function (d) { delete LOADING[key]; return d; });
    return LOADING[key];
}
/* engine calls this by name (boot deep link) → load the CURRENT exam of that year */
window.ensureYearDataLoaded = function (year) {
    var id = CF().exam;
    if (!id || !isAvailable(year, id)) { useExamData(year, '__none__'); return Promise.resolve(null); }
    return loadExam(year, id).then(function (d) {
        if (CF().year === year && String(CF().exam).toLowerCase() === String(id).toLowerCase()) useExamData(year, id);
        return d;
    });
};

/* engine boot runs setupFilters() before any exam file is loaded → give the
   chosen year an empty branch so it doesn't throw (and the engine goes on to
   syncWithCloud + search wiring as usual)                                   */
(function () {
    var orig = window.setupFilters;
    if (typeof orig !== 'function' || orig.__esWrapped) return;
    var w = function () {
        var j = J(), y = CF().year;
        if (j) { if (!j.data || typeof j.data !== 'object') j.data = {}; if (y && !j.data[y]) j.data[y] = {}; }
        return orig.apply(this, arguments);
    };
    w.__esWrapped = true;
    window.setupFilters = w;
})();

/* ── mock-screen header: "SSC CGL · 2026 · Math" ─────────────────────────── */
window._updateMockHeader = function () {
    var cf = CF(), et = examTitle(cf.exam), big = (typeof _isBigScreen === 'function') && _isBigScreen();
    setText('mockTitle', big ? [et, cf.year, cf.subject].filter(Boolean).join(' \u00B7 ') : (cf.subject || et || 'Mocks'));
    setText('mockSub', big ? 'Mock Matrix Hub' : ([et, cf.year].filter(Boolean).join(' \u00B7 ') || 'Mock Matrix Hub'));
};
try {
    var mq = window.matchMedia('(min-width: 900px)');
    var onMq = function () { if (J() && document.getElementById('screenMocks').classList.contains('active')) window._updateMockHeader(); };
    if (mq.addEventListener) mq.addEventListener('change', onMq); else if (mq.addListener) mq.addListener(onMq);
} catch (e) {}

/* ── screens ─────────────────────────────────────────────────────────────── */
var SCREENS = ['screenYear', 'screenExams', 'screenSubjects', 'screenMocks'];
var ROOT_TITLE = document.title;
function active(id) { var s = document.getElementById(id); return !!(s && s.classList.contains('active')); }
function show(id, dir) {
    if (window.MMHNav) { /* t255: slide direction from screen depth */
        var el = MMHNav.show(SCREENS, id);
        var sc0 = el && (el.querySelector('.screen-scroll') || el.querySelector('.scrollable-grid-area'));
        if (sc0) sc0.scrollTop = 0;
        return;
    }
    SCREENS.forEach(function (sid) { var s = document.getElementById(sid); if (s) { s.classList.remove('active'); s.classList.remove('from-left'); } });
    var scr = document.getElementById(id); if (!scr) return;
    scr.classList.add('active');
    if (dir === -1) scr.classList.add('from-left');
    var sc = scr.querySelector('.screen-scroll') || scr.querySelector('.scrollable-grid-area');
    if (sc) sc.scrollTop = 0;
}
function push(o) { try { history.pushState({ mmhNav: 1 }, '', filterUrl(o)); } catch (e) {} }
function save() { try { saveFilters(); } catch (e) {} }

function buildYearCards() {
    var box = document.getElementById('yearCards'); if (!box) return;
    var n = exams().length;
    box.innerHTML = years().map(function (y) {
        var avail = exams().filter(function (e) { return isAvailable(y, e.id); }).length;
        var meta = avail ? (avail + ' of ' + n + ' exams available') : 'Coming soon';
        return '<button type="button" class="nav-card" onclick="hubNavYear(\'' + escJs(y) + '\')">' +
            '<span class="nc-ico blue">' + ICO.calendar + '</span>' +
            '<span class="nc-body"><span class="nc-title">' + esc(y) + '</span><span class="nc-meta">' + esc(meta) + '</span></span>' +
            '<span class="nc-chev">' + ICO.chev + '</span></button>';
    }).join('');
}
function buildExamCards(y) {
    var box = document.getElementById('examCards'); if (!box) return;
    var list = exams();
    box.innerHTML = list.map(function (e, i) {
        var ok = isAvailable(y, e.id);
        var d = CACHE[y + '|' + String(e.id).toLowerCase()];
        var meta = ok ? (d ? Object.keys(d).length + ' subjects \u00B7 ' + countItems(d) + ' mocks' : (e.subtitle || 'Explore subjects')) : 'Tests not uploaded yet';
        var badge = ok ? (e.badge ? '<span class="nc-badge ' + (/soon/i.test(e.badge) ? 'soon' : 'new') + '">' + esc(e.badge) + '</span>' : '')
                       : '<span class="nc-badge soon">Coming Soon</span>';
        return '<button type="button" class="nav-card' + (ok ? '' : ' is-soon') + '" onclick="hubNavExam(\'' + escJs(e.id) + '\')">' +
            icoHtml(e, i) +
            '<span class="nc-body"><span class="nc-title">' + esc(e.title || e.id) + ' ' + badge + '</span>' +
            '<span class="nc-meta">' + esc(meta) + '</span></span>' +
            '<span class="nc-chev">' + ICO.chev + '</span></button>';
    }).join('');
    var avail = list.filter(function (e) { return isAvailable(y, e.id); }).length;
    setText('examsTitle', y);
    setText('examsSub', avail + ' of ' + list.length + ' exams available');
}
function subjectsSkeleton() {
    var box = document.getElementById('subjectCards'); if (!box) return;
    box.innerHTML = Array(4).fill('<div class="nav-card skeleton-nav-card"><div class="nc-ico skeleton-line"></div><div class="nc-body"><div class="skeleton-line skeleton-nc-title"></div><div class="skeleton-line skeleton-nc-meta"></div></div></div>').join('');
}
function subjectsError(y, id) {
    var box = document.getElementById('subjectCards'); if (!box) return;
    box.innerHTML = '<div class="empty-state"><div class="empty-ico">' + ICO.retry + '</div>' +
        '<div class="empty-title">Couldn\u2019t load ' + esc(examTitle(id)) + ' ' + esc(y) + '</div>' +
        '<div class="empty-sub">Check your internet and try again.</div>' +
        '<button type="button" class="modal-btn primary" style="margin-top:14px" onclick="hubNavExam(\'' + escJs(id) + '\', true)">Try again</button></div>';
    setText('subjectsSub', y + ' \u00B7 not loaded');
}
function buildSubjectCards(y, id) {
    var box = document.getElementById('subjectCards'); if (!box) return;
    var d = CACHE[y + '|' + String(id).toLowerCase()];
    if (!d) return;
    var subs = Object.keys(d);
    box.innerHTML = subs.length ? subs.map(function (s) {
        var ic = subjectIcon(s), nT = (d[s] && !Array.isArray(d[s])) ? Object.keys(d[s]).length : 0;
        return '<button type="button" class="nav-card" onclick="hubNavSubject(\'' + escJs(s) + '\')">' +
            '<span class="nc-ico ' + ic.cls + '">' + ic.ico + '</span>' +
            '<span class="nc-body"><span class="nc-title">' + esc(s) + '</span>' +
            '<span class="nc-meta">' + nT + ' topics \u00B7 ' + countItems(d[s]) + ' mocks</span></span>' +
            '<span class="nc-chev">' + ICO.chev + '</span></button>';
    }).join('') : '<div class="empty-state"><div class="empty-title">No subjects yet</div><div class="empty-sub">Tests for this exam will appear here soon.</div></div>';
    setText('subjectsTitle', examTitle(id));
    setText('subjectsSub', y + ' \u00B7 ' + subs.length + ' subjects \u00B7 ' + countItems(d) + ' mocks');
}
function openSubjects(y, id, dir) {
    setText('subjectsTitle', examTitle(id));
    show('screenSubjects', dir);
    document.title = examTitle(id) + ' ' + y + ' — Mock Matrix Hub';
    if (CACHE[y + '|' + String(id).toLowerCase()]) { useExamData(y, id); buildSubjectCards(y, id); return Promise.resolve(true); }
    useExamData(y, '__none__');
    subjectsSkeleton();
    setText('subjectsSub', y + ' \u00B7 Loading subjects\u2026');
    return loadExam(y, id).then(function (d) {
        if (CF().year !== y || String(CF().exam).toLowerCase() !== String(id).toLowerCase()) return false;
        if (!d) { subjectsError(y, id); return false; }
        useExamData(y, id); buildSubjectCards(y, id); buildExamCards(y);
        return true;
    });
}

/* ── navigation (cards call these by name) ───────────────────────────────── */
var hubYear = '';
window.hubNavYear = function (y) {
    var cf = CF();
    hubYear = y;
    cf.year = y; cf.exam = ''; cf.subject = ''; cf.topic = ''; cf.subtopic = '';
    push({ year: y }); save();
    buildExamCards(y);
    show('screenExams', 1);
    document.title = y + ' Exams — Mock Matrix Hub';
};
window.hubNavExam = function (id, retry) {
    var y = hubYear || CF().year, e = examById(id);
    if (!e) return;
    if (!isAvailable(y, e.id)) {
        if (typeof showToast === 'function') showToast((e.title || e.id) + ' ' + y + ' tests are not uploaded yet \u2014 coming soon!', 'error');
        return;
    }
    var cf = CF();
    cf.exam = e.id; cf.subject = ''; cf.topic = ''; cf.subtopic = '';
    if (!retry) push({ year: y, exam: e.id });
    save();
    openSubjects(y, e.id, retry ? 0 : 1);
};
window.hubNavSubject = function (s) {
    var cf = CF(), y = hubYear || cf.year;
    push({ year: y, exam: cf.exam, subject: s });
    useExamData(y, cf.exam);   /* engine may have re-booted (pageshow) and reset EXAM_JSON.data */
    if (typeof setDeepFilter === 'function') setDeepFilter('subject', s);
    window._updateMockHeader();
    show('screenMocks', 1);
    document.title = s + ' \u00B7 ' + examTitle(cf.exam) + ' — Mock Matrix Hub';
};
window.hubBack = function () {
    if (window.MMHNav && MMHNav.pop()) return; /* t255 */
    var st = (window.history && window.history.state) || null;
    if (st && st.mmhNav) { try { history.back(); return; } catch (e) {} }
    var cf = CF();
    if (active('screenMocks')) {
        cf.subject = ''; cf.topic = ''; cf.subtopic = ''; save();
        show('screenSubjects', -1);
    } else if (active('screenSubjects')) {
        cf.exam = ''; cf.subject = ''; cf.topic = ''; cf.subtopic = ''; save();
        buildExamCards(hubYear); show('screenExams', -1);
        document.title = hubYear + ' Exams — Mock Matrix Hub';
    } else if (active('screenExams')) {
        cf.year = ''; cf.exam = ''; save();
        show('screenYear', -1); document.title = window.ROOT_TITLE || ROOT_TITLE;
    }
};
/* URL is the source of truth — boot deep links + every back/forward */
window.hubLandFromUrl = function () {
    var p = window._getUrlFilters(), cf = CF();
    var ys = years();
    var y = p && p.year ? (_matchCaseInsensitive(ys, p.year) || '') : '';
    if (!y) { cf.year = ''; cf.exam = ''; show('screenYear', 0); document.title = window.ROOT_TITLE || ROOT_TITLE; return; }
    hubYear = y; cf.year = y;
    buildExamCards(y);
    var e = p.exam ? examById(p.exam) : null;
    if (!e || !isAvailable(y, e.id)) { cf.exam = ''; cf.subject = ''; cf.topic = ''; cf.subtopic = ''; show('screenExams', 0); document.title = y + ' Exams — Mock Matrix Hub'; return; }
    cf.exam = e.id;
    if (!p.subject) { cf.subject = ''; cf.topic = ''; cf.subtopic = ''; openSubjects(y, e.id, 0); return; }
    show('screenMocks', 0);
    var grid = document.getElementById('quizGrid');
    if (grid && !CACHE[y + '|' + String(e.id).toLowerCase()]) grid.innerHTML = Array(4).fill('<div class="skeleton-card"><div class="card-info"><div class="skeleton-line skeleton-title"></div><div class="skeleton-line skeleton-meta"></div></div><div class="skeleton-line skeleton-btn"></div></div>').join('');
    loadExam(y, e.id).then(function (d) {
        if (!d) { openSubjects(y, e.id, 0); return; }
        useExamData(y, e.id); buildSubjectCards(y, e.id);
        var subj = _matchCaseInsensitive(Object.keys(d), p.subject) || '';
        if (!subj) { openSubjects(y, e.id, 0); return; }
        /* topic / subtopic: case-insensitive, real key casing (same as the engine boot) */
        var sd = d[subj], top = '', sub = '';
        if (p.topic && sd && !Array.isArray(sd)) top = _matchCaseInsensitive(Object.keys(sd), p.topic) || '';
        var td = top ? sd[top] : null;
        if (p.subtopic && td && !Array.isArray(td) && !(typeof _isLeafMockTopic === 'function' && _isLeafMockTopic(td)))
            sub = _matchCaseInsensitive(Object.keys(td), p.subtopic) || '';
        cf.subject = subj; cf.topic = top; cf.subtopic = sub;
        save();
        setupFilters(ys);
        renderMocks();
        window._updateMockHeader();
        document.title = subj + ' \u00B7 ' + examTitle(e.id) + ' — Mock Matrix Hub';
    });
};
/* search inside the mocks screen can jump to another subject — keep titles in sync */
function wrapSearch() {
    var orig = window._selectSearchResult;
    if (typeof orig !== 'function' || orig.__esWrapped) return;
    var w = function (yy, s, t, st) { orig(yy, s, t, st); window._updateMockHeader(); };
    w.__esWrapped = true;
    window._selectSearchResult = w;
}
window.initHubNav = function () {
    if (!J()) return;
    buildYearCards();
    ['backFromMocks', 'backFromSubjects', 'backFromExams'].forEach(function (id) { var b = document.getElementById(id); if (b) b.onclick = window.hubBack; });
    var by = document.getElementById('backFromYear');
    if (by) { by.style.display = ''; by.onclick = window.hubBackFromYear; }
    Array.prototype.forEach.call(document.querySelectorAll('.theme-btn'), function (b) { b.onclick = function () { toggleTheme(); }; });
    wrapSearch();
    window.addEventListener('popstate', function () { window.hubLandFromUrl(); });
    window.hubLandFromUrl();
};
})();

/* ── attempts sync: ids look like SSC-SUB-26-CGL-… → run the engine's sync as
   "ssc-sub" (same worker as SSC SUB). Without this the engine would use the
   folder name "exam-ssc-sub" as the id filter, and a test just submitted on
   this device (qsum_/result_ keys) would not show as attempted until
   "Refetch Attempts". Shares the CLOUD_SYNC_<user>_ssc-sub cache with SSC SUB
   — same worker, same results, one fetch for both pages.                   */
(function () {
    var orig = window.syncWithCloud;
    if (typeof orig !== 'function' || orig.__esWrapped) return;
    var w = function () { return orig.call(this, 'ssc-sub'); };
    w.__esWrapped = true;
    window.syncWithCloud = w;
})();

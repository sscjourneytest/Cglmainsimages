/* ══════════════════════════════════════════════════════════════════════════
   mmh-zip.js — tiny ZIP writer + reader for the admin Bulk Upload / Download
   (no library; same file in the app/website page, the standalone HTML and the
   node tests).
   • write: deflate with the browser's CompressionStream("deflate-raw");
            a browser without it → "stored" (no compression, still a valid zip)
   • read : stored + deflate (DecompressionStream). No ZIP64 / encryption
            (zips made by Windows / Android / macOS / this tool all work).
   window.MMHZip = { writer(), read(buffer) → [{ name, size, text(), bytes() }] }
   ══════════════════════════════════════════════════════════════════════════ */
(function (root) {
"use strict";

var ENC = new TextEncoder(), DEC = new TextDecoder("utf-8");
var CRC = (function () {
  var t = new Uint32Array(256);
  for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(b) {
  var c = 0xFFFFFFFF;
  for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function canStream(kind, fmt) {
  try { return typeof root[kind] === "function" && !!new root[kind](fmt); } catch (e) { return false; }
}
function pipe(bytes, stream) {
  return new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer().then(function (b) { return new Uint8Array(b); });
}
function dosTime(d) {
  return {
    time: (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2),
    date: ((Math.max(1980, d.getFullYear()) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
  };
}

/** zip = MMHZip.writer(); await zip.add("a.json", text); … ; zip.blob() */
function writer() {
  var files = [], parts = [], offset = 0, deflate = canStream("CompressionStream", "deflate-raw");
  var when = dosTime(new Date());
  return {
    deflate: deflate,
    count: function () { return files.length; },
    add: async function (name, data) {
      var raw = typeof data === "string" ? ENC.encode(data) : data;
      var nameB = ENC.encode(name), crc = crc32(raw), comp = raw, method = 0;
      if (deflate && raw.length > 64) {
        var z = await pipe(raw, new root.CompressionStream("deflate-raw"));
        if (z.length < raw.length) { comp = z; method = 8; }
      }
      if (raw.length >= 0xFFFFFFFF || offset >= 0xFFFFFFFF) throw new Error("zip too big (max 4 GB)");
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true);   // UTF-8 names
      h.setUint16(8, method, true); h.setUint16(10, when.time, true); h.setUint16(12, when.date, true);
      h.setUint32(14, crc, true); h.setUint32(18, comp.length, true); h.setUint32(22, raw.length, true);
      h.setUint16(26, nameB.length, true); h.setUint16(28, 0, true);
      parts.push(new Uint8Array(h.buffer), nameB, comp);
      files.push({ nameB: nameB, crc: crc, csize: comp.length, size: raw.length, method: method, offset: offset });
      offset += 30 + nameB.length + comp.length;
    },
    blob: function () {
      var cd = [], cdSize = 0;
      files.forEach(function (f) {
        var c = new DataView(new ArrayBuffer(46));
        c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true);
        c.setUint16(10, f.method, true); c.setUint16(12, when.time, true); c.setUint16(14, when.date, true);
        c.setUint32(16, f.crc, true); c.setUint32(20, f.csize, true); c.setUint32(24, f.size, true);
        c.setUint16(28, f.nameB.length, true); c.setUint32(42, f.offset, true);
        cd.push(new Uint8Array(c.buffer), f.nameB); cdSize += 46 + f.nameB.length;
      });
      var e = new DataView(new ArrayBuffer(22));
      e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true);
      e.setUint32(12, cdSize, true); e.setUint32(16, offset, true);
      return new Blob(parts.concat(cd, [new Uint8Array(e.buffer)]), { type: "application/zip" });
    }
  };
}

function isZip(bytes) { return bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04; }

/** entries of a zip (folders skipped). Each: { name, size, bytes() → Promise<Uint8Array>, text() → Promise<string> } */
function read(buf) {
  var u = buf instanceof Uint8Array ? buf : new Uint8Array(buf), v = new DataView(u.buffer, u.byteOffset, u.byteLength);
  var eocd = -1;
  for (var i = u.length - 22; i >= Math.max(0, u.length - 65557); i--) if (v.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error("Not a zip file (or it is damaged)");
  var n = v.getUint16(eocd + 10, true), p = v.getUint32(eocd + 16, true);
  if (p === 0xFFFFFFFF || n === 0xFFFF) throw new Error("ZIP64 is not supported — make a normal zip");
  var out = [];
  for (var k = 0; k < n; k++) {
    if (v.getUint32(p, true) !== 0x02014b50) throw new Error("Zip directory is damaged");
    var flags = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), csize = v.getUint32(p + 20, true), size = v.getUint32(p + 24, true);
    var nl = v.getUint16(p + 28, true), xl = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), lo = v.getUint32(p + 42, true);
    var name = DEC.decode(u.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + xl + cl;
    if (/\/$/.test(name)) continue;
    if (flags & 1) throw new Error(name + ": password-protected zips are not supported");
    if (csize === 0xFFFFFFFF || size === 0xFFFFFFFF) throw new Error("ZIP64 is not supported — make a normal zip");
    var start = lo + 30 + v.getUint16(lo + 26, true) + v.getUint16(lo + 28, true);
    out.push(entry(name, method, u.subarray(start, start + csize), size));
  }
  return out;
}
function entry(name, method, comp, size) {
  var bytes = function () {
    if (method === 0) return Promise.resolve(comp);
    if (method !== 8) return Promise.reject(new Error(name + ": unsupported zip compression (" + method + ")"));
    if (!canStream("DecompressionStream", "deflate-raw")) return Promise.reject(new Error("This browser cannot open compressed zips — update it, or pick the JSON files instead"));
    return pipe(comp, new root.DecompressionStream("deflate-raw"));
  };
  return { name: name, size: size, bytes: bytes, text: function () { return bytes().then(function (b) { return DEC.decode(b); }); } };
}

root.MMHZip = { writer: writer, read: read, isZip: isZip, crc32: crc32 };
})(typeof globalThis !== "undefined" ? globalThis : this);

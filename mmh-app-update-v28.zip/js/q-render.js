/* ══════════════════════════════════════════════════════════════════════════
   q-render.js — the question-render pipeline, LIFTED VERBATIM from test.html
   by lift_render.py. Shared by saved/index.html and saved/test.html so a saved
   question looks EXACTLY like it does inside a test: same language handling,
   same <br> repair, same \text{} extraction, same MathJax, same dynamic
   GitHub images, same exam tag, same bold-highlight, same broken-image hiding.

   DO NOT EDIT BY HAND — edit test.html and re-run:
       python3 /tmp/lift_render.py
   ══════════════════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const FB_BAD_KEY_CHARS = ".#$[]/";

function fbKey(raw) {
  let s = String(raw == null ? "" : raw).trim().replace(/\s+/g, " ");
  for (const ch of FB_BAD_KEY_CHARS) s = s.split(ch).join("-");
  return s.slice(0, 60);
}

function hasKeyword(id, kw) {
    return id.startsWith(kw + "-") || id.startsWith(kw + "_");
  }

/* Lifted from test.html's quiz-id -> GitHub image folder mapping. The saved
   page shows questions from MANY quizzes at once, so this is a FUNCTION of the
   quizId rather than a one-time global — every card resolves its own path. */
function mmhGithubPathFor(quizId) {
  const id = String(quizId || "").toLowerCase();
  if (hasKeyword(id, "cgl"))            return id.includes("-sub") ? "ssc/cgl/subject"     : "ssc/cgl/full-mock";
  if (hasKeyword(id, "chsl"))           return id.includes("-sub") ? "ssc/chsl/subject"    : "ssc/chsl/full-mock";
  if (hasKeyword(id, "mts"))            return id.includes("-sub") ? "ssc/mts/subject"     : "ssc/mts/full-mock";
  if (hasKeyword(id, "selection-post")) return id.includes("-sub") ? "ssc/phase/subject"   : "ssc/phase/full-mock";
  if (hasKeyword(id, "gd"))             return id.includes("-sub") ? "ssc/gd/subject"      : "ssc/gd/full-mock";
  if (hasKeyword(id, "cpo"))            return id.includes("-sub") ? "ssc/cpo/subject"     : "ssc/cpo/full-mock";
  if (hasKeyword(id, "steno"))          return id.includes("-sub") ? "ssc/steno/subject"   : "ssc/steno/full-mock";
  if (hasKeyword(id, "group-d"))        return "rrb/group-d/full-mock";
  if (hasKeyword(id, "alp"))            return "rrb/alp/full-mock";
  if (hasKeyword(id, "ssc-sub-25"))     return "ssc-sub/2025/mocks";
  if (hasKeyword(id, "ntpcg"))          return "rrb/ntpcg/full-mock";
  if (hasKeyword(id, "ntpc-ug"))        return "rrb/ntpc-ug/full-mock";
  if (hasKeyword(id, "imps"))           return "imps/full-mock";
  return "";
}

function applyBoldHighlight(html, isQuestionText) {
  if (!html || typeof html !== "string") return html;

  // This regex finds text between ** and wraps it in a strong tag.
  // Question text also gets italic; everywhere else stays bold-only.
  const style = isQuestionText
    ? "font-weight: 700; font-style: italic; color: #000;"
    : "font-weight: 700; color: #000;";
  return html.replace(/\*\*(.*?)\*\*/g, `<strong style="${style}">$1</strong>`);
  }

function hideBrokenInlineImages(container) {
  if (!container) return;
  container.querySelectorAll('img').forEach(function(img) {
    const src = img.getAttribute('src');
    if (!src || src.trim() === '') {
      img.style.display = 'none';
      return;
    }
    img.onerror = function() { this.style.display = 'none'; };
  });
}

function extractExamTag(html) {
  if (!html || typeof html !== "string") return { text: html, tag: null };
  let tag = null;
  const cleaned = html.replace(
    /\s*\[([^\[\]]{3,160})\]\s*(?:<br\s*\/?>\s*)*(?=<hr[^>]*>|$)/gi,
    function (match, inner) {
      if (!tag) tag = inner.trim();
      return "";
    }
  );
  return { text: cleaned, tag: tag };
}

function formatExamTag(raw) {
  if (!raw) return "";
  const MONTHS = { jan:"01", feb:"02", mar:"03", apr:"04", may:"05", jun:"06",
                    jul:"07", aug:"08", sep:"09", oct:"10", nov:"11", dec:"12" };
  const parts = raw.split(",").map(function (s) { return s.trim(); }).filter(Boolean);
  const formatted = parts.map(function (part) {
    const dateMatch = part.match(/^(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})$/);
    if (dateMatch) {
      const mon = MONTHS[dateMatch[2].slice(0, 3).toLowerCase()];
      if (mon) return dateMatch[1].padStart(2, "0") + "/" + mon + "/" + dateMatch[3];
    }
    const shiftMatch = part.match(/^shift[\s-]*([0-9]+)$/i);
    if (shiftMatch) return "Shift-" + shiftMatch[1];
    return part;
  });
  return formatted.join(" ");
}

// A few older question records do not carry the trailing [exam, date, shift]
// bracket. Keep the card useful by deriving a readable fallback from the quiz
// path, while still preferring a real tag whenever one exists.
function deriveExamTagFromQuizId(quizId) {
  const raw = String(quizId == null ? "" : quizId).trim();
  if (!raw) return "";
  return raw.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
}

function mmhQuestionDisplay(question, currentLang, quizId) {
  if (currentLang === "bilingual" && question && typeof question === "object" && !Array.isArray(question)) {
    const en = extractExamTag(mmhGetLangText(question, "en"));
    const hi = extractExamTag(mmhGetLangText(question, "hi"));
    const same = en.text.trim() && en.text.trim() === hi.text.trim();
    const pieces = same ? [en.text] : [en.text, hi.text].filter(Boolean);
    return {
      text: pieces.join("<hr style='border:none; border-top:1px dashed #ccc; margin:10px 0;'>"),
      tag: en.tag || hi.tag || deriveExamTagFromQuizId(quizId)
    };
  }
  const parsed = extractExamTag(mmhGetLangText(question, currentLang));
  return { text: parsed.text, tag: parsed.tag || deriveExamTagFromQuizId(quizId) };
}

function mmhDynImgOk(img, qid, slot) {
  img.style.display = "block";
  try {
    if (img.naturalWidth > 0) MMH_DYN_IMG_OK[qid + "|" + slot] = img.currentSrc || img.src;
  } catch (e) {}
}

function mmhDynImgFail(img, qid, slot) {
  img.style.display = "none";
  try { delete MMH_DYN_IMG_OK[qid + "|" + slot]; } catch (e) {}
}

function mmhImgSlotArg(qid) { return String(qid).replace(/[^A-Za-z0-9_-]/g, ""); }

function resolveSavedImages(q) {
  const slots = { question_image: "q", solution_image: "s" };
  for (let n = 1; n <= 5; n++) slots["option_image_" + n] = "o" + n;
  const out = {};
  Object.keys(slots).forEach(field => {
    const manual = q[field];
    if (manual && String(manual).trim() !== "") { out[field] = manual; return; } // manual wins
    const got = MMH_DYN_IMG_OK[String(q.id) + "|" + slots[field]];
    out[field] = got || (manual || "");   // dynamic URL only if it really loaded
  });
  return out;
}

function getOptionPercent(q, optionIndex) {
  const qIndex = getGlobalQIndex(q);
  if (qIndex < 0) return null;
  const arr = QUESTION_STATS["opt" + optionIndex];
  if (!arr || !arr.length || !QUESTION_STATS_TOTAL) return null;
  const cnt = arr[qIndex];
  if (cnt == null) return null;
  return Math.round((cnt / QUESTION_STATS_TOTAL) * 100);
}

function normalizeMathForQuiz(container) {
  if (!container) return;
  // Convert $$...$$ block math to \(...\) inline math for better mobile flow
  container.innerHTML = container.innerHTML
    .replace(/\$\$([\s\S]+?)\$\$/g, '\\($1\\)');
}

function renderMath(){
  function hasUnrenderedMath() {
    const text = document.body.innerText || document.body.textContent || "";
    return /\\\(|\\\)|\\\[|\\\]|\$\$/.test(text);
  }

  function attempt(retriesLeft) {
    // MathJax script may still be downloading (slow connection) or may not
    // have finished loading yet — window.MathJax / typesetPromise won't
    // exist. Wait and try again instead of silently giving up.
    if (!(window.MathJax && MathJax.typesetPromise)) {
      if (retriesLeft > 0) {
        setTimeout(() => attempt(retriesLeft - 1), 500);
      } else {
        console.warn("MathJax failed to load — equations may not render.");
      }
      return;
    }

    // Exact same call as before — typeset the whole page.
    MathJax.typesetPromise().then(() => {
      if (hasUnrenderedMath() && retriesLeft > 0) {
        console.warn("MathJax typeset left raw delimiters, retrying...");
        setTimeout(() => attempt(retriesLeft - 1), 500);
      }
    }).catch(err => {
      console.warn("MathJax typeset failed, retrying...", err);
      if (retriesLeft > 0) {
        setTimeout(() => attempt(retriesLeft - 1), 500);
      }
    });
  }

  attempt(6); // retry for up to ~3s on slow/flaky connections
}

function mmhGetLangText(obj, currentLang) {
    if (!obj) return "";
    
    // Helper to decode HTML entities like &lt; and &amp;
    const decodeHTML = (html) => {
        const txt = document.createElement("textarea");
        txt.innerHTML = html;
        return txt.value;
    };

    let rawText = "";
    if (typeof obj === "string") {
        rawText = obj;
    } else if (currentLang === "bilingual") {
        const enText = obj.en || "";
        const hiText = obj.hi || "";
        // Do not print an English option twice when the bilingual payload has
        // identical strings in both language fields.
        const identical = String(enText).trim() !== "" && String(enText).trim() === String(hiText).trim();
        rawText = identical ? enText : enText + (enText && hiText ? "<hr style='border:none; border-top:1px dashed #ccc; margin:10px 0;'>" : "") + hiText;
    } else {
        rawText = obj[currentLang] || obj["en"] || "";
    }

    // Decode the entities so encoded tags become text strings
    let decodedText = decodeHTML(rawText);

    // 🔥 FIX: Convert literal "<br>" and "<br/>" strings into working HTML element breaks
    decodedText = decodedText.replace(/&lt;br\s*\/?&gt;/gi, '<br>')
                             .replace(/<br\s*\/?>/gi, '<br>');

    // 🔧 FIX: Pull \text{...} content OUT of MathJax's math delimiters
    // (e.g. \(18 \text{ of } 2\) -> \(18\) of \(2\)). MathJax's automatic
    // line-break measures \text{} width itself, and that measurement is
    // unreliable for Devanagari (matras/conjuncts render at widths its
    // simple text-metrics model doesn't predict correctly), causing the
    // "का" overlap. As plain HTML text between two smaller math segments,
    // the word wraps using the browser's own native text flow instead —
    // which handles any script correctly — while the surrounding digits/
    // operators stay exactly as MathJax-rendered math, unchanged.
  decodedText = (function(str){
        const matchBrace = (s,p)=>{ if(s[p]!=='{') return -1; let d=1,k=p+1; while(k<s.length&&d>0){ if(s[k]==='{')d++; else if(s[k]==='}')d--; k++; } return d===0?k:-1; };
        let out='', i=0;
        while(i<str.length){
            if(str.startsWith('\\frac',i)){
                const a1=matchBrace(str,i+5);
                if(a1!==-1){ const a2=matchBrace(str,a1); if(a2!==-1){ out+=str.slice(i,a2); i=a2; continue; } }
            }
            if(str.startsWith('\\binom',i)){
                const a1=matchBrace(str,i+6);
                if(a1!==-1){ const a2=matchBrace(str,a1); if(a2!==-1){ out+=str.slice(i,a2); i=a2; continue; } }
            }
            if(str.startsWith('\\sqrt',i)){
                let j=i+5;
                if(str[j]==='['){ const close=str.indexOf(']',j); if(close!==-1) j=close+1; }
                const a1=matchBrace(str,j);
                if(a1!==-1){ out+=str.slice(i,a1); i=a1; continue; }
            }
            if(str.startsWith('\\overline',i)){
                const a1=matchBrace(str,i+9);
                if(a1!==-1){ out+=str.slice(i,a1); i=a1; continue; }
            }
            if(str.startsWith('\\bar',i)){
                const a1=matchBrace(str,i+4);
                if(a1!==-1){ out+=str.slice(i,a1); i=a1; continue; }
            }
            if(str.startsWith('\\left',i)){
                let depth=1, k=i+5;
                while(depth>0){
                    const nl=str.indexOf('\\left',k);
                    const nr=str.indexOf('\\right',k);
                    if(nr===-1) break;
                    if(nl!==-1 && nl<nr){ depth++; k=nl+5; }
                    else { depth--; k=nr+6; }
                }
                if(depth===0){
                    if(str[k]==='\\'){ k+=2; }
                    else if(k<str.length){ k+=1; }
                    out+=str.slice(i,k); i=k; continue;
                }
            }
            if(str.startsWith('\\text',i)){
                const b=matchBrace(str,i+5);
                if(b!==-1){
                    const inner = str.slice(i+6,b-1);
                    const trimmed = inner.trim();
                    if(trimmed.toLowerCase()==='of' || trimmed==='का'){
                        out += '\\) ' + inner + ' \\('; i=b; continue;
                    }
                }
            }
            out+=str[i]; i++;
        }
        return out;
    })(decodedText);
    

    return decodedText;
};

/* ── the card ─────────────────────────────────────────────────────────────
   Builds one question card with exactly the structure renderQuestion() fills
   in test.html (.qtext > #examTag + #qtext + #questionImage, then .options,
   then .explanation), so the lifted CSS applies unchanged.

   opts:
     lang          'en' | 'hi' | 'bilingual'
     quizId        the quiz this question came from (drives the image path)
     index         1-based number shown in the card head
     total         total in the current list
     mode          'browse' (no answers shown) | 'solution'
     selected      the option the user picked, as "1".."5"
     showPercent   show per-option pick-percentage pills (solution mode)
     onPick        fn(optionIndex) — omit to make options non-interactive
     headExtra     HTML injected into the card head (three-dot menu etc.)
*/
function mmhRenderCard(q, opts) {
  opts = opts || {};
  const lang = opts.lang || "en";
  const mode = opts.mode || "browse";
  const inSolution = mode === "solution";

  const card = document.createElement("div");
  card.className = "quiz-card mmh-card";
  card.setAttribute("data-qid", String(q.id));

  // head: the visible meta row is assembled by the saved-page decorator as
  // Question/QS number, Delete, Move to and three-dot. Quiz/question IDs and
  // scoring metadata remain internal to the card data.
  const head = document.createElement("div");
  head.className = "mmh-card-head";
  head.innerHTML =
    '<div class="mmh-card-num">' + (opts.index != null ? opts.index : "") + '</div>' +
    '<div class="mmh-card-marking">Marking: <span class="mk-pos">+' +
      Number(q.correct_score != null ? q.correct_score : 1) + '</span> / <span class="mk-neg">-' +
      Number(q.negative_score != null ? q.negative_score : 0.5) + '</span></div>' +
    '<div class="mmh-card-head-extra">' + (opts.headExtra || "") + '</div>';
  card.appendChild(head);

  // comprehension passage, when the question carries one
  const comp = q.comprehension || q.comprehension_data || "";
  const compText = comp ? mmhGetLangText(comp, lang) : "";
  if (compText && compText.trim()) {
    const box = document.createElement("div");
    box.className = "comprehension-box";
    box.innerHTML = applyBoldHighlight(compText);
    card.appendChild(box);
    card.classList.add("has-comprehension");
    hideBrokenInlineImages(box);
  }

  // question text — exam tag pulled out first, trailing <br> stripped, exactly
  // as renderQuestion() does it
  const qwrap = document.createElement("div");
  qwrap.className = "qtext";
  const tagEl = document.createElement("div");
  tagEl.className = "exam-tag";
  const textEl = document.createElement("div");
  textEl.className = "qtext-inner";
  const imgBox = document.createElement("div");
  imgBox.className = "question-image";
  imgBox.style.margin = "12px 0";
  qwrap.appendChild(tagEl); qwrap.appendChild(textEl); qwrap.appendChild(imgBox);
  card.appendChild(qwrap);

  const parsed = mmhQuestionDisplay(q.question, lang, opts.quizId);
  textEl.innerHTML = applyBoldHighlight(parsed.text.replace(/(\s*<br\s*\/?\>\s*)+$/gi, ""), true);
  tagEl.textContent = parsed.tag ? formatExamTag(parsed.tag) : "";
  normalizeMathForQuiz(textEl);
  hideBrokenInlineImages(textEl);

  // images — the same GitHub path + slot numbering as test.html
  const gh = mmhGithubPathFor(opts.quizId);
  const seg = gh.split("/");
  const base = seg.length >= 2 ? (seg[0] + "/" + seg[1]) : gh;
  const cleanIdx = parseInt(String(q.id).slice(1), 10);
  const qImgStyle = "max-width:90%; max-height:250px; width:auto; height:auto; display:block; margin:10px auto; border-radius:6px; object-fit:contain;";
  if (gh && base && !isNaN(cleanIdx)) {
    const dynQ = "https://raw.githubusercontent.com/mockmatrixhub/mmhimg/main/" + base + "/" +
                 opts.quizId + "/q-" + cleanIdx + "-image1.jpg";
    if (q.question_image && String(q.question_image).trim() !== "") {
      imgBox.innerHTML = '<img src="' + q.question_image + '" style="' + qImgStyle +
        '" onerror="this.parentElement.innerHTML=\'<div class=&quot;img-fail&quot;><i class=&quot;fa-solid fa-triangle-exclamation&quot;></i> Image failed to load</div>\'">';
    } else {
      imgBox.innerHTML = '<img src="' + dynQ + '" style="' + qImgStyle + ' display:none;" onload="mmhDynImgOk(this,\'' +
        mmhImgSlotArg(q.id) + '\',\'q\')" onerror="mmhDynImgFail(this,\'' + mmhImgSlotArg(q.id) + '\',\'q\')">';
    }
  }

  // options
  const optsBox = document.createElement("div");
  optsBox.className = "options";
  card.appendChild(optsBox);
  const optStyle = "max-width:180px; max-height:100px; width:auto; height:auto; border-radius:4px; object-fit:contain; vertical-align:middle;";
  ["option_1","option_2","option_3","option_4","option_5"].forEach(function (key, idx) {
    if (!q[key]) return;
    const n = idx + 1;
    const isSel = String(opts.selected || "") === String(n);
    const isCor = String(q.answer) === String(n);
    const div = document.createElement("div");
    div.className = "opt";
    div.setAttribute("data-opt", String(n));
    if (inSolution) {
      if (isCor) div.classList.add("correct");
      if (isSel && !isCor) div.classList.add("wrong");
    } else if (isSel) {
      div.classList.add("selected");
    }
    if (!opts.onPick) div.style.cursor = "default";

    let optImg = "";
    if (gh && base && !isNaN(cleanIdx)) {
      const dynO = "https://raw.githubusercontent.com/mockmatrixhub/mmhimg/main/" + base + "/" +
                   opts.quizId + "/q-" + cleanIdx + "-image" + (n + 1) + ".jpg";
      const okey = "option_image_" + n;
      if (q[okey] && String(q[okey]).trim() !== "") {
        optImg = '<img src="' + q[okey] + '" style="' + optStyle + ' margin-top:8px; display:block;" onerror="this.style.display=\'none\'">';
      } else {
        optImg = '<img src="' + dynO + '" style="' + optStyle + ' margin-top:8px; display:none;" onload="mmhDynImgOk(this,\'' +
                 mmhImgSlotArg(q.id) + '\',\'o' + n + '\')" onerror="mmhDynImgFail(this,\'' + mmhImgSlotArg(q.id) + '\',\'o' + n + '\')">';
      }
    }

    div.innerHTML =
      '<div class="custom-radio"></div>' +
      '<div style="flex:1"><div class="opt-text">' + applyBoldHighlight(mmhGetLangText(q[key], lang)) + '</div>' + optImg + '</div>' +
      '<div class="opt-pct-col"></div>';
    hideBrokenInlineImages(div);

    if (inSolution && opts.showPercent) {
      const pct = getOptionPercent(q, n);
      if (pct != null) {
        const p = document.createElement("span");
        p.className = "opt-percent" + (isCor ? " opt-percent-correct" : (isSel ? " opt-percent-wrong" : ""));
        p.textContent = pct + "%";
        div.querySelector(".opt-pct-col").appendChild(p);
      }
    }
    if (opts.onPick) div.addEventListener("click", function () { opts.onPick(n, div); });
    optsBox.appendChild(div);
  });

  // ── solution ─────────────────────────────────────────────────────────────
  // Faithful to test.html's buildExplanationHTML(): the status line, the ruled
  // Explanation heading with the lightbulb, solution_text through the same
  // language + bold pipeline, then the solution image — the manual one from the
  // payload when it has one, otherwise the dynamic q-<n>-image6.jpg slot.
  const expBox = document.createElement("div");
  expBox.className = "explanation";
  expBox.style.display = "none";
  card.appendChild(expBox);

  function buildExplanation() {
    let statusHtml = "";
    if (opts.answers) {                       // only when there IS an attempt
      const userAns = opts.answers[q.id];
      const isCorrect = userAns && String(userAns) === String(q.answer);
      const statusText = !userAns
        ? '<span style="color:#9e9e9e">Skipped (0)</span>'
        : isCorrect
          ? '<span style="color:var(--success)">Correct (+' + (q.correct_score != null ? q.correct_score : 3) + ')</span>'
          : '<span style="color:var(--danger)">Wrong (-' + (q.negative_score != null ? q.negative_score : 1) + ')</span>';
      statusHtml = '<div style="margin-bottom:8px; font-weight:700;">Status: ' + statusText + '</div>';
    }

    let solImgHtml = "";
    const dynSol = (gh && base && !isNaN(cleanIdx))
      ? "https://raw.githubusercontent.com/mockmatrixhub/mmhimg/main/" + base + "/" +
        opts.quizId + "/q-" + cleanIdx + "-image6.jpg"
      : "";
    if (q.solution_image && String(q.solution_image).trim() !== "") {
      solImgHtml = '<div class="sol-img-container"><img src="' + q.solution_image +
        '" class="sol-img-styled" onerror="this.parentElement.innerHTML=' + "'<div class=&quot;img-fail&quot;><i class=&quot;fa-solid fa-triangle-exclamation&quot;></i> Image failed to load</div>'" + '"></div>';
    } else if (dynSol) {
      solImgHtml = '<div class="sol-img-container"><img src="' + dynSol +
        '" class="sol-img-styled" style="display:none;" onload="mmhDynImgOk(this,' + "'" + mmhImgSlotArg(q.id) + "'" +
        ',' + "'" + 's' + "'" + ')" onerror="mmhDynImgFail(this,' + "'" + mmhImgSlotArg(q.id) + "'" + ',' + "'" + 's' + "'" + ')"></div>';
    }

    const solText = q.solution_text ? applyBoldHighlight(mmhGetLangText(q.solution_text, lang)) : "";
    expBox.innerHTML = statusHtml +
      (solText ? '<hr style="border:0; border-top:1px solid #ddd; margin:8px 0;">' +
                 '<strong><i class="fa-solid fa-lightbulb"></i> Explanation:</strong><br><div>' + solText + '</div>' : "") +
      solImgHtml;
    normalizeMathForQuiz(expBox);
    hideBrokenInlineImages(expBox);
  }

  // A saved-questions page is a revision page, so the solution is always one tap
  // away. It stays collapsed until asked for and is built lazily, so a folder
  // holding 300 questions does not typeset 300 solutions nobody opened.
  let solBuilt = false;
  function setSolutionOpen(open) {
    if (open && !solBuilt) { buildExplanation(); solBuilt = true; }
    expBox.style.display = open ? "block" : "none";
    card.classList.toggle("sol-open", !!open);
    const b = card.querySelector(".mmh-sol-btn");
    if (b) {
      b.setAttribute("aria-expanded", open ? "true" : "false");
      b.innerHTML = '<i class="fa-solid ' + (open ? "fa-eye-slash" : "fa-lightbulb") + '"></i>' +
                    '<span>' + (open ? "Hide" : "Solution") + '</span>';
    }
    if (open) renderMath();
  }
  card.mmhSetSolutionOpen = setSolutionOpen;

  const solutionOpenByDefault = opts.solutionOpen === true ||
    (mode === "browse" && opts.defaultSolution === true);
  if (opts.allowSolution !== false && (!solutionOpenByDefault || opts.alwaysSolutionButton === true)) {
    const sb = document.createElement("button");
    sb.type = "button";
    sb.className = "mmh-sol-btn";
    sb.setAttribute("aria-expanded", "false");
    sb.innerHTML = '<i class="fa-solid fa-lightbulb"></i><span>Solution</span>';
    sb.onclick = function (ev) {
      ev.stopPropagation();
      setSolutionOpen(expBox.style.display !== "block");
    };
    // Keep the meta row limited to the four requested controls. Solution is
    // still available one tap below the question, preserving the shared card
    // behavior without crowding the phone header.
    card.insertBefore(sb, expBox);
  }
  if (inSolution || solutionOpenByDefault) setSolutionOpen(true);

  return card;
}

global.FB_BAD_KEY_CHARS = FB_BAD_KEY_CHARS;
global.fbKey = fbKey;
global.hasKeyword = hasKeyword;
global.mmhGithubPathFor = mmhGithubPathFor;
global.applyBoldHighlight = applyBoldHighlight;
global.hideBrokenInlineImages = hideBrokenInlineImages;
global.extractExamTag = extractExamTag;
global.formatExamTag = formatExamTag;
global.deriveExamTagFromQuizId = deriveExamTagFromQuizId;
global.mmhQuestionDisplay = mmhQuestionDisplay;
global.mmhDynImgOk = mmhDynImgOk;
global.mmhDynImgFail = mmhDynImgFail;
global.mmhImgSlotArg = mmhImgSlotArg;
global.resolveSavedImages = resolveSavedImages;
global.getOptionPercent = getOptionPercent;
global.normalizeMathForQuiz = normalizeMathForQuiz;
global.renderMath = renderMath;
global.mmhGetLangText = mmhGetLangText;
global.mmhRenderCard = mmhRenderCard;
})(typeof window !== "undefined" ? window : globalThis);

// ══════════════════════════════════════════════════════════════════════════
//  Mock Matrix Hub — Saved Questions  (Stage 1: shell, folders, cards)
//
//  DATA CONTRACT — the three nodes written by test.html's save modal:
//
//    userSaved/{u}/{subject}/{topic}/{quizId}/{qid} = true
//        the per-user library TREE. Holds no question content. ONE read of
//        userSaved/{u} yields every subject, topic, quizId and qid the user
//        has — which is all the folder screens need, including their counts.
//
//    allQuestions/{quizId}/{qid} = {full question JSON, quiz_id, subject, topic}
//        the shared bank. Read ONLY when the user actually opens a topic, and
//        only for the qids inside it. Never written to from this page.
//
//    userSavedByQuiz/{u}/{quizId}/{qid} = {s, t, at}
//        flat index used by the test page's palette. Stage 2 (delete/move)
//        keeps it in step. Never read on first load — the tree is enough.
//
//  The legacy saved_questions/{u} node is deliberately NOT read and NOT
//  written: questions saved before that structure changed simply do not
//  appear here.
//
//  Everything about a subject or topic name is taken from what Firebase
//  actually returns. Nothing is normalised into a fixed taxonomy, so a custom
//  subject a user typed shows up exactly as they typed it.
// ══════════════════════════════════════════════════════════════════════════

// ── Firebase ────────────────────────────────────────────────────────────────
if (!firebase.apps.length) { firebase.initializeApp(FIREBASE_PROJECTS.common); }
const savedDb = firebase.database();

// ── Sentinels for the two "everything" folders ──────────────────────────────
// fbKey() (test.html's path sanitizer) strips only . # $ [ ] / and caps at 60
// chars, so underscores survive — these match the __CUSTOM__ sentinel already
// used by the save modal. A real folder with one of these exact names is
// filtered out of the grid by isSentinel() so it can never be ambiguous.
const ALL_SUBJECTS = "__ALL_SUBJECTS__";
const ALL_TOPICS   = "__ALL_TOPICS__";
function isSentinel(name) { return name === ALL_SUBJECTS || name === ALL_TOPICS; }

// ── The colourful subject palette, same defs as the save modal ──────────────
// A subject that is not in this list (anything custom the user typed) gets the
// neutral folder icon instead — there is no fallback that pretends to know it.
const SUBJECT_LOOK = {
  "MATHS":     { icon: "fa-square-root-variable", color: "#2563eb" },
  "MATH":      { icon: "fa-square-root-variable", color: "#2563eb" },
  "REASONING": { icon: "fa-brain",                color: "#7c3aed" },
  "GK":        { icon: "fa-earth-asia",           color: "#d97706" },
  "GS":        { icon: "fa-earth-asia",           color: "#d97706" },
  "ENGLISH":   { icon: "fa-language",             color: "#059669" },
  "HINDI":     { icon: "fa-om",                   color: "#dc2626" },
  "COMPUTER":  { icon: "fa-laptop-code",          color: "#0891b2" }
};
const FALLBACK_LOOK   = { icon: "fa-folder",       color: "#64748b" };
const TOPIC_LOOK      = { icon: "fa-folder-open",  color: "#0b5ed7" };
const ALLSUB_LOOK     = { icon: "fa-layer-group",  color: "#198754" };
const ALLTOPIC_LOOK   = { icon: "fa-folder-tree",  color: "#198754" };
function lookForSubject(name) { return SUBJECT_LOOK[String(name).toUpperCase()] || FALLBACK_LOOK; }

// ── State ───────────────────────────────────────────────────────────────────
let USER_EMAIL_KEY = "";     // raw username from the profile
let USER_KEY       = "";     // fbKey()'d — what actually appears in paths
let TREE           = null;   // parsed library: { subjects:[...] }
let QCACHE         = {};     // "quizPathKey|qid" -> question object
let currentLang    = "en";
let viewMode       = "list"; // 'list' | 'focus'
let focusIdx       = 0;
let VIEW_QUESTIONS = [];     // [{quizKey, qid, q}] for the open topic
let navPushes      = 0;      // how many states THIS page pushed (back logic)
let loadingToken   = 0;      // cancels a superseded question load
let REATTEMPT_MODE = false;

try { currentLang = localStorage.getItem("quiz_lang") || "en"; } catch (e) {}
try { REATTEMPT_MODE = localStorage.getItem("mmh_saved_reattempt") === "1"; } catch (e) {}

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// fbKey() is lifted verbatim into q-render.js — the SAME sanitizer test.html
// uses to build its save paths, so this page reads exactly what was written.
function fbKeyLocal(raw) {
  if (typeof fbKey === "function") return fbKey(raw);
  let s = String(raw == null ? "" : raw).trim().replace(/\s+/g, " ");
  for (const ch of ".#$[]/") s = s.split(ch).join("-");
  return s.slice(0, 60);
}

// ══════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════
async function bootSaved() {
  // Wait for auth.js to hand over the profile, exactly as before.
  if (typeof getLocalProfile !== "function") { setTimeout(bootSaved, 100); return; }
  const profile = getLocalProfile();
  if (!profile || (profile.username === "User" && !profile.id)) {
    window.location.replace("/login.html");
    return;
  }
  USER_EMAIL_KEY = profile.username;
  USER_KEY = fbKeyLocal(USER_EMAIL_KEY);

  const langSel = $("globalLangSelect");
  if (langSel) langSel.value = currentLang;
  const palUser = $("palUsername");
  if (palUser) palUser.textContent = USER_EMAIL_KEY;

  // Deep links (?sub=&topic=) are honoured on first paint, so a shared or
  // refreshed URL lands exactly where it says. Routing only happens once the
  // tree actually arrived — renderRoute() clears the fatal panel, so routing
  // after a failure would wipe the retry screen the user needs.
  const okTree = await loadTree();
  if (okTree) routeFromUrl({ initial: true });
}

// One read. The whole folder structure — subjects, topics, quiz ids, question
// ids and therefore every count — comes from this single call.
async function loadTree() {
  showLoader("Loading your library…");
  try {
    const snap = await savedDb.ref("userSaved/" + USER_KEY).once("value");
    TREE = buildTree(snap.val() || {});
  } catch (err) {
    console.error("saved: tree load failed", err);
    TREE = { subjects: [] };
    showFatal("Could not reach your library. Check your connection and retry.",
              () => { loadTree().then(wasOk => { if (wasOk) routeFromUrl({ initial: true }); }); });
    return false;
  }
  return true;
}

// raw = { SUBJECT: { TOPIC: { QUIZID: { QID: true } } } }
// -> sorted, counted, ready to render. Alphabetical everywhere, as specified.
function buildTree(raw) {
  const subjects = [];
  for (const subKey in raw) {
    const topicsRaw = raw[subKey];
    if (!topicsRaw || typeof topicsRaw !== "object") continue;
    if (isSentinel(subKey)) continue;               // never collide with a pseudo-folder

    const topics = [];
    let subCount = 0;
    for (const topKey in topicsRaw) {
      const quizzesRaw = topicsRaw[topKey];
      if (!quizzesRaw || typeof quizzesRaw !== "object") continue;
      if (isSentinel(topKey)) continue;

      const quizMap = {};                            // quizPathKey -> [qid]
      let count = 0;
      for (const quizKey in quizzesRaw) {
        const qidsRaw = quizzesRaw[quizKey];
        const qids = [];
        if (qidsRaw && typeof qidsRaw === "object") {
          for (const qid in qidsRaw) qids.push(qid);
        } else if (qidsRaw === true || typeof qidsRaw === "string" || typeof qidsRaw === "number") {
          // Defensive: a leaf written straight under the topic (older shape).
          qids.push(String(quizKey));
        }
        if (!qids.length) continue;
        qids.sort(compareQuestionIds);
        quizMap[quizKey] = qids;
        count += qids.length;
      }
      if (!count) continue;
      topics.push({ name: topKey, quizMap, count });
      subCount += count;
    }
    if (!topics.length) continue;
    topics.sort((a, b) => a.name.localeCompare(b.name));
    subjects.push({ name: subKey, topics, topicCount: topics.length, count: subCount });
  }
  subjects.sort((a, b) => a.name.localeCompare(b.name));
  return { subjects };
}

// Q1, Q2, Q10 must sort as 1, 2, 10 — not alphabetically as 1, 10, 2.
function compareQuestionIds(a, b) {
  const na = parseInt(String(a).replace(/\D/g, ""), 10);
  const nb = parseInt(String(b).replace(/\D/g, ""), 10);
  if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
  return String(a).localeCompare(String(b));
}

// ══════════════════════════════════════════════════════════════════════════
//  ROUTING  —  the address bar is the source of truth
// ══════════════════════════════════════════════════════════════════════════
function parseRoute(search) {
  const p = new URLSearchParams(search == null ? window.location.search : search);
  const sub = p.get("sub") || "";
  const topic = p.get("topic") || "";
  const view = p.get("view") || "";
  if (sub === ALL_SUBJECTS) return { page: "questions", sub: ALL_SUBJECTS, topic: ALL_TOPICS, view };
  if (sub && topic)         return { page: "questions", sub, topic, view };
  if (sub)                  return { page: "topics", sub };
  return { page: "subjects" };
}

function buildSearch(r) {
  const p = new URLSearchParams();
  if (r.page === "topics")    p.set("sub", r.sub);
  if (r.page === "questions") { p.set("sub", r.sub); p.set("topic", r.topic); if (r.view) p.set("view", r.view); }
  const s = p.toString();
  return s ? "?" + s : window.location.pathname;
}

// Every navigation pushes a real history entry, so the device/browser back
// button walks subjects -> topics -> questions one step at a time on its own.
function navigateTo(r, opts) {
  opts = opts || {};
  const url = buildSearch(r);
  if (opts.replace) history.replaceState(r, "", url);
  else { history.pushState(r, "", url); navPushes++; }
  renderRoute(r);
}

function routeFromUrl(opts) {
  opts = opts || {};
  const r = parseRoute();
  if (!opts.initial) navPushes = Math.max(0, navPushes - 1);   // a pop, not a push
  renderRoute(r);
}

window.addEventListener("popstate", () => routeFromUrl({}));

// In-page back is structural, not browser-history based. It always follows
// the same hierarchy as the exam and SSC-sub engines:
// questions → topic → subjects → Home. A stale page the user visited before
// opening Saved Questions can never hijack this arrow.
function updateSavedModeDeck() {
  const deck = $("savedBottomNav");
  if (!deck) return;
  const r = parseRoute();
  const show = !!(TREE && TREE.subjects && TREE.subjects.length && r.page !== "questions" ||
                  TREE && TREE.subjects && TREE.subjects.length && r.page === "questions" && viewMode === "list");
  deck.hidden = !show;
  document.body.classList.toggle("saved-deck-visible", show);
  const normal = $("savedNormalNav"), test = $("savedTestNav");
  if (normal) normal.classList.toggle("is-active", r.page !== "questions" || viewMode === "list");
  if (test) test.classList.toggle("is-active", false);
}
function savedNormalMode() {
  const r = parseRoute();
  if (r.page === "questions" && viewMode !== "list") {
    viewMode = "list";
    navigateTo({ page: "questions", sub: r.sub, topic: r.topic, view: "list" }, { replace: true });
  }
  updateSavedModeDeck();
}
function savedTestMode() {
  if (typeof window.savedOpenAttemptModal === "function") window.savedOpenAttemptModal();
  else { const btn = $("attemptBtn"); if (btn) btn.click(); }
}

function savedBack() {
  const r = parseRoute();
  if (r.page === "questions") {
    // The all-library view has no real subject/topic parent. Go straight back
    // to Saved's subject screen instead of manufacturing a sentinel topic URL.
    navigateTo(r.sub === ALL_SUBJECTS
      ? { page: "subjects" }
      : { page: "topics", sub: r.sub }, { replace: true });
  } else if (r.page === "topics") {
    navigateTo({ page: "subjects" }, { replace: true });
  } else {
    window.location.href = "/index.html";
  }
}

function renderRoute(r) {
  hideFatal();
  updateSavedModeDeck();
  hideLoader();                 // loadTree() raises the loader; every screen must lower it
  const inner = $("screenInner");
  if (!inner) return;
  $("screenScroll").scrollTop = 0;

  // Folder screens own no questions, so the palette (and its FAB) must go —
  // otherwise navigating BACK out of a topic left it floating over the folders.
  if (r.page !== "questions") { setPaletteVisible(false); VIEW_QUESTIONS = []; SEEN = {}; }

  if (r.page === "subjects") { renderSubjects(inner); return; }
  if (r.page === "topics") {
    const sub = findSubject(r.sub);
    if (!sub) { renderSubjects(inner); return; }        // stale link: fall back
    renderTopics(inner, sub); return;
  }
  renderQuestionsRoute(r);
}

function findSubject(name) {
  return TREE ? TREE.subjects.find(s => s.name === name) : null;
}
function findTopic(sub, name) {
  return sub ? sub.topics.find(t => t.name === name) : null;
}

// ══════════════════════════════════════════════════════════════════════════
//  BREADCRUMB  (in the fixed header, so it never scrolls away)
// ══════════════════════════════════════════════════════════════════════════
function renderCrumb(r) {
  const bar = $("crumbBar");
  if (!bar) return;
  const parts = [];
  // Every segment is an actual route control, including the current segment.
  // This keeps the progress row useful on touch devices instead of leaving a
  // visually identical but inert final label.
  parts.push({ label: "Saved", go: { page: "subjects" } });
  if (r.page !== "subjects") {
    parts.push({
      label: r.sub === ALL_SUBJECTS ? "All Subjects" : r.sub,
      go: r.sub === ALL_SUBJECTS
        ? { page: "subjects" }
        : { page: "topics", sub: r.sub }
    });
  }
  if (r.page === "questions") {
    parts.push({
      label: r.topic === ALL_TOPICS ? "All Topics" : r.topic,
      go: { page: "questions", sub: r.sub, topic: r.topic, view: viewMode }
    });
  }
  bar.innerHTML = parts.map((p, i) => {
    const sep = i ? '<i class="fa-solid fa-angle-right crumb-sep"></i>' : "";
    const label = '<span class="crumb-label">' + esc(p.label) + '</span>';
    return sep + '<button type="button" class="crumb-btn" data-i="' + i + '">' + label + "</button>";
  }).join("");
  bar.querySelectorAll(".crumb-btn").forEach(b => {
    b.onclick = () => { const p = parts[Number(b.dataset.i)]; if (p && p.go) navigateTo(p.go); };
  });
  const title = $("headerTitle");
  if (title) {
    title.textContent = r.page === "subjects" ? "Saved Questions"
      : r.page === "topics" ? (r.sub === ALL_SUBJECTS ? "All Subjects" : r.sub)
      : (r.topic === ALL_TOPICS ? "All Topics" : r.topic);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  FOLDER SCREENS
// ══════════════════════════════════════════════════════════════════════════
function folderCard(o) {
  // One folder tile: icon, name, and the counts that describe what is inside.
  const b = document.createElement("button");
  b.type = "button";
  b.className = "folder-card" + (o.wide ? " folder-wide" : "");
  b.innerHTML =
    '<span class="folder-ico" style="background:' + o.color + '22;color:' + o.color + '">' +
      '<i class="fa-solid ' + o.icon + '"></i></span>' +
    '<span class="folder-body">' +
      '<span class="folder-name">' + esc(o.name) + '</span>' +
      '<span class="folder-meta">' + o.meta.map(m =>
        '<span class="folder-stat"><i class="fa-solid ' + m.icon + '"></i>' + esc(m.text) + '</span>'
      ).join("") + '</span>' +
    '</span>' +
    '<i class="fa-solid fa-chevron-right folder-go"></i>';
  b.onclick = o.onclick;
  return b;
}

function plural(n, one, many) { return n + " " + (n === 1 ? one : (many || one + "s")); }

function renderSubjects(host) {
  renderCrumb({ page: "subjects" });
  host.innerHTML = "";
  const subs = TREE ? TREE.subjects : [];

  host.appendChild(sectionHeading("Your Subjects",
    subs.length ? plural(subs.length, "subject") + " · " +
      plural(subs.reduce((a, s) => a + s.count, 0), "question") : ""));

  const grid = document.createElement("div");
  grid.className = "folder-grid";

  // "All subjects together" — opens every saved question in one list.
  const total = subs.reduce((a, s) => a + s.count, 0);
  if (total) {
    grid.appendChild(folderCard({
      wide: true, name: "All Subjects", icon: ALLSUB_LOOK.icon, color: ALLSUB_LOOK.color,
      meta: [{ icon: "fa-layer-group", text: plural(subs.length, "subject") },
             { icon: "fa-circle-question", text: plural(total, "question") }],
      onclick: () => openQuestions({ page: "questions", sub: ALL_SUBJECTS, topic: ALL_TOPICS })
    }));
  }

  subs.forEach(s => {
    grid.appendChild(folderCard({
      name: s.name, icon: lookForSubject(s.name).icon, color: lookForSubject(s.name).color,
      meta: [{ icon: "fa-folder-open", text: plural(s.topicCount, "topic") },
             { icon: "fa-circle-question", text: plural(s.count, "question") }],
      onclick: () => navigateTo({ page: "topics", sub: s.name })
    }));
  });
  host.appendChild(grid);

  if (!subs.length) host.appendChild(emptyState(
    "fa-bookmark", "Your library is empty",
    "Save a question from any test and it will appear here, filed under the subject and topic you chose."));
  window.__savedDecorate();
}

function renderTopics(host, sub) {
  renderCrumb({ page: "topics", sub: sub.name });
  host.innerHTML = "";

  host.appendChild(sectionHeading(sub.name,
    plural(sub.topicCount, "topic") + " · " + plural(sub.count, "question")));

  const grid = document.createElement("div");
  grid.className = "folder-grid";

  grid.appendChild(folderCard({
    wide: true, name: "All Topics", icon: ALLTOPIC_LOOK.icon, color: ALLTOPIC_LOOK.color,
    meta: [{ icon: "fa-folder-tree", text: plural(sub.topicCount, "topic") },
           { icon: "fa-circle-question", text: plural(sub.count, "question") }],
    onclick: () => openQuestions({ page: "questions", sub: sub.name, topic: ALL_TOPICS })
  }));

  sub.topics.forEach(t => {
    grid.appendChild(folderCard({
      name: t.name, icon: TOPIC_LOOK.icon, color: TOPIC_LOOK.color,
      meta: [{ icon: "fa-circle-question", text: plural(t.count, "question") },
             { icon: "fa-file-lines", text: plural(Object.keys(t.quizMap).length, "paper") }],
      onclick: () => openQuestions({ page: "questions", sub: sub.name, topic: t.name })
    }));
  });
  host.appendChild(grid);
  window.__savedDecorate();
}

function sectionHeading(title, sub) {
  const d = document.createElement("div");
  d.className = "sec-head";
  d.innerHTML = '<h2 class="sec-title">' + esc(title) + '</h2>' +
                (sub ? '<span class="sec-sub">' + esc(sub) + '</span>' : '');
  return d;
}

function emptyState(icon, title, body) {
  const d = document.createElement("div");
  d.className = "empty-state";
  d.innerHTML = '<i class="fa-solid ' + icon + ' empty-ico"></i>' +
                '<h3>' + esc(title) + '</h3><p>' + esc(body) + '</p>';
  return d;
}

// ══════════════════════════════════════════════════════════════════════════
//  OPENING A FOLDER OF QUESTIONS
// ══════════════════════════════════════════════════════════════════════════
// The view-mode choice is asked EVERY time a folder of questions is opened,
// and there is deliberately no in-page toggle afterwards — the choice is made
// once, at the door, and the page commits to it.
function openQuestions(r) {
  const pairs = collectPairs(r);
  if (!pairs.length) {
    showToast("Nothing to open — that folder is empty.");
    return;
  }
  askViewMode(function (mode) {
    viewMode = mode;
    r.view = mode;
    navigateTo(r);                    // pushes history, then renders
  }, pairs.length);
}

function collectPairs(r) {
  // Gather the (quizKey, qid) pairs a route needs — straight from the tree
  // already in memory. No Firebase read happens here.
  const out = [];
  // Carry the real subject/topic with every pair. Aggregate routes use sentinel
  // names in the URL, but delete/move must later address the actual deep path.
  const push = (s, t) => {
    for (const quizKey in t.quizMap) {
      t.quizMap[quizKey].forEach(qid => out.push({ sub: s.name, topic: t.name, quizKey, qid }));
    }
  };
  if (r.sub === ALL_SUBJECTS) {
    (TREE ? TREE.subjects : []).forEach(s => s.topics.forEach(t => push(s, t)));
  } else {
    const s = findSubject(r.sub);
    if (!s) return out;
    if (r.topic === ALL_TOPICS) s.topics.forEach(t => push(s, t));
    else { const t = findTopic(s, r.topic); if (t) push(s, t); }
  }
  return out;
}

async function renderQuestionsRoute(r) {
  const host = $("screenInner");
  renderCrumb(r);

  const pairs = collectPairs(r);
  // An explicit ?view= is a decision already made (a shared link, a refresh, a
  // back-navigation) and is honoured without asking again. A URL that names a
  // folder but no view has no decision in it, so ask — exactly as a click does.
  if (!r.view) {
    if (!pairs.length) { host.innerHTML = ""; renderEmptyQuestions(host); setPaletteVisible(false); return; }
    askViewMode(function (mode) {
      navigateTo({ page: "questions", sub: r.sub, topic: r.topic, view: mode }, { replace: true });
    }, pairs.length, function () {
      // Cancelled with nowhere chosen: fall back to the parent folder rather
      // than leaving a blank screen behind.
      navigateTo(r.sub === ALL_SUBJECTS ? { page: "subjects" } : { page: "topics", sub: r.sub },
                 { replace: true });
    });
    host.innerHTML = "";
    return;
  }
  viewMode = (r.view === "focus") ? "focus" : "list";
  host.innerHTML = "";

  if (!pairs.length) { renderEmptyQuestions(host); setPaletteVisible(false); return; }

  const token = ++loadingToken;
  // When every question is already in memory — revisiting a folder, or
  // re-painting after a move / merge / delete — there is nothing to wait for,
  // so the loader is skipped and the change lands instantly instead of
  // flashing a spinner over a screen that is already correct.
  if (pairs.some(p => !QCACHE[p.quizKey + "|" + p.qid])) showLoader("Loading questions…", 0, pairs.length);
  let loaded;
  try {
    loaded = await loadQuestions(pairs, function (done, total) {
      if (token === loadingToken) showLoader("Loading questions…", done, total);
    });
  } catch (err) {
    console.error("saved: question load failed", err);
    if (token !== loadingToken) return;
    showFatal("Some questions could not be loaded. Check your connection and retry.",
              () => renderQuestionsRoute(r));
    return;
  }
  if (token !== loadingToken) return;          // the user navigated away mid-load
  hideLoader();

  VIEW_QUESTIONS = loaded;
  focusIdx = 0;
  paintQuestions(host, r);
}

function renderEmptyQuestions(host) {
  host.innerHTML = "";
  host.appendChild(emptyState("fa-folder-open", "This folder is empty", "Nothing is saved here yet."));
  window.__savedDecorate();
}

// ── reading the question bank ───────────────────────────────────────────────
// Reads are grouped per quiz: when four or more questions are needed from the
// same quiz it is cheaper to take the whole quiz node in one read than to make
// four separate ones. Below that, individual reads avoid dragging down
// questions the user never asked for. Concurrency is capped so a 300-question
// "All Subjects" folder does not fire 300 sockets at once.
const QUIZ_WHOLE_THRESHOLD = 4;
const MAX_PARALLEL = 8;

async function loadQuestions(pairs, onProgress) {
  const need = [];
  pairs.forEach(p => {
    const k = p.quizKey + "|" + p.qid;
    if (QCACHE[k]) return;
    need.push(p);
  });

  const byQuiz = {};
  need.forEach(p => { (byQuiz[p.quizKey] = byQuiz[p.quizKey] || []).push(p.qid); });

  const jobs = [];
  for (const quizKey in byQuiz) {
    const qids = byQuiz[quizKey];
    if (qids.length >= QUIZ_WHOLE_THRESHOLD) {
      jobs.push({ kind: "quiz", quizKey, qids });
    } else {
      qids.forEach(qid => jobs.push({ kind: "one", quizKey, qid }));
    }
  }

  let done = 0;
  const total = pairs.length;
  const tick = n => { done += n; if (onProgress) onProgress(Math.min(done, total), total); };
  // Already-cached questions count towards progress immediately.
  tick(pairs.length - need.length);

  let cursor = 0;
  async function worker() {
    while (cursor < jobs.length) {
      const job = jobs[cursor++];
      try {
        if (job.kind === "quiz") {
          const snap = await savedDb.ref("allQuestions/" + job.quizKey).once("value");
          const all = snap.val() || {};
          let hit = 0;
          job.qids.forEach(qid => {
            const q = all[qid];
            if (q && typeof q === "object") { QCACHE[job.quizKey + "|" + qid] = q; hit++; }
          });
          tick(hit);
        } else {
          const snap = await savedDb.ref("allQuestions/" + job.quizKey + "/" + job.qid).once("value");
          const q = snap.val();
          if (q && typeof q === "object") { QCACHE[job.quizKey + "|" + job.qid] = q; tick(1); }
        }
      } catch (err) {
        console.warn("saved: read failed", job, err);   // keep going; gaps are reported below
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(MAX_PARALLEL, jobs.length || 1) }, worker));

  // Preserve the tree order (alphabetical subject/topic, numeric question id)
  const out = [];
  const missing = [];
  pairs.forEach(p => {
    const q = QCACHE[p.quizKey + "|" + p.qid];
    if (q) out.push({ sub: p.sub, topic: p.topic, quizKey: p.quizKey, qid: p.qid, q });
    else missing.push(p);
  });
  if (missing.length) {
    console.warn("saved: %d question(s) have no content in allQuestions", missing.length);
    showToast(missing.length + " saved item" + (missing.length === 1 ? "" : "s") +
              " could not be opened (no stored content).");
  }
  return out;
}

// ══════════════════════════════════════════════════════════════════════════
//  PAINTING QUESTIONS
// ══════════════════════════════════════════════════════════════════════════
function paintQuestions(host, r) {
  host.innerHTML = "";
  document.body.classList.toggle("saved-focus", viewMode === "focus");
  document.body.classList.toggle("saved-list",  viewMode === "list");

  const wrap = document.createElement("div");
  wrap.className = "qview";
  const main = document.createElement("div");
  main.className = "qmain";
  wrap.appendChild(main);

  const palCol = document.createElement("div");
  palCol.className = "qpal-col";
  palCol.appendChild(buildPalettePanel());
  wrap.appendChild(palCol);
  host.appendChild(wrap);

  if (viewMode === "focus") paintFocus(main, r);
  else paintList(main, r);

  renderPalette();
  setPaletteVisible(true);
  renderMath();                                  // lifted from test.html
  window.__savedDecorate();
}

function cardOpts(item, index, total) {
  return {
    lang: currentLang,
    // The IMAGE path needs the RAW quiz id (?id= from the original test URL),
    // which travels inside the stored payload as quiz_id. The path key is only
    // sanitised for Firebase, so using it for images would 404 every picture.
    quizId: item.q.quiz_id || item.quizKey,
    index: index + 1,
    total: total,
    mode: "browse",
    // Use the same card controls as the main test page. List cards keep the
    // solution collapsed until requested; focus mode can open it by default,
    // while Reattempt deliberately starts it closed.
    allowSolution: true,
    alwaysSolutionButton: true,
    solutionOpen: viewMode === "focus" && !REATTEMPT_MODE,
    onPick: null
  };
}

function paintList(host, r) {
  host.appendChild(sectionHeading(
    r.topic === ALL_TOPICS ? (r.sub === ALL_SUBJECTS ? "All Subjects" : "All Topics") : r.topic,
    plural(VIEW_QUESTIONS.length, "question") + " · " + viewLabel()));

  const list = document.createElement("div");
  list.className = "q-list";
  list.id = "qList";
  VIEW_QUESTIONS.forEach((item, i) => {
    const cell = document.createElement("div");
    cell.className = "q-cell";
    cell.id = "qcell-" + i;
    cell.appendChild(mmhRenderCard(item.q, cardOpts(item, i, VIEW_QUESTIONS.length)));
    list.appendChild(cell);
  });
  host.appendChild(list);
}

function paintFocus(host, r) {
  host.appendChild(sectionHeading(
    r.topic === ALL_TOPICS ? (r.sub === ALL_SUBJECTS ? "All Subjects" : "All Topics") : r.topic,
    plural(VIEW_QUESTIONS.length, "question") + " · " + viewLabel()));

  const stage = document.createElement("div");
  stage.className = "q-focus-stage";
  stage.id = "qFocusStage";
  host.appendChild(stage);
  host.appendChild(buildFocusNav());
  paintFocusCard();
}

function paintFocusCard() {
  const stage = $("qFocusStage");
  if (!stage) return;
  const item = VIEW_QUESTIONS[focusIdx];
  stage.innerHTML = "";
  if (!item) { stage.appendChild(emptyState("fa-inbox", "Nothing here", "")); return; }
  stage.appendChild(mmhRenderCard(item.q, cardOpts(item, focusIdx, VIEW_QUESTIONS.length)));
  updateFocusNav();
  renderMath();
  const sc = $("screenScroll");
  if (sc) sc.scrollTop = 0;
}

function viewLabel() { return viewMode === "focus" ? "Focus view" : "List view"; }

function buildFocusNav() {
  const bar = document.createElement("div");
  bar.className = "focus-nav";
  bar.id = "focusNav";
  bar.innerHTML =
    '<label class="reattempt-toggle" title="Hide solutions while practising again"><input type="checkbox" id="reattemptToggle"> <span>Reattempt</span></label>' +
    '<button type="button" class="focus-nav-btn" id="focusPrev"><i class="fa-solid fa-arrow-left"></i><span>PREV</span></button>' +
    '<div class="focus-pos"><span id="focusPos">1 / 1</span></div>' +
    '<button type="button" class="focus-nav-btn" id="focusNext"><span>NEXT</span><i class="fa-solid fa-arrow-right"></i></button>';
  bar.querySelector("#focusPrev").onclick = () => navFocus(-1);
  bar.querySelector("#focusNext").onclick = () => navFocus(1);
  const toggle = bar.querySelector("#reattemptToggle");
  toggle.checked = REATTEMPT_MODE;
  toggle.onchange = () => {
    REATTEMPT_MODE = !!toggle.checked;
    try { localStorage.setItem("mmh_saved_reattempt", REATTEMPT_MODE ? "1" : "0"); } catch (e) {}
    paintFocusCard();
  };
  return bar;
}

function navFocus(d) {
  const n = VIEW_QUESTIONS.length;
  if (!n) return;
  const next = focusIdx + d;
  if (next < 0 || next >= n) return;
  focusIdx = next;
  paintFocusCard();
  renderPalette();
}

function updateFocusNav() {
  const pos = $("focusPos");
  if (pos) pos.textContent = (focusIdx + 1) + " / " + VIEW_QUESTIONS.length;
  const p = $("focusPrev"), n = $("focusNext");
  if (p) p.disabled = focusIdx <= 0;
  if (n) n.disabled = focusIdx >= VIEW_QUESTIONS.length - 1;
}

function jumpTo(i) {
  if (i < 0 || i >= VIEW_QUESTIONS.length) return;
  closePaletteSheet();
  if (viewMode === "focus") { focusIdx = i; paintFocusCard(); renderPalette(); return; }
  const cell = $("qcell-" + i);
  if (cell) {
    cell.scrollIntoView({ behavior: "smooth", block: "start" });
    cell.classList.add("q-cell-flash");
    setTimeout(() => cell.classList.remove("q-cell-flash"), 1200);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  PALETTE  —  a real column on desktop, a slide-over sheet on mobile
// ══════════════════════════════════════════════════════════════════════════
function buildPalettePanel() {
  const p = $("paletteWrap");
  if (p) return p;                                  // reuse the single instance
  const wrap = document.createElement("div");
  wrap.className = "palette-wrap";
  wrap.id = "paletteWrap";
  wrap.innerHTML =
    '<div class="pal-head">' +
      '<span class="pal-title">Questions</span>' +
      '<button type="button" class="icon-circle-btn pal-close" id="palClose" aria-label="Close palette">' +
        '<i class="fa-solid fa-times"></i></button>' +
    '</div>' +
    '<div class="pal-user" id="palUsername"></div>' +
    '<div class="palette-grid" id="paletteGrid"></div>' +
    '<div class="pal-legend"><span><i class="lg-dot lg-seen"></i>Viewed</span>' +
      '<span><i class="lg-dot lg-now"></i>Current</span></div>';
  wrap.querySelector("#palClose").onclick = closePaletteSheet;
  const u = wrap.querySelector("#palUsername");
  if (u) u.textContent = USER_EMAIL_KEY;
  return wrap;
}

let SEEN = {};
function renderPalette() {
  const grid = $("paletteGrid");
  if (!grid) return;
  grid.innerHTML = "";
  VIEW_QUESTIONS.forEach((item, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "qbtn" + (SEEN[i] ? " seen" : "") + (i === focusIdx ? " current" : "");
    b.textContent = String(i + 1);
    b.onclick = () => jumpTo(i);
    grid.appendChild(b);
  });
  if (viewMode === "list") markSeenFromScroll();
}

function setPaletteVisible(on) {
  document.body.classList.toggle("palette-on", !!on);
  const fab = $("paletteFab");
  if (fab) fab.style.display = on ? "" : "none";
  if (!on) closePaletteSheet();
}

function togglePaletteSheet() {
  const open = document.body.classList.contains("palette-open");
  open ? closePaletteSheet() : openPaletteSheet();
}
function openPaletteSheet() {
  if (window.innerWidth >= 1024) return;            // desktop: always a column
  document.body.classList.add("palette-open");
  const bd = $("paletteBackdrop");
  if (bd) bd.style.display = "block";
}
function closePaletteSheet() {
  document.body.classList.remove("palette-open");
  const bd = $("paletteBackdrop");
  if (bd) bd.style.display = "none";
}

// In list view every card is on screen, so "viewed" follows the scroll.
let scrollRaf = 0;
function markSeenFromScroll() {
  if (scrollRaf) return;
  scrollRaf = requestAnimationFrame(() => {
    scrollRaf = 0;
    const mid = window.innerHeight * 0.55;
    VIEW_QUESTIONS.forEach((_, i) => {
      const cell = $("qcell-" + i);
      if (!cell) return;
      const r = cell.getBoundingClientRect();
      if (r.top < mid && r.bottom > 60) {
        if (!SEEN[i]) { SEEN[i] = true; }
      }
    });
    const grid = $("paletteGrid");
    if (grid) grid.querySelectorAll(".qbtn").forEach((b, i) => {
      b.classList.toggle("seen", !!SEEN[i]);
    });
  });
}

// ══════════════════════════════════════════════════════════════════════════
//  VIEW-MODE MODAL  (asked every time a folder is opened)
// ══════════════════════════════════════════════════════════════════════════
let viewModeCb = null;
let viewModeCancel = null;
function askViewMode(cb, count, onCancel) {
  viewModeCb = cb;
  viewModeCancel = onCancel || null;
  const m = $("viewModeModal");
  $("vmCount").textContent = plural(count, "question") + " in this folder";
  m.style.display = "flex";
  m.classList.remove("vm-in");
  requestAnimationFrame(() => m.classList.add("vm-in"));
}
function chooseViewMode(mode) {
  const m = $("viewModeModal");
  m.style.display = "none";
  const cb = viewModeCb; viewModeCb = null; viewModeCancel = null;
  if (cb) cb(mode);
}
function cancelViewMode() {
  const m = $("viewModeModal");
  m.style.display = "none";
  const cb = viewModeCancel;
  viewModeCb = null; viewModeCancel = null;
  // From a folder click there is simply nothing to open. From a URL with no
  // view chosen, the caller supplied a way back so the screen is never blank.
  if (cb) cb();
}

// ══════════════════════════════════════════════════════════════════════════
//  LANGUAGE
// ══════════════════════════════════════════════════════════════════════════
function changeGlobalLang(v) {
  currentLang = v || "en";
  try { localStorage.setItem("quiz_lang", currentLang); } catch (e) {}
  // Re-render in place: the questions are already in memory, so this is free.
  const r = parseRoute();
  if (r.page === "questions" && VIEW_QUESTIONS.length) {
    const host = $("screenInner");
    paintQuestions(host, r);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  LOADER / FATAL / TOAST
// ══════════════════════════════════════════════════════════════════════════
function showLoader(msg, done, total) {
  const l = $("loader");
  if (!l) return;
  l.style.display = "flex";
  $("loaderText").textContent = msg || "Loading…";
  const bar = $("loaderBar");
  const pct = $("loaderPct");
  if (typeof done === "number" && typeof total === "number" && total > 0) {
    const p = Math.round(done * 100 / total);
    bar.style.display = "block";
    bar.firstElementChild.style.width = p + "%";
    pct.textContent = done + " / " + total;
  } else {
    bar.style.display = "none";
    pct.textContent = "";
  }
}
function hideLoader() { const l = $("loader"); if (l) l.style.display = "none"; }

let fatalRetry = null;
function showFatal(msg, retry) {
  hideLoader();
  fatalRetry = retry || null;
  const f = $("fatalBox");
  if (!f) return;
  $("fatalMsg").textContent = msg;
  $("fatalRetry").style.display = fatalRetry ? "" : "none";
  f.style.display = "flex";
}
function hideFatal() { const f = $("fatalBox"); if (f) f.style.display = "none"; }
function doFatalRetry() { hideFatal(); if (fatalRetry) fatalRetry(); }

let toastTimer = 0;
function showToast(msg) {
  let t = $("mmhToast");
  if (!t) {
    t = document.createElement("div");
    t.id = "mmhToast";
    t.className = "mmh-toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
}

// ══════════════════════════════════════════════════════════════════════════
//  TREE SURGERY
//  Every mutation hits Firebase FIRST and this in-memory tree SECOND, so the
//  screen is correct the instant the write resolves — no re-read, no flicker,
//  and no chance of showing something the database does not agree with.
//  Empty parents are pruned here exactly as Firebase prunes them on the server.
// ══════════════════════════════════════════════════════════════════════════
function treeSubject(name) { return TREE ? TREE.subjects.find(s => s.name === name) : null; }

function treeAddQuestion(subKey, topKey, quizKey, qid) {
  if (!TREE) return;
  let s = treeSubject(subKey);
  if (!s) { s = { name: subKey, topics: [], topicCount: 0, count: 0 }; TREE.subjects.push(s); }
  let t = s.topics.find(x => x.name === topKey);
  if (!t) { t = { name: topKey, quizMap: {}, count: 0 }; s.topics.push(t); }
  if (!t.quizMap[quizKey]) t.quizMap[quizKey] = [];
  if (t.quizMap[quizKey].indexOf(qid) < 0) t.quizMap[quizKey].push(qid);
}

function treeRemoveQuestion(subKey, topKey, quizKey, qid) {
  const s = treeSubject(subKey);
  if (!s) return;
  const t = s.topics.find(x => x.name === topKey);
  if (!t || !t.quizMap[quizKey]) return;
  t.quizMap[quizKey] = t.quizMap[quizKey].filter(x => x !== qid);
  if (!t.quizMap[quizKey].length) delete t.quizMap[quizKey];
}

// Drop empty quizzes, topics and subjects, recompute every count, re-sort.
function treeRecount() {
  if (!TREE) return;
  TREE.subjects.forEach(s => {
    s.topics.forEach(t => {
      Object.keys(t.quizMap).forEach(qk => {
        t.quizMap[qk] = t.quizMap[qk].filter(Boolean);
        t.quizMap[qk].sort(compareQuestionIds);
        if (!t.quizMap[qk].length) delete t.quizMap[qk];
      });
      t.count = Object.keys(t.quizMap).reduce((a, k) => a + t.quizMap[k].length, 0);
    });
    s.topics = s.topics.filter(t => t.count > 0);
    s.topics.sort((a, b) => a.name.localeCompare(b.name));
    s.topicCount = s.topics.length;
    s.count = s.topics.reduce((a, t) => a + t.count, 0);
  });
  TREE.subjects = TREE.subjects.filter(s => s.count > 0);
  TREE.subjects.sort((a, b) => a.name.localeCompare(b.name));
}

// Everything a folder holds, as {sub, topic, quizKey, qid} tuples.
function treeItems(spec) {
  const out = [];
  const take = (s, t) => Object.keys(t.quizMap).forEach(qk =>
    t.quizMap[qk].forEach(qid => out.push({ sub: s.name, topic: t.name, quizKey: qk, qid: qid })));
  if (spec.sub === ALL_SUBJECTS) {
    (TREE ? TREE.subjects : []).forEach(s => s.topics.forEach(t => take(s, t)));
  } else {
    const s = treeSubject(spec.sub);
    if (!s) return out;
    if (spec.topic === ALL_TOPICS) s.topics.forEach(t => take(s, t));
    else { const t = s.topics.find(x => x.name === spec.topic); if (t) take(s, t); }
  }
  return out;
}

// ── the API the management module (js/saved-manage.js) drives ──────────────
// Exposed deliberately rather than reached for through globals, so the two files
// have a contract instead of an accident.
window.SavedCore = {
  get tree()      { return TREE; },
  get user()      { return USER_KEY; },
  get username()  { return USER_EMAIL_KEY; },
  get route()     { return parseRoute(); },
  get questions() { return VIEW_QUESTIONS; },
  get viewMode()  { return viewMode; },
  get lang()      { return currentLang; },
  ALL_SUBJECTS: ALL_SUBJECTS,
  ALL_TOPICS:   ALL_TOPICS,
  // The live database handle. Mutations live in saved-manage.js, so the handle
  // travels through the contract rather than being fished off window.
  get db()      { return savedDb; },
  fbKey:       raw => fbKeyLocal(raw),
  badKeyChars: raw => ".#$[]/".split("").filter(ch => String(raw == null ? "" : raw).indexOf(ch) >= 0),
  subjectNames: () => (TREE ? TREE.subjects.map(s => s.name) : []),
  topicNames:   sub => { const s = treeSubject(sub); return s ? s.topics.map(t => t.name) : []; },
  treeItems, treeAddQuestion, treeRemoveQuestion, treeRecount, collectPairs,
  // Stage 3 exports the batched question loader and the progress UI so the PDF
  // builder can fetch a whole subject (or the whole library) with the same
  // per-quiz batching, the same parallelism cap and the same progress bar the
  // topic view already uses — rather than growing a second loader.
  loadQuestions, showLoader, hideLoader,
  rerender:   () => { const r = parseRoute(); renderRoute(r); return r; },
  navigateTo,
  toast:      showToast,
  typeset:    () => { if (typeof renderMath === "function") renderMath(); }
};

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initSavedPage() {
  const sc = $("screenScroll");
  if (sc) sc.addEventListener("scroll", function () {
    if (viewMode === "list" && document.body.classList.contains("palette-on")) markSeenFromScroll();
  }, { passive: true });

  // Swipe between questions in focus mode — same feel as the test page.
  let sx = 0, sy = 0;
  const stageHost = $("screenScroll");
  if (stageHost) {
    stageHost.addEventListener("touchstart", e => {
      if (viewMode !== "focus") return;
      sx = e.touches[0].clientX; sy = e.touches[0].clientY;
    }, { passive: true });
    stageHost.addEventListener("touchend", e => {
      if (viewMode !== "focus") return;
      const dx = e.changedTouches[0].clientX - sx;
      const dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.6) navFocus(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  window.addEventListener("resize", function () {
    if (window.innerWidth >= 1024) closePaletteSheet();
  });

  bootSaved();
}

// The scripts sit at the end of <body>, so depending on caching the document
// may already be past "loading" by the time this runs — a bare DOMContentLoaded
// listener would then never fire and the page would never boot at all.
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initSavedPage);
else initSavedPage();

// Exposed for inline handlers in the markup.
Object.assign(window, {
  savedBack, navigateTo, openQuestions, chooseViewMode, cancelViewMode, changeGlobalLang,
  savedNormalMode, savedTestMode, updateSavedModeDeck,
  togglePaletteSheet, closePaletteSheet, openPaletteSheet, jumpTo, navFocus,
  doFatalRetry, showToast
});

// Called after every screen is painted so the management module can attach its
// three-dot menus, selection controls and per-card hooks. Late-bound on purpose:
// saved.js carries no load-time dependency on saved-manage.js.
window.__savedDecorate = window.__savedDecorate || function () {};

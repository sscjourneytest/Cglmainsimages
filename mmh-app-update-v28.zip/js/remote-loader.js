/*
   Mock Matrix Hub — bundled JSON remote loader

   Bundled JSON is always read and painted first. A live copy is requested only
   in the background; it can never hold the first paint behind a network wait.
   If the live JSON differs from the bundled JSON, the loader emits
   `mmh-live-json-updated` and the page may repaint in place.

   These are the small JSON files that have an APK/bundled copy and a live
   counterpart. Their live refresh keeps the existing Slow internet / Offline
   status surfaces without blocking the bundled page.
     /data/home-config.json
     /data/exam-categories.json
     /data/series-categories.json
     /data/app-update.json
     /cloudflare-config.json
     /premium-plans.json

   /whats-new.json and /sale-information.json are intentionally live-only.
   They are not loaded by this adapter and are never required by the APK.
*/
(function (global) {
  'use strict';

  if (global.MMHRemoteJSON && global.MMHRemoteJSON.load) return;

  var LIVE_BASE = global.MMH_LIVE_BASE || 'https://mockmatrixhub.in';
  var backgroundJobs = Object.create(null);
  var bundledPaths = Object.create(null);
  [
    '/data/home-config.json',
    '/data/exam-categories.json',
    '/data/series-categories.json',
    '/data/app-update.json',
    '/cloudflare-config.json',
    '/premium-plans.json'
  ].forEach(function (path) { bundledPaths[path] = true; });

  var activeLiveJobs = 0;
  var slowTimer = null;
  var pendingStatus = null;
  var statusDismissed = false;
  var statusHideTimer = null;

  function cleanPath(path) {
    var value = String(path || '');
    var q = value.indexOf('?');
    return (q < 0 ? value : value.slice(0, q)) || '/';
  }

  function isBundledPath(path) {
    return !!bundledPaths[cleanPath(path)];
  }

  function liveUrl(path) {
    var rel = cleanPath(path).replace(/^\/+/, '');
    return LIVE_BASE.replace(/\/$/, '') + '/' + rel + '?mmh_live=' + Date.now();
  }

  function cloneWithoutSignal(options) {
    var out = Object.assign({ cache: 'no-store' }, options || {});
    // The caller's local timeout must never abort the background live request.
    delete out.signal;
    return out;
  }

  function stable(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    return '{' + Object.keys(value).sort().map(function (key) {
      return JSON.stringify(key) + ':' + stable(value[key]);
    }).join(',') + '}';
  }

  function emit(path, data, url) {
    if (typeof global.CustomEvent !== 'function' || !global.dispatchEvent) return;
    global.dispatchEvent(new global.CustomEvent('mmh-live-json-updated', {
      detail: { path: cleanPath(path), data: data, liveUrl: url }
    }));
  }

  // ── Slow/offline status for bundled JSON only ────────────────────────────
  // This is informational: it never covers or delays the already-rendered APK
  // content. The banner disappears automatically when the live request wins.
  function ensureStatusStyle() {
    if (!global.document || global.document.getElementById('mmhBundledNetworkStyle')) return;
    var style = global.document.createElement('style');
    style.id = 'mmhBundledNetworkStyle';
    style.textContent = '' +
      '#mmhBundledNetworkStatus{position:fixed;z-index:5000;left:50%;max-width:min(92vw,390px);' +
      'padding:14px 42px 14px 16px;border:1px solid rgba(255,255,255,.16);border-radius:16px;' +
      'background:rgba(15,23,42,.96);color:#fff;box-shadow:0 18px 50px rgba(2,6,23,.32);' +
      'font:600 12px/1.45 system-ui,-apple-system,sans-serif;display:none}' +
      '#mmhBundledNetworkStatus.mmh-status-slow{top:50%;transform:translate(-50%,-50%)}' +
      '#mmhBundledNetworkStatus.mmh-status-offline{bottom:18px;transform:translateX(-50%)}' +
      '#mmhBundledNetworkStatus strong{display:block;font-size:13px;margin-bottom:2px}' +
      '#mmhBundledNetworkStatus span{display:block;color:#cbd5e1}' +
      '#mmhBundledNetworkStatus button{position:absolute;right:9px;top:9px;width:26px;height:26px;' +
      'border:0;border-radius:8px;background:rgba(255,255,255,.12);color:#fff;cursor:pointer;font-size:17px;line-height:1}' +
      '@media(max-width:600px){#mmhBundledNetworkStatus.mmh-status-slow{top:auto;bottom:18px;transform:translateX(-50%)}}';
    (global.document.head || global.document.documentElement).appendChild(style);
  }

  function ensureStatusElement() {
    if (!global.document || !global.document.body) return null;
    ensureStatusStyle();
    var el = global.document.getElementById('mmhBundledNetworkStatus');
    if (el) return el;
    el = global.document.createElement('div');
    el.id = 'mmhBundledNetworkStatus';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    el.innerHTML = '<button type="button" aria-label="Dismiss">×</button>' +
      '<strong></strong><span></span>';
    el.querySelector('button').addEventListener('click', function () {
      statusDismissed = true;
      el.style.display = 'none';
    });
    global.document.body.appendChild(el);
    return el;
  }

  function setStatus(kind) {
    if (statusDismissed) return;
    pendingStatus = kind;
    var el = ensureStatusElement();
    if (!el) return;
    el.className = 'mmh-status-' + kind;
    el.querySelector('strong').textContent = kind === 'slow' ? 'Slow internet' : 'Offline';
    el.querySelector('span').textContent = kind === 'slow'
      ? 'Bundled content is ready. Live refresh is taking longer than expected.'
      : 'Bundled content is being used. Live refresh will retry when you reconnect.';
    el.style.display = 'block';
    // These are short informational alerts, never a persistent blocking modal.
    if (statusHideTimer) clearTimeout(statusHideTimer);
    statusHideTimer = setTimeout(function () { hideStatus(); }, 2000);
  }

  function hideStatus() {
    pendingStatus = null;
    if (statusHideTimer) { clearTimeout(statusHideTimer); statusHideTimer = null; }
    if (!global.document) return;
    var el = global.document.getElementById('mmhBundledNetworkStatus');
    if (el) el.style.display = 'none';
  }

  if (global.document && global.document.addEventListener) {
    global.document.addEventListener('DOMContentLoaded', function () {
      if (pendingStatus) setStatus(pendingStatus);
    });
  }

  function refreshInBackground(path, bundledData) {
    var clean = cleanPath(path);
    if (!isBundledPath(clean) || backgroundJobs[clean]) return;
    backgroundJobs[clean] = true;
    activeLiveJobs += 1;

    // Start the two-second informational timer only after local JSON has been accepted.
    // Nothing here can delay local rendering.
    slowTimer = slowTimer || setTimeout(function () {
      if (activeLiveJobs > 0) setStatus('slow');
      slowTimer = null;
    }, 2000);

    if (global.navigator && global.navigator.onLine === false) setStatus('offline');

    var requestUrl = liveUrl(clean);
    global.fetch(requestUrl, { cache: 'no-store' })
      .then(function (response) {
        if (!response || !response.ok) throw new Error('HTTP ' + (response && response.status));
        return response.json();
      })
      .then(function (liveData) {
        if (stable(liveData) !== stable(bundledData)) emit(clean, liveData, requestUrl);
        activeLiveJobs = Math.max(0, activeLiveJobs - 1);
        if (activeLiveJobs === 0) {
          if (slowTimer) { clearTimeout(slowTimer); slowTimer = null; }
          hideStatus();
        }
      })
      .catch(function () {
        activeLiveJobs = Math.max(0, activeLiveJobs - 1);
        if (slowTimer && activeLiveJobs === 0) { clearTimeout(slowTimer); slowTimer = null; }
        setStatus('offline');
        // Bundled content remains the source of truth until a later refresh.
      })
      .then(function () {
        delete backgroundJobs[clean];
      });
  }

  async function load(path, options) {
    var localPath = String(path);
    var response = await global.fetch(localPath, cloneWithoutSignal(options));
    if (!response || !response.ok) throw new Error('Could not load bundled JSON: ' + localPath);
    var bundled = await response.clone().json();
    refreshInBackground(localPath, bundled);
    return bundled;
  }

  async function loadResponse(path, options) {
    var localPath = String(path);
    var response = await global.fetch(localPath, cloneWithoutSignal(options));
    if (!response || !response.ok) throw new Error('Could not load bundled JSON: ' + localPath);
    var bundled = await response.clone().json();
    refreshInBackground(localPath, bundled);
    return response;
  }

  global.MMH_LIVE_BASE = LIVE_BASE;
  global.MMHRemoteJSON = {
    load: load,
    loadResponse: loadResponse,
    refresh: refreshInBackground,
    cleanPath: cleanPath,
    isBundledPath: isBundledPath
  };

  // Compatibility for existing page engines. Their callers still ask for a
  // Response, but it now always comes from the APK/local copy first.
  if (typeof global.fetchLiveFirst !== 'function') {
    global.fetchLiveFirst = function (localPath, options) {
      return loadResponse(localPath, options);
    };
  }
})(typeof window !== 'undefined' ? window : globalThis);

// ══════════════════════════════════════════════════════════════════════════
//  saved-attempt.js — Stage 4
//  "Attempt test" for the saved-questions library.
//
//  A bottom dock offers a local, self-contained test built from whatever
//  scope you are looking at. Settings are collected in a modal, the question
//  set is assembled here from the tree already in memory, and the runner lives
//  on its own page (saved/test.html) reached through the same one-time
//  sessionStorage handoff the PDF export uses.
//
//  The runner deliberately does NOT reuse test.html's engine. test.html is a
//  server-backed exam: it fetches a quiz, posts attempts, and ranks you
//  against other candidates. None of that applies here — this is a private
//  practice run over questions you saved yourself, so it must not post an
//  attempt, must not appear in any topper list, and must not compute a rank
//  or percentile. Keeping it separate is what makes that structurally true
//  rather than a promise.
//
//  Reads: allQuestions (through saved.js's own batched loader) in addition to
//  the tree already in memory. Writes: NOTHING. Attempting a test is entirely
//  local — no attempt is recorded, no answer is uploaded, nothing is mutated.
// ══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const C = () => window.SavedCore;
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const HANDOFF_KEY = "mmh-saved-attempt-handoff";
const TEST_PAGE   = "test.html";                   // relative to /saved/
// sessionStorage is ~5MB everywhere we care about. Past this the write throws,
// so refuse early with a useful message instead of a QuotaExceededError.
const MAX_PAYLOAD = 4 * 1024 * 1024;

let busy = false;
let chosen = null;                                 // the scope id the user picked
let minutesTouched = false;                        // stop auto-timing fighting the user

// ══════════════════════════════════════════════════════════════════════════
//  SCOPE
//  This mirrors saved-pdf.js's scope resolution exactly: the narrowest scope
//  is what you are looking at, and the wider ones that contain it are offered
//  so you never have to navigate first. It is written out here rather than
//  called across modules so the dock cannot silently die if script order ever
//  changes — and tests/savedtest4.js asserts the two implementations agree on
//  every route, which is what stops them drifting apart.
// ══════════════════════════════════════════════════════════════════════════
function countFor(spec) {
  const items = C().treeItems(spec);
  const subs = new Set(), tops = new Set();
  items.forEach(i => { subs.add(i.sub); tops.add(i.sub + "\u0000" + i.topic); });
  return { questions: items.length, subjects: subs.size, topics: tops.size };
}

function scopesFor(route) {
  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const out = [];
  const onQuestions = route.page === "questions";
  const realSub = onQuestions && route.sub !== AS ? route.sub : (route.page === "topics" ? route.sub : null);
  const realTop = onQuestions && route.topic !== AT ? route.topic : null;

  if (realSub && realTop) {
    out.push({ id: "topic", name: realTop, sub: realSub,
               label: realTop, hint: "This folder only",
               spec: { sub: realSub, topic: realTop } });
  }
  if (realSub) {
    out.push({ id: "subject", name: realSub, sub: realSub,
               label: realSub, hint: realTop ? "The whole subject this folder is in" : "This subject",
               spec: { sub: realSub, topic: AT } });
  }
  out.push({ id: "library", name: null, sub: null,
             label: "Whole library", hint: "Every subject and folder you have saved",
             spec: { sub: AS, topic: AT } });

  return out.map(s => Object.assign(s, countFor(s.spec))).filter(s => s.questions > 0);
}

function scopeTitle(s) {
  if (s.id === "topic") return s.sub + " \u2192 " + s.name;
  if (s.id === "subject") return s.name;
  return "Whole library";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE DOCK
//  A footer inside .exam-page-container, so it sits outside the scrolling
//  region and pushes the content up instead of covering the last question.
//  It hides itself when there is nothing to attempt, and CSS hides it during
//  multi-select so it never competes with the selection subheader.
// ══════════════════════════════════════════════════════════════════════════
function refreshDock() {
  const dock = $("attemptDock");
  if (!dock) return;
  const core = C();
  const scopes = (core && core.tree) ? scopesFor(core.route) : [];
  const ctx = scopes[0] || null;

  // The library now uses the two-button saved-bottom-nav. Keep the legacy
  // attempt dock hidden so it cannot create a second footer or cover cards.
  dock.hidden = true;
  document.body.classList.remove("has-attempt-dock");
  if (!ctx) return;

  const count = $("attemptDockCount");
  if (count) count.textContent = String(ctx.questions);
  const label = $("attemptDockLabel");
  if (label) label.textContent = scopeTitle(ctx);
  const btn = $("attemptBtn");
  if (btn) {
    btn.disabled = busy;
    btn.title = "Attempt " + scopeTitle(ctx) + " (" + ctx.questions +
                (ctx.questions === 1 ? " question)" : " questions)");
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  THE MODAL
// ══════════════════════════════════════════════════════════════════════════
function currentScopes() { return scopesFor(C().route); }
function chosenScope() {
  const list = currentScopes();
  return list.find(s => s.id === chosen) || list[0] || null;
}

function openModal() {
  if (busy) return;
  const core = C();
  const scopes = scopesFor(core.route);
  if (!scopes.length) { core.toast("There is nothing to attempt yet."); return; }

  const host = $("atScopes");
  host.innerHTML = "";
  scopes.forEach((s, i) => {
    const lab = document.createElement("label");
    lab.className = "pdf-scope" + (i === 0 ? " is-checked" : "");
    lab.innerHTML =
      '<input type="radio" name="atScope" value="' + esc(s.id) + '"' + (i === 0 ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid ' +
          (s.id === "topic" ? "fa-folder-open" : s.id === "subject" ? "fa-folder-tree" : "fa-book-bookmark") +
          '"></i>' + esc(s.label) + '</span>' +
        '<span class="pdf-scope-hint">' + esc(s.hint) + '</span>' +
      '</span>' +
      '<span class="pdf-scope-count">' + s.questions + '</span>';
    host.appendChild(lab);
  });
  chosen = scopes[0].id;

  // The name on the result sheet defaults to the signed-in username. It is
  // editable because the sheet is a local document the user may want to label
  // with their own name, and nothing about it is ever uploaded.
  const name = $("atName");
  name.value = core.username || "";
  $("atLang").value = core.lang || "en";
  $("atCorrect").value = "2";
  $("atNegative").value = "0.5";
  minutesTouched = false;

  applyScopeLimits();
  const m = $("attemptModal");
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
  ["atShuffle", "atTopicwise"].forEach(id => { const b = $(id); if (b) b.disabled = false; });
}

function closeModal() { if (!busy) $("attemptModal").style.display = "none"; }
function closeModalForce() {
  const m = $("attemptModal");
  if (m) { m.style.display = "none"; m.classList.remove("sv-in"); }
}

// Total is capped at the chosen scope, and the suggested duration follows it —
// one minute a question, which is the SSC convention — until the user sets a
// duration of their own, after which it is left alone.
function applyScopeLimits() {
  const s = chosenScope();
  const max = s ? s.questions : 0;
  const total = $("atTotal");
  total.max = String(max);
  total.min = "1";
  if (!total.value || Number(total.value) > max || Number(total.value) < 1) total.value = String(max);
  if (!minutesTouched) $("atMinutes").value = String(suggestedMinutes(Number(total.value)));
  paintSummary();
}

function suggestedMinutes(n) {
  if (!isFinite(n) || n <= 0) return 1;
  return Math.min(600, Math.max(1, Math.round(n)));
}

function readSettings() {
  const s = chosenScope();
  if (!s) return null;
  const num = (id, lo, hi, dflt) => {
    const raw = parseFloat($(id).value);
    if (!isFinite(raw)) return dflt;
    return Math.min(hi, Math.max(lo, raw));
  };
  const name = ($("atName").value || "").trim() || C().username || "Candidate";
  return {
    scope: s,
    name: name.slice(0, 60),
    total: Math.round(num("atTotal", 1, s.questions, s.questions)),
    minutes: Math.round(num("atMinutes", 1, 600, suggestedMinutes(s.questions))),
    correct: num("atCorrect", 0, 100, 2),
    negative: num("atNegative", 0, 100, 0.5),
    lang: $("atLang").value || C().lang || "en"
  };
}

function paintSummary() {
  const st = readSettings();
  const el = $("atSummary");
  if (!el || !st) return;
  const parts = [];
  parts.push(st.total + (st.total === 1 ? " question" : " questions"));
  parts.push(st.minutes + (st.minutes === 1 ? " minute" : " minutes"));
  parts.push("+" + st.correct + " / \u2212" + st.negative);
  el.textContent = parts.join("  \u00b7  ");

  // The context line always describes where the user actually is; the summary
  // describes what the chosen scope will contain. Conflating them would make
  // "You are in" lie the moment a wider scope is picked.
  const list = currentScopes();
  $("atScopeLine").textContent = list.length ? scopeTitle(list[0]) : "\u2014";

  // A very long test is worth flagging: it has to be fetched first, and the
  // timer suggestion may not be what the user meant.
  const warn = $("atBigWarn");
  if (warn) {
    warn.hidden = st.total < 120;
    if (!warn.hidden) warn.querySelector("b").textContent = String(st.total);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  ASSEMBLING THE PAPER
// ══════════════════════════════════════════════════════════════════════════
function shuffle(arr) {
  // Fisher-Yates. Math.random is fine here: this is a practice paper, not a
  // cryptographic draw, and reproducibility across devices is not a goal.
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}

// treeItems() yields the tree's own order — alphabetical subject, alphabetical
// folder, then numeric question id — which is exactly the "topic-wise" order
// the user asked for, so that path needs no re-sorting at all.
//
// When the total is lower than the scope, the sample is drawn at random rather
// than taking the first N. Taking the first N would hand back the same
// questions every single time and make a shortened test entirely predictable.
function pickItems(items, total, order) {
  const tagged = items.map((it, i) => ({ it: it, i: i }));
  let pool = tagged;
  if (total > 0 && total < pool.length) pool = shuffle(pool).slice(0, total);
  if (order === "random") return shuffle(pool).map(x => x.it);
  return pool.slice().sort((a, b) => a.i - b.i).map(x => x.it);
}

async function startAttempt(order) {
  if (busy) return;
  const core = C();
  const st = readSettings();
  if (!st) { core.toast("There is nothing to attempt yet."); return; }

  const items = core.treeItems(st.scope.spec);
  if (!items || !items.length) { core.toast("That folder has no saved questions."); return; }

  busy = true;
  ["atShuffle", "atTopicwise"].forEach(id => { const b = $(id); if (b) b.disabled = true; });
  const picked = pickItems(items, st.total, order);

  core.showLoader("Preparing your test\u2026", 0, picked.length);
  const pairs = picked.map(it => ({ quizKey: it.quizKey, qid: it.qid }));

  let loaded;
  try {
    loaded = await core.loadQuestions(pairs, (done, total) =>
      core.showLoader("Preparing your test\u2026", done, total));
  } catch (err) {
    console.error("saved-attempt: load failed", err);
    core.hideLoader(); busy = false; refreshDock();
    core.toast("Could not load the questions. Check your connection and try again.");
    return;
  }

  // loadQuestions swallows per-read errors and returns what it got, so an empty
  // result across a whole scope is a connection failure, not missing data.
  if (!loaded || !loaded.length) {
    core.hideLoader(); busy = false; refreshDock();
    core.toast("Could not load those questions. Check your connection and try again.");
    return;
  }

  try {
    const byKey = new Map();
    loaded.forEach(l => byKey.set(l.quizKey + "|" + l.qid, l.q));
    const questions = [];
    picked.forEach(it => {
      const q = byKey.get(it.quizKey + "|" + it.qid);
      if (!q || typeof q !== "object") return;        // gaps were already reported
      questions.push({
        sub: it.sub, topic: it.topic,
        quizKey: it.quizKey, qid: it.qid,
        // The RAW quiz id, not the sanitised folder key — the dynamic image
        // URLs are built from it and a rewritten key would 404 every image.
        quizId: q.quiz_id || it.quizKey,
        q: q
      });
    });

    if (!questions.length) {
      core.hideLoader(); busy = false; refreshDock();
      core.toast("None of those questions have content stored yet.");
      return;
    }

    core.showLoader("Building the test\u2026", questions.length, questions.length);
    const payload = {
      v: 1,
      id: "at" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      name: st.name,
      username: core.user || "",
      lang: st.lang,
      correct: st.correct,
      negative: st.negative,
      minutes: st.minutes,
      order: order,
      scopeId: st.scope.id,
      scopeTitle: scopeTitle(st.scope),
      route: Object.assign({}, core.route),
      generated: Date.now(),
      questions: questions
    };

    const json = JSON.stringify(payload);
    if (json.length > MAX_PAYLOAD) {
      core.hideLoader(); busy = false; refreshDock();
      core.toast("That is too many questions to hand to the test page. Reduce the total and try again.");
      return;
    }
    try {
      sessionStorage.setItem(HANDOFF_KEY, json);
    } catch (err) {
      console.error("saved-attempt: handoff failed", err);
      core.hideLoader(); busy = false; refreshDock();
      core.toast("Could not start the test on this device. Try a smaller total.");
      return;
    }
    closeModalForce();
    window.location.href = TEST_PAGE;
  } catch (err) {
    console.error("saved-attempt: build failed", err);
    core.hideLoader(); busy = false; refreshDock();
    core.toast("Could not start the test. Please try again.");
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initAttempt() {
  const btn = $("attemptBtn");
  if (btn) btn.onclick = openModal;

  const m = $("attemptModal");
  if (!m) { refreshDock(); return; }
  const x = m.querySelector(".sv-x");       if (x) x.onclick = closeModal;
  const c = m.querySelector(".sv-cancel");  if (c) c.onclick = closeModal;
  m.addEventListener("click", ev => { if (ev.target === m) closeModal(); });

  $("atScopes").addEventListener("change", ev => {
    if (ev.target && ev.target.name === "atScope") {
      chosen = ev.target.value;
      // :has(input:checked) is absent on older Android WebViews, so mirror the
      // checked state in a class the CSS can also select on.
      $("atScopes").querySelectorAll(".pdf-scope").forEach(l => {
        const on = !!(l.querySelector("input") && l.querySelector("input").checked);
        l.classList.toggle("is-checked", on);
      });
      minutesTouched = false;                // a new scope re-suggests the time
      applyScopeLimits();
    }
  });

  $("atTotal").addEventListener("input", () => { minutesTouched = false; applyScopeLimits(); });
  $("atMinutes").addEventListener("input", () => { minutesTouched = true; paintSummary(); });
  ["atCorrect", "atNegative", "atLang"].forEach(id =>
    $(id).addEventListener("change", paintSummary));
  $("atName").addEventListener("input", paintSummary);

  $("atShuffle").onclick   = () => startAttempt("random");
  $("atTopicwise").onclick = () => startAttempt("topic");

  document.addEventListener("keydown", ev => {
    if (ev.key === "Escape" && $("attemptModal").style.display !== "none") closeModal();
  });

  // Chain onto the paint hook rather than replacing it: saved-manage.js owns
  // the menus and selection, saved-pdf.js owns the PDF button, and all three
  // need to run after every screen.
  const prev = window.__savedDecorate || function () {};
  window.__savedDecorate = function () { prev(); refreshDock(); };
  refreshDock();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initAttempt);
else initAttempt();

// ── exported for the test suite ─────────────────────────────────────────────
Object.assign(window, {
  savedOpenAttemptModal: openModal,
  savedCloseAttemptModal: closeModal,
  savedStartAttempt: startAttempt,
  savedAttemptScopes: scopesFor,
  savedAttemptChosen: () => chosen,
  savedAttemptSetChosen: id => { chosen = id; minutesTouched = false; applyScopeLimits(); },
  savedAttemptSettings: readSettings,
  savedAttemptPick: pickItems,
  savedAttemptSuggestedMinutes: suggestedMinutes,
  savedAttemptBusy: () => busy,
  savedAttemptHandoffKey: HANDOFF_KEY,
  savedAttemptTestPage: TEST_PAGE,
  savedAttemptMaxPayload: MAX_PAYLOAD
});
})();

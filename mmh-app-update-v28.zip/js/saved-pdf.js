// ══════════════════════════════════════════════════════════════════════════
//  saved-pdf.js — Stage 3
//  Contextual "Save as PDF" for the saved-questions library.
//
//  This follows the pipeline the app already uses for printable documents
//  (score-calculator/js/official-print.js → official-print.html): build the
//  printable HTML here, hand it off through sessionStorage under a one-time
//  key, navigate to a dedicated print page, and let the platform's own print
//  engine produce the PDF — Capacitor WebviewPrint on native, window.print()
//  in a browser.
//
//  Deliberately NO canvas and NO rasterization anywhere. html2canvas/jsPDF
//  would turn every MathJax equation into a bitmap: unselectable,
//  unsearchable, blurry at any zoom, and huge. Going through the print engine
//  keeps the mathematics as real vector text, paginates correctly, and costs
//  no extra library.
//
//  Reads: allQuestions (through saved.js's own batched loader) in addition to
//  the tree already in memory. Writes: NOTHING. Exporting a PDF never touches
//  the database.
// ══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const C = () => window.SavedCore;
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const HANDOFF_KEY = "mmh-saved-pdf-handoff";
const PRINT_PAGE  = "print.html";                 // relative to /saved/
// sessionStorage is used for ordinary papers. Large papers are written to a
// same-origin IndexedDB handoff instead, so export quality is never reduced by
// a storage quota and images/options/solutions are not silently omitted.
const MAX_PAYLOAD = 4 * 1024 * 1024;
const HANDOFF_DB = "mmh-saved-pdf-handoff-db";

let busy = false;
let chosen = null;                                // the scope id the user picked

// ══════════════════════════════════════════════════════════════════════════
//  SCOPE — what "contextual" means
//  The button exports what you are looking at, and the modal offers the wider
//  scopes that contain it, so there is never a need to navigate first.
// ══════════════════════════════════════════════════════════════════════════
function countFor(spec) {
  const items = C().treeItems(spec);
  const subs = new Set(), tops = new Set();
  items.forEach(i => { subs.add(i.sub); tops.add(i.sub + "\u0000" + i.topic); });
  return { questions: items.length, subjects: subs.size, topics: tops.size };
}

function scopesFor(route) {
  const core = C();
  const AS = core.ALL_SUBJECTS, AT = core.ALL_TOPICS;
  const out = [];
  const onQuestions = route.page === "questions";
  const realSub = onQuestions && route.sub !== AS ? route.sub : (route.page === "topics" ? route.sub : null);
  const realTop = onQuestions && route.topic !== AT ? route.topic : null;

  if (realSub && realTop) {
    out.push({ id: "topic", name: realTop, sub: realSub,
               label: realTop, hint: "This folder only",
               spec: { sub: realSub, topic: realTop } });
  }
  if (realSub) {
    out.push({ id: "subject", name: realSub, sub: realSub,
               label: realSub, hint: realTop ? "The whole subject this folder is in" : "This subject",
               spec: { sub: realSub, topic: AT } });
  }
  out.push({ id: "library", name: null, sub: null,
             label: "Whole library", hint: "Every subject and folder you have saved",
             spec: { sub: AS, topic: AT } });

  // A scope with nothing in it is not a choice, it is a dead button.
  return out.map(s => Object.assign(s, countFor(s.spec))).filter(s => s.questions > 0);
}

function scopeTitle(s) {
  if (s.id === "topic") return s.sub + " \u2192 " + s.name;
  if (s.id === "subject") return s.name;
  return "Whole library";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE BUTTON
// ══════════════════════════════════════════════════════════════════════════
function refreshPdfButton() {
  const btn = $("pdfBtn");
  if (!btn) return;
  const core = C();
  if (!core) { btn.hidden = true; return; }        // contract not published yet
  // Nothing to export until the tree has arrived; on a fatal error or an empty
  // library the button stays out of the way rather than offering a dead click.
  const ready = !!core.tree && countFor({ sub: core.ALL_SUBJECTS, topic: core.ALL_TOPICS }).questions > 0;
  btn.hidden = !ready;
  const scopes = ready ? scopesFor(core.route) : [];
  btn.disabled = scopes.length === 0;
  btn.title = scopes.length ? "Save " + scopeTitle(scopes[0]) + " as PDF" : "Nothing to save yet";
}

// ══════════════════════════════════════════════════════════════════════════
//  THE MODAL
// ══════════════════════════════════════════════════════════════════════════
function openPdfModal() {
  if (busy) return;
  const core = C();
  const scopes = scopesFor(core.route);
  if (!scopes.length) { core.toast("There is nothing to save as a PDF yet."); return; }

  const host = $("pdfScopes");
  host.innerHTML = "";
  scopes.forEach((s, i) => {
    const lab = document.createElement("label");
    lab.className = "pdf-scope" + (i === 0 ? " is-checked" : "");
    lab.innerHTML =
      '<input type="radio" name="pdfScope" value="' + esc(s.id) + '"' + (i === 0 ? " checked" : "") + '>' +
      '<span class="pdf-scope-body">' +
        '<span class="pdf-scope-name"><i class="fa-solid ' +
          (s.id === "topic" ? "fa-folder-open" : s.id === "subject" ? "fa-folder-tree" : "fa-book-bookmark") +
          '"></i>' + esc(s.label) + '</span>' +
        '<span class="pdf-scope-hint">' + esc(s.hint) + '</span>' +
      '</span>' +
      '<span class="pdf-scope-count">' + s.questions + '</span>';
    host.appendChild(lab);
  });
  chosen = scopes[0].id;

  // Language defaults to whatever the page is showing, so the PDF matches what
  // the user was just reading rather than silently reverting to English.
  const lang = $("pdfLang");
  lang.value = core.lang || "en";
  $("pdfSolutions").checked = true;

  paintSummary();
  const m = $("pdfModal");
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
  $("pdfGo").disabled = false;
}

function closePdfModal() { if (!busy) $("pdfModal").style.display = "none"; }

function currentScopes() { return scopesFor(C().route); }
function chosenScope() {
  const list = currentScopes();
  return list.find(s => s.id === chosen) || list[0];
}

function paintSummary() {
  const s = chosenScope();
  if (!s) return;
  const parts = [];
  if (s.subjects > 1 || s.id === "library") parts.push(s.subjects + (s.subjects === 1 ? " subject" : " subjects"));
  parts.push(s.topics + (s.topics === 1 ? " folder" : " folders"));
  parts.push(s.questions + (s.questions === 1 ? " question" : " questions"));
  $("pdfSummary").textContent = parts.join(" · ");
  // The context line always describes where the user actually is; the summary
  // describes what the chosen scope will contain. Conflating them would make
  // "You are in" lie the moment a wider scope is picked.
  const list = currentScopes();
  $("pdfScopeLine").textContent = list.length ? scopeTitle(list[0]) : "—";
  // A big export is worth warning about: it has to be fetched first.
  const warn = $("pdfBigWarn");
  warn.hidden = s.questions < 120;
  if (!warn.hidden) warn.querySelector("b").textContent = String(s.questions);
}

// ══════════════════════════════════════════════════════════════════════════
//  BUILD
// ══════════════════════════════════════════════════════════════════════════
const LANG_LABEL = { en: "English", hi: "Hindi", bilingual: "English + Hindi" };

async function buildPdf() {
  if (busy) return;
  const core = C();
  const scope = chosenScope();
  if (!scope) return;

  const lang = $("pdfLang").value || "en";
  const withSolutions = $("pdfSolutions").checked;

  busy = true;
  closePdfModalForce();
  const items = core.treeItems(scope.spec);
  const pairs = items.map(i => ({ quizKey: i.quizKey, qid: i.qid }));

  core.showLoader("Preparing your PDF…", 0, pairs.length);
  let loaded;
  try {
    loaded = await core.loadQuestions(pairs, (done, total) =>
      core.showLoader("Preparing your PDF…", done, total));
  } catch (err) {
    console.error("saved-pdf: load failed", err);
    core.hideLoader(); busy = false;
    core.toast("Could not load the questions. Check your connection and try again.");
    return;
  }

  // loadQuestions swallows per-read errors and returns what it got, so an
  // empty result across a whole scope is a connection failure, not missing
  // data. Saying "no content stored" here would send the user hunting for a
  // data problem that does not exist. A partial result is fine and proceeds —
  // loadQuestions has already reported the specific gaps.
  if (!loaded || !loaded.length) {
    core.hideLoader(); busy = false;
    core.toast("Could not load those questions. Check your connection and try again.");
    return;
  }

  try {
    const byKey = new Map();
    loaded.forEach(l => byKey.set(l.quizKey + "|" + l.qid, l.q));
    const model = groupItems(items, byKey);
    if (!model.length) {
      core.hideLoader(); busy = false;
      core.toast("None of those questions have content stored yet.");
      return;
    }
    core.showLoader("Laying out the document…", pairs.length, pairs.length);
    const payload = await buildPayload(model, { scope, lang, withSolutions });
    if (!payload) return;                          // buildPayload already explained why
    if (!await handoff(payload)) return;          // handoff reports its own error
    window.location.href = PRINT_PAGE;
  } catch (err) {
    console.error("saved-pdf: build failed", err);
    core.toast("Could not build the PDF. Please try again.");
  } finally {
    core.hideLoader();
    busy = false;
  }
}

function closePdfModalForce() {
  const m = $("pdfModal");
  if (m) { m.style.display = "none"; m.classList.remove("sv-in"); }
}

// treeItems() yields the tree's own order — alphabetical subject, alphabetical
// folder, then numeric question id — so grouping is a single pass over
// consecutive runs. Nothing is re-sorted and nothing is assumed.
function groupItems(items, byKey) {
  const subjects = [];
  let curS = null, curT = null;
  items.forEach(it => {
    const q = byKey.get(it.quizKey + "|" + it.qid);
    if (!q || typeof q !== "object") return;         // gaps were already reported
    if (!curS || curS.name !== it.sub) { curS = { name: it.sub, topics: [] }; subjects.push(curS); curT = null; }
    if (!curT || curT.name !== it.topic) { curT = { name: it.topic, questions: [] }; curS.topics.push(curT); }
    curT.questions.push({ q: q, quizKey: it.quizKey, qid: it.qid });
  });
  return subjects;
}

// ── rendering the cards ─────────────────────────────────────────────────────
// mmhRenderCard is the SAME function test.html uses, so a question in the PDF
// looks exactly like it does on screen and inside a test: same language
// handling, same <br> repair, same exam tag, same dynamic GitHub images, same
// MathJax source.
//
// Cards are built DETACHED and serialized. MathJax is not run here at all —
// the print page typesets the whole document once, which is both faster and
// the only way pagination can be correct.
//
// setSolutionOpen() calls the module-local renderMath() inside q-render.js,
// which typesets the entire live page and retries on a timer. Doing that once
// per question would stall a 240-question export for seconds, so MathJax is
// swapped for a dead-end thenable for the length of the build: the check
// passes, the callback is never invoked, no timers are scheduled and the real
// MathJax is restored in a finally block.
const DEAD = { then: () => DEAD, catch: () => DEAD };

function renderCards(model, lang, withSolutions) {
  const realMJ = window.MathJax;
  window.MathJax = { typesetPromise: () => DEAD };
  try {
    model.forEach(s => s.topics.forEach(t => {
      const total = t.questions.length;
      t.questions.forEach((item, i) => {
        const q = item.q;
        const card = window.mmhRenderCard(q, {
          lang: lang,
          // The RAW quiz id, not the sanitised folder key — the dynamic image
          // URLs are built from it and a rewritten key would 404 every image.
          quizId: q.quiz_id || item.quizKey,
          index: i + 1,
          total: total,
          mode: withSolutions ? "solution" : "browse",
          allowSolution: false,          // a PDF has no buttons to press
          showPercent: false
        });
        item.html = card.outerHTML;
      });
    }));
  } finally {
    window.MathJax = realMJ;
  }
}

// Plain answer-key text is supplementary to the full q-render solution card.
// It gives the reference-style quick key without throwing away any option,
// explanation, image, exam tag, or MathJax content in the question itself.
function answerKeyText(q, lang) {
  const n = Number(q && q.answer);
  if (!Number.isFinite(n) || n < 1 || n > 5) return "Not supplied";
  const raw = q["option_" + n];
  let text = raw;
  try { if (typeof window.mmhGetLangText === "function") text = window.mmhGetLangText(raw, lang); } catch (e) {}
  text = String(text == null ? "" : text).replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
  return String.fromCharCode(64 + n) + (text ? ". " + text : "");
}

// ── the document ────────────────────────────────────────────────────────────
async function buildPayload(model, o) {
  const core = C();
  renderCards(model, o.lang, o.withSolutions);

  const totals = model.reduce((a, s) => {
    a.subjects++;
    s.topics.forEach(t => { a.topics++; a.questions += t.questions.length; });
    return a;
  }, { subjects: 0, topics: 0, questions: 0 });

  const generated = new Date();
  const dateStr = generated.toLocaleDateString("en-IN",
    { day: "2-digit", month: "short", year: "numeric" });

  let html = "";

  // ── cover + index, sharing page 1 (the index flows on if it is long) ──
  html += '<section class="pdf-cover">';
  html +=   '<img class="pdf-cover-logo" src="/logo.png" alt="">';
  html +=   '<h1>Saved Questions</h1>';
  html +=   '<div class="pdf-cover-brand">Mock Matrix Hub &middot; Practice to Perfection</div>';
  html +=   '<table class="pdf-cover-meta"><tbody>';
  html +=     row("Prepared for", core.username || "—");
  html +=     row("Scope", scopeTitle(o.scope));
  html +=     row("Generated", dateStr);
  html +=     row("Contents", totals.subjects + (totals.subjects === 1 ? " subject" : " subjects") +
                             " &middot; " + totals.topics + (totals.topics === 1 ? " folder" : " folders") +
                             " &middot; " + totals.questions + (totals.questions === 1 ? " question" : " questions"));
  html +=     row("Language", LANG_LABEL[o.lang] || o.lang);
  html +=     row("Solutions", o.withSolutions ? "Included" : "Not included");
  html +=   '</tbody></table>';
  html += '</section>';

  // Reference-style full-width index. The grouped subject blocks preserve the
  // reference hierarchy and topic counts; the detailed table adds stable row
  // numbers, percentages, and internal links for a long paper.
  html += '<section class="pdf-index"><h2>Index</h2>';
  model.forEach(s => {
    const subjectQuestions = s.topics.reduce((a, t) => a + t.questions.length, 0);
    html += '<div class="pdf-idx-sub"><div class="pdf-idx-head"><b>' + esc(s.name) + '</b><span>' +
      s.topics.length + (s.topics.length === 1 ? ' folder' : ' folders') + ' &middot; ' +
      subjectQuestions + (subjectQuestions === 1 ? ' question' : ' questions') + '</span></div><ul class="pdf-idx-list">';
    s.topics.forEach((t, ti) => {
      const rowNo = model.slice(0, model.indexOf(s)).reduce((a, x) => a + x.topics.length, 0) + ti + 1;
      html += '<li><span class="pdf-idx-dot"></span><a class="pdf-idx-name" href="#pdf-topic-' + rowNo + '">' + esc(t.name) +
        '</a><span class="pdf-idx-rule"></span><span class="pdf-idx-n">' + t.questions.length + '</span></li>';
    });
    html += '</ul></div>';
  });
  html += '<table class="pdf-index-table"><thead><tr><th>#</th><th>Subject</th><th>Folder / Topic</th><th>Questions</th><th>Weightage</th></tr></thead><tbody>';
  const totalIndexed = totals.questions || 1;
  let indexNo = 0;
  model.forEach(s => s.topics.forEach(t => {
    indexNo++;
    const n = t.questions.length;
    const wt = (n / totalIndexed * 100).toFixed(1) + "%";
    html += '<tr><td>' + indexNo + '</td><td>' + esc(s.name) + '</td><td><a href="#pdf-topic-' + indexNo + '">' + esc(t.name) +
      '</a></td><td class="num">' + n + '</td><td class="num">' + wt + '</td></tr>';
  }));
  html += '</tbody><tfoot><tr><th colspan="3">Total</th><th class="num">' + totals.questions + '</th><th class="num">100%</th></tr></tfoot></table></section>';

  // ── one section per folder, each forced onto a fresh page ──
  let topicSerial = 0;
  model.forEach(s => s.topics.forEach(t => {
    topicSerial++;
    html += '<section class="pdf-topic" id="pdf-topic-' + topicSerial + '">';
    html +=   '<header class="pdf-topic-head">';
    html +=     '<div class="pdf-topic-sub">' + esc(s.name) + '</div>';
    html +=     '<h2>' + esc(t.name) + '</h2>';
    html +=     '<div class="pdf-topic-meta">' + t.questions.length +
                (t.questions.length === 1 ? " question" : " questions") +
                (o.withSolutions ? " &middot; with solutions" : "") + '</div>';
    html +=   '</header>';
    html +=   '<div class="pdf-cols">';
    t.questions.forEach(item => { html += '<div class="pdf-q">' + item.html + '</div>'; });
    html +=   '</div>';
    if (o.withSolutions) {
      html += '<div class="pdf-answer-key"><h3>Answer key</h3><table><thead><tr><th>Question</th><th>Correct option</th></tr></thead><tbody>';
      t.questions.forEach((item, answerIndex) => {
        html += '<tr><td>' + (answerIndex + 1) + '</td><td>' + esc(answerKeyText(item.q, o.lang)) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '<footer class="pdf-topic-foot">Saved Questions &middot; ' + esc(s.name) + ' &middot; ' + esc(t.name) + '</footer>';
    html += '</section>';
  }));

  function row(k, v) {
    return '<tr><th>' + esc(k) + '</th><td>' + v + '</td></tr>';
  }

  const payload = {
    title: "Saved Questions — " + scopeTitle(o.scope),
    bodyHtml: html,
    username: core.username || "",
    totals: totals,
    lang: LANG_LABEL[o.lang] || o.lang,
    solutions: o.withSolutions,
    columns: 2,
    divider: false,
    generated: dateStr
  };

  return payload;
}

// One-time handoff, consumed and wiped by the print page. Normal papers use
// sessionStorage because it is immediate; a large paper uses IndexedDB so a
// 20 MB document is still complete instead of being rejected or truncated.
function openHandoffDb() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) { reject(new Error("IndexedDB unavailable")); return; }
    const req = indexedDB.open(HANDOFF_DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore("handoff");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IndexedDB open failed"));
  });
}
function writeLargeHandoff(raw) {
  return openHandoffDb().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction("handoff", "readwrite");
    tx.objectStore("handoff").put(raw, "payload");
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error("IndexedDB write failed")); };
  }));
}
async function handoff(payload) {
  const raw = JSON.stringify(payload);
  try {
    if (raw.length <= MAX_PAYLOAD) {
      sessionStorage.setItem(HANDOFF_KEY, raw);
      return true;
    }
  } catch (err) {
    console.warn("saved-pdf: sessionStorage handoff unavailable", err);
  }
  try {
    await writeLargeHandoff(raw);
    // A previous failed/abandoned attempt may have left the old raw value in
    // storage. Remove it before writing the tiny marker, otherwise a full
    // sessionStorage bucket could make the large handoff unreachable.
    try { sessionStorage.removeItem(HANDOFF_KEY); } catch (e) {}
    sessionStorage.setItem(HANDOFF_KEY, "__indexeddb__");
    return true;
  } catch (err) {
    console.error("saved-pdf: large handoff failed", err);
    C().toast("This browser could not store the document temporarily. Please allow site storage and try again.");
    return false;
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initPdf() {
  const btn = $("pdfBtn");
  if (btn) { btn.onclick = openPdfModal; btn.hidden = true; }

  const m = $("pdfModal");
  if (!m) return;
  m.querySelector(".sv-x").onclick = closePdfModal;
  m.querySelector(".sv-cancel").onclick = closePdfModal;
  $("pdfGo").onclick = buildPdf;

  // No backdrop-click close: an accidental tap on the dim area must not throw
  // away a set of choices the user just made.
  $("pdfScopes").addEventListener("change", ev => {
    if (ev.target && ev.target.name === "pdfScope") {
      chosen = ev.target.value;
      // .is-checked mirrors :has(input:checked) for WebViews old enough not to
      // support it, so the chosen scope is highlighted everywhere.
      $("pdfScopes").querySelectorAll(".pdf-scope").forEach(l =>
        l.classList.toggle("is-checked", !!l.querySelector("input:checked")));
      paintSummary();
    }
  });
  document.addEventListener("keydown", ev => {
    if (ev.key === "Escape" && !busy && m.style.display === "flex") closePdfModal();
  });

  // Chain onto the paint hook rather than replacing it: saved-manage.js owns
  // the menus and selection, and both need to run after every screen.
  const prev = window.__savedDecorate || function () {};
  window.__savedDecorate = function () { prev(); refreshPdfButton(); };
  refreshPdfButton();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initPdf);
else initPdf();

// ── exported for the test suite ─────────────────────────────────────────────
Object.assign(window, {
  savedOpenPdfModal: openPdfModal,
  savedClosePdfModal: closePdfModal,
  savedBuildPdf: buildPdf,
  savedPdfScopes: scopesFor,
  savedPdfChosen: () => chosen,
  savedPdfSetChosen: id => { chosen = id; paintSummary(); },
  savedPdfCount: countFor,
  savedPdfGroup: groupItems,
  savedPdfBusy: () => busy,
  savedPdfHandoffKey: HANDOFF_KEY,
  savedPdfPrintPage: PRINT_PAGE,
  savedPdfMaxPayload: MAX_PAYLOAD
});
})();

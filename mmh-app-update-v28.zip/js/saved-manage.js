// ══════════════════════════════════════════════════════════════════════════
//  saved-manage.js — Stage 2
//  Three-dot menus · multi-select · delete · move-to · merge
//
//  WRITES ARE CONFINED TO TWO NODES, exactly as specified:
//      userSaved/{u}/{subject}/{topic}/{quizId}/{qid}      the library tree
//      userSavedByQuiz/{u}/{quizId}/{qid}/{s|t}            the flat index
//
//  allQuestions is never touched — it is shared with every other user, and a
//  question nobody can reach costs nothing. saved_questions, the legacy node,
//  is neither read nor written.
//
//  Two invariants this module is careful about:
//
//  1. test.html's unsave rebuilds the deep library path as
//         userSaved/{u}/fbKey(entry.s)/fbKey(entry.t)/...
//     so after any move or merge, fbKey(s) MUST equal the folder key the
//     question now lives under — otherwise unsave from a test page silently
//     fails and leaves a ghost behind. fbKey() is idempotent, so writing the
//     folder key itself always satisfies this; a freshly typed name is stored
//     raw and its key is computed with the same fbKey().
//
//  2. userSavedByQuiz entries are updated through DEEP paths (.../s and .../t)
//     rather than by replacing the object, so the original `at` timestamp
//     survives a move. Replacing the whole object would silently reset it.
//
//  Every mutation is ONE multi-path update() call, so a 200-question merge is a
//  single round trip rather than 600 writes.
// ══════════════════════════════════════════════════════════════════════════
(function () {
"use strict";

const C = () => window.SavedCore;
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
const TOPIC_DEFAULT = "All Topic";          // same fallback test.html saves under
const BAD_CHARS = ".#$[]/";

// ── selection state ─────────────────────────────────────────────────────────
let selMode = false;
let selKind = null;                          // 'subject' | 'topic' | 'question'
let SELECTED = new Set();                    // JSON-encoded tuples, collision-proof
let opBusy = false;                          // re-entrancy guard for writes

// A topic name may legally contain "|", so keys are JSON, not delimited strings.
const keyOf = o => JSON.stringify(o);
const subjKey = name => keyOf({ k: "s", name });
const topicKey = (sub, name) => keyOf({ k: "t", sub, name });
const qKey = (sub, topic, quizKey, qid) => keyOf({ k: "q", sub, topic, quizKey, qid });

// ══════════════════════════════════════════════════════════════════════════
//  HEADER DENSITY
//  Under 900px the appbar keeps only the title and the PDF button, so the
//  language and theme controls move down into the breadcrumb row. One element
//  is physically moved — never duplicated — so there is only ever one of each.
// ══════════════════════════════════════════════════════════════════════════
const NARROW = 900;
let headerSlots = null;
function applyHeaderDensity() {
  const narrow = window.innerWidth < NARROW;
  document.body.classList.toggle("header-narrow", narrow);
  const lang = $("globalLangSelect");
  const theme = $("darkModeToggle");
  const crumb = $("crumbActions");
  const app = $("appbarActions");
  if (!lang || !theme || !crumb || !app) return;

  // Move the actual controls, never clone them. This keeps their listeners,
  // selected values and theme state intact while preventing the narrow appbar
  // from wrapping or pushing the PDF/auth actions off-screen.
  if (!headerSlots) {
    headerSlots = {
      lang: document.createComment("saved-lang-slot"),
      theme: document.createComment("saved-theme-slot")
    };
    app.insertBefore(headerSlots.lang, lang);
    app.insertBefore(headerSlots.theme, theme);
  }
  if (narrow) {
    if (lang.parentNode !== crumb) crumb.appendChild(lang);
    if (theme.parentNode !== crumb) crumb.appendChild(theme);
  } else {
    if (lang.parentNode !== app) app.insertBefore(lang, headerSlots.lang.nextSibling);
    if (theme.parentNode !== app) app.insertBefore(theme, headerSlots.theme.nextSibling);
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  THREE-DOT POPUP MENU
// ══════════════════════════════════════════════════════════════════════════
let menuOpenFor = null;

function closeMenu() {
  const layer = $("menuLayer");
  if (layer) layer.hidden = true;
  if (menuOpenFor) { menuOpenFor.setAttribute("aria-expanded", "false"); menuOpenFor = null; }
}

function openMenu(anchor, items) {
  const layer = $("menuLayer"), menu = $("popMenu");
  if (!layer || !menu) return;
  if (menuOpenFor === anchor) { closeMenu(); return; }
  closeMenu();
  menu.innerHTML = "";
  items.forEach(it => {
    if (it.sep) { const d = document.createElement("div"); d.className = "pop-sep"; menu.appendChild(d); return; }
    const b = document.createElement("button");
    b.type = "button";
    b.className = "pop-item" + (it.danger ? " pop-danger" : "");
    b.setAttribute("role", "menuitem");
    b.innerHTML = '<i class="fa-solid ' + it.icon + '"></i><span>' + esc(it.label) + '</span>';
    b.onclick = ev => { ev.stopPropagation(); closeMenu(); it.run(); };
    menu.appendChild(b);
  });
  layer.hidden = false;
  anchor.setAttribute("aria-expanded", "true");
  menuOpenFor = anchor;

  // Position under the anchor, then pull it back inside the viewport so a menu
  // on the last tile of a row can never be clipped off-screen.
  const r = anchor.getBoundingClientRect();
  const mw = menu.offsetWidth || 190, mh = menu.offsetHeight || 150;
  let left = r.right - mw;
  left = Math.max(8, Math.min(left, window.innerWidth - mw - 8));
  let top = r.bottom + 6;
  if (top + mh > window.innerHeight - 8) top = Math.max(8, r.top - mh - 6);
  menu.style.left = left + "px";
  menu.style.top = top + "px";
}

function dotButton(label, items) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "dot-btn";
  b.setAttribute("aria-label", label);
  b.setAttribute("aria-haspopup", "menu");
  b.setAttribute("aria-expanded", "false");
  b.innerHTML = '<i class="fa-solid fa-ellipsis-vertical"></i>';
  b.onclick = ev => { ev.stopPropagation(); ev.preventDefault(); openMenu(b, items); };
  return b;
}

// ══════════════════════════════════════════════════════════════════════════
//  SELECTION MODE
// ══════════════════════════════════════════════════════════════════════════
function enterSelect(kind, firstKey) {
  selMode = true; selKind = kind;
  SELECTED = new Set(firstKey ? [firstKey] : []);
  document.body.classList.add("select-mode");
  document.body.classList.add("select-" + kind);
  renderCtxBar();
  applySelectionToDom();
}

function exitSelect() {
  selMode = false; selKind = null; SELECTED.clear();
  document.body.classList.remove("select-mode", "select-subject", "select-topic", "select-question");
  renderCtxBar();
  applySelectionToDom();
}

function toggleSel(key) {
  if (SELECTED.has(key)) SELECTED.delete(key); else SELECTED.add(key);
  renderCtxBar();
  applySelectionToDom();
}

// Every selectable thing on screen, in DOM order.
function selectableEls() {
  if (!selMode) return [];
  if (selKind === "question") return Array.from(document.querySelectorAll(".q-cell[data-selkey]"));
  return Array.from(document.querySelectorAll(".folder-card[data-selkey]"));
}

function allKeys() { return selectableEls().map(e => e.getAttribute("data-selkey")); }

function selectAllToggle() {
  const keys = allKeys();
  const everything = keys.length && keys.every(k => SELECTED.has(k));
  SELECTED = everything ? new Set() : new Set(keys);
  renderCtxBar();
  applySelectionToDom();
}

function applySelectionToDom() {
  selectableEls().forEach(el => {
    el.classList.toggle("is-selected", SELECTED.has(el.getAttribute("data-selkey")));
    const box = el.querySelector(".sel-box");
    if (box) box.classList.toggle("on", SELECTED.has(el.getAttribute("data-selkey")));
  });
  if (selMode && selKind === "question") renderPaletteSelection();
}

function renderPaletteSelection() {
  // In selection mode the palette mirrors the selection instead of "viewed",
  // so a 240-question folder can be selected from the grid without scrolling.
  const grid = $("paletteGrid");
  if (!grid) return;
  const items = C().questions;
  grid.querySelectorAll(".qbtn").forEach((b, i) => {
    const it = items[i];
    if (!it) return;
    // The palette can be showing an aggregate route (All Subjects / All
    // Topics). Use the item's real location, not those synthetic route labels,
    // otherwise delete/move would write a path that never existed.
    const k = qKey(it.sub, it.topic, it.quizKey, it.qid);
    b.classList.toggle("sel", SELECTED.has(k));
  });
}

function renderCtxBar() {
  const bar = $("ctxBar");
  if (!bar) return;
  if (!selMode) { bar.hidden = true; return; }
  bar.hidden = false;
  const n = SELECTED.size;
  $("ctxCount").textContent = String(n);
  const word = selKind === "question" ? (n === 1 ? "question" : "questions")
             : selKind === "topic"    ? (n === 1 ? "topic" : "topics")
             :                          (n === 1 ? "subject" : "subjects");
  $("ctxCountWord").textContent = word + " selected";
  const keys = allKeys();
  const all = $("ctxSelectAll");
  all.textContent = (keys.length && keys.every(k => SELECTED.has(k))) ? "Clear all" : "Select all";
  all.disabled = keys.length === 0;
  $("ctxMerge").hidden = selKind === "question";
  $("ctxMove").hidden  = selKind !== "question";
  ["ctxMerge", "ctxMove", "ctxDelete"].forEach(id => { $(id).disabled = n === 0; });
}

// ══════════════════════════════════════════════════════════════════════════
//  DECORATE — runs after every paint (hook owned by saved.js)
// ══════════════════════════════════════════════════════════════════════════
window.__savedDecorate = function () {
  closeMenu();
  const route = C().route;
  if (route.page === "questions") decorateQuestions(route);
  else decorateFolders(route);
  // Leaving a screen always ends selection: a selection cannot outlive the
  // things it pointed at.
  if (selMode) {
    const kind = route.page === "questions" ? "question" : (route.page === "topics" ? "topic" : "subject");
    if (selKind && selKind !== kind) exitSelect();
  }
  renderCtxBar();
};

function decorateFolders(route) {
  const kind = route.page === "topics" ? "topic" : "subject";
  document.querySelectorAll(".folder-card").forEach(card => {
    const wide = card.classList.contains("folder-wide");
    const nameEl = card.querySelector(".folder-name");
    if (!nameEl) return;
    const name = nameEl.textContent;

    // The "All Subjects" / "All Topics" shortcuts are views, not folders. They
    // get no three-dot and cannot be selected — deleting one would mean
    // deleting the whole library with a single mistap.
    if (wide) { card.removeAttribute("data-selkey"); return; }

    const key = kind === "subject" ? subjKey(name) : topicKey(route.sub, name);
    card.setAttribute("data-selkey", key);

    if (!card.querySelector(".dot-btn")) {
      const dot = dotButton((kind === "subject" ? "Subject" : "Topic") + " menu", folderMenuItems(kind, name, route));
      card.appendChild(dot);
    }
    if (!card.querySelector(".sel-box")) {
      const box = document.createElement("span");
      box.className = "sel-box";
      box.innerHTML = '<i class="fa-solid fa-check"></i>';
      card.appendChild(box);
    }
    // In selection mode a tap toggles instead of opening the folder.
    card.onclick = ev => {
      if (ev.target.closest(".dot-btn")) return;
      if (selMode) { ev.preventDefault(); toggleSel(key); return; }
      if (kind === "subject") C().navigateTo({ page: "topics", sub: name });
      else openTopicFolder(route.sub, name);
    };
    if (selMode) card.classList.toggle("is-selected", SELECTED.has(key));
  });
}

// saved.js owns openQuestions(); resolved at call time so this module carries no
// load-order dependency on it.
function openTopicFolder(sub, topic) {
  if (typeof window.openQuestions === "function") window.openQuestions({ page: "questions", sub, topic });
}

function questionActionButton(label, icon, text, run, danger) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "mmh-direct-btn" + (danger ? " mmh-direct-danger" : "");
  b.setAttribute("aria-label", label);
  b.setAttribute("title", label);
  b.innerHTML = '<i class="fa-solid ' + icon + '" aria-hidden="true"></i><span class="mmh-direct-label">' + esc(text) + '</span>';
  b.onclick = ev => { ev.stopPropagation(); ev.preventDefault(); run(); };
  return b;
}

function decorateQuestions(route) {
  const items = C().questions;
  items.forEach((it, i) => {
    const cell = $("qcell-" + i);
    if (!cell) return;
    // route.sub/topic may be the aggregate sentinels. The mutation key must
    // always carry the question's actual Firebase subject and topic.
    const key = qKey(it.sub, it.topic, it.quizKey, it.qid);
    cell.setAttribute("data-selkey", key);
    const card = cell.querySelector(".mmh-card");
    if (!card) return;

    const extra = card.querySelector(".mmh-card-head-extra");
    if (extra) {
      // Question cards expose the two high-frequency actions directly in the
      // meta row. Desktop shows icon + label; the compact phone layout keeps
      // the same hit targets but hides the labels. The three-dot menu below
      // intentionally contains the exact same Delete / Move / Select actions.
      if (!extra.querySelector(".mmh-direct-actions")) {
        const direct = document.createElement("span");
        direct.className = "mmh-direct-actions";
        direct.appendChild(questionActionButton("Delete question", "fa-trash-can", "Delete", () => askDelete("question", [key]), true));
        direct.appendChild(questionActionButton("Move question", "fa-arrow-right-to-bracket", "Move to", () => openMove([key]), false));
        extra.insertBefore(direct, extra.firstChild);
      }
      if (!extra.querySelector(".dot-btn")) {
        const dot = dotButton("Question menu", questionMenuItems(route, it, key));
        const direct = extra.querySelector(".mmh-direct-actions");
        extra.insertBefore(dot, direct ? direct.nextSibling : extra.firstChild);
      }
    }
    if (extra && !extra.querySelector(".sel-box")) {
      // In the head's action row, not floating over the card: an absolutely
      // positioned box at top-left would land on the question-number badge.
      const box = document.createElement("span");
      box.className = "sel-box card-sel-box";
      box.innerHTML = '<i class="fa-solid fa-check"></i>';
      extra.insertBefore(box, extra.firstChild);
    }
    // Bound on the CELL rather than the card: the cell carries padding around
    // the card and a tap in that padding should still toggle. Clicks on the
    // card bubble up here, so one handler covers both — and the controls that
    // must keep working in selection mode are excluded by name.
    cell.onclick = ev => {
      if (!selMode) return;
      if (ev.target.closest(".dot-btn") || ev.target.closest(".mmh-sol-btn") ||
          ev.target.closest(".opt") || ev.target.closest("a")) return;
      ev.preventDefault();
      toggleSel(key);
    };
    if (selMode) card.classList.toggle("is-selected", SELECTED.has(key));
  });
}

// ── menu contents ───────────────────────────────────────────────────────────
function folderMenuItems(kind, name, route) {
  const isSubject = kind === "subject";
  const label = isSubject ? "subject" : "folder";
  return [
    { icon: "fa-check-double", label: "Select", run: () => enterSelect(kind, isSubject ? subjKey(name) : topicKey(route.sub, name)) },
    { icon: "fa-code-merge",   label: "Merge to…", run: () => openMerge(kind, isSubject ? [subjKey(name)] : [topicKey(route.sub, name)]) },
    { sep: true },
    { icon: "fa-trash-can", label: "Delete " + label, danger: true,
      run: () => askDelete(kind, isSubject ? [subjKey(name)] : [topicKey(route.sub, name)]) }
  ];
}

function questionMenuItems(route, it, key) {
  return [
    { icon: "fa-check-double", label: "Select", run: () => enterSelect("question", key) },
    { icon: "fa-arrow-right-to-bracket", label: "Move to…", run: () => openMove([key]) },
    { sep: true },
    { icon: "fa-trash-can", label: "Delete", danger: true, run: () => askDelete("question", [key]) }
  ];
}

// ══════════════════════════════════════════════════════════════════════════
//  RESOLVING A SELECTION INTO REAL ITEMS
// ══════════════════════════════════════════════════════════════════════════
function resolveItems(kind, keys) {
  const core = C();
  const out = [];
  keys.forEach(raw => {
    const o = JSON.parse(raw);
    if (o.k === "q") out.push({ sub: o.sub, topic: o.topic, quizKey: o.quizKey, qid: o.qid });
    else if (o.k === "t") out.push.apply(out, core.treeItems({ sub: o.sub, topic: o.name }));
    else if (o.k === "s") out.push.apply(out, core.treeItems({ sub: o.name, topic: core.ALL_TOPICS }));
  });
  return out;
}

function describeSelection(kind, keys) {
  if (kind === "question") return { noun: keys.length === 1 ? "question" : "questions", n: keys.length };
  if (kind === "topic") {
    const n = resolveItems("topic", keys).length;
    return { noun: keys.length === 1 ? "folder" : "folders", n: n, folders: keys.length };
  }
  const n = resolveItems("subject", keys).length;
  return { noun: "questions", n: n, folders: keys.length };
}

// ══════════════════════════════════════════════════════════════════════════
//  MODAL PLUMBING — one busy-spinner contract for all of them
//  Mirrors the save modal in test.html: the action button spins, Cancel and ✕
//  lock for the length of the write, and a finally block guarantees the
//  spinner can never be left stuck on a failure.
// ══════════════════════════════════════════════════════════════════════════
function setBusy(modal, on) {
  opBusy = !!on;
  const go = modal.querySelector(".sv-go, #transferGo");
  const cancel = modal.querySelector(".sv-cancel");
  const x = modal.querySelector(".sv-x");
  if (go) {
    go.classList.toggle("is-busy", !!on);
    go.setAttribute("aria-busy", on ? "true" : "false");
    if (on) go.disabled = true;
  }
  [cancel, x].forEach(b => { if (b) { b.disabled = !!on; b.classList.toggle("exit-locked", !!on); } });
}

function showModal(id) {
  const m = $(id);
  m.style.display = "flex";
  m.classList.remove("sv-in");
  requestAnimationFrame(() => m.classList.add("sv-in"));
  return m;
}
function hideModal(id) { const m = $(id); if (m) { m.style.display = "none"; m.classList.remove("sv-in"); } }

function wireModalChrome(id, onCancel) {
  const m = $(id);
  m.querySelector(".sv-x").onclick = () => { if (opBusy) return; hideModal(id); if (onCancel) onCancel(); };
  m.querySelector(".sv-cancel").onclick = () => { if (opBusy) return; hideModal(id); if (onCancel) onCancel(); };
  // No backdrop-click close: these modals perform destructive or stateful
  // writes, and an accidental tap on the dim area must not dismiss one.
}

// ══════════════════════════════════════════════════════════════════════════
//  DELETE
// ══════════════════════════════════════════════════════════════════════════
let pendingDelete = null;

function askDelete(kind, keys) {
  const d = describeSelection(kind, keys);
  const isFolder = kind !== "question";
  const names = keys.map(k => JSON.parse(k)).map(o => o.name).filter(Boolean);
  $("confirmTitle").textContent = isFolder
    ? (keys.length === 1 ? "Delete this folder?" : "Delete these folders?")
    : (keys.length === 1 ? "Delete this question?" : "Delete these questions?");
  $("confirmMsg").innerHTML = isFolder
    ? '<b>' + esc(names.length === 1 ? names[0] : names.length + " folders") + '</b> and ' +
      '<b>' + d.n + '</b> saved question' + (d.n === 1 ? "" : "s") +
      ' will be deleted permanently.'
    : '<b>' + d.n + '</b> saved question' + (d.n === 1 ? "" : "s") + ' will be deleted permanently.';
  pendingDelete = { kind, keys };
  const m = showModal("confirmModal");
  setBusy(m, false);
  const go = $("confirmGo");
  go.disabled = false;
  go.querySelector(".sv-go-label").innerHTML = '<i class="fa-solid fa-trash-can"></i> Delete' +
    (d.n ? ' (' + d.n + ')' : '');
}

async function runDelete() {
  if (opBusy || !pendingDelete) return;
  const { kind, keys } = pendingDelete;
  const items = resolveItems(kind, keys);
  if (!items.length) { hideModal("confirmModal"); pendingDelete = null; return; }

  const core = C();
  const u = core.user;
  const updates = {};
  // Folder-level removals collapse to ONE null on the subtree; the index still
  // has to be cleared question by question because it is keyed by quiz, not
  // by folder.
  keys.forEach(raw => {
    const o = JSON.parse(raw);
    if (o.k === "s") updates["userSaved/" + u + "/" + o.name] = null;
    else if (o.k === "t") updates["userSaved/" + u + "/" + o.sub + "/" + o.name] = null;
  });
  items.forEach(it => {
    if (kind === "question") updates["userSaved/" + u + "/" + it.sub + "/" + it.topic + "/" + it.quizKey + "/" + it.qid] = null;
    updates["userSavedByQuiz/" + u + "/" + it.quizKey + "/" + it.qid] = null;
  });

  const m = $("confirmModal");
  setBusy(m, true);
  try {
    await core.db.ref().update(updates);
    items.forEach(it => core.treeRemoveQuestion(it.sub, it.topic, it.quizKey, it.qid));
    core.treeRecount();
    pendingDelete = null;
    hideModal("confirmModal");
    exitSelect();
    afterMutation(kind, keys, items, "deleted");
    core.toast(items.length + " question" + (items.length === 1 ? "" : "s") + " deleted");
  } catch (err) {
    console.error("saved: delete failed", err);
    // The modal stays OPEN and the button stops spinning, so this is a retry
    // rather than a dead end — nothing was removed from the tree in memory
    // either, so the screen still matches the database.
    core.toast("Delete failed. Check your connection and try again.");
  } finally {
    setBusy(m, false);
    const go = $("confirmGo"); if (go) go.disabled = false;
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  MOVE  (questions only)
// ══════════════════════════════════════════════════════════════════════════
let pendingMove = null;

function openMove(keys) {
  const items = resolveItems("question", keys);
  if (!items.length) return;
  pendingMove = { keys, items };

  // "Currently in" — one location when every selected question shares it,
  // otherwise an honest "several" rather than a misleading single name.
  const subs = Array.from(new Set(items.map(i => i.sub)));
  const tops = Array.from(new Set(items.map(i => i.topic)));
  $("transferTitle").textContent = keys.length === 1 ? "Move question" : "Move " + keys.length + " questions";
  $("transferCurrent").hidden = false;
  $("curSubject").textContent = subs.length === 1 ? subs[0] : subs.length + " subjects";
  $("curTopic").textContent = tops.length === 1 ? tops[0] : tops.length + " topics";
  $("transferGoLabel").innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> Move' +
    (items.length > 1 ? ' (' + items.length + ')' : '');

  buildTargets({ subject: true, topic: true },
    "Moved questions keep their content and their saved time; only their place in your library changes.");
  showModal("transferModal");
  setBusy($("transferModal"), false);
}

// ══════════════════════════════════════════════════════════════════════════
//  MERGE  (folders)
// ══════════════════════════════════════════════════════════════════════════
let pendingMerge = null;

function openMerge(kind, keys) {
  const items = resolveItems(kind, keys);
  if (!items.length) return;
  pendingMerge = { kind, keys, items };

  const names = keys.map(k => JSON.parse(k).name);
  const isSubject = kind === "subject";
  $("transferTitle").textContent = (keys.length === 1 ? "Merge " : "Merge " + keys.length + " ") +
                                   (isSubject ? "subject" : "folder") + (keys.length === 1 ? "" : "s");
  $("transferCurrent").hidden = false;
  $("curSubject").textContent = isSubject
    ? (names.length === 1 ? names[0] : names.length + " subjects")
    : (keys.map(k => JSON.parse(k).sub).filter((v, i, a) => a.indexOf(v) === i).join(", ") || "—");
  $("curTopic").textContent = isSubject
    ? (resolveItems("subject", keys).map(i => i.topic).filter((v, i, a) => a.indexOf(v) === i).length + " topics")
    : (names.length === 1 ? names[0] : names.length + " folders");
  $("transferGoLabel").innerHTML = '<i class="fa-solid fa-code-merge"></i> Merge' +
    (items.length > 1 ? ' (' + items.length + ')' : '');

  // Merging a subject carries its topics across untouched, so only a subject
  // target is needed. Merging a topic needs both.
  buildTargets({ subject: true, topic: !isSubject },
    isSubject
      ? "Every topic inside the merged subject keeps its own name and moves across with it."
      : "All questions in the merged folders land together in the topic you choose.");
  showModal("transferModal");
  setBusy($("transferModal"), false);
}

// ══════════════════════════════════════════════════════════════════════════
//  THE TARGET PICKERS
//  Filled from the tree already in memory. Opening, typing and filtering cost
//  ZERO Firebase reads — that is an assertion in the test suite, not a claim.
// ══════════════════════════════════════════════════════════════════════════
let pickers = {};

function buildTargets(cfg, note) {
  const host = $("transferTargets");
  host.innerHTML = "";
  pickers = {};
  $("transferNote").textContent = note || "";

  if (cfg.subject) host.appendChild(makePicker("sub", "Subject", () => C().subjectNames(), ""));
  if (cfg.topic)   host.appendChild(makePicker("top", "Topic or Library",
      () => {
        const s = pickers.sub ? pickers.sub.value() : "";
        return s ? C().topicNames(s) : [];
      },
      TOPIC_DEFAULT));

  if (cfg.subject && cfg.topic) {
    // Choosing a subject from the list rescopes the topic list and clears a
    // topic that belonged to the old subject — the same rule the save modal in
    // test.html follows. Merely TYPING only rescopes the list, so a topic the
    // user typed first is not wiped out from under them mid-word.
    pickers.sub.onChoose = () => { pickers.top.setOptions(true); };
    pickers.sub.onPick   = () => { pickers.top.refresh(); };
  }
  validateTargets();
}

function makePicker(id, label, optionsFn, blankMeans) {
  const wrap = document.createElement("div");
  wrap.className = "pk";
  wrap.innerHTML =
    '<label class="pk-label">' + esc(label) +
      (blankMeans ? ' <span class="pk-hint">(blank = ' + esc(blankMeans) + ')</span>' : '') + '</label>' +
    '<div class="pk-row">' +
      '<button type="button" class="pk-select">Select</button>' +
      '<input type="text" class="pk-input" placeholder="Type your ' + esc(label.toLowerCase()) + ' or select" autocomplete="off" autocapitalize="off" spellcheck="false">' +
    '</div>' +
    '<div class="pk-err" hidden></div>' +
    '<div class="pk-list" hidden></div>';

  const input = wrap.querySelector(".pk-input");
  const list = wrap.querySelector(".pk-list");
  const selBtn = wrap.querySelector(".pk-select");
  const errEl = wrap.querySelector(".pk-err");

  const api = {
    el: wrap,
    value: () => input.value.trim(),
    // A picker is only ever fed from memory, so "loading" is instantaneous.
    setOptions: function (clearIfSubjectChanged) {
      if (clearIfSubjectChanged && input.value.trim()) input.value = "";
      render("");
    },
    // Re-render only while the list is actually open, so typing in one picker
    // never pops another picker's dropdown open behind the user's back.
    refresh: function () { if (!list.hidden) render(input.value); },
    onPick: null, onChoose: null,
    valid: () => {
      const bad = C().badKeyChars(input.value);
      if (bad.length) {
        errEl.hidden = false;
        errEl.innerHTML = 'These characters cannot be used: ' +
          bad.map(c => '<span class="pk-pill">' + esc(c === " " ? "space" : c) + '</span>').join("");
        return false;
      }
      errEl.hidden = true;
      return true;
    }
  };

  function render(query) {
    const opts = optionsFn() || [];
    const q = String(query || "").trim().toLowerCase();
    let hits = q ? opts.filter(o => o.toLowerCase().indexOf(q) >= 0) : opts;
    // A typed name that matches nothing is a NEW folder, which is perfectly
    // legal here — but it must not leave the dropdown showing an empty box, or
    // the user has no way to see what already exists. Fall back to the full
    // list instead of a dead end.
    if (q && !hits.length) hits = opts;
    if (!hits.length) { list.hidden = true; list.innerHTML = ""; return; }
    list.innerHTML = hits.slice(0, 60).map(o =>
      '<button type="button" class="pk-opt" data-v="' + esc(o) + '">' + esc(o) + '</button>').join("");
    list.hidden = false;
    list.querySelectorAll(".pk-opt").forEach(b => {
      b.onmousedown = ev => ev.preventDefault();          // keep focus in the input
      b.onclick = ev => {
        ev.stopPropagation();
        input.value = b.getAttribute("data-v");
        list.hidden = true;
        api.valid(); validateTargets();
        if (api.onChoose) api.onChoose();
      };
    });
  }

  selBtn.onclick = ev => {
    ev.stopPropagation();
    if (list.hidden) render(input.value); else list.hidden = true;
  };
  input.addEventListener("input", () => {
    render(input.value);                                  // live search as they type
    api.valid(); validateTargets();
    if (api.onPick) api.onPick();
  });
  input.addEventListener("focus", () => render(input.value));
  input.addEventListener("blur", () => { setTimeout(() => { list.hidden = true; }, 140); });

  pickers[id] = api;
  return wrap;
}

function validateTargets() {
  const go = $("transferGo");
  if (!go) return;
  let okAll = true;
  Object.keys(pickers).forEach(k => { if (!pickers[k].valid()) okAll = false; });
  // A merge or move needs at least a subject; the topic may stay blank, which
  // means the "All Topic" folder exactly as it does when saving.
  if (pickers.sub && !pickers.sub.value()) okAll = false;
  go.disabled = !okAll || opBusy;
}

// close any open picker list on an outside tap
document.addEventListener("click", ev => {
  if (!ev.target.closest(".pk")) Object.keys(pickers).forEach(k => {
    const l = pickers[k].el.querySelector(".pk-list"); if (l) l.hidden = true;
  });
  if (!ev.target.closest(".dot-btn") && !ev.target.closest(".pop-menu")) closeMenu();
}, true);

// ══════════════════════════════════════════════════════════════════════════
//  APPLYING A MOVE / MERGE
// ══════════════════════════════════════════════════════════════════════════
function targetNames() {
  const core = C();
  const rawSub = pickers.sub ? pickers.sub.value() : "";
  const rawTop = pickers.top ? (pickers.top.value() || TOPIC_DEFAULT) : null;
  return {
    rawSub, rawTop,
    subKey: core.fbKey(rawSub),
    topKey: rawTop == null ? null : core.fbKey(rawTop)
  };
}

async function runTransfer() {
  if (opBusy) return;
  const isMove = !!pendingMove;
  const job = isMove ? pendingMove : pendingMerge;
  if (!job) return;

  const core = C();
  const t = targetNames();
  if (!t.subKey) return;
  const u = core.user;

  // Work out WHAT changes before touching the update object, so a no-op can be
  // refused without a write and without a spinner.
  const moves = [];
  job.items.forEach(it => {
    // Merging a subject carries its topics across under their own names; every
    // other transfer lands in the single topic the user chose.
    const dstTopic = (!isMove && job.kind === "subject") ? it.topic : t.topKey;
    if (dstTopic === it.topic && t.subKey === it.sub) return;      // already there
    moves.push({ from: it, to: { sub: t.subKey, topic: dstTopic, quizKey: it.quizKey, qid: it.qid } });
  });
  if (!moves.length) {
    core.toast("That is where they already are.");
    hideModal("transferModal");
    pendingMove = pendingMerge = null;
    return;
  }

  const updates = {};

  // A folder merge empties its source completely, so the whole subtree goes with
  // ONE null rather than one per question — 500 questions become a single path.
  // A question-level move must keep the per-question nulls, because there the
  // source folder usually has survivors.
  const sourcePrefixes = [];
  if (!isMove) {
    job.keys.forEach(raw => {
      const o = JSON.parse(raw);
      const pre = "userSaved/" + u + "/" + (o.k === "s" ? o.name : o.sub + "/" + o.name);
      sourcePrefixes.push(pre + "/");
      updates[pre] = null;
    });
  }
  const covered = p => sourcePrefixes.some(pre => p.indexOf(pre) === 0);

  moves.forEach(mv => {
    const it = mv.from, dst = mv.to;
    const oldPath = "userSaved/" + u + "/" + it.sub + "/" + it.topic + "/" + it.quizKey + "/" + it.qid;
    if (!covered(oldPath)) updates[oldPath] = null;
    updates["userSaved/" + u + "/" + dst.sub + "/" + dst.topic + "/" + it.quizKey + "/" + it.qid] = true;
    // Deep paths, so `at` survives. Replacing the whole entry would reset it,
    // and fbKey(s)/fbKey(t) must keep resolving to the folder it now lives in —
    // test.html rebuilds exactly that path when the user unsaves from a test.
    const ix = "userSavedByQuiz/" + u + "/" + it.quizKey + "/" + it.qid;
    updates[ix + "/s"] = t.rawSub;
    if (isMove || job.kind === "topic") updates[ix + "/t"] = t.rawTop;
  });

  const m = $("transferModal");
  setBusy(m, true);
  try {
    await core.db.ref().update(updates);
    moves.forEach(mv => {
      core.treeRemoveQuestion(mv.from.sub, mv.from.topic, mv.from.quizKey, mv.from.qid);
      core.treeAddQuestion(mv.to.sub, mv.to.topic, mv.to.quizKey, mv.to.qid);
    });
    core.treeRecount();
    const kind = isMove ? "question" : job.kind;
    const keys = job.keys;
    const froms = moves.map(x => x.from);
    pendingMove = pendingMerge = null;
    hideModal("transferModal");
    exitSelect();
    afterMutation(kind, keys, froms, isMove ? "moved" : "merged");
    core.toast(moves.length + " question" + (moves.length === 1 ? "" : "s") + " " + (isMove ? "moved" : "merged"));
  } catch (err) {
    console.error("saved: transfer failed", err);
    core.toast((isMove ? "Move" : "Merge") + " failed. Check your connection and try again.");
  } finally {
    setBusy(m, false);
    validateTargets();
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  AFTER ANY MUTATION — keep the screen truthful
// ══════════════════════════════════════════════════════════════════════════
function afterMutation(kind, keys, items, verb) {
  const core = C();
  const route = core.route;

  if (route.page === "questions") {
    // Walk OUT one level at a time, but only to a parent that still exists.
    // Emptying the last folder of a subject prunes the subject too, and
    // stepping back into a subject that is gone would show a blank screen the
    // user never asked for — so keep walking until something real is found.
    const subjects = core.subjectNames();
    if (route.sub === core.ALL_SUBJECTS) {
      if (!subjects.length) { core.navigateTo({ page: "subjects" }, { replace: true }); return; }
    } else if (subjects.indexOf(route.sub) < 0) {
      core.navigateTo({ page: "subjects" }, { replace: true }); return;
    } else if (route.topic !== core.ALL_TOPICS &&
               core.topicNames(route.sub).indexOf(route.topic) < 0) {
      core.navigateTo({ page: "topics", sub: route.sub }, { replace: true }); return;
    }
    if (!core.collectPairs(route).length) {
      core.navigateTo(route.sub === core.ALL_SUBJECTS ? { page: "subjects" }
                                                      : { page: "topics", sub: route.sub },
                      { replace: true });
      return;
    }
  }
  core.rerender();
}

// ══════════════════════════════════════════════════════════════════════════
//  WIRING
// ══════════════════════════════════════════════════════════════════════════
function initManage() {
  applyHeaderDensity();
  window.addEventListener("resize", () => { applyHeaderDensity(); closeMenu(); });
  window.addEventListener("scroll", closeMenu, true);

  $("ctxClose").onclick = exitSelect;
  $("ctxSelectAll").onclick = selectAllToggle;
  $("ctxDelete").onclick = () => askDelete(selKind, Array.from(SELECTED));
  $("ctxMove").onclick = () => openMove(Array.from(SELECTED));
  $("ctxMerge").onclick = () => openMerge(selKind, Array.from(SELECTED));

  wireModalChrome("confirmModal", () => { pendingDelete = null; });
  wireModalChrome("transferModal", () => { pendingMove = pendingMerge = null; });
  $("confirmGo").onclick = runDelete;
  $("transferGo").onclick = runTransfer;
  $("transferGo").disabled = true;

  // The view-mode modal's buttons are wired here rather than with inline
  // onclick so they are real, testable event listeners.
  document.querySelectorAll("#viewModeModal .vm-choice").forEach(b => {
    b.onclick = () => window.chooseViewMode(b.getAttribute("data-mode"));
  });
  const vmx = document.querySelector("#viewModeModal .vm-x");
  if (vmx) vmx.onclick = () => window.cancelViewMode();

  // saved.js is loaded first and may already have painted a screen before this
  // file arrived, so decorate now — otherwise the very first screen the user
  // sees would have no three-dot menus until they navigated somewhere.
  if (window.SavedCore) window.__savedDecorate();

  // Escape backs out of a menu, then a selection, then a modal.
  document.addEventListener("keydown", ev => {
    if (ev.key !== "Escape" || opBusy) return;
    if (!$("menuLayer").hidden) { closeMenu(); return; }
    if ($("confirmModal").style.display === "flex") { hideModal("confirmModal"); pendingDelete = null; return; }
    if ($("transferModal").style.display === "flex") {
      hideModal("transferModal"); pendingMove = pendingMerge = null; return;
    }
    if (selMode) exitSelect();
  });
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initManage);
else initManage();

// ── exported for the markup and the test suite ──────────────────────────────
Object.assign(window, {
  savedEnterSelect: enterSelect, savedExitSelect: exitSelect, savedToggleSel: toggleSel,
  savedSelectAll: selectAllToggle, savedOpenMove: openMove, savedOpenMerge: openMerge,
  savedAskDelete: askDelete, savedRunDelete: runDelete, savedRunTransfer: runTransfer,
  savedCloseMenu: closeMenu, savedSelState: () => ({
    selMode, selKind, size: SELECTED.size, keys: Array.from(SELECTED)
  }),
  savedTargetNames: targetNames,
  savedValidateTargets: validateTargets,
  savedPickers: () => pickers,
  savedHeaderNarrow: () => document.body.classList.contains("header-narrow"),
  savedResolveItems: resolveItems
});

})();

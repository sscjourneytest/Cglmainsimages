/* ═══════════════════════════════════════════════════════════════════════════
   live-json.js — WEBSITE variant (reduced on purpose)

   The APP version of this file also redefines window.fetchLiveFirst so the APK
   paints from its bundled JSON first and refreshes from the network afterwards.
   The website deliberately does NOT do that: here the "local" file and the
   "live" file are the same file on the same server, and the existing
   live-first loading in js/home-engine.js is left exactly as it was.

   So this file adds ONE thing and changes nothing:

       window.fetchLiveOnly(url, opts)
           Always reads the live website copy and never falls back to a local
           file. Used by the sale / information popup for
           /sale-information.json, which is not bundled anywhere.

   It is guarded, so loading it twice is harmless, and because it does not
   define fetchLiveFirst the guarded copy inside home-engine.js still installs
   and behaves precisely as before.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.__MMH_LIVE_JSON__) return;
    window.__MMH_LIVE_JSON__ = true;

    var LIVE_BASE = String(window.MMH_LIVE_BASE || 'https://mockmatrixhub.in').replace(/\/+$/, '');
    window.MMH_LIVE_BASE = LIVE_BASE;

    function relOf(url) {
        return String(url || '').replace(/^\/+/, '').split('?')[0];
    }

    function liveUrlFor(rel) {
        return LIVE_BASE + '/' + rel;
    }

    function fetchLiveOnly(urlOrRel, opts) {
        var rel = relOf(urlOrRel);
        var o = opts || {};
        if (!o.cache) o.cache = 'no-store';
        return fetch(liveUrlFor(rel) + (liveUrlFor(rel).indexOf('?') >= 0 ? '&' : '?') + 'mmh_live=' + Date.now(), o);
    }

    window.mmhLiveRelOf   = relOf;
    window.mmhLiveUrlFor  = liveUrlFor;
    window.fetchLiveOnly  = fetchLiveOnly;
})();

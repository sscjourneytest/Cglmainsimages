-- ═══════════════════════════════════════════════════════════════════════════
-- MOCK MATRIX HUB · SCORE CALCULATOR & RANK ENGINE
-- COMPLETE SELF-HEALING & IDEMPOTENT SUPABASE DATABASE SCHEMA
-- Overwrites cleanly with ZERO errors even if executed repeatedly
-- ═══════════════════════════════════════════════════════════════════════════

-- 0. CLEANUP ANY PREVIOUS OVERLOADED FUNCTION VERSIONS (PREVENTS ERROR 42725)
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN (
        SELECT proname, pg_get_function_identity_arguments(oid) as args
        FROM pg_proc
        WHERE proname IN ('submit_candidate_data', 'get_all_ranks')
          AND pronamespace = 'public'::regnamespace
    ) LOOP
        EXECUTE format('DROP FUNCTION IF EXISTS public.%I(%s) CASCADE;', r.proname, r.args);
    END LOOP;
END $$;


-- 1. CANDIDATE SUBMISSIONS TABLE
-- Stores 1 row per candidate per exam. Upserts on (exam_id, roll_number).
CREATE TABLE IF NOT EXISTS public.candidate_submissions (
    id BIGSERIAL PRIMARY KEY,
    exam_id VARCHAR(64) NOT NULL,
    shift_id VARCHAR(64) NOT NULL,           -- e.g. "09 sep 2026_10:00 AM (Shift-1)"
    roll_number VARCHAR(64) NOT NULL,
    name VARCHAR(128) DEFAULT 'Candidate',
    category VARCHAR(16) NOT NULL DEFAULT 'UR', -- UR, OBC, SC, ST, EWS
    gender VARCHAR(16) DEFAULT 'NA',        -- Male, Female, Other
    zone VARCHAR(64),                       -- Railway zone (Ajmer, Ahmedabad, Patna, etc.)
    state VARCHAR(64),                      -- Candidate state for SSC
    total_score NUMERIC(6, 2) NOT NULL,
    total_questions INT DEFAULT 0,          -- Total questions in paper
    attempted INT DEFAULT 0,                -- Number of questions attempted
    correct_count INT DEFAULT 0,            -- Correct answers (+)
    wrong_count INT DEFAULT 0,              -- Incorrect answers (-)
    skip_count INT DEFAULT 0,               -- Skipped questions
    bonus_count INT DEFAULT 0,              -- Bonus / challenged questions
    section_scores JSONB,                   -- Complete section-wise marks breakdown array
    answer_key_url TEXT,                    -- Raw official answer key URL
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_candidate_submission UNIQUE (exam_id, roll_number)
);

-- Safe column additions if table was created earlier without breakdown columns
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS total_questions INT DEFAULT 0;
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS attempted INT DEFAULT 0;
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS correct_count INT DEFAULT 0;
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS wrong_count INT DEFAULT 0;
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS skip_count INT DEFAULT 0;
ALTER TABLE public.candidate_submissions ADD COLUMN IF NOT EXISTS bonus_count INT DEFAULT 0;

-- Compound B-Tree Indexes for sub-5ms rank counting & filtering
CREATE INDEX IF NOT EXISTS idx_subm_air   ON public.candidate_submissions (exam_id, total_score DESC);
CREATE INDEX IF NOT EXISTS idx_subm_cat   ON public.candidate_submissions (exam_id, category, total_score DESC);
CREATE INDEX IF NOT EXISTS idx_subm_shift ON public.candidate_submissions (exam_id, shift_id, total_score DESC);
CREATE INDEX IF NOT EXISTS idx_subm_zone  ON public.candidate_submissions (exam_id, zone, total_score DESC) WHERE zone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_subm_state ON public.candidate_submissions (exam_id, state, total_score DESC) WHERE state IS NOT NULL;


-- 2. QUESTION ANALYTICS TABLE (Admin / Internal Only)
-- Compact aggregated counters: Only 1 row per question per shift!
-- 100 questions x 30 shifts = only 3,000 rows total (< 1 MB storage).
CREATE TABLE IF NOT EXISTS public.exam_question_stats (
    exam_id VARCHAR(64) NOT NULL,
    shift_id VARCHAR(64) NOT NULL,
    question_key VARCHAR(64) NOT NULL,      -- SSC: Question Number ("1", "2"...) | RRB: official question_id
    section_name VARCHAR(64),
    correct_count INT DEFAULT 0,
    wrong_count INT DEFAULT 0,
    skip_count INT DEFAULT 0,
    PRIMARY KEY (exam_id, shift_id, question_key)
);

-- Fix Question 1 test artifact if it was incremented during initial testing
UPDATE public.exam_question_stats
SET section_name = 'PART-A (General Intelligence & Reasoning)',
    correct_count = 1
WHERE exam_id = 'ssc-steno' AND question_key = '1' AND correct_count > 1;


-- 3. STORED PROCEDURE: ATOMIC SUBMISSION & QUESTION BATCH COUNTER
-- Upserts candidate score data and updates question stats in 1 single transaction.
CREATE OR REPLACE FUNCTION public.submit_candidate_data(
    p_exam_id VARCHAR,
    p_shift_id VARCHAR,
    p_roll_number VARCHAR,
    p_name VARCHAR,
    p_category VARCHAR,
    p_gender VARCHAR,
    p_zone VARCHAR,
    p_state VARCHAR,
    p_total_score NUMERIC,
    p_total_questions INT,
    p_attempted INT,
    p_correct_count INT,
    p_wrong_count INT,
    p_skip_count INT,
    p_bonus_count INT,
    p_section_scores JSONB,
    p_answer_key_url TEXT,
    p_questions JSONB                       -- Array: [{"q": "1", "sec": "Maths", "s": "correct"|"wrong"|"skipped"}]
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_is_new_candidate BOOLEAN := FALSE;
    q_elem JSONB;
BEGIN
    -- Check if this candidate is submitting for the first time for this exam
    SELECT NOT EXISTS (
        SELECT 1 FROM public.candidate_submissions 
        WHERE exam_id = p_exam_id AND roll_number = p_roll_number
    ) INTO v_is_new_candidate;

    -- 1. Upsert candidate submission (Enforces 1 unique row per candidate per exam)
    INSERT INTO public.candidate_submissions (
        exam_id, shift_id, roll_number, name, category, gender, zone, state,
        total_score, total_questions, attempted, correct_count, wrong_count, skip_count, bonus_count,
        section_scores, answer_key_url, updated_at
    ) VALUES (
        p_exam_id, p_shift_id, p_roll_number, p_name, p_category, p_gender, p_zone, p_state,
        p_total_score, p_total_questions, p_attempted, p_correct_count, p_wrong_count, p_skip_count, p_bonus_count,
        p_section_scores, p_answer_key_url, NOW()
    )
    ON CONFLICT (exam_id, roll_number) DO UPDATE SET
        shift_id = EXCLUDED.shift_id,
        name = EXCLUDED.name,
        category = EXCLUDED.category,
        gender = EXCLUDED.gender,
        zone = EXCLUDED.zone,
        state = EXCLUDED.state,
        total_score = EXCLUDED.total_score,
        total_questions = EXCLUDED.total_questions,
        attempted = EXCLUDED.attempted,
        correct_count = EXCLUDED.correct_count,
        wrong_count = EXCLUDED.wrong_count,
        skip_count = EXCLUDED.skip_count,
        bonus_count = EXCLUDED.bonus_count,
        section_scores = EXCLUDED.section_scores,
        answer_key_url = EXCLUDED.answer_key_url,
        updated_at = NOW();

    -- 2. Update question stats ONLY for new candidates (Prevents double counting on recalculate)
    IF v_is_new_candidate AND p_questions IS NOT NULL AND jsonb_array_length(p_questions) > 0 THEN
        FOR q_elem IN SELECT * FROM jsonb_array_elements(p_questions) LOOP
            INSERT INTO public.exam_question_stats (
                exam_id, shift_id, question_key, section_name,
                correct_count, wrong_count, skip_count
            ) VALUES (
                p_exam_id,
                p_shift_id,
                q_elem->>'q',
                q_elem->>'sec',
                CASE WHEN q_elem->>'s' = 'correct' THEN 1 ELSE 0 END,
                CASE WHEN q_elem->>'s' = 'wrong' THEN 1 ELSE 0 END,
                CASE WHEN q_elem->>'s' = 'skipped' THEN 1 ELSE 0 END
            )
            ON CONFLICT (exam_id, shift_id, question_key) DO UPDATE SET
                section_name = EXCLUDED.section_name,
                correct_count = exam_question_stats.correct_count + (CASE WHEN q_elem->>'s' = 'correct' THEN 1 ELSE 0 END),
                wrong_count = exam_question_stats.wrong_count + (CASE WHEN q_elem->>'s' = 'wrong' THEN 1 ELSE 0 END),
                skip_count = exam_question_stats.skip_count + (CASE WHEN q_elem->>'s' = 'skipped' THEN 1 ELSE 0 END);
        END LOOP;
    END IF;

    RETURN jsonb_build_object('ok', true, 'is_new', v_is_new_candidate);
END;
$$;


-- 4. STORED PROCEDURE: REALTIME RANK & AVERAGE CALCULATION (SINGLE ROUND TRIP)
-- Computes AIR, Shift, Category, and Zone ranks + percentiles + averages in < 5ms.
CREATE OR REPLACE FUNCTION public.get_all_ranks(
    p_exam_id VARCHAR,
    p_shift_id VARCHAR,
    p_category VARCHAR,
    p_gender VARCHAR,
    p_zone VARCHAR,
    p_score NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_air_rank INT;
    v_air_total INT;
    v_air_avg NUMERIC(6, 2);
    v_air_pct NUMERIC(6, 2);

    v_cat_rank INT;
    v_cat_total INT;
    v_cat_avg NUMERIC(6, 2);

    v_shift_rank INT;
    v_shift_total INT;
    v_shift_avg NUMERIC(6, 2);
    v_shift_pct NUMERIC(6, 2);

    v_zone_rank INT;
    v_zone_total INT;
    v_zone_avg NUMERIC(6, 2);
BEGIN
    -- 1. All-India Rank + Total Candidates + Overall Average Score + Overall Percentile
    SELECT 
        COUNT(*) FILTER (WHERE total_score > p_score) + 1,
        COUNT(*),
        ROUND(COALESCE(AVG(total_score), 0), 2)
    INTO v_air_rank, v_air_total, v_air_avg 
    FROM public.candidate_submissions 
    WHERE exam_id = p_exam_id;

    v_air_pct := CASE WHEN v_air_total > 1 THEN ROUND((((v_air_total - v_air_rank)::NUMERIC / v_air_total::NUMERIC) * 100.0), 2)
                      WHEN v_air_total = 1 THEN 100.00
                      ELSE 0.00 END;

    -- 2. Shift Rank + Shift Total + Shift Average Score + Shift Percentile
    SELECT 
        COUNT(*) FILTER (WHERE total_score > p_score) + 1,
        COUNT(*),
        ROUND(COALESCE(AVG(total_score), 0), 2)
    INTO v_shift_rank, v_shift_total, v_shift_avg 
    FROM public.candidate_submissions 
    WHERE exam_id = p_exam_id AND shift_id = p_shift_id;

    v_shift_pct := CASE WHEN v_shift_total > 1 THEN ROUND((((v_shift_total - v_shift_rank)::NUMERIC / v_shift_total::NUMERIC) * 100.0), 2)
                        WHEN v_shift_total = 1 THEN 100.00
                        ELSE 0.00 END;

    -- 3. Category Rank + Category Total + Category Average Score
    SELECT 
        COUNT(*) FILTER (WHERE total_score > p_score) + 1,
        COUNT(*),
        ROUND(COALESCE(AVG(total_score), 0), 2)
    INTO v_cat_rank, v_cat_total, v_cat_avg 
    FROM public.candidate_submissions 
    WHERE exam_id = p_exam_id AND category = p_category;

    -- 4. Railway Zone Rank + Zone Total + Zone Average Score (If Zone selected)
    IF p_zone IS NOT NULL AND p_zone <> '' AND p_zone <> 'None' THEN
        SELECT 
            COUNT(*) FILTER (WHERE total_score > p_score) + 1,
            COUNT(*),
            ROUND(COALESCE(AVG(total_score), 0), 2)
        INTO v_zone_rank, v_zone_total, v_zone_avg 
        FROM public.candidate_submissions 
        WHERE exam_id = p_exam_id AND zone = p_zone;
    END IF;

    RETURN jsonb_build_object(
        'air', jsonb_build_object('rank', v_air_rank, 'total', v_air_total, 'avg', v_air_avg, 'percentile', v_air_pct),
        'shift', jsonb_build_object('rank', v_shift_rank, 'total', v_shift_total, 'avg', v_shift_avg, 'percentile', v_shift_pct),
        'category', jsonb_build_object('rank', v_cat_rank, 'total', v_cat_total, 'avg', v_cat_avg, 'label', p_category),
        'zone', CASE WHEN p_zone IS NOT NULL AND p_zone <> '' AND p_zone <> 'None'
                     THEN jsonb_build_object('rank', v_zone_rank, 'total', v_zone_total, 'avg', v_zone_avg, 'label', p_zone) 
                     ELSE NULL END
    );
END;
$$;


-- 5. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.candidate_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_question_stats ENABLE ROW LEVEL SECURITY;

-- Allow public users (via anon key) to submit/upsert their score
DROP POLICY IF EXISTS "Allow public insert to submissions" ON public.candidate_submissions;
CREATE POLICY "Allow public insert to submissions"
ON public.candidate_submissions FOR INSERT
TO anon
WITH CHECK (true);

-- Block public users from browsing or reading other candidates' raw rows or URLs
DROP POLICY IF EXISTS "Deny public select on raw submissions" ON public.candidate_submissions;
CREATE POLICY "Deny public select on raw submissions"
ON public.candidate_submissions FOR SELECT
TO anon
USING (false);

-- Question analytics are strictly private (Admin / service_role only)
DROP POLICY IF EXISTS "Admin only for question analytics" ON public.exam_question_stats;
CREATE POLICY "Admin only for question analytics"
ON public.exam_question_stats FOR ALL
TO service_role
USING (true);

-- 6. PERMISSIONS (SPECIFIC SIGNATURES TO PREVENT AMBIGUITY ERRORS)
GRANT EXECUTE ON FUNCTION public.submit_candidate_data(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR,
    NUMERIC, INT, INT, INT, INT, INT, INT, JSONB, TEXT, JSONB
) TO anon, authenticated, service_role;

GRANT EXECUTE ON FUNCTION public.get_all_ranks(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, NUMERIC
) TO anon, authenticated, service_role;

-- Catch-all grant to ensure PostgREST exposes public functions to anon API
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO anon, authenticated, service_role;

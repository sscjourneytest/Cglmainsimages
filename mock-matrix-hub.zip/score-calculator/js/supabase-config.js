/* ═══════════════════════════════════════════════════════════════════════
   MOCK MATRIX HUB · SUPABASE LIVE CONFIGURATION
   Project: ssvruparam141's Project (rankmockmatrixhub)
   Connected: Direct PostgREST / RPC Client
   ═══════════════════════════════════════════════════════════════════════ */

window.MMH_SUPABASE_URL = "https://hverewyohweodqnomnex.supabase.co";

window.MMH_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2ZXJld3lvaHdlb2Rxbm9tbmV4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA0OTIzNTQsImV4cCI6MjEwNjA2ODM1NH0.iUAl7aqC3RIKm-K0F7lJakuP15lh_Li4jEVmtc8FAIg";

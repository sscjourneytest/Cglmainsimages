/* ═══════════════════════════════════════════════════════════════════════
   MOCK MATRIX HUB · SCORE CALCULATOR ENGINE
   Official Response Sheet Evaluation Engine & Interactive UI
   Real server API integration, responsive layout & A4 print scorecard
═══════════════════════════════════════════════════════════════════════ */

// Global State
var _activeExamTab = 'rrb';
var _scoreData = null;
var _scoreSubmissionId = null;
var _currentExamName = '';
var _canonicalExamKey = '';
var _isCustomMarking = false;
var _rawResultData = null; // Stashes raw parts/html for Review & PDF Print

var _examsData = { ssc: null, rrb: null, other: null };
var _selectedExamConfig = null;

// Supabase Direct REST/RPC Configuration (No Worker proxy required)
var SUPABASE_CONFIG = {
  url: window.MMH_SUPABASE_URL || 'https://hverewyohweodqnomnex.supabase.co',
  anonKey: window.MMH_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2ZXJld3lvaHdlb2Rxbm9tbmV4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA0OTIzNTQsImV4cCI6MjEwNjA2ODM1NH0.iUAl7aqC3RIKm-K0F7lJakuP15lh_Li4jEVmtc8FAIg'
};

// Built-in fallback exams if JSON fetch is unreachable
var _fallbackExams = {
  ssc: [
    { id: "ssc-cgl-tier1", title: "SSC CGL — Tier I", correct: 2, wrong: 0.5, parts: 4 },
    { id: "ssc-cgl-tier2", title: "SSC CGL — Tier II", correct: 3, wrong: 1, parts: 3 },
    { id: "ssc-chsl-tier1", title: "SSC CHSL — Tier I", correct: 2, wrong: 0.5, parts: 4 },
    { id: "ssc-chsl-tier2", title: "SSC CHSL — Tier II", correct: 3, wrong: 1, parts: 1 },
    { id: "ssc-cpo-tier1", title: "SSC CPO — Paper I", correct: 1, wrong: 0.25, parts: 4 },
    { id: "ssc-gd", title: "SSC GD Constable", correct: 2, wrong: 0.25, parts: 4 },
    { id: "ssc-mts", title: "SSC MTS / Havaldar", correct: 1, wrong: 0.25, parts: 4 },
    { id: "ssc-je", title: "SSC JE", correct: 1, wrong: 0.25, parts: 3 },
    { id: "ssc-steno", title: "SSC Stenographer (Gr. C & D)", correct: 1, wrong: 0.25, parts: 3 },
    { id: "ssc-selection-post", title: "SSC Selection Post", correct: 1, wrong: 0.25, parts: 4 }
  ],
  rrb: [
    { id: "rrb-groupd", title: "RRB Level 1 / Group D", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-ntpc-ug-cbt1", title: "RRB NTPC (UG / Graduate) — CBT I", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-ntpc-ug-cbt2", title: "RRB NTPC (UG / Graduate) — CBT II", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-alp-cbt1", title: "RRB ALP — CBT I", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-technician", title: "RRB Technician", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-je-cbt1", title: "RRB JE — CBT I", correct: 1, wrong: 0.3333, parts: 1 },
    { id: "rrb-paramedical", title: "RRB Paramedical Staff", correct: 1, wrong: 0.3333, parts: 1 }
  ],
  other: [
    { id: "other-state-psc", title: "State PSC Examination", correct: 1.0, wrong: 0.333, parts: 1 },
    { id: "other-police", title: "Police SI / Constable Exam", correct: 2.0, wrong: 0.5, parts: 1 },
    { id: "other-teaching", title: "Teaching Examination (CTET / DSSSB)", correct: 1.0, wrong: 0.25, parts: 1 },
    { id: "other-defence", title: "Defence / Paramilitary Forces Exam", correct: 2.0, wrong: 0.5, parts: 1 }
  ]
};

// Safe string escape
function esc(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Short ID helper
function _shortIdFromUuid(uid) {
  if (!uid || uid.length < 12) return uid || ('MMH-' + Date.now().toString(36).toUpperCase());
  var hex = uid.replace(/-/g, '').slice(0, 12);
  var alpha = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  try {
    var n = BigInt("0x" + hex);
    var out = "";
    while (n > 0n) {
      var r = Number(n % 62n);
      out = alpha[r] + out;
      n = n / 62n;
    }
    while (out.length < 8) out = "0" + out;
    return 'MMH-' + out;
  } catch (e) {
    return 'MMH-' + hex.slice(0, 8).toUpperCase();
  }
}

// ── Viewport & Desktop View Manager ─────────────────────────────────
// Simulates desktop site mode (width=1024, user-scalable=yes) when scorecard is displayed
// Reverts to standard mobile responsive viewport on form view
function enableScorecardDesktopView(enable) {
  var vp = document.getElementById('mmhViewport') || document.querySelector('meta[name="viewport"]');
  if (!vp) {
    vp = document.createElement('meta');
    vp.id = 'mmhViewport';
    vp.name = 'viewport';
    document.head.appendChild(vp);
  }

  if (enable) {
    document.documentElement.classList.add('scorecard-desktop-mode');
    document.body.classList.add('scorecard-desktop-mode');
    document.documentElement.classList.remove('form-responsive-mode');
    document.body.classList.remove('form-responsive-mode');

    // Simulate desktop site mode: width=1024, user-scalable=yes
    vp.setAttribute('content', 'width=1024, user-scalable=yes');
  } else {
    document.documentElement.classList.remove('scorecard-desktop-mode');
    document.body.classList.remove('scorecard-desktop-mode');
    document.documentElement.classList.add('form-responsive-mode');
    document.body.classList.add('form-responsive-mode');

    // Revert to standard mobile responsive viewport
    vp.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover');
  }
}
window.enableScorecardDesktopView = enableScorecardDesktopView;

// ── Exam Dynamic Selection & Marking Scheme Loader ──────────────────
async function loadExamsForCategory(cat, targetExamId) {
  var sel = document.getElementById('scoreExamSelect');
  if (!sel) return;

  var list = _examsData[cat];
  if (!list) {
    try {
      var res = await fetch('/score-calculator/data/exams-' + cat + '.json');
      if (res.ok) {
        list = await res.json();
        list.forEach(function(item) {
          if (!item.title && item.name) item.title = item.name;
          if (item.marksPerCorrect != null && item.correct == null) item.correct = item.marksPerCorrect;
          if (item.negativePerWrong != null && item.wrong == null) item.wrong = item.negativePerWrong;
        });
        _examsData[cat] = list;
      }
    } catch (e) {
      console.warn('Failed loading exams JSON for ' + cat, e);
    }
  }

  if (!list || !list.length) {
    list = _fallbackExams[cat] || [];
    _examsData[cat] = list;
  }

  sel.innerHTML = '';

  // Default unselected placeholder option
  var defaultOpt = document.createElement('option');
  defaultOpt.value = '';
  defaultOpt.disabled = true;
  defaultOpt.textContent = '-- Select Your Examination --';
  sel.appendChild(defaultOpt);

  var targetMatch = null;
  var effTargetId = targetExamId || (_scoreData && _scoreData.exam_id) || '';
  if (effTargetId) {
    var t = String(effTargetId).toLowerCase().trim();
    targetMatch = list.find(function(item) {
      var id = (item.id || '').toLowerCase();
      return id === t || t.indexOf(id) !== -1 || id.indexOf(t) !== -1;
    });
  }

  list.forEach(function(item) {
    var opt = document.createElement('option');
    opt.value = item.id;
    // Pure clean title — NO marking scheme in dropdown text
    opt.textContent = item.title || item.name || item.id;
    if (targetMatch && item.id === targetMatch.id) {
      opt.selected = true;
    }
    sel.appendChild(opt);
  });

  if (targetMatch) {
    sel.value = targetMatch.id;
    _selectedExamConfig = targetMatch;
    _currentExamName = targetMatch.title || targetMatch.name || targetMatch.id;
  } else {
    defaultOpt.selected = true;
    sel.value = '';
    _selectedExamConfig = null;
    _currentExamName = '';
  }

  onExamSelectChange();
}

function onExamSelectChange() {
  var sel = document.getElementById('scoreExamSelect');
  if (!sel) return;
  var val = sel.value;
  if (!val) {
    _selectedExamConfig = null;
    _currentExamName = '';
    return;
  }
  var list = _examsData[_activeExamTab] || _fallbackExams[_activeExamTab] || [];
  var found = list.find(function(item) { return item.id === val; });
  _selectedExamConfig = found || null;
  if (_selectedExamConfig) {
    _currentExamName = _selectedExamConfig.title || _selectedExamConfig.name || '';
  }
  var err = document.getElementById('urlError');
  if (err && val) err.style.display = 'none';
}

// ── Exam Category Switcher ──────────────────────────────────────────
function switchExamCategory(cat, targetExamId) {
  _activeExamTab = cat || 'rrb';

  var tabSsc = document.getElementById('tabSsc');
  var tabRrb = document.getElementById('tabRrb');
  var tabOther = document.getElementById('tabOther');
  var zoneGroup = document.getElementById('rrbZoneGroup');
  var titleEl = document.getElementById('formFamilyTitle');
  var subEl = document.getElementById('formFamilySub');
  var logoEl = document.getElementById('formExamLogo');
  var urlInput = document.getElementById('scoreUrl');
  var docTitle = document.getElementById('docTitle');

  if (tabSsc) tabSsc.classList.toggle('active', cat === 'ssc');
  if (tabRrb) tabRrb.classList.toggle('active', cat === 'rrb');
  if (tabOther) tabOther.classList.toggle('active', cat === 'other');

  var howCard = document.getElementById('howCleanCard');
  var howTitle = document.getElementById('howCardTitle');

  if (cat === 'rrb') {
    if (zoneGroup) zoneGroup.style.display = '';
    if (titleEl) titleEl.textContent = 'Railway Exams Score Calculator';
    if (subEl) subEl.textContent = 'RRB Group D, NTPC, ALP & Technician Official Evaluation';
    if (logoEl) logoEl.src = '/score-calculator/railway-logo.jpg';
    if (urlInput) urlInput.placeholder = 'Paste RRB URL (https://rrb.digialm.com...)';
    if (docTitle) docTitle.textContent = 'Railway Score Calculator — Mock Matrix Hub';
    if (howCard) howCard.style.borderLeftColor = '#dc2626';
    if (howTitle) howTitle.textContent = 'How to Check Your Railway RRB Score';
  } else if (cat === 'ssc') {
    if (zoneGroup) zoneGroup.style.display = 'none';
    if (titleEl) titleEl.textContent = 'SSC Exam Score Calculator';
    if (subEl) subEl.textContent = 'SSC CGL, CHSL, GD, MTS & CPO Official Evaluation';
    if (logoEl) logoEl.src = '/score-calculator/ssc-logo.jpg';
    if (urlInput) urlInput.placeholder = 'Paste SSC URL (https://ssc.digialm.com...)';
    if (docTitle) docTitle.textContent = 'SSC Score Calculator — Mock Matrix Hub';
    if (howCard) howCard.style.borderLeftColor = '#2563eb';
    if (howTitle) howTitle.textContent = 'How to Check Your SSC Score';
  } else {
    if (zoneGroup) zoneGroup.style.display = 'none';
    if (titleEl) titleEl.textContent = 'Other Govt Exams Score Calculator';
    if (subEl) subEl.textContent = 'State PSC, Police SI & Defence Exam Evaluation';
    if (logoEl) logoEl.src = '/score-calculator/logo.jpg';
    if (urlInput) urlInput.placeholder = 'Paste Exam URL (https://...digialm.com...)';
    if (docTitle) docTitle.textContent = 'Score Calculator — Mock Matrix Hub';
    if (howCard) howCard.style.borderLeftColor = '#475569';
    if (howTitle) howTitle.textContent = 'How to Check Your Score';
  }

  if (typeof switchHowGuideLang === 'function') {
    switchHowGuideLang(_howGuideLang || 'en');
  }

  // Populate dynamic exam dropdown and set active exam
  loadExamsForCategory(cat, targetExamId);

  // Sync URL query parameter without full reload
  try {
    var u = new URL(window.location.href);
    u.searchParams.set('exam', targetExamId || cat);
    window.history.replaceState({}, '', u.toString());
  } catch (e) {}

  // ── Tab Switch Cache Isolation ──
  // Check if this specific category has its own cached score
  var cached = getScorecardCache(null, cat);
  var panel = document.getElementById('scorecardPanel');
  var formCard = document.getElementById('scoreFormCard');

  if (cached && cached.scoreData) {
    restoreFromScorecardCache(cached);
  } else {
    enableScorecardDesktopView(false);
    // No saved result for this category: hide scorecard, show input form card
    if (panel) panel.classList.add('hidden');
    if (formCard) {
      formCard.style.display = 'block';
      formCard.style.opacity = '1';
    }
    _scoreData = null;
    _rawResultData = null;
    var banner = document.getElementById('cacheNoticeBanner');
    if (banner) banner.remove();

    // Clear previous validation error on tab switch (preserve user-pasted URL)
    var errEl = document.getElementById('urlError');
    if (errEl) errEl.style.display = 'none';
  }
}

// Flag to permit sample demo paper evaluation ONLY when filled via Try Demo button
var _isDemoUrlFilled = false;

// ── Quick Form Actions ──────────────────────────────────────────────
function fillDemoUrl() {
  _isDemoUrlFilled = true;
  switchExamCategory('rrb', 'rrb-groupd');
  var urlEl = document.getElementById('scoreUrl');
  if (urlEl) {
    urlEl.value = 'https://rrb.digialm.com//per/g06/pub/sample-demo-paper.html';
    urlEl.focus();
  }
  var cat = document.getElementById('scoreCategory');
  if (cat) cat.value = 'UR';
  var st = document.getElementById('scoreState');
  if (st) st.value = 'Rajasthan';
  var zn = document.getElementById('scoreRrbZone');
  if (zn) zn.value = '';
  var gd = document.getElementById('scoreGender');
  if (gd) gd.value = 'Male';
}

function clearUrlInput() {
  var urlEl = document.getElementById('scoreUrl');
  if (urlEl) {
    urlEl.value = '';
    urlEl.focus();
  }
}

function showInputForm() {
  enableScorecardDesktopView(false);
  var formCard = document.getElementById('scoreFormCard');
  if (formCard) {
    formCard.style.display = 'block';
    formCard.style.opacity = '1';
    formCard.scrollIntoView({ behavior: 'smooth' });
    var urlEl = document.getElementById('scoreUrl');
    if (urlEl && typeof urlEl.focus === 'function') urlEl.focus();
  }
}

async function pasteFromClipboard() {
  try {
    if (navigator.clipboard && navigator.clipboard.readText) {
      var t = await navigator.clipboard.readText();
      if (t) {
        var u = document.getElementById('scoreUrl');
        if (u) {
          u.value = t.trim();
          u.focus();
        }
        return;
      }
    }
  } catch (e) {}
  _showToast('Press Ctrl+V to paste your response sheet URL', 'info');
}

function toggleCustomMarking() {
  var mc = document.getElementById('markingCard');
  if (mc) {
    mc.classList.toggle('hidden');
    if (!mc.classList.contains('hidden')) {
      var cIn = document.getElementById('overrideCorrect');
      var iIn = document.getElementById('overrideIncorrect');
      if (cIn && !cIn.value) {
        cIn.value = (_selectedExamConfig && _selectedExamConfig.correct != null)
          ? _selectedExamConfig.correct
          : (_activeExamTab === 'ssc' ? 2.0 : 1.0);
      }
      if (iIn && !iIn.value) {
        iIn.value = (_selectedExamConfig && _selectedExamConfig.wrong != null)
          ? _selectedExamConfig.wrong
          : (_activeExamTab === 'ssc' ? 0.5 : 0.3333);
      }
      mc.scrollIntoView({ behavior: 'smooth' });
    }
  }
}

// ── Animated Evaluation Progress ────────────────────────────────────
var _evalTimers = [];

function clearEvaluationTimers() {
  _evalTimers.forEach(function(t) { clearTimeout(t); });
  _evalTimers = [];
}

function startEvaluationAnimation(isSsc) {
  clearEvaluationTimers();

  var card = document.getElementById('calcProcessingCard');
  var formCard = document.getElementById('scoreFormCard');
  if (card) {
    card.style.display = 'block';
    setTimeout(function() {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 40);
  }
  if (formCard) formCard.style.opacity = '0.45';

  var ticker = document.getElementById('evalProgressTicker');
  var fill = document.getElementById('evalBarFill');

  for (var i = 1; i <= 5; i++) {
    var step = document.getElementById('evalStep' + i);
    if (step) step.className = 'eval-step-item' + (i === 1 ? ' active' : '');
  }
  if (fill) fill.style.width = '12%';

  var step1Txt = document.getElementById('stepTxt1');
  if (step1Txt) step1Txt.textContent = isSsc ? 'Fetching answer key parts' : 'Fetching response sheet';

  var stages = isSsc ? [
    { t: 0,     pct: 15, step: 1, msg: 'Fetching answer key part 1...' },
    { t: 900,   pct: 28, step: 1, msg: 'Fetching answer key part 2...' },
    { t: 1800,  pct: 42, step: 1, msg: 'Fetching answer key part 3...' },
    { t: 2700,  pct: 55, step: 1, msg: 'Fetching answer key part 4...' },
    { t: 3700,  pct: 68, step: 2, msg: 'Evaluating questions and responses...' },
    { t: 5100,  pct: 82, step: 3, msg: 'Calculating marks and performance...' },
    { t: 6600,  pct: 90, step: 4, msg: 'Computing rank and percentiles...' },
    { t: 8400,  pct: 93, step: 1, msg: 'Fetching answer key parts again...' },
    { t: 10500, pct: 96, step: 2, msg: 'Verifying all response sheet parts...' },
    { t: 12800, pct: 98, step: 5, msg: 'Generating candidate scorecard...' }
  ] : [
    { t: 0,     pct: 22, step: 1, msg: 'Fetching candidate response sheet...' },
    { t: 1200,  pct: 52, step: 2, msg: 'Evaluating questions and responses...' },
    { t: 2800,  pct: 75, step: 3, msg: 'Calculating marks and performance...' },
    { t: 4400,  pct: 88, step: 4, msg: 'Computing rank and percentiles...' },
    { t: 6400,  pct: 93, step: 1, msg: 'Fetching response sheet again...' },
    { t: 8600,  pct: 96, step: 2, msg: 'Verifying candidate responses...' },
    { t: 10800, pct: 98, step: 5, msg: 'Generating candidate scorecard...' }
  ];

  stages.forEach(function(s) {
    var tid = setTimeout(function() {
      if (!_scoreData) {
        if (ticker) ticker.textContent = s.msg;
        if (fill) fill.style.width = s.pct + '%';

        for (var i = 1; i <= 5; i++) {
          var el = document.getElementById('evalStep' + i);
          if (el) {
            if (i < s.step) el.className = 'eval-step-item done';
            else if (i === s.step) el.className = 'eval-step-item active';
            else el.className = 'eval-step-item';
          }
        }
      }
    }, s.t);
    _evalTimers.push(tid);
  });
}

function stopEvaluationAnimation() {
  clearEvaluationTimers();
  var card = document.getElementById('calcProcessingCard');
  if (card) card.style.display = 'none';

  var formCard = document.getElementById('scoreFormCard');
  if (formCard) formCard.style.opacity = '1';

  var fill = document.getElementById('evalBarFill');
  if (fill) fill.style.width = '100%';
}

// ── Number Counter Animation ────────────────────────────────────────
function animateScoreCount(el, target, duration) {
  if (!el) return;
  var currentVal = parseFloat(el.textContent);
  var start = isNaN(currentVal) ? 0 : currentVal;
  var startTime = null;
  target = parseFloat(target);
  if (isNaN(target)) target = 0;
  duration = duration || 500;

  function step(timestamp) {
    if (!startTime) startTime = timestamp;
    var progress = Math.min((timestamp - startTime) / duration, 1);
    var ease = 1 - Math.pow(1 - progress, 3);
    var current = (start + (target - start) * ease);
    el.textContent = current.toFixed(current % 1 === 0 ? 1 : 2);
    if (progress < 1) {
      window.requestAnimationFrame(step);
    } else {
      el.textContent = target.toFixed(target % 1 === 0 ? 1 : 2);
    }
  }
  window.requestAnimationFrame(step);
}

// ── Render Complete Candidate Details ───────────────────────────────
function renderStudentInfo(student, data) {
  var examTitleEl = document.getElementById('cardExamTitle');
  var examSubEl = document.getElementById('cardExamSub');
  var examLogoEl = document.getElementById('cardExamLogo');
  var printLogoEl = document.getElementById('printAuthorityLogo');
  var container = document.getElementById('candidateInfoGrid');

  var examName = student.exam || student.exam_name || 'Official Examination';
  if (examTitleEl) examTitleEl.textContent = examName;
  if (examSubEl) examSubEl.textContent = (student.exam_date || student.date || 'Exam Date') + ' · ' + (student.exam_time || student.time || 'Official Shift');

  var isSsc = _activeExamTab === 'ssc' || examName.toLowerCase().includes('ssc');
  var isRrb = _activeExamTab === 'rrb' || examName.toLowerCase().includes('rrb') || examName.toLowerCase().includes('railway');

  var authLogo = isSsc ? '/score-calculator/ssc-logo.jpg' : (isRrb ? '/score-calculator/railway-logo.jpg' : '/score-calculator/logo.jpg');
  if (examLogoEl) examLogoEl.src = authLogo;
  if (printLogoEl) printLogoEl.src = authLogo;

  function cleanVal(v) {
    if (!v) return '';
    return String(v)
      .replace(/&amp;/gi, '&')
      .replace(/&mp;/gi, '&')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  var fields = [
    ['Candidate Name', cleanVal(student.name || 'Aspirant XYZ')],
    ['Roll Number', cleanVal(student.roll || student.roll_no || '2401XXXXXXXX')],
    ['Exam Date', cleanVal(student.date || student.exam_date || '03/08/2026')],
    ['Exam Shift / Time', cleanVal(student.time || student.exam_time || 'Shift 1')],
    ['Category (Vertical)', cleanVal(data.category_vertical || student.category || 'UR')],
    ['Horizontal Res.', cleanVal(data.category_horizontal || 'None')],
    ['Gender', cleanVal(data.gender || student.gender || 'Male')],
    ['Home State / UT', cleanVal(data.state || student.state || 'Rajasthan')]
  ];

  if (_activeExamTab === 'rrb' || data.rrb_zone || student.zone) {
    fields.push(['Applied RRB Zone', cleanVal(data.rrb_zone || student.zone || 'Ajmer')]);
  }
  if (student.venue || student.venue_name) {
    fields.push(['Test Venue', cleanVal(student.venue || student.venue_name)]);
  }
  if (student.subject && student.subject !== 'All Sections') {
    var cSub = cleanVal(student.subject);
    var cExam = cleanVal(examName);
    if (cSub && cSub !== cExam && !cSub.toLowerCase().includes('examination') && !cSub.toLowerCase().includes(cExam.toLowerCase())) {
      fields.push(['Subject / Trade', cSub]);
    }
  }

  // Filter out empty values
  var validFields = fields.filter(function(f) {
    return f[1] && f[1] !== '-' && f[1] !== '';
  });

  // Render in table form: word on one side, value on right side
  var tableHtml = '<div class="table-responsive" style="margin-top:6px;">' +
    '<table class="cand-details-table"><tbody>';

  for (var i = 0; i < validFields.length; i += 2) {
    var f1 = validFields[i];
    var f2 = validFields[i + 1];

    tableHtml += '<tr>';
    tableHtml += '<td class="cand-tbl-lbl">' + esc(f1[0]) + '</td>';
    tableHtml += '<td class="cand-tbl-val">' + esc(f1[1]) + '</td>';

    if (f2) {
      tableHtml += '<td class="cand-tbl-lbl">' + esc(f2[0]) + '</td>';
      tableHtml += '<td class="cand-tbl-val">' + esc(f2[1]) + '</td>';
    } else {
      tableHtml += '<td class="cand-tbl-lbl"></td><td class="cand-tbl-val"></td>';
    }
    tableHtml += '</tr>';
  }

  tableHtml += '</tbody></table></div>';

  if (container) container.innerHTML = tableHtml;
}

// ── Render Scorecard (Scores, Ranks & Section Breakdown) ─────────────
function renderScorecardV2(data) {
  enableScorecardDesktopView(true);

  var scores = data.scores || {};
  var sections = scores.sections || scores.section_scores || [];
  var ranks = data.rank || data.ranks || {};

  // 1. Total Score Hero
  var heroScore = document.getElementById('heroTotalScore');
  var totalVal = Number(scores.total_score != null ? scores.total_score : 0);
  if (heroScore) {
    animateScoreCount(heroScore, totalVal, 500);
  }
  var maxScoreEl = document.getElementById('heroMaxScore');
  if (maxScoreEl) {
    var maxVal = scores.max_score != null
      ? Number(scores.max_score)
      : ((scores.total_questions || 100) * (scores.marking_scheme ? (scores.marking_scheme.correct || 1) : 1));
    maxScoreEl.textContent = maxVal % 1 === 0 ? maxVal : maxVal.toFixed(2);
  }

  // 5 Metrics: Total, Attempted, Correct, Incorrect, Skipped
  var statTotQ = document.getElementById('statTotalQ');
  var statAtt = document.getElementById('statAttempted');
  var statCor = document.getElementById('statCorrect');
  var statIncor = document.getElementById('statIncorrect');
  var statSkip = document.getElementById('statSkipped');

  var totQ = scores.total_questions || 100;
  var cor = scores.total_correct || 0;
  var incor = scores.total_incorrect || 0;
  var att = scores.total_answered || (cor + incor) || 0;
  var skip = scores.total_not_answered != null ? scores.total_not_answered : (scores.total_unattempted != null ? scores.total_unattempted : Math.max(0, totQ - att));

  if (statTotQ) statTotQ.textContent = totQ;
  if (statAtt) statAtt.textContent = att;
  if (statCor) statCor.textContent = cor;
  if (statIncor) statIncor.textContent = incor;
  if (statSkip) statSkip.textContent = skip;

  // 2. Section-Wise Breakdown Table (RENDERED IMMEDIATELY AFTER SCORE CARD)
  var tbody = document.getElementById('sectionsTableBody');
  if (tbody && sections.length > 0) {
    var tblHtml = '';
    var sumQ = 0, sumC = 0, sumW = 0, sumU = 0, sumB = 0, sumMarks = 0;

    sections.forEach(function(sec) {
      var sName = sec.name || sec.subject || 'Section';
      var q = sec.questions || sec.total_questions || sec.count || 25;
      var c = sec.correct || 0;
      var w = sec.incorrect || 0;
      var b = sec.bonus || sec.bonus_questions || 0;
      var u = sec.not_answered != null ? sec.not_answered : (sec.unattempted != null ? sec.unattempted : (sec.skipped != null ? sec.skipped : Math.max(0, q - (c + w))));
      var m = sec.score != null ? sec.score : (sec.marks != null ? sec.marks : 0);

      sumQ += q;
      sumC += c;
      sumW += w;
      sumU += u;
      sumB += b;
      sumMarks += m;

      tblHtml += '<tr>' +
        '<td style="font-weight:500;">' + esc(sName) + '</td>' +
        '<td style="text-align:center;">' + q + '</td>' +
        '<td style="text-align:center;color:var(--success);font-weight:600;">' + c + '</td>' +
        '<td style="text-align:center;color:var(--danger);font-weight:600;">' + w + '</td>' +
        '<td style="text-align:center;color:var(--warning);font-weight:500;">' + u + '</td>' +
        '<td style="text-align:center;">' + b + '</td>' +
        '<td style="text-align:right;font-weight:600;color:var(--primary);">' + Number(m).toFixed(2) + '</td>' +
        '</tr>';
    });

    // Total Row
    tblHtml += '<tr class="tbl-total-row">' +
      '<td style="font-weight:600;">TOTAL SCORE</td>' +
      '<td style="text-align:center;font-weight:600;">' + sumQ + '</td>' +
      '<td style="text-align:center;color:var(--success);font-weight:600;">' + sumC + '</td>' +
      '<td style="text-align:center;color:var(--danger);font-weight:600;">' + sumW + '</td>' +
      '<td style="text-align:center;color:var(--warning);font-weight:600;">' + sumU + '</td>' +
      '<td style="text-align:center;font-weight:600;">' + sumB + '</td>' +
      '<td style="text-align:right;font-weight:600;color:var(--primary);">' + Number(scores.total_score != null ? scores.total_score : sumMarks).toFixed(2) + '</td>' +
      '</tr>';

    tbody.innerHTML = tblHtml;
  }

  // 3. Ranks & Percentiles (NO HARDCODED VALUES — Only rendered if real rank data exists)
  var airVal = document.getElementById('rankAirVal');
  var airDenom = document.getElementById('rankAirDenom');
  var catVal = document.getElementById('rankCatVal');
  var catDenom = document.getElementById('rankCatDenom');
  var shiftVal = document.getElementById('rankShiftVal');
  var shiftDenom = document.getElementById('rankShiftDenom');
  var pctVal = document.getElementById('rankPercentileVal');

  var aRank = (ranks.air && typeof ranks.air === 'object') ? ranks.air.rank : ranks.air;
  var aTot = (ranks.air && typeof ranks.air === 'object') ? ranks.air.total : ranks.total_candidates;
  if (airVal) airVal.textContent = (aRank != null) ? Number(aRank).toLocaleString() : '—';
  if (airDenom) airDenom.textContent = aTot ? ('of ' + Number(aTot).toLocaleString() + ' candidates') : 'Overall All-India Pool';

  var cRank = (ranks.category && typeof ranks.category === 'object') ? ranks.category.rank : ranks.category_rank;
  var cTot = (ranks.category && typeof ranks.category === 'object') ? ranks.category.total : ranks.category_total;
  if (catVal) catVal.textContent = (cRank != null) ? Number(cRank).toLocaleString() : '—';
  if (catDenom) catDenom.textContent = cTot ? ('of ' + Number(cTot).toLocaleString() + ' in ' + (data.category_vertical || (ranks.category && ranks.category.label) || 'Category')) : 'Category Competition';

  var sRank = (ranks.shift && typeof ranks.shift === 'object') ? ranks.shift.rank : ranks.shift_rank;
  var sTot = (ranks.shift && typeof ranks.shift === 'object') ? ranks.shift.total : ranks.shift_total;
  if (shiftVal) shiftVal.textContent = (sRank != null) ? Number(sRank).toLocaleString() : '—';
  if (shiftDenom) shiftDenom.textContent = sTot ? ('of ' + Number(sTot).toLocaleString() + ' in Shift') : 'In Exam Shift';

  var pVal = (ranks.air && ranks.air.percentile != null) ? ranks.air.percentile : (ranks.percentile != null ? ranks.percentile : (scores.percentile != null ? scores.percentile : null));
  if (pctVal) pctVal.textContent = (pVal != null) ? (Number(pVal).toFixed(2) + '%') : '—%';

  // 4. Print Header Sync
  var printId = document.getElementById('printReportId');
  if (printId) printId.textContent = _shortIdFromUuid(data.submission_id);

  var printDate = document.getElementById('printReportDate');
  if (printDate) {
    var now = new Date();
    printDate.textContent = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
}

// ── PROMINENT PRINT SCORE CARD ACTION ───────────────────────────────
function printScoreCard() {
  if (!_scoreData) {
    _showToast('Please calculate a scorecard first before printing.', 'error');
    return;
  }
  // Make sure print date and id are current
  var printDate = document.getElementById('printReportDate');
  if (printDate) {
    var now = new Date();
    printDate.textContent = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  window.print();
}

function shareResults() {
  var url = window.location.href;
  var scoreText = (_scoreData && _scoreData.scores && _scoreData.scores.total_score != null) ? _scoreData.scores.total_score : '';
  if (navigator.share) {
    navigator.share({
      title: 'My Exam Scorecard — Mock Matrix Hub',
      text: 'Checked my score on Mock Matrix Hub! Score: ' + scoreText + ' marks.',
      url: url
    }).catch(function() {});
  } else {
    try {
      navigator.clipboard.writeText(url);
      _showToast('Scorecard link copied to clipboard!', 'info');
    } catch (e) {
      prompt('Copy this link to share:', url);
    }
  }
}

function resetForNewUrl() {
  enableScorecardDesktopView(false);
  var urlEl = document.getElementById('scoreUrl');
  if (urlEl) {
    urlEl.value = '';
    if (typeof urlEl.focus === 'function') urlEl.focus();
  }
  var panel = document.getElementById('scorecardPanel');
  if (panel) panel.classList.add('hidden');

  resetRankUI();

  var formCard = document.getElementById('scoreFormCard');
  if (formCard) {
    formCard.style.display = 'block';
    formCard.style.opacity = '1';
    formCard.scrollIntoView({ behavior: 'smooth' });
  }
}

// ── Helper: Transform Parsed HTML Data to Standard Scorecard Object ──
function transformParsedToScorecard(parsed, body, family) {
  var cMark = (_selectedExamConfig && _selectedExamConfig.correct != null)
    ? Number(_selectedExamConfig.correct)
    : (family === 'ssc' ? 2.0 : 1.0);
  var wMark = (_selectedExamConfig && _selectedExamConfig.wrong != null)
    ? Number(_selectedExamConfig.wrong)
    : (family === 'ssc' ? 0.5 : 0.3333);
  var candidate = parsed.candidateInfo || {};
  var userCat = body.category_vertical || 'UR';
  var userState = body.state || 'Rajasthan';
  var examTitle = (_selectedExamConfig && (_selectedExamConfig.title || _selectedExamConfig.name))
    || candidate.exam
    || (family === 'ssc' ? 'SSC Examination' : 'Railway Recruitment Examination');

  var totalCorrect = 0, totalWrong = 0, totalSkipped = 0, totalBonus = 0, totalQ = 0;
  var secScores = [];

  (parsed.sections || []).forEach(function(sec) {
    var c = 0, w = 0, s = 0, b = 0;
    (sec.questions || []).forEach(function(q) {
      if (q.status === 'correct') c++;
      else if (q.status === 'wrong') w++;
      else if (q.status === 'bonus') b++;
      else s++;
    });
    var total = (sec.questions || []).length;
    var score = Number(((c * cMark) - (w * wMark) + (b * cMark)).toFixed(2));
    secScores.push({
      subject: sec.name,
      total_questions: total,
      answered: c + w,
      not_answered: s,
      correct: c,
      incorrect: w,
      bonus_questions: b,
      score: score
    });
    totalCorrect += c;
    totalWrong += w;
    totalSkipped += s;
    totalBonus += b;
    totalQ += total;
  });

  var totalScore = Number(((totalCorrect * cMark) - (totalWrong * wMark) + (totalBonus * cMark)).toFixed(2));
  var maxScore = Number((totalQ * cMark).toFixed(2));
  var pct = maxScore > 0 ? Number(((totalScore / maxScore) * 100).toFixed(2)) : 0;

  return {
    ok: true,
    submission_id: 'sub-' + Date.now().toString(36),
    student: {
      name: candidate.name || 'Candidate',
      roll: candidate.rollNo || candidate.roll || 'N/A',
      exam_name: examTitle,
      exam_date: candidate.date || 'Official Shift',
      exam_time: candidate.shift || 'Shift 1',
      date: candidate.date || '',
      shift: candidate.shift || '',
      venue: candidate.centre || 'Examination Center',
      subject: candidate.exam || examTitle,
      category: userCat,
      state: userState,
      gender: body.gender || 'Male',
      zone: body.rrb_zone || null
    },
    scores: {
      total_score: totalScore,
      max_score: maxScore,
      percentage: pct,
      total_questions: totalQ,
      total_correct: totalCorrect,
      total_incorrect: totalWrong,
      total_answered: totalCorrect + totalWrong,
      total_not_answered: totalSkipped,
      total_bonus: totalBonus,
      marking_scheme: { correct: cMark, incorrect: -wMark, bonus: cMark },
      section_scores: secScores
    },
    exam_id: (_selectedExamConfig && _selectedExamConfig.id) || (body && body.exam_id) || '',
    exam_tab: _activeExamTab || family || 'ssc',
    family: family || _activeExamTab || 'ssc',
    category_vertical: userCat,
    state: userState,
    gender: body.gender || 'Male',
    rrb_zone: body.rrb_zone || null,
    parsed_sections: parsed.sections || [],
    ranks: null
  };
}

// ── Frontend Response Sheet URL Validator ───────────────────────────
function validateAnswerKeyUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== 'string' || !rawUrl.trim()) {
    return {
      valid: false,
      message: 'Please paste your official response sheet / answer key URL.'
    };
  }

  var url = rawUrl.trim();

  // Basic HTTP/HTTPS protocol validation
  if (!/^https?:\/\//i.test(url)) {
    return {
      valid: false,
      message: 'Please enter a valid official URL starting with http:// or https://'
    };
  }

  var lower = url.toLowerCase();
  var cleanPath = lower.split('?')[0].split('#')[0].replace(/\/+$/, '');

  // 1. SSC / CBEXAMS Verification
  var isSscDomain = /cbexams\.com|ssccbt|ssccbe/i.test(lower);
  var isSscFormat = lower.includes('viewcandresponse.aspx');

  if (isSscDomain || isSscFormat) {
    var hasViewCand = lower.includes('viewcandresponse.aspx');
    var hasEncKey = lower.includes('enckey=');

    // Reject if ViewCandResponse or EncKey= is missing
    if (!hasViewCand || !hasEncKey) {
      return {
        valid: false,
        family: 'ssc',
        message: 'This is not an answer key URL. Official SSC response sheets must contain "ViewCandResponse.aspx?EncKey=".'
      };
    }

    // Reject if EncKey parameter has no value
    var encMatch = url.match(/EncKey=([^&#\s]+)/i);
    if (!encMatch || !encMatch[1] || encMatch[1].trim().length < 4) {
      return {
        valid: false,
        family: 'ssc',
        message: 'This is not an answer key URL. The EncKey parameter is missing or incomplete.'
      };
    }

    return { valid: true, family: 'ssc' };
  }

  // 2. Reject login.html for any response sheet URL (login portal page, not response sheet)
  if (cleanPath.endsWith('/login.html') || cleanPath.endsWith('login.html')) {
    return {
      valid: false,
      family: 'rrb',
      message: 'This is a login page link, not your response sheet. Please login and click "Candidate Response" to copy your answer key link.'
    };
  }

  // 3. Reject sample-demo-paper.html (unless explicitly loaded via Try Demo button)
  if (lower.includes('sample-demo-paper.html') && !_isDemoUrlFilled) {
    return {
      valid: false,
      family: 'rrb',
      message: 'This is a sample demo link, not an official candidate answer key URL.'
    };
  }

  // 4. DigiALM / TCS iON Verification (Railway RRB, etc.)
  var isDigialmDomain = /digialm\.com|tcsion\.com/i.test(lower);
  if (isDigialmDomain) {
    var endsWithHtml = cleanPath.endsWith('.html') || cleanPath.endsWith('.htm');
    if (!endsWithHtml) {
      return {
        valid: false,
        family: 'rrb',
        message: 'This is not an answer key URL. Official Railway / DigiALM response sheet URLs must end with ".html".'
      };
    }
    return { valid: true, family: 'rrb' };
  }

  // 5. Generic format check (must end with .html, .htm, .aspx, or contain query parameters)
  if (!cleanPath.endsWith('.html') && !cleanPath.endsWith('.htm') && !cleanPath.endsWith('.aspx') && !lower.includes('?')) {
    return {
      valid: false,
      message: 'This is not an answer key URL. Please paste the direct candidate response sheet link.'
    };
  }

  return { valid: true, family: 'other' };
}

// ── Calculate and Rank (Server API Call) ─────────────────────────────
async function calculateAndRank() {
  var urlEl = document.getElementById('scoreUrl');
  var url = (urlEl ? urlEl.value : '').trim();
  var errorEl = document.getElementById('urlError');
  if (errorEl) errorEl.style.display = 'none';

  // 1. Validate Examination Selection
  var examSel = document.getElementById('scoreExamSelect');
  var examVal = (examSel ? examSel.value : '').trim();
  if (!examVal) {
    if (errorEl) {
      errorEl.textContent = 'Please select your examination.';
      errorEl.style.display = 'block';
    }
    if (examSel) {
      examSel.focus();
      examSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  // 2. Validate URL Field with frontend URL Checker / HTML file
  var clientHtml = null;
  var htmlInput = document.getElementById('scoreHtmlFile');
  if (htmlInput && htmlInput.files && htmlInput.files.length > 0) {
    try {
      clientHtml = await htmlInput.files[0].text();
    } catch (e) {}
  }

  if (!url && !clientHtml) {
    if (errorEl) {
      errorEl.textContent = 'Please paste your official response sheet / answer key URL.';
      errorEl.style.display = 'block';
    }
    if (urlEl) {
      urlEl.focus();
      urlEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  if (url) {
    var urlValidation = validateAnswerKeyUrl(url);
    if (!urlValidation.valid) {
      if (errorEl) {
        errorEl.textContent = urlValidation.message;
        errorEl.style.display = 'block';
      }
      if (urlEl) {
        urlEl.focus();
        urlEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
  }

  // 3. Validate Category (Vertical)
  var catSel = document.getElementById('scoreCategory');
  var catVal = (catSel ? catSel.value : '').trim();
  if (!catVal) {
    if (errorEl) {
      errorEl.textContent = 'Please select your category.';
      errorEl.style.display = 'block';
    }
    if (catSel) {
      catSel.focus();
      catSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  // 4. Validate Home State / UT
  var stateSel = document.getElementById('scoreState');
  var stateVal = (stateSel ? stateSel.value : '').trim();
  if (!stateVal) {
    if (errorEl) {
      errorEl.textContent = 'Please select your home state / UT.';
      errorEl.style.display = 'block';
    }
    if (stateSel) {
      stateSel.focus();
      stateSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  // 5. Validate RRB Zone (if Railway tab active)
  var zoneSel = document.getElementById('scoreRrbZone');
  var zoneVal = (zoneSel ? zoneSel.value : '').trim();
  if (_activeExamTab === 'rrb' && (!zoneVal || zoneVal === 'None')) {
    if (errorEl) {
      errorEl.textContent = 'Please select your applied RRB zone.';
      errorEl.style.display = 'block';
    }
    if (zoneSel) {
      zoneSel.focus();
      zoneSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  // 6. Validate Gender
  var genderSel = document.getElementById('scoreGender');
  var genderVal = (genderSel ? genderSel.value : '').trim();
  if (!genderVal) {
    if (errorEl) {
      errorEl.textContent = 'Please select your gender.';
      errorEl.style.display = 'block';
    }
    if (genderSel) {
      genderSel.focus();
      genderSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return;
  }

  var isSscUrl = /cbexams\.com|ssccbe|ssccbt|viewcandresponse/i.test(url);
  var isDigialmUrl = /digialm\.com|tcsion\.com/i.test(url);

  // 7. Check 15-Minute Scorecard Cache (Instant restoration without re-fetching)
  var cachedEntry = getScorecardCache(url);
  if (cachedEntry) {
    restoreFromScorecardCache(cachedEntry);
    _showToast('Loaded instantly from 15-minute cache.', 'info');
    return;
  }

  var btn = document.getElementById('scoreCalcBtn');
  var btnTxt = document.getElementById('calcBtnText');
  if (btn) btn.disabled = true;
  if (btnTxt) btnTxt.textContent = 'Connecting to Server...';

  startEvaluationAnimation(isSscUrl);

  var clientHtml = null;
  var htmlInput = document.getElementById('scoreHtmlFile');
  if (htmlInput && htmlInput.files && htmlInput.files.length > 0) {
    try {
      clientHtml = await htmlInput.files[0].text();
    } catch (e) {}
  }

  var partsCount = isSscUrl
    ? ((_selectedExamConfig && _selectedExamConfig.parts) ? _selectedExamConfig.parts : 4)
    : 1;

  var body = {
    url: url,
    html: clientHtml,
    category_vertical: catVal,
    category_horizontal: document.getElementById('scoreCatH').value || 'None',
    gender: genderVal,
    state: stateVal,
    rrb_zone: _activeExamTab === 'rrb' ? zoneVal : null,
    paper_language: 'EN',
    exam_tab: _activeExamTab || (isSscUrl ? 'ssc' : 'rrb'),
    exam_id: _selectedExamConfig ? _selectedExamConfig.id : examVal,
    exam_name: _selectedExamConfig ? (_selectedExamConfig.title || _selectedExamConfig.name) : examVal,
    partsCount: partsCount,
    parts: partsCount
  };

  try {
    // Primary Worker endpoint with fallback
    var workerEndpoint = 'https://rank.mockmatrixhub.in/calculate';
    var isLocalDev = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    var targetEndpoint = isLocalDev ? '/api/score/calculate-and-rank' : workerEndpoint;

    var res;
    try {
      res = await fetch(targetEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    } catch (networkErr) {
      if (targetEndpoint !== '/api/score/calculate-and-rank') {
        res = await fetch('/api/score/calculate-and-rank', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
      } else {
        throw networkErr;
      }
    }

    var data = null;
    var resStatus = res ? res.status : 0;
    try {
      data = await res.json();
    } catch (e) {}

    // Check if error, server busy, wrong URL, or official sites are down
    var is404 = resStatus === 404 || (data && (
      data.code === 'WRONG_URL' ||
      data.status === 404 ||
      data.is404 ||
      (typeof data.details === 'string' && data.details.includes('404')) ||
      (typeof data.message === 'string' && data.message.includes('404')) ||
      (typeof data.error === 'string' && data.error.includes('404'))
    ));
    var isBusyOrDown = !is404 && (resStatus === 503 || resStatus === 204 || (data && (data.code === 'SERVER_BUSY_OR_DOWN' || data.code === 'SERVER_BUSY' || data.busy || data.status === 503 || data.status === 204 || data.code === 'FETCH_FAILED')));

    if (is404 || isBusyOrDown || !res.ok || (data && data.ok === false)) {
      stopEvaluationAnimation();
      if (btn) btn.disabled = false;
      if (btnTxt) btnTxt.textContent = 'Calculate';
      if (errorEl) {
        var errorMsg = '';
        if (is404) {
          errorMsg = 'Wrong URL! The answer key link you entered does not exist. Please check and enter the correct official answer key URL.';
        } else if (isBusyOrDown) {
          errorMsg = 'Server is busy or SSC / RRB official sites are currently down. Please try again after some time.';
        } else {
          errorMsg = (data && data.message) || 'Server is busy or SSC / RRB official sites are currently down. Please try again after some time.';
        }
        errorEl.textContent = errorMsg;
        errorEl.style.display = 'block';
        errorEl.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    if (!data) {
      stopEvaluationAnimation();
      if (btn) btn.disabled = false;
      if (btnTxt) btnTxt.textContent = 'Calculate';
      if (errorEl) {
        errorEl.textContent = 'Server is busy or SSC / RRB official sites are currently down. Please try again after some time.';
        errorEl.style.display = 'block';
        errorEl.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    // ── Process Parsed Response ──
    // Parser selection is STRICTLY decided by URL format first:
    // If URL is SSC format (cbexams / ViewCandResponse): use RSMParserSSC
    // If URL is DigiALM format (digialm / tcsion or single HTML page): use RSMParserRRB
    var isUrlSsc = /cbexams\.com|ssccbt|ssccbe|viewcandresponse/i.test(url);
    var isUrlDigialm = /digialm\.com|tcsion\.com/i.test(url);
    var hasSscParts = (data.family === 'ssc' && data.parts) || (data.parts && data.parts.p1);

    if ((isUrlSsc || hasSscParts) && data.parts && typeof RSMParserSSC !== 'undefined') {
      // Strictly enforce parts count limit based on selected exam config
      if (_selectedExamConfig && _selectedExamConfig.parts) {
        var maxAllowed = _selectedExamConfig.parts;
        var filteredParts = {};
        for (var pIdx = 1; pIdx <= maxAllowed; pIdx++) {
          if (data.parts['p' + pIdx]) {
            filteredParts['p' + pIdx] = data.parts['p' + pIdx];
          }
        }
        data.parts = filteredParts;
      }
      _rawResultData = {
        family: 'ssc',
        parts: data.parts,
        url: url,
        examName: (_selectedExamConfig && (_selectedExamConfig.title || _selectedExamConfig.name)) || (data.student && data.student.exam_name) || 'SSC Examination'
      };
      var parsedData = RSMParserSSC.parse(data.parts, (_selectedExamConfig && _selectedExamConfig.parts) || null);
      data = transformParsedToScorecard(parsedData, body, 'ssc');
    }
    else if ((isUrlDigialm || !isUrlSsc) && (data.html || (typeof data === 'object' && !data.scores && !data.student))) {
      var rawHtml = data.html || (data.data && data.data.html) || '';
      if (rawHtml) {
        var detectedSsc = isUrlSsc || /lblsubject|ViewCandResponse|td_correct/i.test(rawHtml);
        _rawResultData = {
          family: detectedSsc ? 'ssc' : 'rrb',
          parts: { p1: rawHtml },
          url: url,
          examName: (_selectedExamConfig && (_selectedExamConfig.title || _selectedExamConfig.name)) || (detectedSsc ? 'SSC Examination' : 'Railway Examination')
        };
        var parsed = detectedSsc && typeof RSMParserSSC !== 'undefined'
          ? RSMParserSSC.parse({ p1: rawHtml })
          : RSMParserRRB.parse({ p1: rawHtml });
        data = transformParsedToScorecard(parsed, body, detectedSsc ? 'ssc' : 'rrb');
      }
    }
    else if (data.scores) {
      _rawResultData = null;
    }

    // Update animation message to indicate database sync & rank generation
    var animTxt = document.getElementById('evalAnimText');
    if (animTxt) animTxt.textContent = 'Saving evaluation to database & computing ranks...';

    // Track score revelation to ensure it runs exactly once
    var isRevealed = false;
    function revealScorecard(isSavedToDb) {
      if (isRevealed) return;
      isRevealed = true;

      stopEvaluationAnimation();
      _scoreData = data;

      enableScorecardDesktopView(true);

      renderStudentInfo(data.student || {}, body);
      renderScorecardV2(data);

      // Save to 15-Minute Cache
      saveToScorecardCache(url, data, _rawResultData, data.student || {}, body);

      var formCard = document.getElementById('scoreFormCard');
      if (formCard) formCard.style.display = 'none';

      resetRankUI();

      var panel = document.getElementById('scorecardPanel');
      if (panel) {
        panel.classList.remove('hidden');
        renderCacheBanner(Date.now());
      }

      var scrollContainer = document.querySelector('.screen-scroll');
      if (scrollContainer) {
        scrollContainer.scrollTo({ top: 0, behavior: 'smooth' });
      }

      if (btn) btn.disabled = false;
      if (btnTxt) btnTxt.textContent = 'Calculate';

      // Live rank computation strictly triggers when candidate data has confirmed saved in Supabase
      if (isSavedToDb) {
        autoComputeAndShowRanks();
      }
    }

    // Single try completion safety timeout (3.5s max) so candidate is never indefinitely stuck
    var syncSafetyTimeout = setTimeout(function() {
      revealScorecard(false);
    }, 3500);

    // Sync candidate scores and question stats to Supabase FIRST; ONLY reveal score after saving data or try completes
    syncToSupabase(data, url, body, function() {
      clearTimeout(syncSafetyTimeout);
      // SUCCESS: Candidate data confirmed in database -> reveal scorecard & calculate live rank
      revealScorecard(true);
    }, function(err) {
      clearTimeout(syncSafetyTimeout);
      console.warn('Supabase save error:', err);
      // FAILED / TRY COMPLETE: Reveal scorecard after one try complete
      revealScorecard(false);
    });

  } catch (err) {
    console.warn('Evaluation network error:', err);
    stopEvaluationAnimation();
    if (btn) btn.disabled = false;
    if (btnTxt) btnTxt.textContent = 'Calculate';
    if (errorEl) {
      errorEl.textContent = 'Server is busy or SSC / RRB official sites are currently down. Please try again after some time.';
      errorEl.style.display = 'block';
      errorEl.scrollIntoView({ behavior: 'smooth' });
    }
  }
}

// ── Action Buttons Handlers ──────────────────────────────────────────

// Helper: Reset all rank-related UI elements
function resetRankUI() {
  var statusContainer = document.getElementById('rankStatusContainer');
  if (statusContainer) statusContainer.style.display = 'none';
  var compBox = document.getElementById('rankComputingBox');
  if (compBox) compBox.style.display = 'none';
  var notEnabledBox = document.getElementById('rankNotEnabledBox');
  if (notEnabledBox) notEnabledBox.style.display = 'none';
  var ranksContainer = document.getElementById('ranksGridContainer');
  if (ranksContainer) ranksContainer.style.display = 'none';
  var rankChevron = document.getElementById('rankChevron');
  if (rankChevron) rankChevron.style.transform = 'rotate(0deg)';
  var zoneCard = document.getElementById('rankZoneCard');
  if (zoneCard) zoneCard.style.display = 'none';
  var avgZoneCard = document.getElementById('avgZoneCard');
  if (avgZoneCard) avgZoneCard.style.display = 'none';
  var btnCheckRank = document.getElementById('btnCheckRank');
  if (btnCheckRank) {
    btnCheckRank.setAttribute('aria-expanded', 'false');
    var spans = btnCheckRank.getElementsByTagName('span');
    if (spans && spans.length > 1) spans[1].textContent = 'Check All-India Rank & Percentiles';
  }
}

// ── Supabase Background Sync & Realtime Analytics ───────────────────
function syncToSupabase(scoreData, rawUrl, formInputs, onSuccess, onError) {
  if (!SUPABASE_CONFIG || !SUPABASE_CONFIG.url || !SUPABASE_CONFIG.anonKey) {
    if (typeof onError === 'function') onError('Supabase not configured');
    return;
  }
  if (!scoreData || !scoreData.scores) {
    if (typeof onError === 'function') onError('No scores');
    return;
  }

  var examId = (_selectedExamConfig && _selectedExamConfig.id) || (formInputs && formInputs.exam_id) || 'ssc-cgl-tier1';
  var student = scoreData.student || {};
  var roll = student.roll || student.roll_number || 'NA';

  var rawDate = student.date || student.exam_date || '';
  var rawTime = student.shift || student.exam_time || '';
  var shift = (rawDate && rawTime && rawDate !== 'Official Shift')
    ? (rawDate.trim() + '_' + rawTime.trim())
    : (rawTime.trim() || rawDate.trim() || 'Shift 1');

  var cat = (formInputs && formInputs.category_vertical)
    || (document.getElementById('scoreCategory') ? document.getElementById('scoreCategory').value : null)
    || (document.getElementById('scoreCatV') ? document.getElementById('scoreCatV').value : null)
    || 'UR';
  var gender = (formInputs && formInputs.gender) || (document.getElementById('scoreGender') ? document.getElementById('scoreGender').value : 'NA');
  var zone = (formInputs && formInputs.rrb_zone) || (document.getElementById('scoreRrbZone') ? document.getElementById('scoreRrbZone').value : null);
  if (zone === 'None' || zone === '') zone = null;
  var state = (formInputs && formInputs.state) || (document.getElementById('scoreState') ? document.getElementById('scoreState').value : null);

  var sc = scoreData.scores || {};
  var totalQuestions = sc.total_questions || 0;
  var attempted = sc.total_answered || (sc.total_correct + sc.total_incorrect) || 0;
  var correctCount = sc.total_correct || 0;
  var wrongCount = sc.total_incorrect || 0;
  var skipCount = sc.total_not_answered || 0;
  var bonusCount = sc.total_bonus || 0;
  var totalScore = sc.total_score != null ? sc.total_score : 0;

  var secScores = sc.section_scores || sc.sections || [];

  var questionsPayload = [];
  var secList = scoreData.parsed_sections || [];

  // Strictly check if URL or HTML is DigiALM / TCS type (NEVER rely on exam family or active tab)
  var targetUrlStr = String(rawUrl || (_rawResultData && _rawResultData.url) || (scoreData && scoreData.url) || '');
  var isDigialmUrl = /digialm\.com|tcsion\.com|touchstone|AssessmentQPHTML/i.test(targetUrlStr);

  var firstPartHtml = (_rawResultData && _rawResultData.parts && (_rawResultData.parts.p1 || Object.values(_rawResultData.parts)[0])) || '';
  var isDigialmHtml = typeof firstPartHtml === 'string' && /digialm|Question\s*ID\s*:|Option\s*1\s*ID\s*:|question-pnl|menu-tbl/i.test(firstPartHtml);

  var isDigialmTcs = isDigialmUrl || isDigialmHtml;

  if (Array.isArray(secList)) {
    secList.forEach(function(sec) {
      var sName = sec.name || sec.title || 'Section';
      var qList = sec.questions || [];
      qList.forEach(function(q, idx) {
        // In DigiALM / TCS: Question and option order is randomized per candidate in the same shift.
        // Therefore, for DigiALM / TCS, the question key MUST strictly be the Question ID (q.qId) from inside the question!
        // In SSC (cbexams): Question order is identical for all candidates in the shift, so question number (q.qno or idx+1) is used.
        var qKey = (isDigialmTcs || q.qId) ? (q.qId ? String(q.qId) : String(q.qno != null ? q.qno : idx + 1)) : String(q.qno != null ? q.qno : idx + 1);

        var qStatus = 'skipped';
        if (q.status === 'correct' || q.isCorrect === true) qStatus = 'correct';
        else if (q.status === 'wrong' || q.status === 'incorrect' || q.isCorrect === false) qStatus = 'wrong';
        else if (q.status === 'bonus') qStatus = 'bonus';
        else qStatus = 'skipped';

        questionsPayload.push({
          q: String(qKey),
          sec: String(sName),
          s: qStatus
        });
      });
    });
  }

  var payload = {
    p_exam_id: examId,
    p_shift_id: shift,
    p_roll_number: roll,
    p_name: student.name || 'Candidate',
    p_category: cat,
    p_gender: gender,
    p_zone: zone,
    p_state: state,
    p_total_score: totalScore,
    p_total_questions: totalQuestions,
    p_attempted: attempted,
    p_correct_count: correctCount,
    p_wrong_count: wrongCount,
    p_skip_count: skipCount,
    p_bonus_count: bonusCount,
    p_section_scores: secScores,
    p_answer_key_url: rawUrl || '',
    p_questions: questionsPayload
  };

  fetch(SUPABASE_CONFIG.url + '/rest/v1/rpc/submit_candidate_data', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_CONFIG.anonKey,
      'Authorization': 'Bearer ' + SUPABASE_CONFIG.anonKey
    },
    body: JSON.stringify(payload)
  })
  .then(function(res) {
    if (!res.ok) {
      return res.text().then(function(t) {
        // Fallback for earlier 12-parameter schema if user hasn't run latest SQL yet
        if (t && t.indexOf('PGRST202') !== -1) {
          var payloadLegacy = {
            p_exam_id: examId,
            p_shift_id: shift,
            p_roll_number: roll,
            p_name: student.name || 'Candidate',
            p_category: cat,
            p_gender: gender,
            p_zone: zone,
            p_state: state,
            p_total_score: totalScore,
            p_section_scores: secScores,
            p_answer_key_url: rawUrl || '',
            p_questions: questionsPayload
          };
          return fetch(SUPABASE_CONFIG.url + '/rest/v1/rpc/submit_candidate_data', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'apikey': SUPABASE_CONFIG.anonKey,
              'Authorization': 'Bearer ' + SUPABASE_CONFIG.anonKey
            },
            body: JSON.stringify(payloadLegacy)
          });
        }
        throw new Error('Supabase submit failed with status: ' + res.status + ' ' + t);
      });
    }
    return res;
  })
  .then(function(res) {
    if (res && (res.ok || res.status === 200 || res.status === 204)) {
      console.log('Supabase candidate + questions synced successfully');
      if (typeof onSuccess === 'function') onSuccess();
    } else {
      console.warn('Supabase submission response was not ok');
      if (typeof onError === 'function') onError('Submission not ok');
    }
  })
  .catch(function(err) {
    console.warn('Supabase sync notice:', err);
    if (typeof onError === 'function') onError(err);
  });
}

// Automatically calculate and display ranks immediately upon submission
function autoComputeAndShowRanks() {
  var grid = document.getElementById('ranksGridContainer');
  var chevron = document.getElementById('rankChevron');
  var computingBox = document.getElementById('rankComputingBox');
  var statusContainer = document.getElementById('rankStatusContainer');
  var btnCheckRank = document.getElementById('btnCheckRank');

  if (computingBox) computingBox.style.display = 'none';
  if (statusContainer) statusContainer.style.display = 'none';

  executeRankCalculation(function(rankResult) {
    if (rankResult && rankResult.ok && rankResult.ranks) {
      if (_scoreData) {
        _scoreData.ranks = rankResult.ranks;
        // Persist computed ranks into 15-minute cache immediately
        var urlEl = document.getElementById('scoreUrl');
        var currentUrl = (urlEl && urlEl.value) || (_rawResultData && _rawResultData.url) || '';
        saveToScorecardCache(currentUrl, _scoreData, _rawResultData, _scoreData.student || {}, {
          exam_id: _scoreData.exam_id,
          category_vertical: (_scoreData.student && _scoreData.student.category) || 'UR',
          state: (_scoreData.student && _scoreData.student.state) || 'Rajasthan',
          gender: (_scoreData.student && _scoreData.student.gender) || 'Male',
          rrb_zone: (_scoreData.student && _scoreData.student.zone) || null
        });
      }
      populateRanksUI(rankResult.ranks);
      if (grid) grid.style.display = 'flex';
      if (chevron) chevron.style.transform = 'rotate(180deg)';
      if (btnCheckRank) {
        btnCheckRank.setAttribute('aria-expanded', 'true');
        var spans = btnCheckRank.getElementsByTagName('span');
        if (spans && spans.length > 1) spans[1].textContent = 'All-India Rank & Percentiles (Live)';
      }
    }
  });
}

// 1. Check if Rank API exists for this exam
function checkRankApiAvailability() {
  if (SUPABASE_CONFIG && SUPABASE_CONFIG.url && SUPABASE_CONFIG.anonKey) {
    return true;
  }
  if (_selectedExamConfig) {
    if (_selectedExamConfig.hasRank === true || _selectedExamConfig.rankApi || _selectedExamConfig.rankWorker || _selectedExamConfig.enable_rank === true) {
      return true;
    }
  }
  if (_scoreData && _scoreData.ranks && _scoreData.ranks.air && _scoreData.ranks.air.rank) {
    return true;
  }
  return false;
}

// Execute Rank Calculation or fetch
function executeRankCalculation(callback) {
  if (_scoreData && _scoreData.ranks && _scoreData.ranks.air && _scoreData.ranks.air.rank) {
    setTimeout(function() {
      callback({ ok: true, ranks: _scoreData.ranks });
    }, 400);
    return;
  }

  var student = (_scoreData && _scoreData.student) || {};
  var examId = (_selectedExamConfig && _selectedExamConfig.id)
    || (_scoreData && _scoreData.exam_id)
    || (document.getElementById('scoreExamSelect') && document.getElementById('scoreExamSelect').value)
    || '';

  // Fallback: If examId is not found yet, detect from student exam title/subject
  if (!examId) {
    var examNameLow = (student.exam_name || student.exam || student.subject || '').toLowerCase();
    if (examNameLow.includes('steno')) examId = 'ssc-steno';
    else if (examNameLow.includes('cgl')) examId = 'ssc-cgl-tier1';
    else if (examNameLow.includes('chsl')) examId = 'ssc-chsl-tier1';
    else if (examNameLow.includes('gd')) examId = 'ssc-gd';
    else if (examNameLow.includes('mts')) examId = 'ssc-mts';
    else if (examNameLow.includes('je')) examId = 'ssc-je';
    else if (examNameLow.includes('cpo')) examId = 'ssc-cpo-tier1';
    else if (examNameLow.includes('ntpc')) examId = 'rrb-ntpc-ug-cbt1';
    else if (examNameLow.includes('group d') || examNameLow.includes('level 1')) examId = 'rrb-groupd';
    else if (examNameLow.includes('alp')) examId = 'rrb-alp';
    else examId = (_activeExamTab === 'rrb' || (_scoreData && _scoreData.family === 'rrb')) ? 'rrb-ntpc-ug-cbt1' : 'ssc-cgl-tier1';
  }

  var rawDate = student.date || student.exam_date || '';
  var rawTime = student.shift || student.exam_time || '';
  var shift = (rawDate && rawTime && rawDate !== 'Official Shift')
    ? (rawDate.trim() + '_' + rawTime.trim())
    : (rawTime.trim() || rawDate.trim() || 'Shift 1');

  var catEl = document.getElementById('scoreCategory') || document.getElementById('scoreCatV');
  var cat = (catEl && catEl.value) ? catEl.value : ((student && student.category) || (_scoreData && _scoreData.category_vertical) || 'UR');
  var genderEl = document.getElementById('scoreGender');
  var gender = (genderEl && genderEl.value) ? genderEl.value : ((student && student.gender) || (_scoreData && _scoreData.gender) || 'NA');
  var zoneSel = document.getElementById('scoreRrbZone');
  var zone = (zoneSel && zoneSel.value && zoneSel.value !== 'None') ? zoneSel.value : ((student && student.zone) || (_scoreData && _scoreData.rrb_zone) || null);
  var totalScore = (_scoreData && _scoreData.scores && _scoreData.scores.total_score != null) ? _scoreData.scores.total_score : 0;

  var rpcUrl = SUPABASE_CONFIG.url + '/rest/v1/rpc/get_all_ranks';
  var payload = {
    p_exam_id: examId,
    p_shift_id: shift,
    p_category: cat,
    p_gender: gender,
    p_zone: zone,
    p_score: totalScore
  };

  fetch(rpcUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_CONFIG.anonKey,
      'Authorization': 'Bearer ' + SUPABASE_CONFIG.anonKey
    },
    body: JSON.stringify(payload)
  })
  .then(function(res) {
    if (!res.ok) throw new Error('Supabase RPC status: ' + res.status);
    return res.json();
  })
  .then(function(data) {
    if (data && (data.air || data.ranks)) {
      callback({ ok: true, ranks: data.ranks || data });
    } else {
      callback({ ok: false });
    }
  })
  .catch(function(err) {
    console.warn('Supabase rank RPC notice:', err);
    // Fallback if configured on exam
    if (_selectedExamConfig && _selectedExamConfig.rankApi) {
      fetch(_selectedExamConfig.rankApi, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(function(r) { return r.json(); })
      .then(function(d) { callback({ ok: true, ranks: d.ranks || d }); })
      .catch(function() { callback({ ok: false }); });
    } else {
      callback({ ok: false });
    }
  });
}

// Populate real ranks & averages into UI cards
function populateRanksUI(ranks) {
  if (!ranks) return;
  var airVal = document.getElementById('rankAirVal');
  var airDenom = document.getElementById('rankAirDenom');
  var overallPctVal = document.getElementById('rankOverallPctVal');
  var catVal = document.getElementById('rankCatVal');
  var catDenom = document.getElementById('rankCatDenom');
  var shiftVal = document.getElementById('rankShiftVal');
  var shiftDenom = document.getElementById('rankShiftDenom');
  var pctVal = document.getElementById('rankPercentileVal');

  var zoneCard = document.getElementById('rankZoneCard');
  var zoneVal = document.getElementById('rankZoneVal');
  var zoneDenom = document.getElementById('rankZoneDenom');
  var zoneTitle = document.getElementById('rankZoneTitle');

  var avgOverallVal = document.getElementById('avgOverallVal');
  var avgShiftVal = document.getElementById('avgShiftVal');
  var avgShiftDenom = document.getElementById('avgShiftDenom');
  var avgZoneCard = document.getElementById('avgZoneCard');
  var avgZoneVal = document.getElementById('avgZoneVal');
  var avgZoneTitle = document.getElementById('avgZoneTitle');
  var avgZoneDenom = document.getElementById('avgZoneDenom');

  // 1. All India Rank
  var aRank = (ranks.air && typeof ranks.air === 'object') ? ranks.air.rank : ranks.air_rank;
  var aTot = (ranks.air && typeof ranks.air === 'object') ? ranks.air.total : ranks.total_candidates;
  if (airVal) airVal.textContent = (aRank != null) ? Number(aRank).toLocaleString() : '—';
  if (airDenom) airDenom.textContent = aTot ? ('of ' + Number(aTot).toLocaleString() + ' candidates') : 'Overall All-India Pool';

  // 2. Overall Percentile (AIR Percentile)
  if (overallPctVal) {
    var airPct = (ranks.air && ranks.air.percentile != null) ? ranks.air.percentile :
                 (ranks.overall_percentile != null ? ranks.overall_percentile :
                 ((aRank != null && aTot != null && aTot > 0) ? (aTot > 1 ? (((aTot - aRank) / aTot) * 100).toFixed(2) : '100.00') : null));
    overallPctVal.textContent = (airPct != null) ? (Number(airPct).toFixed(2) + '%') : '—%';
  }

  // 3. Category Rank
  var cRank = (ranks.category && typeof ranks.category === 'object') ? ranks.category.rank : ranks.category_rank;
  var cTot = (ranks.category && typeof ranks.category === 'object') ? ranks.category.total : ranks.category_total;
  var cLabel = (ranks.category && typeof ranks.category === 'object' && ranks.category.label) ? ranks.category.label : '';
  if (catVal) catVal.textContent = (cRank != null) ? Number(cRank).toLocaleString() : '—';
  if (catDenom) catDenom.textContent = cTot ? ('of ' + Number(cTot).toLocaleString() + (cLabel ? (' in ' + cLabel) : ' in Category')) : 'Category Competition';

  // 4. Shift Rank
  var sRank = (ranks.shift && typeof ranks.shift === 'object') ? ranks.shift.rank : ranks.shift_rank;
  var sTot = (ranks.shift && typeof ranks.shift === 'object') ? ranks.shift.total : ranks.shift_total;
  if (shiftVal) shiftVal.textContent = (sRank != null) ? Number(sRank).toLocaleString() : '—';
  if (shiftDenom) shiftDenom.textContent = sTot ? ('of ' + Number(sTot).toLocaleString() + ' in Shift') : 'In Exam Shift';

  // 5. Shift Percentile
  var pVal = (ranks.shift && ranks.shift.percentile != null) ? ranks.shift.percentile :
             ((sRank != null && sTot != null && sTot > 0) ? (sTot > 1 ? (((sTot - sRank) / sTot) * 100) : 100) : null);
  if (pctVal) pctVal.textContent = (pVal != null) ? (Number(pVal).toFixed(2) + '%') : '—%';

  // 6. Zone Rank (for Railway RRB Exams)
  var zRank = (ranks.zone && typeof ranks.zone === 'object') ? ranks.zone.rank : ranks.zone_rank;
  var zTot = (ranks.zone && typeof ranks.zone === 'object') ? ranks.zone.total : ranks.zone_total;
  var zLabel = (ranks.zone && typeof ranks.zone === 'object' && ranks.zone.label) ? ranks.zone.label : (document.getElementById('scoreRrbZone') ? document.getElementById('scoreRrbZone').value : '');
  if (zoneCard) {
    if (zRank != null && zTot != null && zLabel && zLabel !== 'None') {
      zoneCard.style.display = 'flex';
      if (zoneTitle) zoneTitle.textContent = zLabel + ' Zone Rank';
      if (zoneVal) zoneVal.textContent = Number(zRank).toLocaleString();
      if (zoneDenom) zoneDenom.textContent = 'of ' + Number(zTot).toLocaleString() + ' in Zone';
    } else {
      zoneCard.style.display = 'none';
    }
  }

  // 7. Overall Average Score (Total All Users Avg)
  var oAvg = (ranks.air && ranks.air.avg != null) ? ranks.air.avg :
             (ranks.overallAverage != null ? ranks.overallAverage : ranks.overall_avg);
  if (avgOverallVal) avgOverallVal.textContent = (oAvg != null && oAvg !== 'N/A') ? Number(oAvg).toFixed(2) : '—';

  // 8. Shift Average Score (User Shift Avg)
  var sAvg = (ranks.shift && ranks.shift.avg != null) ? ranks.shift.avg :
             (ranks.shiftAverage != null ? ranks.shiftAverage : ranks.shift_avg);
  if (avgShiftVal) avgShiftVal.textContent = (sAvg != null && sAvg !== 'N/A') ? Number(sAvg).toFixed(2) : '—';
  if (avgShiftDenom) {
    var shiftName = (_scoreData && _scoreData.student && (_scoreData.student.shift || _scoreData.student.exam_time)) ? (_scoreData.student.shift || _scoreData.student.exam_time) : 'Shift';
    avgShiftDenom.textContent = shiftName ? ('Average for ' + shiftName) : 'Your Shift Average';
  }

  // 9. Zone Average Score (for Railway RRB Exams)
  var zAvg = (ranks.zone && ranks.zone.avg != null) ? ranks.zone.avg :
             (ranks.zoneAverage != null ? ranks.zoneAverage : ranks.zone_avg);
  if (avgZoneCard) {
    if (zAvg != null && zAvg !== 'N/A' && zLabel && zLabel !== 'None') {
      avgZoneCard.style.display = 'flex';
      if (avgZoneTitle) avgZoneTitle.textContent = zLabel + ' Zone Avg';
      if (avgZoneVal) avgZoneVal.textContent = Number(zAvg).toFixed(2);
      if (avgZoneDenom) avgZoneDenom.textContent = 'Average in ' + zLabel + ' Zone';
    } else {
      avgZoneCard.style.display = 'none';
    }
  }
}

var _rankComputingTimer = null;

// Toggle Rank Display (Checks API existence -> shows animation or not enabled notice)
function toggleRankDisplay() {
  var statusContainer = document.getElementById('rankStatusContainer');
  var computingBox = document.getElementById('rankComputingBox');
  var notEnabledBox = document.getElementById('rankNotEnabledBox');
  var grid = document.getElementById('ranksGridContainer');
  var chevron = document.getElementById('rankChevron');

  if (!grid) return;

  var isGridOpen = grid.style.display !== 'none' && getComputedStyle(grid).display !== 'none';
  var isNotEnabledOpen = notEnabledBox && notEnabledBox.style.display !== 'none' && getComputedStyle(notEnabledBox).display !== 'none';
  var isComputingOpen = computingBox && computingBox.style.display !== 'none';

  // Toggle close if currently visible
  if (isGridOpen || isNotEnabledOpen || isComputingOpen) {
    if (_rankComputingTimer) clearInterval(_rankComputingTimer);
    resetRankUI();
    return;
  }

  // Open state: Check if API exists for this exam
  var hasApi = checkRankApiAvailability();
  if (chevron) chevron.style.transform = 'rotate(180deg)';

  if (hasApi) {
    // API exists -> Show beautiful animation, then reveal ranks
    if (statusContainer) statusContainer.style.display = 'block';
    if (computingBox) computingBox.style.display = 'block';
    if (notEnabledBox) notEnabledBox.style.display = 'none';
    if (grid) grid.style.display = 'none';

    computingBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    var msgEl = document.getElementById('rankComputingMsg');
    var messages = [
      'Connecting to Rank Engine database...',
      'Analyzing response across All-India candidate pool...',
      'Comparing category & shift scores...',
      'Computing normalized percentiles & rankings...'
    ];
    var mIdx = 0;
    if (_rankComputingTimer) clearInterval(_rankComputingTimer);
    _rankComputingTimer = setInterval(function() {
      mIdx++;
      if (mIdx < messages.length && msgEl) {
        msgEl.textContent = messages[mIdx];
      }
    }, 450);

    executeRankCalculation(function(rankResult) {
      if (_rankComputingTimer) clearInterval(_rankComputingTimer);
      if (computingBox) computingBox.style.display = 'none';
      if (statusContainer) statusContainer.style.display = 'none';

      if (rankResult && rankResult.ok && rankResult.ranks) {
        if (_scoreData) {
          _scoreData.ranks = rankResult.ranks;
          var urlEl = document.getElementById('scoreUrl');
          var currentUrl = (urlEl && urlEl.value) || (_rawResultData && _rawResultData.url) || '';
          saveToScorecardCache(currentUrl, _scoreData, _rawResultData, _scoreData.student || {}, {
            exam_id: _scoreData.exam_id,
            category_vertical: (_scoreData.student && _scoreData.student.category) || 'UR',
            state: (_scoreData.student && _scoreData.student.state) || 'Rajasthan',
            gender: (_scoreData.student && _scoreData.student.gender) || 'Male',
            rrb_zone: (_scoreData.student && _scoreData.student.zone) || null
          });
        }
        populateRanksUI(rankResult.ranks);
        if (grid) {
          grid.style.display = 'flex';
          grid.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      } else {
        if (statusContainer) statusContainer.style.display = 'block';
        if (notEnabledBox) {
          notEnabledBox.style.display = 'flex';
          notEnabledBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

  } else {
    // API does not exist for this exam -> Show "Rank feature not enabled for this exam yet"
    if (grid) grid.style.display = 'none';
    if (statusContainer) statusContainer.style.display = 'block';
    if (computingBox) computingBox.style.display = 'none';
    if (notEnabledBox) {
      notEnabledBox.style.display = 'flex';
      notEnabledBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }
}

// 2. Review Questions (Full question-wise review & solutions)
function openReviewQuestions() {
  if (!_rawResultData || !_rawResultData.parts) {
    _showToast('Review paper is available when official response sheet is loaded.', 'info');
    return;
  }
  if (typeof RSMReviewBuilder === 'undefined') {
    _showToast('Review builder loading... please try again.', 'warn');
    return;
  }
  try {
    var reviewJson = RSMReviewBuilder.build(_rawResultData.family, _rawResultData.parts, _rawResultData.url);
    if (!reviewJson || !reviewJson.sections || !reviewJson.sections.length) {
      _showToast('Could not extract review questions from this paper.', 'error');
      return;
    }
    // Store exact return URL with current exam category (so back navigation never defaults to railway)
    var currentUrl = new URL(window.location.href);
    var targetExam = (_selectedExamConfig && _selectedExamConfig.id) || _activeExamTab || 'ssc';
    currentUrl.searchParams.set('exam', targetExam);
    sessionStorage.setItem('rsm-return-to', currentUrl.toString());

    sessionStorage.setItem('rsm-review-handoff', JSON.stringify(reviewJson));
    window.location.href = 'review.html';
  } catch (e) {
    console.error('Review open error:', e);
    _showToast('Failed to open Review Questions: ' + e.message, 'error');
  }
}

// Helper: Build dynamic filename from Exam Name and Roll Number (No fixed prefix)
function getScorecardFilename(extension) {
  var student = (_scoreData && _scoreData.student) || {};
  var roll = student.roll || student.roll_no || student.roll_number || '';
  var exam = (_selectedExamConfig && (_selectedExamConfig.title || _selectedExamConfig.name))
    || student.exam_name
    || student.exam
    || 'Scorecard';

  var cleanExam = String(exam)
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/&amp;/gi, '&')
    .replace(/&mp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim();

  var cleanRoll = String(roll)
    .replace(/[\\/:*?"<>|]/g, '')
    .trim();

  var baseName = (cleanExam + (cleanRoll ? (' ' + cleanRoll) : '')).trim();
  if (!baseName) baseName = 'Scorecard';

  var ext = extension ? (extension.startsWith('.') ? extension : ('.' + extension)) : '';
  return baseName + ext;
}

// 3. Download Official Answer Key PDF (Merged 1024 width view for SSC / single for RRB)
function downloadAnsKeyPdf() {
  if (!_rawResultData || !_rawResultData.parts) {
    _showToast('Official answer key is available when response sheet is loaded.', 'info');
    return;
  }
  if (typeof RSMOfficialPrint === 'undefined') {
    _showToast('Print module loading... please try again.', 'warn');
    return;
  }
  try {
    var pdfTitle = getScorecardFilename('');
    var merged = RSMOfficialPrint.mergeParts(_rawResultData.parts, _rawResultData.url);
    sessionStorage.setItem(RSMOfficialPrint.HANDOFF_KEY, JSON.stringify({
      title: pdfTitle,
      styles: merged.styles,
      bodyHtml: merged.bodyHtml
    }));
    window.open('official-print.html', '_blank');
  } catch (e) {
    console.error('Answer key open error:', e);
    _showToast('Failed to prepare answer key: ' + e.message, 'error');
  }
}

// 4. Print Candidate Scorecard or Save as PDF (Filename: Exam Name Roll Number.pdf)
function printScoreCard() {
  var origTitle = document.title;
  var pdfName = getScorecardFilename('');
  if (pdfName) {
    document.title = pdfName;
  }
  // Make sure print date and id are current
  var printDate = document.getElementById('printReportDate');
  if (printDate) {
    var now = new Date();
    printDate.textContent = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  var scrollContainer = document.querySelector('.screen-scroll');
  if (scrollContainer) {
    scrollContainer.scrollTop = 0;
  }
  window.scrollTo(0, 0);

  setTimeout(function() {
    window.print();
    setTimeout(function() {
      document.title = origTitle;
    }, 1200);
  }, 100);
}

window.addEventListener('beforeprint', function() {
  var scrollContainer = document.querySelector('.screen-scroll');
  if (scrollContainer) {
    scrollContainer.scrollTop = 0;
  }
  window.scrollTo(0, 0);
  if (_scoreData && _scoreData.student) {
    document.title = getScorecardFilename('');
  }
});

window.addEventListener('afterprint', function() {
  document.title = 'Score Calculator — Mock Matrix Hub | SSC & Railway Exams';
});

// 5. Open Review Questions filtered to Wrong / Correct / Skipped / All Questions
function openReviewQuestionsFilter(filter) {
  if (filter) {
    sessionStorage.setItem('rsm-review-filter', filter);
  } else {
    sessionStorage.removeItem('rsm-review-filter');
  }
  openReviewQuestions();
}

function openReviewWrongQuestions() {
  openReviewQuestionsFilter('wrong');
}

function openReviewCorrectQuestions() {
  openReviewQuestionsFilter('correct');
}

function openReviewSkippedQuestions() {
  openReviewQuestionsFilter('skipped');
}

function openReviewAllQuestions() {
  openReviewQuestionsFilter('all');
}

// 6. Save Candidate Scorecard as High-Resolution JPG Image in Background (Zero UI Disturbance)
async function generateScorecardImage() {
  var panel = document.getElementById('scorecardPanel');
  if (!panel) return;

  if (typeof html2canvas === 'undefined') {
    _showToast('Image renderer loading, please try again in a moment.', 'info');
    return;
  }

  var btn = document.getElementById('btnDownloadScorecardImg');
  var origText = btn ? btn.innerHTML : '';
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span>Saving Image...</span>';
  }

  var exportWidth = 1000;

  // 1. Create a 100% isolated off-screen sandbox container
  // Placed at left:0 and top:-99999px so it is perfectly aligned at x=0 (never clipped or translated incorrectly)
  var offscreenHost = document.createElement('div');
  offscreenHost.id = 'mmhOffscreenExportHost';
  offscreenHost.style.cssText = 'position:absolute; left:0; top:-99999px; width:' + exportWidth + 'px; max-width:' + exportWidth + 'px; min-width:' + exportWidth + 'px; background:#ffffff; z-index:-9999; opacity:0; pointer-events:none; overflow:visible; box-sizing:border-box; margin:0; padding:0;';

  // 2. Deep clone the scorecard panel
  var clone = panel.cloneNode(true);
  clone.id = 'scorecardPanelExportClone';
  clone.className = 'scorecard-panel image-export-active';
  clone.style.cssText = 'width:' + exportWidth + 'px !important; max-width:' + exportWidth + 'px !important; min-width:' + exportWidth + 'px !important; margin:0 !important; padding:24px 28px !important; background:#ffffff !important; box-sizing:border-box !important; position:static !important; overflow:visible !important;';

  // 3. Remove non-printable / interactive UI elements from the clone
  var removeSelectors = [
    '#cacheNoticeBanner',
    '.cache-notice-banner',
    '.no-print',
    '.pill-view-qs-text',
    '#markingCard',
    '#scorecardActionsBar',
    '.scorecard-actions-bar',
    '.score-actions-row',
    '.rank-trigger-container',
    '#rankStatusContainer',
    '.btn-edit-url',
    '.btn-pill-view-qs'
  ];
  removeSelectors.forEach(function(sel) {
    clone.querySelectorAll(sel).forEach(function(el) { el.remove(); });
  });

  // Ensure official header in clone is visible
  var printHeader = clone.querySelector('.print-only-block');
  if (printHeader) {
    printHeader.style.display = 'block';
    printHeader.style.marginBottom = '14px';
  }

  // Ensure candidate details table is 100% full width and properly formatted
  var candGrid = clone.querySelector('#candidateInfoGrid') || clone.querySelector('.candidate-info-grid');
  if (candGrid) {
    candGrid.style.cssText = 'display:block !important; width:100% !important; margin-top:6px !important; box-sizing:border-box !important;';
  }
  var candTable = clone.querySelector('.cand-details-table');
  if (candTable) {
    candTable.style.cssText = 'width:100% !important; border-collapse:collapse !important; font-size:11px !important; table-layout:fixed !important; box-sizing:border-box !important;';
  }

  // Ensure ranks grid in clone is open with separated subgroups
  var ranksWrap = clone.querySelector('#ranksGridContainer');
  if (ranksWrap) {
    ranksWrap.style.cssText = 'display:flex !important; flex-direction:column !important; gap:12px !important; margin-bottom:10px !important; width:100% !important; box-sizing:border-box !important;';
  }
  clone.querySelectorAll('.ranks-grid').forEach(function(g) {
    g.style.cssText = 'display:grid !important; grid-template-columns:repeat(4, 1fr) !important; gap:8px !important; width:100% !important; box-sizing:border-box !important;';
  });
  clone.querySelectorAll('.avgs-subgrid').forEach(function(g) {
    g.style.cssText = 'display:grid !important; grid-template-columns:repeat(3, 1fr) !important; gap:8px !important; width:100% !important; box-sizing:border-box !important;';
  });

  // Ensure section table is 100% visible without horizontal scroll
  var tblWrap = clone.querySelector('.table-responsive');
  if (tblWrap) {
    tblWrap.style.cssText = 'width:100% !important; overflow:visible !important; border:1px solid #cbd5e1 !important; box-sizing:border-box !important;';
  }
  var secTbl = clone.querySelector('.scorecard-tbl');
  if (secTbl) {
    secTbl.style.cssText = 'width:100% !important; table-layout:auto !important; font-size:12px !important; zoom:1 !important; box-sizing:border-box !important;';
  }

  // Ensure child cards don't have min-width 1000px that would overflow past padding
  clone.querySelectorAll('.candidate-card, .score-hero-box, .sections-card, .ranks-container-wrap').forEach(function(c) {
    c.style.cssText = 'width:100% !important; max-width:100% !important; min-width:0 !important; box-sizing:border-box !important; margin-bottom:12px !important;';
  });

  offscreenHost.appendChild(clone);
  document.body.appendChild(offscreenHost);

  try {
    // Small delay to ensure layout and fonts render in offscreen DOM
    await new Promise(function(resolve) { setTimeout(resolve, 80); });

    var actualWidth = clone.scrollWidth || exportWidth;
    var finalWidth = Math.max(exportWidth, actualWidth);

    var canvas = await html2canvas(clone, {
      scale: 2, // 2x crisp HD resolution
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      width: finalWidth,
      windowWidth: finalWidth,
      scrollX: 0,
      scrollY: 0,
      logging: false
    });

    var filename = getScorecardFilename('.jpg');

    // 100% quality JPEG export (0.98 ensures pristine 100% fidelity without compression artifacts)
    var dataUrl = canvas.toDataURL('image/jpeg', 0.98);
    var link = document.createElement('a');
    link.download = filename;
    link.href = dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    _showToast('Scorecard JPG image downloaded successfully!', 'success');
  } catch (err) {
    console.error('Image generation error:', err);
    _showToast('Notice generating image. Opening print view...', 'warn');
    window.print();
  } finally {
    if (offscreenHost && offscreenHost.parentNode) {
      offscreenHost.parentNode.removeChild(offscreenHost);
    }
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = origText;
    }
  }
}

// ── Custom Recalculation Override (Direct, Instant Client-Side Math) ──
function recalculateWithOverride() {
  if (!_scoreData || !_scoreData.scores) {
    _showToast('No calculated scorecard available to recalculate.', 'warn');
    return;
  }

  var corIn = document.getElementById('overrideCorrect');
  var incorIn = document.getElementById('overrideIncorrect');

  var corVal = corIn ? corIn.value.trim() : '';
  var incorVal = incorIn ? incorIn.value.trim() : '';

  var cor = parseFloat(corVal);
  var incor = parseFloat(incorVal);

  if (isNaN(cor)) {
    cor = (_selectedExamConfig && _selectedExamConfig.correct != null)
      ? Number(_selectedExamConfig.correct)
      : (_activeExamTab === 'ssc' ? 2.0 : 1.0);
  }
  if (isNaN(incor)) {
    incor = (_selectedExamConfig && _selectedExamConfig.wrong != null)
      ? Number(_selectedExamConfig.wrong)
      : (_activeExamTab === 'ssc' ? 0.5 : 0.3333);
  }
  incor = Math.abs(incor);

  var scores = _scoreData.scores;
  var secs = scores.sections || scores.section_scores || [];

  var newTotalScore = 0;
  var totalCorrect = 0;
  var totalIncorrect = 0;
  var totalBonus = 0;
  var totalQ = 0;

  secs.forEach(function(s) {
    var c = Number(s.correct) || 0;
    var w = Number(s.incorrect) || 0;
    var b = Number(s.bonus || s.bonus_questions) || 0;
    var q = Number(s.questions || s.total_questions || s.count) || (c + w);

    var secScore = Number(((c * cor) - (w * incor) + (b * cor)).toFixed(2));
    s.score = secScore;
    s.marks = secScore;

    newTotalScore += secScore;
    totalCorrect += c;
    totalIncorrect += w;
    totalBonus += b;
    totalQ += q;
  });

  newTotalScore = Number(newTotalScore.toFixed(2));

  // Directly update scores in _scoreData
  scores.total_score = newTotalScore;
  scores.max_score = Number((totalQ * cor).toFixed(2));
  if (scores.max_score > 0) {
    scores.percentage = Number(((newTotalScore / scores.max_score) * 100).toFixed(2));
  }
  scores.marking_scheme = {
    correct: cor,
    wrong: incor,
    incorrect: incor,
    bonus: cor
  };

  _isCustomMarking = true;

  // Immediately re-render scorecard with new values
  renderScorecardV2(_scoreData);

  // Sync to 15-minute cache so returning preserves this recalculated score
  var urlEl = document.getElementById('scoreUrl');
  var url = (urlEl && urlEl.value) || (_rawResultData && _rawResultData.url);
  if (url) {
    saveToScorecardCache(url, _scoreData, _rawResultData, _scoreData.student || {}, {});
  }

  var rBtn = document.getElementById('resetMarkingBtn');
  if (rBtn) rBtn.classList.remove('hidden');

  _showToast('Total score recalculated: ' + newTotalScore.toFixed(2), 'info');
}

function resetToDefaultMarking() {
  _isCustomMarking = false;
  var rBtn = document.getElementById('resetMarkingBtn');
  if (rBtn) rBtn.classList.add('hidden');

  var corIn = document.getElementById('overrideCorrect');
  var incorIn = document.getElementById('overrideIncorrect');
  if (corIn) corIn.value = '';
  if (incorIn) incorIn.value = '';

  var defCor = (_selectedExamConfig && _selectedExamConfig.correct != null)
    ? Number(_selectedExamConfig.correct)
    : (_activeExamTab === 'ssc' ? 2.0 : 1.0);
  var defIncor = (_selectedExamConfig && _selectedExamConfig.wrong != null)
    ? Number(_selectedExamConfig.wrong)
    : (_activeExamTab === 'ssc' ? 0.5 : 0.3333);

  var scores = _scoreData && _scoreData.scores;
  if (!scores) return;
  var secs = scores.sections || scores.section_scores || [];
  var newTot = 0;
  var totalQ = 0;

  secs.forEach(function(s) {
    var c = Number(s.correct) || 0;
    var w = Number(s.incorrect) || 0;
    var b = Number(s.bonus || s.bonus_questions) || 0;
    var q = Number(s.questions || s.total_questions || s.count) || (c + w);

    var secScore = Number(((c * defCor) - (w * defIncor) + (b * defCor)).toFixed(2));
    s.score = secScore;
    s.marks = secScore;

    newTot += secScore;
    totalQ += q;
  });

  newTot = Number(newTot.toFixed(2));
  scores.total_score = newTot;
  scores.max_score = Number((totalQ * defCor).toFixed(2));
  if (scores.max_score > 0) {
    scores.percentage = Number(((newTot / scores.max_score) * 100).toFixed(2));
  }
  scores.marking_scheme = {
    correct: defCor,
    wrong: defIncor,
    incorrect: defIncor,
    bonus: defCor
  };

  renderScorecardV2(_scoreData);
  _showToast('Default marking scheme restored.', 'info');
}

function resetForNewUrl() {
  enableScorecardDesktopView(false);
  var urlEl = document.getElementById('scoreUrl');
  if (urlEl) {
    urlEl.value = '';
    if (typeof urlEl.focus === 'function') urlEl.focus();
  }
  var panel = document.getElementById('scorecardPanel');
  if (panel) panel.classList.add('hidden');

  resetRankUI();

  var formCard = document.getElementById('scoreFormCard');
  if (formCard) {
    formCard.style.display = 'block';
    formCard.style.opacity = '1';
    formCard.scrollIntoView({ behavior: 'smooth' });
  }
}

// Fallback generator with clean dummy placeholder data (NO real student data)
function generateFallbackScorecard(url, body) {
  var isSsc = body.exam_tab === 'ssc';
  return {
    ok: true,
    submission_id: 'MMH-' + Date.now().toString(36).toUpperCase(),
    student: {
      name: "Aspirant XYZ",
      roll: "2401XXXXXXXX",
      exam: isSsc ? "SSC CGL 2025 Tier-I Examination" : "RRB Level 1 / Group D Exam",
      date: "03/08/2026",
      time: "12:45 PM - 2:15 PM",
      subject: isSsc ? "Combined Graduate Level" : "Level 1",
      venue: "Digital Assessment Center"
    },
    scores: {
      total_score: isSsc ? 124.50 : 50.00,
      total_questions: 100,
      total_correct: isSsc ? 68 : 57,
      total_incorrect: isSsc ? 22 : 21,
      total_not_answered: isSsc ? 10 : 22,
      bonus_questions: 0,
      accuracy: 73.08,
      percentile: 85.69,
      section_scores: isSsc ? [
        { subject: "General Intelligence & Reasoning", total_questions: 25, correct: 20, incorrect: 3, not_answered: 2, bonus_questions: 0, score: 38.50 },
        { subject: "General Awareness", total_questions: 25, correct: 14, incorrect: 8, not_answered: 3, bonus_questions: 0, score: 24.00 },
        { subject: "Quantitative Aptitude", total_questions: 25, correct: 18, incorrect: 5, not_answered: 2, bonus_questions: 0, score: 33.50 },
        { subject: "English Comprehension", total_questions: 25, correct: 16, incorrect: 6, not_answered: 3, bonus_questions: 0, score: 28.50 }
      ] : [
        { subject: "General Science", total_questions: 25, correct: 15, incorrect: 5, not_answered: 5, bonus_questions: 0, score: 13.33 },
        { subject: "Mathematics", total_questions: 25, correct: 16, incorrect: 5, not_answered: 4, bonus_questions: 0, score: 14.33 },
        { subject: "General Intelligence & Reasoning", total_questions: 30, correct: 18, incorrect: 6, not_answered: 6, bonus_questions: 0, score: 26.00 },
        { subject: "General Awareness", total_questions: 20, correct: 8, incorrect: 5, not_answered: 7, bonus_questions: 0, score: 3.33 }
      ]
    },
    ranks: null
  };
}

function _showToast(msg, type) {
  var t = document.createElement('div');
  t.style.position = 'fixed';
  t.style.bottom = '24px';
  t.style.left = '50%';
  t.style.transform = 'translateX(-50%)';
  t.style.background = type === 'error' ? '#dc2643' : '#141c2e';
  t.style.color = '#ffffff';
  t.style.padding = '10px 18px';
  t.style.borderRadius = '8px';
  t.style.fontSize = '13px';
  t.style.fontWeight = '700';
  t.style.zIndex = '99999';
  t.style.boxShadow = '0 6px 20px rgba(0,0,0,0.3)';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function() { t.remove(); }, 3000);
}

// ── 15-Minute Scorecard Cache Engine (Partitioned per Category) ──────
var MMH_CACHE_KEY_PREFIX = 'mmh_calc_cache_v2_';
var MMH_CACHE_TTL = 15 * 60 * 1000; // 15 minutes

function normalizeUrlKey(u) {
  if (!u) return '';
  return u.trim().toLowerCase().split('#')[0];
}

function getCacheKeyForCategory(cat) {
  var c = (cat || _activeExamTab || 'rrb').toLowerCase();
  return MMH_CACHE_KEY_PREFIX + c;
}

function saveToScorecardCache(url, scoreData, rawResultData, studentInfo, formInputs) {
  try {
    var cat = (_activeExamTab || (scoreData && scoreData.family) || 'rrb').toLowerCase();
    var examId = (_selectedExamConfig && _selectedExamConfig.id)
      || (scoreData && scoreData.exam_id)
      || (formInputs && formInputs.exam_id)
      || (document.getElementById('scoreExamSelect') && document.getElementById('scoreExamSelect').value)
      || '';

    // NEVER save full page HTML in cache — only the rendered scorecard details
    var payload = {
      url: (url || '').trim(),
      timestamp: Date.now(),
      category: cat,
      family: cat,
      exam_tab: cat,
      exam_id: examId,
      scoreData: scoreData,
      studentInfo: studentInfo,
      formInputs: formInputs || {}
    };
    localStorage.setItem(getCacheKeyForCategory(cat), JSON.stringify(payload));
  } catch (err) {
    console.warn('Cache save notice:', err);
  }
}

function getScorecardCache(targetUrl, targetCategory) {
  try {
    var cat = (targetCategory || _activeExamTab || 'rrb').toLowerCase();
    var raw = localStorage.getItem(getCacheKeyForCategory(cat));
    if (!raw) return null;
    var cached = JSON.parse(raw);
    if (!cached || !cached.timestamp) {
      localStorage.removeItem(getCacheKeyForCategory(cat));
      return null;
    }
    // Auto-expire after 15 minutes
    var age = Date.now() - cached.timestamp;
    if (age > MMH_CACHE_TTL) {
      localStorage.removeItem(getCacheKeyForCategory(cat));
      return null;
    }
    // Strictly verify category matches
    if (cached.category && cached.category !== cat) {
      return null;
    }
    if (targetUrl) {
      if (normalizeUrlKey(targetUrl) !== normalizeUrlKey(cached.url)) {
        return null;
      }
    }
    return cached;
  } catch (err) {
    return null;
  }
}

function purgeScorecardCache(category) {
  try {
    if (category) {
      localStorage.removeItem(getCacheKeyForCategory(category));
    } else {
      ['ssc', 'rrb', 'other'].forEach(function(c) {
        localStorage.removeItem(MMH_CACHE_KEY_PREFIX + c);
      });
      localStorage.removeItem('mmh_calc_cache_v2');
    }
  } catch (e) {}
}

function toggleFormCard() {
  showInputForm();
}
window.toggleFormCard = toggleFormCard;

function restoreFromScorecardCache(cached) {
  if (!cached || !cached.scoreData) return false;

  enableScorecardDesktopView(true);

  _scoreData = cached.scoreData;
  _rawResultData = null; // Clean cache: raw HTML is never stored in cache

  // Restore exam_id, category, and family on _scoreData
  var restoredExamId = cached.exam_id || (_scoreData && _scoreData.exam_id) || '';
  if (restoredExamId && _scoreData) {
    _scoreData.exam_id = restoredExamId;
  }
  if (cached.category && _scoreData) {
    _scoreData.category_vertical = cached.category;
  }

  if (cached.formInputs) {
    var fi = cached.formInputs;
    if (fi.url) {
      var uIn = document.getElementById('scoreUrl');
      if (uIn) uIn.value = fi.url;
    }
    if (fi.category_vertical) {
      var catIn = document.getElementById('scoreCategory');
      if (catIn) catIn.value = fi.category_vertical;
    }
    if (fi.state) {
      var stIn = document.getElementById('scoreState');
      if (stIn) stIn.value = fi.state;
    }
    if (fi.gender) {
      var gnIn = document.getElementById('scoreGender');
      if (gnIn) gnIn.value = fi.gender;
    }
    if (fi.rrb_zone) {
      var znIn = document.getElementById('scoreRrbZone');
      if (znIn) znIn.value = fi.rrb_zone;
    }
  }

  // Restore selected exam in dropdown
  if (restoredExamId) {
    var sel = document.getElementById('scoreExamSelect');
    if (sel) {
      sel.value = restoredExamId;
      onExamSelectChange();
    }
  }

  renderStudentInfo(cached.studentInfo || (_scoreData && _scoreData.student) || {}, cached.formInputs || {});
  renderScorecardV2(_scoreData);

  var formCard = document.getElementById('scoreFormCard');
  if (formCard) formCard.style.display = 'none';

  var panel = document.getElementById('scorecardPanel');
  if (panel) {
    panel.classList.remove('hidden');
    renderCacheBanner(cached.timestamp);
  }

  // Restore or automatically compute ranks
  if (_scoreData && _scoreData.ranks && _scoreData.ranks.air && _scoreData.ranks.air.rank) {
    populateRanksUI(_scoreData.ranks);
    var ranksContainer = document.getElementById('ranksGridContainer');
    if (ranksContainer) ranksContainer.style.display = 'flex';
    var rankChevron = document.getElementById('rankChevron');
    if (rankChevron) rankChevron.style.transform = 'rotate(180deg)';
  } else {
    autoComputeAndShowRanks();
  }

  return true;
}

function renderCacheBanner(timestamp) {
  var existing = document.getElementById('cacheNoticeBanner');
  if (existing) existing.remove();

  var ageSec = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
  var ageMins = Math.floor(ageSec / 60);
  var remainingMins = Math.max(1, 15 - ageMins);

  var banner = document.createElement('div');
  banner.id = 'cacheNoticeBanner';
  banner.className = 'cache-notice-banner no-print';
  banner.innerHTML = '<span class="cn-icon">⚡</span>' +
    '<span class="cn-text">Restored from recent calculation (Auto-clears in ' + remainingMins + ' min)</span>' +
    '<button type="button" class="cn-btn-clear" onclick="clearCachedScore()">Recalculate Fresh</button>';

  var panel = document.getElementById('scorecardPanel');
  if (panel) {
    panel.insertBefore(banner, panel.firstChild);
  }
}

function clearCachedScore() {
  enableScorecardDesktopView(false);
  purgeScorecardCache(_activeExamTab);
  var existing = document.getElementById('cacheNoticeBanner');
  if (existing) existing.remove();
  var panel = document.getElementById('scorecardPanel');
  if (panel) panel.classList.add('hidden');
  var formCard = document.getElementById('scoreFormCard');
  if (formCard) {
    formCard.style.display = 'block';
    formCard.style.opacity = '1';
    formCard.scrollIntoView({ behavior: 'smooth' });
  }
  _scoreData = null;
  _rawResultData = null;
  _showToast('Cache cleared for ' + _activeExamTab.toUpperCase() + '. You can calculate fresh.', 'info');
}
window.clearCachedScore = clearCachedScore;

// Auto-cleanup expired cache
setInterval(function() {
  ['ssc', 'rrb', 'other'].forEach(function(cat) {
    var raw = localStorage.getItem(MMH_CACHE_KEY_PREFIX + cat);
    if (raw) {
      try {
        var cached = JSON.parse(raw);
        if (cached && (Date.now() - cached.timestamp > MMH_CACHE_TTL)) {
          purgeScorecardCache(cat);
          if (_activeExamTab === cat) {
            var banner = document.getElementById('cacheNoticeBanner');
            if (banner) banner.remove();
          }
        }
      } catch (e) { purgeScorecardCache(cat); }
    }
  });
}, 30000);

// Auto-initialize from URL query parameters (exam id or category)
document.addEventListener('DOMContentLoaded', function() {
  try {
    var p = new URLSearchParams(window.location.search);
    var examParam = p.get('exam') || p.get('id');
    var familyParam = p.get('family');
    var urlParam = p.get('url');

    var targetFamily = familyParam || 'rrb';
    var targetExamId = null;

    if (examParam) {
      var ep = examParam.toLowerCase().trim();
      if (ep === 'ssc' || ep === 'rrb' || ep === 'other') {
        targetFamily = ep;
      } else {
        targetExamId = examParam;
        if (ep.startsWith('ssc') || ep.startsWith('delhi-police')) {
          targetFamily = 'ssc';
        } else if (ep.startsWith('rrb')) {
          targetFamily = 'rrb';
        } else if (ep.startsWith('other')) {
          targetFamily = 'other';
        }
      }
    }

    // Purge legacy unpartitioned key if found
    try { localStorage.removeItem('mmh_calc_cache_v2'); } catch (e) {}

    // Check if initial target category has active scorecard cache
    var initCached = getScorecardCache(null, targetFamily);
    if (initCached && initCached.scoreData) {
      enableScorecardDesktopView(true);
    } else {
      enableScorecardDesktopView(false);
    }

    switchExamCategory(targetFamily, targetExamId);

    // Auto-populate URL parameter if present & attach live validation listeners
    var uIn = document.getElementById('scoreUrl');
    if (uIn) {
      if (urlParam) uIn.value = urlParam;

      uIn.addEventListener('input', function() {
        _isDemoUrlFilled = false;
        var errEl = document.getElementById('urlError');
        if (errEl) errEl.style.display = 'none';
      });

      uIn.addEventListener('blur', function() {
        var val = (uIn.value || '').trim();
        if (val) {
          var vRes = validateAnswerKeyUrl(val);
          var errEl = document.getElementById('urlError');
          if (!vRes.valid && errEl) {
            errEl.textContent = vRes.message;
            errEl.style.display = 'block';
          }
        }
      });
    }
  } catch (e) {
    switchExamCategory('rrb');
  }
});


var _howGuideLang = 'en';
var _howGuideSteps = {
  rrb: {
    en: [
      'Go to the official Railway response sheet page and <strong>copy your response sheet URL</strong>',
      'Paste the copied URL in the input box above and select your <strong>Category, State and Zone</strong>',
      'Click on <strong>Calculate</strong> to instantly view your verified score, section marks, and rank'
    ],
    hi: [
      'ऑफिशियल रेलवे रिस्पॉन्स शीट पेज पर जाएं और <strong>अपना रिस्पॉन्स शीट URL कॉपी करें</strong>',
      'ऊपर दिए गए इनपुट बॉक्स में कॉपी किया गया URL पेस्ट करें और अपनी <strong>Category, State और Zone</strong> चुनें',
      'अपना वेरीफाइड स्कोर, सेक्शन मार्क्स और रैंक तुरंत देखने के लिए <strong>Calculate</strong> पर क्लिक करें'
    ]
  },
  ssc: {
    en: [
      'Go to the official SSC response sheet page and <strong>copy your response sheet URL</strong>',
      'Paste the copied URL in the input box above and select your <strong>Category and State</strong>',
      'Click on <strong>Calculate</strong> to instantly view your verified score, section marks, and rank'
    ],
    hi: [
      'ऑफिशियल SSC रिस्पॉन्स शीट पेज पर जाएं और <strong>अपना रिस्पॉन्स शीट URL कॉपी करें</strong>',
      'ऊपर दिए गए इनपुट बॉक्स में कॉपी किया गया URL पेस्ट करें और अपनी <strong>Category और State</strong> चुनें',
      'अपना वेरीफाइड स्कोर, सेक्शन मार्क्स और रैंक तुरंत देखने के लिए <strong>Calculate</strong> पर क्लिक करें'
    ]
  },
  other: {
    en: [
      'Go to the official exam response sheet page and <strong>copy your response sheet URL</strong>',
      'Paste the copied URL in the input box above and select your <strong>Category and State</strong>',
      'Click on <strong>Calculate</strong> to instantly view your verified score, section marks, and rank'
    ],
    hi: [
      'ऑफिशियल रिस्पॉन्स शीट पेज पर जाएं और <strong>अपना रिस्पॉन्स शीट URL कॉपी करें</strong>',
      'ऊपर दिए गए इनपुट बॉक्स में कॉपी किया गया URL पेस्ट करें और अपनी <strong>Category और State</strong> चुनें',
      'अपना वेरीफाइड स्कोर, सेक्शन मार्क्स और रैंक तुरंत देखने के लिए <strong>Calculate</strong> पर क्लिक करें'
    ]
  }
};

function switchHowGuideLang(lang) {
  _howGuideLang = lang || 'en';
  var btnEn = document.getElementById('howLangEn');
  var btnHi = document.getElementById('howLangHi');
  if (btnEn) btnEn.classList.toggle('active', _howGuideLang === 'en');
  if (btnHi) btnHi.classList.toggle('active', _howGuideLang === 'hi');

  var cat = _activeExamTab || 'rrb';
  var texts = (_howGuideSteps[cat] && _howGuideSteps[cat][_howGuideLang]) || _howGuideSteps.rrb[_howGuideLang];
  var s1 = document.getElementById('howStep1');
  var s2 = document.getElementById('howStep2');
  var s3 = document.getElementById('howStep3');
  if (s1 && texts && texts[0]) s1.innerHTML = texts[0];
  if (s2 && texts && texts[1]) s2.innerHTML = texts[1];
  if (s3 && texts && texts[2]) s3.innerHTML = texts[2];
}
window.switchHowGuideLang = switchHowGuideLang;

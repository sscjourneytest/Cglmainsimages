/* ═══════════════════════════════════════════════════
   MOCK MATRIX HUB · SCORE CALCULATOR — parser-rrb.js  (v4 — Universal TCS / DigiAlm Parser)
   Parses the single-page TCS / DigiAlm / Railway response sheet HTML
   into the same { candidateInfo, sections[] } shape the SSC
   parser produces.

   Supports ALL TCS & DigiAlm formats:
   - RRB NTPC, RRB Group D, RRB ALP, RRB Technician, RRB JE
   - DSSSB, FCI, State Police, DDA, CTET, and all other exams
   - Question ID and Option IDs extraction from menu-tbl
   - Numbered options (1, 2, 3, 4) and lettered options (A, B, C, D)
   - Evaluates Correct, Wrong, Skipped, and Bonus accurately
═══════════════════════════════════════════════════ */

const RSMParserRRB = (() => {

  function decodeEntities(s) {
    return (s || '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .trim();
  }

  /**
   * Candidate info extraction from .main-info-pnl or top tables.
   */
  function parseCandidateInfo(html) {
    const info = {};
    const panelM = html.match(/class=["']main-info-pnl["'][\s\S]*?<table[\s\S]*?<\/table>/i);
    const scope = panelM ? panelM[0] : html;

    const grab = (patterns) => {
      for (const pat of patterns) {
        const re = new RegExp(`<td[^>]*>\\s*${pat}\\s*<\\/td>\\s*<td[^>]*>([\\s\\S]*?)<\\/td>`, 'i');
        const m = scope.match(re);
        if (m) {
          const val = decodeEntities(m[1].replace(/<[^>]+>/g, '')).trim();
          if (val) return val;
        }
      }
      return '';
    };

    info.rollNo = grab(['Roll\\s*Number', 'Roll\\s*No\\.?', 'Participant\\s*ID', 'Candidate\\s*ID']);
    info.name = grab(['Candidate\\s*Name', 'Participant\\s*Name', 'Applicant\\s*Name']);
    info.registrationNo = grab(['Registration\\s*Number', 'Reg\\s*No\\.?', 'Application\\s*No\\.?']);
    info.community = grab(['Community', 'Category']);
    info.centre = grab(['Test\\s*Centre\\s*Name', 'Centre\\s*Name', 'Center\\s*Name', 'Venue\\s*Name', 'Vanue\\s*Name']);
    info.date = grab(['Test\\s*Date', 'Exam\\s*Date', 'Date']);
    info.shift = grab(['Test\\s*Time', 'Exam\\s*Time', 'Shift']);
    info.exam = grab(['Subject', 'Subject\\s*Name', 'Test', 'Test\\s*Name', 'Post', 'Post\\s*Name', 'Exam\\s*Name']);

    Object.keys(info).forEach(k => { if (!info[k]) delete info[k]; });
    return info;
  }

  /**
   * Splits the page into sections using section-lbl markers.
   * Falls back to one "General" section if none found.
   */
  function splitSections(html) {
    const sections = [];
    const lblRegex = /class=["']section-lbl["'][^>]*>([\s\S]*?)<\/div>/gi;
    const labelPositions = [];
    let m;
    while ((m = lblRegex.exec(html)) !== null) {
      const name = decodeEntities(m[1].replace(/<[^>]+>/g, '')).replace(/^Section\s*:?\s*/i, '').trim();
      labelPositions.push({ name: name || 'General', pos: m.index });
    }

    if (labelPositions.length === 0) {
      return [{ name: 'General', html }];
    }

    labelPositions.forEach((lbl, idx) => {
      const end = idx + 1 < labelPositions.length ? labelPositions[idx + 1].pos : html.length;
      sections.push({ name: lbl.name, html: html.substring(lbl.pos, end) });
    });

    return sections;
  }

  /**
   * Splits a section's html into individual question blocks.
   * Uses robust multiple fallbacks:
   *   1. <td ...> Q.N </td> (universal in TCS/DigiAlm)
   *   2. <div class="question-pnl">
   *   3. Question ID : in menu-tbl
   */
  function splitQuestions(sectionHtml) {
    let positions = [];
    const qRegex = /<td[^>]*>\s*Q\.?\s*(\d+)\s*<\/td>/gi;
    let m;
    while ((m = qRegex.exec(sectionHtml)) !== null) {
      positions.push({ qno: parseInt(m[1], 10), pos: m.index });
    }

    if (positions.length === 0) {
      const pnlRegex = /<div[^>]*class=["'][^"']*question-pnl[^"']*["']/gi;
      let count = 0;
      while ((m = pnlRegex.exec(sectionHtml)) !== null) {
        count++;
        positions.push({ qno: count, pos: m.index });
      }
    }

    if (positions.length === 0) {
      const qidRegex = /Question\s*ID\s*:\s*<\/td>/gi;
      let count = 0;
      while ((m = qidRegex.exec(sectionHtml)) !== null) {
        count++;
        positions.push({ qno: count, pos: m.index });
      }
    }

    const blocks = [];
    positions.forEach((p, idx) => {
      const end = idx + 1 < positions.length ? positions[idx + 1].pos : sectionHtml.length;
      blocks.push({ qno: p.qno, html: sectionHtml.substring(p.pos, end) });
    });
    return blocks;
  }

  function normalizeOptionKey(str) {
    if (!str) return '';
    const s = str.trim().toUpperCase();
    if (s === '1') return 'A';
    if (s === '2') return 'B';
    if (s === '3') return 'C';
    if (s === '4') return 'D';
    if (s === '5') return 'E';
    return s;
  }

  /**
   * Extracts the official correct answer from a TCS question block.
   * Finds the option associated with class="rightAns".
   */
  function extractRightAnswer(block) {
    if (
      block.toLowerCase().includes('question cancelled') ||
      block.toLowerCase().includes('benefit of doubt') ||
      block.toLowerCase().includes('question ignored') ||
      block.toLowerCase().includes('given to all') ||
      block.toLowerCase().includes('taken up for challenge')
    ) {
      return null;
    }

    // Iterate through individual <tr> rows to find the exact option row containing rightAns
    const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
    let trM;
    while ((trM = trRegex.exec(block)) !== null) {
      const trHtml = trM[1];
      if (/class=["'](?:[^"']*\s+)?rightAns(?:\s+[^"']*)?["']/i.test(trHtml)) {
        const numM = trHtml.match(/\b([A-E1-5])\s*\./i) || trHtml.match(/\b([A-E1-5])\b/i);
        if (numM) return normalizeOptionKey(numM[1]);
      }
    }

    return null;
  }

  /**
   * Extracts raw "Chosen Option" value (e.g. "1", "2", "A", "B", "--").
   */
  function extractChosenOption(block) {
    const m = block.match(/Chosen\s*Option\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? decodeEntities(m[1].replace(/<[^>]+>/g, '')).trim() : '';
  }

  /**
   * Extracts question status label (e.g. "Answered", "Not Answered", "Marked For Review").
   */
  function extractStatus(block) {
    const m = block.match(/Status\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? decodeEntities(m[1].replace(/<[^>]+>/g, '')).trim() : '';
  }

  /**
   * Extracts the Question ID from menu-tbl (e.g. "4410091631384").
   */
  function extractQuestionId(block) {
    const m = block.match(/Question\s*ID\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? decodeEntities(m[1].replace(/<[^>]+>/g, '')).trim() : null;
  }

  /**
   * Extracts Option IDs { "1": "...", "2": "...", ... } from menu-tbl.
   */
  function extractOptionIds(block) {
    const ids = {};
    const re = /Option\s*(\d)\s*ID\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/gi;
    let m;
    while ((m = re.exec(block)) !== null) {
      ids[m[1]] = decodeEntities(m[2].replace(/<[^>]+>/g, '')).trim();
    }
    return ids;
  }

  /**
   * Status evaluation:
   *   1. If cancelled / benefit of doubt / no right answer -> bonus
   *   2. If chosen option is missing, "--", or status is "Not Answered" -> skipped
   *   3. If chosen option matches right answer -> correct
   *   4. Otherwise -> wrong
   */
  function questionStatus(block) {
    if (
      block.toLowerCase().includes('question cancelled') ||
      block.toLowerCase().includes('benefit of doubt') ||
      block.toLowerCase().includes('question ignored') ||
      block.toLowerCase().includes('given to all') ||
      block.toLowerCase().includes('taken up for challenge')
    ) {
      return 'bonus';
    }

    const chosenRaw = extractChosenOption(block);
    const statusText = extractStatus(block);
    const chosen = normalizeOptionKey(chosenRaw);
    const rightAns = extractRightAnswer(block);

    if (!rightAns) {
      return 'bonus';
    }

    const isSkipped = !chosen || chosen === '--' || chosenRaw === '--' || chosenRaw === ' -- ' || statusText === 'Not Answered' || !/^[A-E]$/.test(chosen);

    if (isSkipped) {
      return 'skipped';
    }

    if (chosen === rightAns) {
      return 'correct';
    }

    return 'wrong';
  }

  function parseSection(section) {
    const blocks = splitQuestions(section.html);
    const questions = blocks.map(b => ({
      qno: b.qno,
      qId: extractQuestionId(b.html),
      optionIds: extractOptionIds(b.html),
      status: questionStatus(b.html)
    }));
    return { name: section.name, questions };
  }

  /**
   * @param {Object<string,string>} parts - TCS / RRB fetcher returns { p1: html }
   * @returns {{ candidateInfo: Object, sections: Array<{name,questions}> }}
   */
  function parse(parts) {
    const html = parts.p1 || Object.values(parts)[0] || '';
    const candidateInfo = parseCandidateInfo(html);
    const rawSections = splitSections(html);
    const sections = rawSections.map(parseSection).filter(s => s.questions.length > 0);

    return { candidateInfo, sections };
  }

  return { parse };
})();

if (typeof window !== 'undefined') window.RSMParserRRB = RSMParserRRB;
if (typeof module !== 'undefined' && module.exports) module.exports = RSMParserRRB;

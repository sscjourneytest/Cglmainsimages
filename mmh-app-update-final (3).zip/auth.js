const PROXY_URL = 'https://auth.mockmatrixhub.in';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1cW1lanl5cHFna3JqbHBwbHJ6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2MDIyNTAsImV4cCI6MjA4NzE3ODI1MH0.aAIITdr-BS-D-TJHY1fEkqgN4CRVwsyz90d2I9IrhVc';

let _supabase = null;

// De-duplicates CONCURRENT getSession() calls into a single underlying
// request — e.g. auth.js's own initAuth() and a page's own on-load check
// both firing within the same tick would otherwise trigger two separate
// (possibly two separate refresh) calls to Supabase. This does NOT cache
// indefinitely: the in-flight flag clears the moment the call resolves,
// so a call made later (a button click minutes after page load) still
// performs its own fresh check, as it correctly should.
let _inFlightSessionCheck = null;
function getSessionOnce(client) {
    if (_inFlightSessionCheck) return _inFlightSessionCheck;
    _inFlightSessionCheck = client.auth.getSession().finally(() => {
        _inFlightSessionCheck = null;
    });
    return _inFlightSessionCheck;
}

async function getClient() {
    if (_supabase) return _supabase;
    if (typeof supabase === 'undefined' || !supabase || typeof supabase.createClient !== 'function') {
        throw new Error('Network offline: Supabase SDK not loaded');
    }
    _supabase = supabase.createClient(PROXY_URL, SUPABASE_KEY);

    // Single authoritative signal for "the user is really logged out."
    // Supabase fires this only when it has confirmed the session is gone
    // (explicit sign-out, refresh token revoked/invalid) — never on a
    // transient network error. This replaces ad-hoc redirect-to-login
    // decisions scattered across page loads with one reliable source.
    _supabase.auth.onAuthStateChange((event) => {
        if (event === 'SIGNED_OUT') {
            // When the user explicitly logs out via the confirmation modal,
            // executeLogout() handles the spinner completion and transition.
            if (window._mmhLogoutInProgress) return;
            // Never sign out a user with a valid u_vault while offline
            if (!navigator.onLine && typeof getLocalProfile === 'function' && getLocalProfile()) return;
            clearAuthLocal();
            const path = window.location.pathname;
            // LOGIN-FIRST: every page except the public whitelist is gated,
            // so a confirmed sign-out leaves it. sendToLogin() shows the
            // in-home auth view when already on '/', preventing any loop.
            if (isGatedPage(path)) {
                if (!sendToLogin(path + window.location.search)) {
                    window.dispatchEvent(new Event('profileUpdated'));
                }
            } else {
                // Public page — storage already cleared above. Don't
                // redirect, just tell the page to refresh its UI.
                window.dispatchEvent(new Event('profileUpdated'));
            }
        }
    });

    return _supabase;
}

const SECRET_SALT = "mmh_vault_key_99";

// ── UTC-safe expiry helpers (handles Supabase format "2027-08-24 09:23:05.553+00") ──
function parseExpiryDate(str){
    if(!str) return null;
    try{
        let s = String(str).trim();
        if(s.includes(' ') && !s.includes('T')){
            s = s.replace(' ', 'T');
        }
        s = s.replace(/\+00$/, 'Z').replace(/\+00:00$/, 'Z').replace(/\+0000$/, 'Z').replace(/\s*\+00$/, 'Z');
        const d = new Date(s);
        if(!isNaN(d.getTime())) return d;
        const d2 = new Date(str);
        return isNaN(d2.getTime()) ? null : d2;
    }catch(e){ return null; }
}
function isPaidStillValid(p){
    if(!p || !p.is_paid) return false;
    if(!p.expires_at) return true;
    const exp = parseExpiryDate(p.expires_at);
    if(!exp) return !!p.is_paid;
    return exp.getTime() > Date.now();
}
function getTimeLeftMs(expires_at){
    const exp = parseExpiryDate(expires_at);
    if(!exp) return null;
    return exp.getTime() - Date.now();
}
window.parseExpiryDate = parseExpiryDate;
window.isPaidStillValid = isPaidStillValid;
window.getTimeLeftMs = getTimeLeftMs;

// Same storage clearing handleLogout() does — minus signOut()/redirect,
// so it's safe to call from anywhere (including from inside the
// SIGNED_OUT listener itself) without recursing or double-navigating.
function clearAuthLocal() {
    localStorage.removeItem('u_vault');
    localStorage.removeItem('mmh_guide_seen');
}

// ── Page gating: LOGIN-FIRST — a whitelist of PUBLIC paths ────────────────
// The gate is now inverted. EVERY page requires a logged-in session, and
// only the paths listed below are reachable without one:
//
//   • /login.html      — the entry point. Must stay public or nobody can
//                        ever get in (redirect loop).
//   • legal pages      — terms / privacy / refund / about / contact. Left
//                        public on purpose: Play Store & App Store review
//                        open these from the store listing, and signup
//                        screens conventionally link to them.
//   • /delete-account.html — Google Play's account-deletion web resource.
//                        Must be reachable with NO session at all: a user who
//                        already uninstalled the app (or whose password no
//                        longer works) still has to be able to request
//                        deletion. Gating this page would itself be the policy
//                        violation.
//   • /score-calculator/* — standalone tool with its own JS bundle.
//
// Anything else — home, exams, live-test, series, saved, profile, premium,
// admin/partner, test.html — sends an anonymous visitor straight to
// login.html with ?redirect=<where they were>, so they land back on the
// exact page after signing in.
//
// To make a page public again, add its path to PUBLIC_PATHS. To lock one
// down, remove it. Nothing else needs changing.
const PUBLIC_PATHS = [
    '/terms-conditions.html',
    '/privacy-policy.html',
    '/refund-policy.html',
    '/about-us.html',
    '/contact-us.html',
    '/delete-account.html',
    '/score-calculator',
];

// Treated as the same page as its filename (e.g. "/" === "/index.html"),
// so the site root cannot be used to slip past the gate.
const PATH_ALIASES = { '/': '/index.html' };

function isHomePagePath(path) {
    const p = normalisePath(path || window.location.pathname);
    return p === '/index.html' || p === '/';
}
window.isHomePagePath = isHomePagePath;

function normalisePath(path) {
    let p = String(path || '/');
    try { p = decodeURIComponent(p); } catch (e) { /* malformed %xx — use raw */ }
    p = p.split('#')[0].split('?')[0];
    if (!p.startsWith('/')) p = '/' + p;

    // Collapse "." / ".." segments BEFORE matching. Browsers and servers
    // resolve these, so without this a crafted URL could wear a public
    // prefix as a disguise — e.g. "/terms-conditions.html/../../profile.html"
    // starts with a whitelisted path but is really the gated profile page.
    const out = [];
    for (const seg of p.split('/')) {
        if (!seg || seg === '.') continue;
        if (seg === '..') { out.pop(); continue; }
        out.push(seg);
    }
    p = '/' + out.join('/');
    // keep a trailing slash only if the original had one ("/score-calculator/")
    if (p !== '/' && /\/$/.test(String(path).split('#')[0].split('?')[0])) p += '/';

    return PATH_ALIASES[p] || p;
}

function isPublicPath(path) {
    const p = normalisePath(path);
    return PUBLIC_PATHS.some(pub =>
        p === pub ||
        p.startsWith(pub.endsWith('/') ? pub : pub + '/') ||
        // extension-less routes: /terms-conditions -> /terms-conditions.html
        p + '.html' === pub
    );
}

// Every page that is not explicitly public now needs a session to render.
function isGatedPage(path) {
    return !isPublicPath(path);
}

// ── Single funnel to the login screen (now embedded in Home '/') ──────────
// Preserves the page the user was trying to open so they land back on it
// after signing in. When already on the Home page ('/' or '/index.html'),
// displays the in-home auth overlay directly in place with zero redirect.
function sendToLogin(returnPath) {
    const here = window.location.pathname + window.location.search;
    if (isPublicPath(window.location.pathname)) return false; // already on public/legal — nowhere to go
    if (isHomePagePath(window.location.pathname)) {
        if (typeof window.mmhShowHomeAuth === 'function') {
            window.mmhShowHomeAuth();
        } else {
            document.documentElement.classList.add('mmh-auth-active');
            try {
                if (!new URLSearchParams(window.location.search).has('login')) {
                    window.history.replaceState({}, '', '/?login');
                }
            } catch (e) {}
        }
        return false;
    }
    const target = returnPath || here;
    const isTargetHome = target === '/' || target === '/index.html' || target.startsWith('/index.html?') || target.startsWith('/?');
    const url = isTargetHome ? '/?login' : ('/?login&redirect=' + encodeURIComponent(target));
    try { window.location.replace(url); } catch (e) { window.location.href = url; }
    return true;
}
window.mmhSendToLogin = sendToLogin;

// ── Pre-paint gate: splash overlay + release valve ───────────────────────
// A logged-out visitor must not even SEE a gated page while Supabase is
// being asked "is there a session?". The <head> of a gated page flips
// window.MMH_AUTH_GATE_PENDING to true and (on pages without their own
// boot splash, i.e. everything except home) injects the overlay below
// before first paint. initAuth() then does exactly one of:
//   releaseAuthGate()  — session verified, reveal the page
//   sendToLogin()      — no session, go to login (overlay stays up)
// Nothing in between ever reveals gated content.
window.MMH_AUTH_GATE_PENDING = false;

function gateOverlayStyles() {
    if (document.getElementById('mmhGateCss')) return;
    const css = document.createElement('style');
    css.id = 'mmhGateCss';
    css.textContent = [
        '.mmh-auth-gate{position:fixed;inset:0;z-index:2147483000;display:flex;',
        'flex-direction:column;align-items:center;justify-content:center;gap:12px;',
        'padding:32px 24px calc(32px + env(safe-area-inset-bottom));text-align:center;',
        'background:#fff;font-family:Poppins,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;}',
        'html.dark-mode .mmh-auth-gate,body.dark-mode .mmh-auth-gate{background:#0a0f1e;}',
        '.mag-mark{width:68px;height:68px;border-radius:19px;display:grid;place-items:center;',
        'background:linear-gradient(135deg,#3d5afe,#7c4dff);color:#fff;',
        'box-shadow:0 10px 26px rgba(61,90,254,.35);animation:mag-pulse 1.1s ease-in-out infinite;}',
        '.mag-mark img{width:100%;height:100%;object-fit:cover;border-radius:19px;display:block;}',
        '.mag-mark svg{width:34px;height:34px;}',
        '.mag-title{margin-top:6px;font-size:17px;font-weight:800;letter-spacing:-.2px;color:#0f172a;}',
        '.mag-spin{width:22px;height:22px;margin-top:6px;border-radius:50%;',
        'border:2.5px solid #dbe2f3;border-top-color:#3d5afe;animation:mag-spin .8s linear infinite;}',
        '.mag-text{font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:#7b879c;}',
        '.mag-actions{display:none;gap:10px;margin-top:8px;flex-wrap:wrap;justify-content:center;}',
        '.mag-btn{appearance:none;border:0;cursor:pointer;font:inherit;font-size:12px;font-weight:800;',
        'letter-spacing:.4px;padding:11px 18px;border-radius:12px;background:#3d5afe;color:#fff;}',
        '.mag-btn.ghost{background:transparent;color:#3d5afe;box-shadow:inset 0 0 0 2px #c7d2fe;}',
        'html.dark-mode .mag-title{color:#eef1fb;}html.dark-mode .mag-text{color:#6d7898;}',
        'html.dark-mode .mag-spin{border-color:#31406a;border-top-color:#5b74ff;}',
        'html.dark-mode .mag-btn.ghost{color:#9db0ff;box-shadow:inset 0 0 0 2px #31406a;}',
        '@keyframes mag-spin{to{transform:rotate(360deg)}}',
        '@keyframes mag-pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}',
        '@media (prefers-reduced-motion:reduce){.mag-mark{animation:none}.mag-spin{animation-duration:1.6s}}',
    ].join('');
    (document.head || document.documentElement).appendChild(css);
}

// Builds the overlay markup. Safe to call from a <head> script (no DOM yet)
// or later. Reuses an existing overlay instead of stacking duplicates.
function ensureAuthGateSplash(label) {
    gateOverlayStyles();
    let box = document.getElementById('mmhAuthGate');
    const mark = '<img src="/logo.png" alt="" onerror="this.outerHTML=' +
        "'<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\'>" +
        "<rect x=\'3.2\' y=\'3.2\' width=\'7.6\' height=\'7.6\' rx=\'2.2\'/>" +
        "<rect x=\'13.2\' y=\'3.2\' width=\'7.6\' height=\'7.6\' rx=\'2.2\'/>" +
        "<rect x=\'3.2\' y=\'13.2\' width=\'7.6\' height=\'7.6\' rx=\'2.2\'/>" +
        "<rect x=\'13.2\' y=\'13.2\' width=\'7.6\' height=\'7.6\' rx=\'2.2\' fill=\'currentColor\' stroke=\'none\'/></svg>'\">";
    const html =
        '<div class="mag-mark">' + mark + '</div>' +
        '<div class="mag-title">Mock Matrix Hub</div>' +
        '<div class="mag-spin"></div>' +
        '<div class="mag-text" id="mmhGateText">' + (label || 'Checking your session\u2026') + '</div>' +
        '<div class="mag-actions" id="mmhGateActions">' +
            '<button type="button" class="mag-btn" id="mmhGateRetry">Retry</button>' +
            '<button type="button" class="mag-btn ghost" id="mmhGateToLogin">Go to login</button>' +
        '</div>';
    if (!box) {
        box = document.createElement('div');
        box.id = 'mmhAuthGate';
        box.className = 'mmh-auth-gate';
        box.setAttribute('aria-hidden', 'true');
        box.innerHTML = html;
        (document.body || document.documentElement).appendChild(box);
    } else if (label) {
        box.innerHTML = html;
    }
    return box;
}

function setGateText(text) {
    const el = document.getElementById('mmhGateText');
    if (el) el.textContent = text;
}

// Session verified — take the curtain down. On home this also releases the
// page's own boot splash (body.home-booting), which stays up while the gate
// is pending so the frame can never paint before auth resolves.
function releaseAuthGate() {
    window.MMH_AUTH_GATE_PENDING = false;
    document.body.classList.remove('home-booting');
    const box = document.getElementById('mmhAuthGate');
    if (box) box.remove();
}

// Verification itself failed (offline, blocked storage, Worker cold start).
// The curtain stays DOWN — an unverifiable visitor is not a logged-in one.
// Auto-retries a few times, then offers Retry / Go to login.
function showGateRetry(message) {
    window.MMH_AUTH_GATE_PENDING = false; // stop auto-retry loops from stacking
    const box = ensureAuthGateSplash();
    setGateText(message || 'Could not verify your login.');
    const spin = box.querySelector('.mag-spin');
    if (spin) spin.style.display = 'none';
    const actions = box.querySelector('#mmhGateActions');
    if (actions) {
        actions.style.display = 'flex';
        const retry = box.querySelector('#mmhGateRetry');
        const toLogin = box.querySelector('#mmhGateToLogin');
        if (retry) retry.onclick = () => { window.MMH_AUTH_GATE_PENDING = true; setGateText('Checking your session\u2026'); if (spin) spin.style.display = ''; actions.style.display = 'none'; initAuth(); };
        if (toLogin) toLogin.onclick = () => { sendToLogin(window.location.pathname + window.location.search); };
    }
}
window.mmhReleaseAuthGate = releaseAuthGate;
window.mmhEnsureAuthGateSplash = ensureAuthGateSplash;

function isExplicitInvalidTokenError(err) {
    if (!err) return false;
    const status = Number(err.status || err.statusCode || 0);
    const name = String(err.name || '');
    const msg = String(err.message || err.error_description || err.code || '').toLowerCase();
    // Network / offline / timeout / 5xx errors during token refresh are NOT invalid tokens
    if (name === 'AuthRetryableFetchError' || status === 0 || status >= 500 ||
        msg.includes('failed to fetch') || msg.includes('network') || msg.includes('timeout') || msg.includes('load failed')) {
        return false;
    }
    if (msg.includes('invalid refresh token') ||
        msg.includes('refresh_token_not_found') ||
        msg.includes('invalid_grant') ||
        msg.includes('user_not_found') ||
        msg.includes('user_banned') ||
        msg.includes('session_not_found') ||
        status === 400 || status === 401 || status === 403) {
        return true;
    }
    return false;
}

function hasStoredSupabaseToken() {
    try {
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith('sb-') && k.endsWith('-auth-token')) {
                const v = localStorage.getItem(k);
                if (v && v !== 'null' && v.length > 10) return true;
            }
        }
    } catch (e) {}
    return false;
}

// Call this before any ACTION that needs a logged-in user on an otherwise
// public page — "Start Test", "Save Question", "Buy Premium", "Reattempt",
// etc. Returns the user if already logged in. If not, sends them to
// login with a return path (so they land back on the exact action
// they meant to do) and returns null — caller should stop right there.
function isProfileIncomplete(p) {
    if (!p || !p.id) return true;
    const u = String(p.username || '').trim();
    return !u || u === 'User';
}
window.isProfileIncomplete = isProfileIncomplete;

async function requireLogin(returnPath) {
    const client = await getClient();
    let session = null;
    try {
        const { data } = await getSessionOnce(client);
        session = data.session;
    } catch (e) {
        // Network hiccup — don't falsely claim "not logged in" and wipe
        // their progress toward this action. Let them know and stop.
        alert("Could not verify your login. Please check your connection and try again.");
        return null;
    }
    const target = returnPath || (window.location.pathname + window.location.search);
    if (session && session.user) {
        let localProf = getLocalProfile();
        if (!localProf || isProfileIncomplete(localProf)) {
            localProf = await fetchAndCacheProfile(client, session.user);
        }
        if (!localProf || localProf._incomplete || isProfileIncomplete(localProf)) {
            if (typeof window.mmhOpenCompleteProfileModal === 'function') {
                window.mmhOpenCompleteProfileModal(session.user, localProf, target);
                return null;
            }
            window.location.href = "/?complete_profile=1&redirect=" + encodeURIComponent(target);
            return null;
        }
        return session.user;
    }

    clearAuthLocal();
    sendToLogin(target);
    return null;
}

/**
 * Fetches (and caches) the full profile for a logged-in user.
 * Used both by initAuth() and by login.html's login/signup flows so that
 * nobody gets redirected to another page before their profile data
 * has actually arrived.
 * Returns the profile object on success, or null if it could not be loaded.
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Attempts the profiles fetch up to `retries` times with a short backoff
 * between attempts (network blips, cold-start Worker, etc). Throws the
 * last error if every attempt fails. A "no row found" response is also
 * treated as a failure here (single() errors on 0 rows) so it goes
 * through the same retry path — cheap insurance in case it was actually
 * transient replication lag rather than a truly missing profile.
 */
async function fetchProfileWithRetry(client, userId, retries = 3) {
    let lastError = null;
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const { data, error } = await client.from('profiles').select('*').eq('id', userId).single();
            if (error) throw error;
            if (data) return data;
            throw new Error('Profile row not found');
        } catch (e) {
            lastError = e;
            if (attempt < retries) await sleep(attempt * 700); // 700ms, then 1400ms
        }
    }
    throw lastError;
}

async function fetchAndCacheProfile(client, user, forceRefresh) {
    // 1. BACKGROUND SYNC: If user has a pending request, check status automatically
    if (localStorage.getItem('pending_premium_request') === 'true') {
        await syncPendingPremiumStatus(client, user.email);
    }

    let profile = getLocalProfile();
    const urlParams = new URLSearchParams(window.location.search);
    // A cached profile only counts as "current" if it actually belongs to
    // the user who is now authenticated. Without this, a still-valid (not
    // yet expired) cache left over from a PREVIOUS user on this same
    // browser/device gets returned as-is for the NEW logged-in user —
    // showing the wrong username/is_paid/etc until the old cache happens
    // to expire on its own 7-day timer.
    const cacheBelongsToOtherUser = profile && profile.id !== user.id;
    const forceFetch = !!forceRefresh || urlParams.get('type') === 'recovery' || !profile || !profile.id || !profile.username || isProfileIncomplete(profile) || cacheBelongsToOtherUser;

    if (cacheBelongsToOtherUser) {
        profile = null; // don't hand back stale data from a different account while the fresh fetch is in flight
    }

    // 2. CACHE MANAGEMENT: Fetch profile if missing or expired
    if (forceFetch || isCacheExpired()) {
        // Stale-While-Revalidate: If we already have a valid cached profile for this user,
        // return it immediately so the UI is never blocked by slow network requests!
        if (profile && !forceFetch) {
            fetchProfileWithRetry(client, user.id, 2).then(async (dbProfile) => {
                if (isProfileIncomplete(dbProfile)) return;
                let isPartner = false;
                try {
                    const { data: activeCoupons } = await client
                        .from('coupons')
                        .select('code')
                        .eq('owner_user_id', dbProfile.id)
                        .eq('is_active', true)
                        .limit(1);
                    isPartner = !!(activeCoupons && activeCoupons.length > 0);
                } catch (e) {}

                let freshProfile = { ...dbProfile, is_partner: isPartner };
                if (freshProfile.is_paid && freshProfile.expires_at) {
                    const exp = parseExpiryDate(freshProfile.expires_at);
                    if (exp && exp.getTime() <= Date.now()) {
                        freshProfile.is_paid = false;
                    }
                }
                saveLocalProfile(freshProfile);
            }).catch(e => {
                console.warn('Background profile refresh skipped/failed:', e);
            });
            return profile;
        }

        try {
            const dbProfile = await fetchProfileWithRetry(client, user.id, 3);

            // If user signed in with Google for the first time and has not yet
            // completed Full Name + Unique Username + 10-Digit Mobile, do not
            // cache u_vault yet — signal caller to open strict Complete Profile view.
            if (isProfileIncomplete(dbProfile)) {
                try { localStorage.removeItem('u_vault'); } catch (e) {}
                return { ...dbProfile, _incomplete: true };
            }

            // Partner status lives in the coupons table, not profiles.
            // Resolve it HERE — only when we're already doing a fresh
            // fetch (once per login / once every 7 days) — instead of
            // querying it separately on every page load.
            //
            // NOTE: an owner_user_id can have MORE THAN ONE active coupon
            // row (confirmed in production data). maybeSingle() throws
            // when a query matches more than one row, which was silently
            // failing here for those users and leaving is_partner=false
            // even though they do have active coupons. Using a plain
            // select + limit(1) instead — we only need to know whether
            // at least one active coupon exists, not fetch a single row.
            let isPartner = false;
            try {
                const { data: activeCoupons } = await client
                    .from('coupons')
                    .select('code')
                    .eq('owner_user_id', dbProfile.id)
                    .eq('is_active', true)
                    .limit(1);
                isPartner = !!(activeCoupons && activeCoupons.length > 0);
            } catch (e) {
                // Leave isPartner false on error; next cache refresh will retry.
            }

            let freshProfile = { ...dbProfile, is_partner: isPartner };
            // ── enforce expiry before caching (zero API) ──
            if(freshProfile.is_paid && freshProfile.expires_at){
                const exp = parseExpiryDate(freshProfile.expires_at);
                if(exp && exp.getTime() <= Date.now()){
                    try{
                        const oldRaw = localStorage.getItem('u_vault');
                        if(oldRaw){
                            const oldDec = decodeURIComponent(escape(atob(oldRaw))).replace(SECRET_SALT,'');
                            const oldData = JSON.parse(oldDec);
                            if(oldData && oldData.is_paid){
                                localStorage.setItem('mmh_just_expired','1');
                                localStorage.setItem('mmh_just_expired_ts', String(Date.now()));
                            }
                        }
                    }catch(e){}
                    freshProfile.is_paid = false;
                }
            }
            saveLocalProfile(freshProfile);

            // GUARANTEE: never treat this as a successful load unless it's
            // actually readable back from localStorage. Protects against a
            // silent write failure (quota exceeded, private-browsing storage
            // caps, etc) where saveLocalProfile() ran but nothing actually
            // persisted — we don't want to hand back a "profile loaded"
            // result that isn't backed by cache.
            const verify = getLocalProfile();
            if (!verify || verify.id !== freshProfile.id) {
                throw new Error('Profile save to localStorage could not be verified');
            }

            // Only now — save confirmed — does this become "the" profile.
            profile = freshProfile;
        } catch (e) {
            console.error('Profile fetch failed after retries:', e);

            // Deliberately NOT signing the user out here, even when there's
            // no cached fallback. A failed profile read (network hiccup,
            // Worker cold start, DB briefly slow) says nothing about whether
            // the auth session itself is valid — only Supabase's own
            // onAuthStateChange('SIGNED_OUT') is treated as proof of that.
            // Callers handle profile === null by showing a retry message
            // (login.html) or simply proceeding with whatever getLocalProfile()
            // already has cached (every other page) — the user stays logged
            // in and the UI self-corrects once the fetch succeeds.
            return profile || null;
        }
    }

    return profile;
}

/**
 * Works out where to send the user after they finish logging in / registering.
 * Priority: explicit ?redirect= param (the page that bounced them to login) >
 * same-origin referrer (if it isn't the login page itself) > home page.
 */
function getSafeRedirectTarget() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('redirect');
    if (raw) {
        try {
            const decoded = decodeURIComponent(raw);
            // Only allow internal, same-site paths (never redirect off-site)
            if (decoded.startsWith('/') && !decoded.startsWith('//')) {
                return decoded;
            }
        } catch (e) {}
    }

    if (document.referrer) {
        try {
            const refUrl = new URL(document.referrer);
            if (refUrl.origin === window.location.origin && !refUrl.pathname.endsWith('login.html') && refUrl.pathname !== '/' && !refUrl.pathname.endsWith('/index.html')) {
                return refUrl.pathname + refUrl.search;
            }
        } catch (e) {}
    }

    return "/";
}

// `_autoRetries` is threaded through the recursive retry below — a plain
// local would reset to 0 on every re-entry and loop forever when the
// network stays down.
async function initAuth(_autoRetries = 0) {
    const path = window.location.pathname;
    const isLoginPage = path.endsWith("login.html") || path.endsWith("/login");
    const isHomePage = isHomePagePath(path);
    const requiresLogin = isGatedPage(path) && !isLoginPage;

    let autoRetries = _autoRetries;
    const MAX_AUTO_RETRIES = 2;

    if (requiresLogin) {
        if (!isHomePage) {
            window.MMH_AUTH_GATE_PENDING = true;
            // Home carries its own boot splash (body.home-booting), so it does
            // not need this generic overlay; every other gated page does.
            if (!document.body.classList.contains('home-booting')) {
                ensureAuthGateSplash('Checking your session\u2026');
            }
        } else {
            // Home page: unblock UI immediately so cached content shows without network delay
            window.MMH_AUTH_GATE_PENDING = false;
            document.body.classList.remove('home-booting');
        }
    }

    let client = null;
    let user = null;
    let checkFailed = false;
    let explicitInvalidToken = false;
    try {
        client = await getClient();
        const res = await getSessionOnce(client);
        const session = res && res.data ? res.data.session : null;
        const sessionError = res ? res.error : null;
        user = session ? session.user : null;
        if (sessionError) {
            if (isExplicitInvalidTokenError(sessionError)) {
                explicitInvalidToken = true;
            } else {
                console.warn('Session refresh network/offline error (preserving u_vault):', sessionError);
                checkFailed = true;
            }
        }
    } catch (e) {
        if (isExplicitInvalidTokenError(e)) {
            explicitInvalidToken = true;
        } else {
            console.error('Session check failed:', e);
            checkFailed = true;
        }
    }

    if (user) {
        // Fetch the full profile and WAIT for it before doing anything that
        // depends on it (like leaving the login page).
        const profile = await fetchAndCacheProfile(client, user);

        // If the user logged in via Google and has not completed their profile
        // (Full Name, Unique Username, 10-Digit Mobile), strictly enforce completion.
        if (profile && profile._incomplete) {
            if (requiresLogin) releaseAuthGate();
            const sp = new URLSearchParams(window.location.search);
            if (isHomePage && typeof window.mmhOpenCompleteProfileModal === 'function') {
                window.mmhOpenCompleteProfileModal(user, profile, sp.get('redirect') || null);
            } else {
                const returnTo = path + window.location.search;
                window.location.href = "/?complete_profile=1&redirect=" + encodeURIComponent(returnTo);
            }
            return;
        }

        // VARIABLE EXPOSURE: Extracting required data for other page functions
        const username = profile ? profile.username : "User";
        const isPaid = profile ? profile.is_paid : false;
        const isAdmin = profile ? profile.role === 'admin' : false;
        const isPartner = profile ? profile.is_partner : false;
        const expiryDate = profile && profile.expires_at ? new Date(profile.expires_at) : null;

        let daysLeft = 0;
        if (expiryDate) {
            daysLeft = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
        }

        // (Note: UI rendering logic moved to individual index.html files)

        if (isLoginPage && profile) {
            // Profile confirmed loaded — safe to leave the login page now.
            window.location.href = getSafeRedirectTarget();
        }

        if (isHomePage && (profile || getLocalProfile())) {
            // If the in-home auth screen was active (or a ?redirect= parameter exists),
            // unlock the home page or forward to the requested redirect target.
            if (typeof window.mmhOnHomeAuthSuccess === 'function') {
                window.mmhOnHomeAuthSuccess(true);
            } else {
                document.documentElement.classList.remove('mmh-auth-active');
            }
        }

        // Logged in: whatever curtain this page put up can come down.
        if (requiresLogin) releaseAuthGate();
        // If profile is null here, the session is still perfectly valid —
        // fetchAndCacheProfile() no longer signs anyone out over a failed
        // profile read. The page just keeps whatever getLocalProfile() has
        // cached (or sensible defaults) and self-corrects once a fetch
        // succeeds and fires 'profileUpdated'.
        return;
    }

    // If u_vault profile exists in localStorage and Supabase has NOT explicitly
    // rejected the token (e.g., user is offline or internet is slow while token
    // refresh failed), NEVER show the login overlay or clear u_vault!
    const cachedVaultProfile = typeof getLocalProfile === 'function' ? getLocalProfile() : null;
    const hasValidVault = !!(cachedVaultProfile && (cachedVaultProfile.id || cachedVaultProfile.username));

    if (!explicitInvalidToken && hasValidVault && (checkFailed || !navigator.onLine)) {
        if (isHomePage) {
            if (typeof window.mmhOnHomeAuthSuccess === 'function') {
                window.mmhOnHomeAuthSuccess(true);
            } else {
                document.documentElement.classList.remove('mmh-auth-active');
            }
        }
        if (requiresLogin) releaseAuthGate();
        return;
    }

    if (checkFailed) {
        // Could not determine auth state at all (rare — storage blocked,
        // client init error, offline) and no cached u_vault profile exists.
        if (requiresLogin) {
            if (autoRetries < MAX_AUTO_RETRIES) {
                autoRetries++;
                setGateText('Retrying\u2026 (' + autoRetries + '/' + MAX_AUTO_RETRIES + ')');
                await sleep(900);
                return initAuth(autoRetries); // carry the counter, don't restart it
            }
            showGateRetry('Could not verify your login. Check your connection.');
        }
        return;
    }

    // Confirmed: Supabase explicitly returned no valid session / invalid token.
    if (requiresLogin) {
        clearAuthLocal();
        sendToLogin(path + window.location.search);
    }
}

/**
 * Background Sync Logic: Checks if a pending payment has been approved
 */
async function syncPendingPremiumStatus(client, email) {
    const { data } = await client.from('payment_requests')
        .select('status')
        .eq('email', email)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

    if (data && data.status === 'success') {
        const { data: dbProfile } = await client.from('profiles').select('*').eq('email', email).single();
        if (dbProfile) {
            const profile = { ...dbProfile, email: email, is_paid: true };
            saveLocalProfile(profile);
            localStorage.removeItem('pending_premium_request');
            location.reload(); // Refresh to update premium UI across the site
        }
    } else if (data && data.status === 'rejected') {
        localStorage.removeItem('pending_premium_request');
    }
}

function saveLocalProfile(data) {
    if (!data || typeof data !== 'object') return;
    const payload = { ...data };
    delete payload.cache_expiry; // No automatic 7-day expiry — u_vault persists until logout/delete
    const json = JSON.stringify(payload) + SECRET_SALT;
    // btoa() only handles Latin1 — a Hindi/Devanagari full_name (unrestricted
    // free-text field at signup) would throw here and silently break caching
    // for that user on every save. encodeURIComponent/unescape round-trip
    // makes this Unicode-safe without changing the stored format.
    const encrypted = btoa(unescape(encodeURIComponent(json)));
    try {
        localStorage.setItem('u_vault', encrypted);
    } catch (e) {
        try {
            const broadPrefixes = ['state_', 'result_', 'qstats_', 'stream_', 'rankLastAutoRefreshedAt_'];
            const keysToRemove = [];
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && broadPrefixes.some(p => key.startsWith(p))) {
                    keysToRemove.push(key);
                }
            }
            keysToRemove.forEach(k => localStorage.removeItem(k));
            localStorage.setItem('u_vault', encrypted);
        } catch (e2) {
            console.error('saveLocalProfile: localStorage write failed', e2);
            return;
        }
    }

    // Tell active page to update UI right now
    window.dispatchEvent(new Event('profileUpdated'));
}


let _mmhExpiryRecheckInFlight = false;
async function reverifyExpiredPlanOnce(staleData) {
    if (_mmhExpiryRecheckInFlight || !staleData || !staleData.id) return;
    _mmhExpiryRecheckInFlight = true;
    try {
        const client = await getClient();
        const { data: dbProf, error } = await client
            .from('profiles')
            .select('is_paid, expires_at')
            .eq('id', staleData.id)
            .maybeSingle();
        if (!error && dbProf) {
            const dbExp = dbProf.expires_at ? parseExpiryDate(dbProf.expires_at) : null;
            const dbStillValid = !!(dbProf.is_paid && (!dbExp || dbExp.getTime() > Date.now()));
            if (dbStillValid) {
                // User renewed on another device or during 48h window — update u_vault with new expiry!
                localStorage.removeItem('mmh_just_expired');
                localStorage.removeItem('mmh_just_expired_ts');
                saveLocalProfile({ ...staleData, is_paid: true, expires_at: dbProf.expires_at });
                return;
            }
        }
        // Confirmed expired in DB (or no active renewal found) — mark u_vault as is_paid: false
        try {
            const lastShown = parseInt(localStorage.getItem('mmh_expired_banner_shown_ts') || '0', 10);
            if (!lastShown || Date.now() - lastShown > 24 * 60 * 60 * 1000) {
                localStorage.setItem('mmh_just_expired', '1');
                localStorage.setItem('mmh_just_expired_ts', String(Date.now()));
            }
        } catch (e) {}
        const corrected = { ...staleData, is_paid: false };
        delete corrected.cache_expiry;
        const json = JSON.stringify(corrected) + SECRET_SALT;
        const encrypted = btoa(unescape(encodeURIComponent(json)));
        localStorage.setItem('u_vault', encrypted);
        setTimeout(() => { try { window.dispatchEvent(new Event('profileUpdated')); } catch (e) {} }, 0);
    } catch (e) {
        // Offline/network error — fallback to local expiry enforcement
        const corrected = { ...staleData, is_paid: false };
        delete corrected.cache_expiry;
        const json = JSON.stringify(corrected) + SECRET_SALT;
        const encrypted = btoa(unescape(encodeURIComponent(json)));
        try { localStorage.setItem('u_vault', encrypted); } catch (e2) {}
        setTimeout(() => { try { window.dispatchEvent(new Event('profileUpdated')); } catch (e2) {} }, 0);
    } finally {
        _mmhExpiryRecheckInFlight = false;
    }
}

function getLocalProfile() {
    const raw = localStorage.getItem('u_vault');
    if (!raw) return null;
    try {
        let decrypted = '';
        try {
            decrypted = decodeURIComponent(escape(atob(raw))).replace(SECRET_SALT, '');
        } catch (e1) {
            decrypted = atob(raw).replace(SECRET_SALT, '');
        }
        const data = JSON.parse(decrypted);
        if (!data || typeof data !== 'object' || (!data.id && !data.username)) {
            // Corrupted or incomplete vault entry — clean it up so it gets freshly updated
            try { localStorage.removeItem('u_vault'); } catch (e) {}
            return null;
        }
        let base = {
            username: "User",
            email: "",
            is_paid: false,
            is_partner: false,
            ...data
        };
        // ── expiry enforcement - checks DB once on transition in case renewed on another device / 48h window ──
        // Handles "2027-08-24 09:23:05.553+00" robustly (UTC)
        if(data.is_paid && data.expires_at){
            const exp = parseExpiryDate(data.expires_at);
            if(exp && exp.getTime() <= Date.now()){
                base.is_paid = false;
                setTimeout(() => { reverifyExpiredPlanOnce(data); }, 0);
            }
        }
        return base;
    } catch (e) {
        // Corrupted u_vault — remove so it can be cleanly re-populated
        try { localStorage.removeItem('u_vault'); } catch (e2) {}
        return null;
    }
}

function isCacheExpired() {
    const p = getLocalProfile();
    // Only re-fetch when missing, corrupted, or incomplete (no 7-day automatic expiry)
    return !p || !p.id || !p.username || p.username === 'User' || !p.email;
}

async function handleChangePassword() {
    const client = await getClient();
    const { data: { session } } = await getSessionOnce(client);
    const user = session ? session.user : null;
    if (user) {
        const { error } = await client.auth.resetPasswordForEmail(user.email, {
            redirectTo: window.location.origin + '/?type=recovery',
        });
        alert(error ? "Error: " + error.message : "A password reset link has been sent to your Gmail!");
    }
}

function ensureLogoutModalStyles() {
    if (document.getElementById('mmhLogoutModalCss')) return;
    const st = document.createElement('style');
    st.id = 'mmhLogoutModalCss';
    st.textContent =
        '.mmh-lo-backdrop{position:fixed;inset:0;z-index:100050;background:rgba(15,23,42,0.52);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;transition:opacity .18s ease}' +
        '.mmh-lo-backdrop.show{opacity:1}' +
        '.mmh-lo-card{width:100%;max-width:330px;background:var(--surface,#ffffff);color:var(--text,#0b0f19);border:1px solid var(--border,#e2e8f0);border-radius:18px;padding:22px 20px 18px;box-shadow:0 20px 44px -12px rgba(15,23,42,0.28);text-align:center;font-family:"Plus Jakarta Sans",system-ui,-apple-system,sans-serif;transform:scale(0.95) translateY(6px);transition:transform .2s cubic-bezier(0.22,1,0.36,1)}' +
        '[data-theme="dark"] .mmh-lo-card,body.dark-mode .mmh-lo-card{background:#111c2d;color:#f8fafc;border-color:#23324a;box-shadow:0 22px 48px -12px rgba(0,0,0,0.65)}' +
        '.mmh-lo-backdrop.show .mmh-lo-card{transform:scale(1) translateY(0)}' +
        '.mmh-lo-icon{width:46px;height:46px;border-radius:50%;background:rgba(220,38,38,0.1);color:#dc2626;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px}' +
        '[data-theme="dark"] .mmh-lo-icon,body.dark-mode .mmh-lo-icon{background:rgba(248,113,113,0.14);color:#f87171}' +
        '.mmh-lo-title{font-size:16.5px;font-weight:500;letter-spacing:-0.2px;margin:0 0 6px;color:inherit}' +
        '.mmh-lo-sub{font-size:13px;font-weight:400;line-height:1.45;color:var(--text-2,#334155);margin:0 0 18px}' +
        '[data-theme="dark"] .mmh-lo-sub,body.dark-mode .mmh-lo-sub{color:#cbd5e1}' +
        '.mmh-lo-actions{display:flex;gap:10px}' +
        '.mmh-lo-btn{flex:1;height:42px;border-radius:11px;font-family:inherit;font-size:13.5px;font-weight:500;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:background .15s,opacity .15s,transform .1s;border:none;outline:none}' +
        '.mmh-lo-btn:active:not(:disabled){transform:scale(0.98)}' +
        '.mmh-lo-btn:disabled{opacity:0.65;cursor:not-allowed}' +
        '.mmh-lo-cancel{background:var(--surface-2,#f1f5f9);color:var(--text,#0b0f19);border:1px solid var(--border,#e2e8f0)}' +
        '[data-theme="dark"] .mmh-lo-cancel,body.dark-mode .mmh-lo-cancel{background:#192538;color:#e2e8f0;border-color:#293548}' +
        '.mmh-lo-confirm{background:#dc2626;color:#ffffff;box-shadow:0 4px 12px rgba(220,38,38,0.24)}' +
        '.mmh-lo-confirm:hover:not(:disabled){background:#b91c1c}' +
        '.mmh-lo-spin{width:15px;height:15px;border-radius:50%;border:2px solid rgba(255,255,255,0.32);border-top-color:#ffffff;animation:mmhLoSpin .65s linear infinite;flex-shrink:0}' +
        '@keyframes mmhLoSpin{to{transform:rotate(360deg)}}';
    (document.head || document.documentElement).appendChild(st);
}

async function executeLogout(redirectTo, modalEl) {
    window._mmhLogoutInProgress = true;
    const minWait = sleep(380);
    try {
        if (window.MMHRazorpay && typeof window.MMHRazorpay.signOutGoogle === 'function') {
            window.MMHRazorpay.signOutGoogle('55996733763-t11uoh5csjbntq6o0d2e9vefr52nu54j.apps.googleusercontent.com');
        }
    } catch (e) {}
    try {
        const client = await getClient();
        clearAuthLocal();
        await Promise.all([
            client.auth.signOut().catch(() => {}),
            minWait
        ]);
    } catch (e) {
        clearAuthLocal();
        await minWait;
    } finally {
        window._mmhLogoutInProgress = false;
    }

    if (modalEl && modalEl.parentNode) {
        modalEl.classList.remove('show');
        setTimeout(() => { try { modalEl.remove(); } catch (e) {} }, 180);
    }

    if (redirectTo && isPublicPath(redirectTo)) {
        window.location.href = redirectTo;
        return;
    }

    if (isHomePagePath(window.location.pathname)) {
        try { if (typeof closeSidebar === 'function') closeSidebar(); } catch (e) {}
        try { if (typeof resetLoggedOutUI === 'function') resetLoggedOutUI(); } catch (e) {}
        try { window.dispatchEvent(new Event('profileUpdated')); } catch (e) {}
        if (typeof window.mmhShowHomeAuth === 'function') {
            window.mmhShowHomeAuth();
        } else {
            document.documentElement.classList.add('mmh-auth-active');
            try { window.history.replaceState({}, '', '/?login'); } catch (e) {}
        }
        return;
    }

    try { window.location.replace('/?login'); } catch (e) { window.location.href = '/?login'; }
}

function handleLogout(redirectTo) {
    ensureLogoutModalStyles();
    const existing = document.getElementById('mmhLogoutModal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'mmhLogoutModal';
    modal.className = 'mmh-lo-backdrop';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.innerHTML =
        '<div class="mmh-lo-card">' +
            '<div class="mmh-lo-icon">' +
                '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>' +
                    '<polyline points="16 17 21 12 16 7"/>' +
                    '<line x1="21" y1="12" x2="9" y2="12"/>' +
                '</svg>' +
            '</div>' +
            '<h3 class="mmh-lo-title">Logout Account?</h3>' +
            '<p class="mmh-lo-sub">Are you sure you want to log out of your account?</p>' +
            '<div class="mmh-lo-actions">' +
                '<button type="button" class="mmh-lo-btn mmh-lo-cancel" id="mmhLogoutCancelBtn">Cancel</button>' +
                '<button type="button" class="mmh-lo-btn mmh-lo-confirm" id="mmhLogoutConfirmBtn">Yes, Logout</button>' +
            '</div>' +
        '</div>';

    (document.body || document.documentElement).appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('show'));

    let busy = false;
    const closeModal = () => {
        if (busy) return;
        modal.classList.remove('show');
        setTimeout(() => { try { modal.remove(); } catch (e) {} }, 180);
    };

    const cancelBtn = modal.querySelector('#mmhLogoutCancelBtn');
    const confirmBtn = modal.querySelector('#mmhLogoutConfirmBtn');

    cancelBtn.onclick = closeModal;
    modal.onclick = (e) => {
        if (e.target === modal) closeModal();
    };

    confirmBtn.onclick = () => {
        if (busy) return;
        busy = true;
        cancelBtn.disabled = true;
        confirmBtn.disabled = true;
        confirmBtn.style.opacity = '1';
        confirmBtn.innerHTML = '<span class="mmh-lo-spin"></span><span>Logging out\u2026</span>';
        executeLogout(redirectTo, modal);
    };
}


// -----------------------------------------------------------
// Auto-clear old quiz cache when storage is nearly full.
// Runs on every page EXCEPT the quiz page itself (test.html sets
// window.MMH_QUIZ_PAGE_ACTIVE = true before this file loads, since
// an exam may be in progress there and its keys must not be touched).
// Only clears keys belonging to the CURRENTLY logged-in username —
// never another user's leftover data on a shared device.
// -----------------------------------------------------------
function getLocalStorageUsageRatio() {
    try {
        let totalChars = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (!k) continue;
            const v = localStorage.getItem(k) || '';
            totalChars += k.length + v.length;
        }
        return totalChars / (4.5 * 1024 * 1024);
    } catch (e) {
        return 0;
    }
}

async function clearOldQuizCacheIfNeeded() {
    if (window.MMH_QUIZ_PAGE_ACTIVE) return;

    let usage = 0, quota = 0;
    if (navigator.storage && navigator.storage.estimate) {
        try {
            const estimate = await navigator.storage.estimate();
            usage = estimate.usage || 0;
            quota = estimate.quota || 0;
        } catch (e) {}
    }

    const quotaRatio = quota > 0 ? (usage / quota) : 0;
    const lsRatio = getLocalStorageUsageRatio();
    const usedRatio = Math.max(quotaRatio, lsRatio);

    const profileForPageCheck = typeof getLocalProfile === 'function' ? getLocalProfile() : null;

    // Special case: nobody logged in. There's no "current
    // user" to protect here — anything sitting in localStorage belongs to
    // some PAST session, not the one about to be established. A lower 25%
    // threshold (vs the normal 75% below) is used deliberately: full
    // storage here can silently break login itself — the Supabase SDK's
    // own session-persist write can fail the same way, so it's worth
    // clearing well before things get critical. No username filtering,
    // no CLOUD_SYNC tier — just clear the big keys broadly and stop.
    if (!profileForPageCheck) {
        if (usedRatio < 0.25) return;

        const broadPrefixes = ['state_', 'result_', 'qstats_', 'stream_', 'rankLastAutoRefreshedAt_'];
        const keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!key) continue;
            for (const p of broadPrefixes) {
                if (key.startsWith(p)) {
                    keysToRemove.push(key);
                    break;
                }
            }
        }
        keysToRemove.forEach((k) => localStorage.removeItem(k));
        if (keysToRemove.length) {
            console.log(`No active session, storage was ${(usedRatio * 100).toFixed(1)}% full — cleared ${keysToRemove.length} old cache entries (all users).`);
        }
        return; // no other logic needed for this case
    }

    const THRESHOLD = 0.75; // start clearing once 75% of the browser's quota / localStorage is used
    if (usedRatio < THRESHOLD) return;

    const profile = typeof getLocalProfile === 'function' ? getLocalProfile() : null;
    const username = profile ? profile.username : null;
    if (!username) return; // don't know who's logged in — don't guess whose data to remove

    // Prefixes test.html uses for per-user, per-quiz keys:
    //   state_<username>_<quizId>, result_<username>_<quizId>,
    //   qstats_<username>_<quizId>, stream_<username>_<quizId>,
    //   rankLastAutoRefreshedAt_<username>_<quizId>
    // plus saved_status_<username> (no quiz id suffix).
    // Deliberately excludes qsum_<user>_<id> and CLOUD_SYNC_<user>_<exam> —
    // those are the small, permanent per-quiz summaries (score/attempted/
    // date only) that exam-engine.js/ssc-sub-engine.js rely on for the
    // "attempted" checklist across quiz listing pages. They must survive
    // this cleanup regardless of when it runs relative to the engine's own
    // absorb step, so they're never listed here.
    const dynamicPrefixes = ['state_', 'result_', 'qstats_', 'stream_', 'rankLastAutoRefreshedAt_'];
    const staticKey = 'saved_status_' + username;

    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key) continue;
        if (key === staticKey) {
            keysToRemove.push(key);
            continue;
        }
        for (const p of dynamicPrefixes) {
            if (key.startsWith(p + username + '_')) {
                keysToRemove.push(key);
                break;
            }
        }
    }

    keysToRemove.forEach((k) => localStorage.removeItem(k));
    if (keysToRemove.length) {
        console.log(`Storage was ${(usedRatio * 100).toFixed(1)}% full — cleared ${keysToRemove.length} old quiz cache entries for "${username}".`);
    }

    // Last resort — only reached if storage is STILL >=75% after clearing
    // the big per-attempt keys above. Drops the single LARGEST
    // CLOUD_SYNC_<username>_<exam> key (the small "attempted" checklist
    // cache the exam engines maintain — see exam-engine.js/ssc-sub-
    // engine.js). Safe: syncWithCloud() re-populates it from the server
    // on next visit, so this costs one extra fetch, not real data loss.
    // In practice this realistically only triggers once a user has
    // attempted an enormous number of DISTINCT quizzes (each entry is
    // only ~100-150 bytes), so this is a defensive final tier, not
    // something expected to fire for typical usage.
    let recheckRatio = getLocalStorageUsageRatio();
    if (navigator.storage && navigator.storage.estimate) {
        try {
            const recheck = await navigator.storage.estimate();
            if (recheck && recheck.quota) {
                recheckRatio = Math.max(recheckRatio, (recheck.usage || 0) / recheck.quota);
            }
        } catch (e) {}
    }
    if (recheckRatio < THRESHOLD) return;

    const cloudSyncPrefix = 'CLOUD_SYNC_' + username + '_';
    let biggestKey = null;
    let biggestSize = 0;
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key || !key.startsWith(cloudSyncPrefix)) continue;
        const size = (localStorage.getItem(key) || '').length;
        if (size > biggestSize) {
            biggestSize = size;
            biggestKey = key;
        }
    }
    if (biggestKey) {
        localStorage.removeItem(biggestKey);
        console.log(`Storage still >=75% after clearing attempt cache — removed largest CLOUD_SYNC key "${biggestKey}" (${biggestSize} bytes) for "${username}".`);
    }
}
window.clearOldQuizCacheIfNeeded = clearOldQuizCacheIfNeeded;

// -----------------------------------------------------------
// Hard cap on stored full quiz attempts — same philosophy as the
// Service Worker's MAX_CACHE_ENTRIES: always keep the count bounded,
// checked on every page load. This runs regardless of how full
// storage actually is (proactive), on top of the reactive 75%-full
// wipe above (safety net for anything unusual).
//
// Deliberately NOT recency-sorted: score/attempted history is
// already preserved forever in the small qsum_/CLOUD_SYNC_ keys
// (untouched by this), and full attempt detail is always re-
// fetchable via test.html's own Cloud Recovery path if a pruned
// result_ is ever opened again. Since pruning is never actually
// data-lossy — worst case is one extra fetch on reopen — WHICH
// excess attempts get removed doesn't matter, so this skips
// parsing/sorting by date entirely and just trims by count. Only
// counts COMPLETED attempts (have a result_ key) — an in-progress
// state_-only attempt is never touched.
// -----------------------------------------------------------
const MAX_STORED_ATTEMPTS = 25;

function enforceMaxStoredAttempts() {
    if (window.MMH_QUIZ_PAGE_ACTIVE) return;

    const profile = typeof getLocalProfile === 'function' ? getLocalProfile() : null;
    const username = profile ? profile.username : null;
    if (!username) return;

    const resultPrefix = `result_${username}_`;
    const ids = [];
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(resultPrefix)) ids.push(key.slice(resultPrefix.length));
    }

    if (ids.length <= MAX_STORED_ATTEMPTS) return; // cheap common-case exit

    const excess = ids.length - MAX_STORED_ATTEMPTS;
    const toRemove = ids.slice(0, excess); // no sorting needed — see comment above

    toRemove.forEach((id) => {
        localStorage.removeItem(`result_${username}_${id}`);
        localStorage.removeItem(`state_${username}_${id}`);
        localStorage.removeItem(`qstats_${username}_${id}`);
        localStorage.removeItem(`stream_${username}_${id}`);
        localStorage.removeItem(`rankLastAutoRefreshedAt_${username}_${id}`);
    });

    if (toRemove.length) {
        console.log(`Kept ${MAX_STORED_ATTEMPTS} stored attempts — trimmed ${toRemove.length} excess for "${username}".`);
    }
}

document.addEventListener('DOMContentLoaded', enforceMaxStoredAttempts);

// Fire-and-forget: runs alongside initAuth() without blocking it or
// the page's own scripts.
document.addEventListener('DOMContentLoaded', clearOldQuizCacheIfNeeded);

// Keep this for the very first initial load
document.addEventListener('DOMContentLoaded', initAuth);

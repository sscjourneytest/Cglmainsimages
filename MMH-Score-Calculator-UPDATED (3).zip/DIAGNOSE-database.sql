-- ═══════════════════════════════════════════════════════════════════════
--  MMH · DATABASE INSPECTOR  ·  100% READ-ONLY
--  ─────────────────────────────────────────────────────────────────────
--  Ye file me SIRF EK SELECT statement hai (UNION ALL se report banti hai).
--  Na koi object banata hai, na kisi table me kuch likhta hai, na schema
--  badalta hai. Isliye Supabase koi "destructive operation" ya "RLS"
--  warning nahi dega.
--
--  Isme kya kuch NAHI hai:
--    · naya table / object banana
--    · kuch hatana ya badalna
--    · kisi table me row likhna
--    · permissions badalna
--    · aisa koi function call jo kuch likhe
--
--  RESULT: ek hi table → columns: section | item | detail
--          CSV download karke bhejna.
--
--  NOTE: pg_cron / storage wale hisse catalog se padhe jaate hain aur
--        schema missing ho to bhi query fail nahi hoti.
-- helper: kisi bhi schema ki table ka oid, bina permission error ke.
-- (to_regclass() restricted role me "permission denied for schema" deta hai,
--  pg_class se dhoondhne par nahi — isliye ye tarika use hua hai.)
-- ═══════════════════════════════════════════════════════════════════════


SELECT * FROM (

  -- ═══════════════ 01 · DB ════════════════════════════════════════════
  SELECT '01 DB'::text AS section, 'version'::text AS item, version()::text AS detail
  UNION ALL
  SELECT '01 DB', 'current_user', current_user::text
  UNION ALL
  SELECT '01 DB', 'extensions',
         coalesce((SELECT string_agg(extname || ' v' || extversion, ', ' ORDER BY extname)
                   FROM pg_extension), '—')

  -- ═══════════════ 02 · TABLE ═════════════════════════════════════════
  UNION ALL
  SELECT '02 TABLE', c.relname::text,
         format('rls_enabled=%s  rls_forced=%s  approx_rows=%s  size=%s',
                c.relrowsecurity, c.relforcerowsecurity,
                c.reltuples::bigint, pg_size_pretty(pg_total_relation_size(c.oid)))
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relkind = 'r'

  -- ═══════════════ 03 · COLUMN ════════════════════════════════════════
  UNION ALL
  SELECT '03 COLUMN', table_name || '.' || column_name,
         format('type=%s  nullable=%s  default=%s',
                data_type, is_nullable, coalesce(column_default, '—'))
  FROM information_schema.columns
  WHERE table_schema = 'public'

  -- ═══════════════ 04 · POLICY (RLS) ══════════════════════════════════
  UNION ALL
  SELECT '04 POLICY', tablename || ' · ' || policyname,
         format('cmd=%s  roles=%s  using=%s  check=%s',
                cmd, coalesce(array_to_string(roles, ','), '—'),
                coalesce(qual, '—'), coalesce(with_check, '—'))
  FROM pg_policies
  WHERE schemaname = 'public'

  -- jis table pe RLS ON hai par ek bhi policy nahi (= sab blocked)
  UNION ALL
  SELECT '04 POLICY', c.relname || ' — !! NO POLICY !!',
         'RLS is ON but there is NO policy → anon ke liye sab blocked'
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relkind = 'r' AND c.relrowsecurity = TRUE
    AND NOT EXISTS (SELECT 1 FROM pg_policies p
                    WHERE p.schemaname = 'public' AND p.tablename = c.relname)

  -- ═══════════════ 05 · PRIVILEGES ═══════════════════════════════════
  UNION ALL
  SELECT '05 PRIVILEGES', table_name || ' → ' || grantee,
         string_agg(DISTINCT privilege_type, ', ')
  FROM information_schema.role_table_grants
  WHERE table_schema = 'public' AND grantee IN ('anon', 'authenticated', 'service_role')
  GROUP BY table_name, grantee

  UNION ALL
  SELECT '05 PRIVILEGES', 'SEQUENCE ' || object_name || ' → ' || grantee, privilege_type::text
  FROM information_schema.role_usage_grants
  WHERE object_schema = 'public' AND grantee IN ('anon', 'authenticated')

  -- ═══════════════ 06 · FUNCTION ══════════════════════════════════════
  UNION ALL
  SELECT '06 FUNCTION', p.proname::text,
         format('args=(%s)  returns=%s  security=%s  volatility=%s  search_path=%s',
                pg_get_function_identity_arguments(p.oid),
                pg_get_function_result(p.oid),
                CASE WHEN p.prosecdef THEN 'DEFINER (careful)' ELSE 'invoker' END,
                CASE p.provolatile WHEN 'i' THEN 'IMMUTABLE'
                                   WHEN 's' THEN 'STABLE' ELSE 'VOLATILE' END,
                coalesce(array_to_string(p.proconfig, ','), 'not set'))
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.prokind = 'f'

  -- EXECUTE grants
  UNION ALL
  SELECT '06 FUNCTION', 'EXECUTE: ' || p.proname || ' → ' || r.rolname, 'granted'
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  CROSS JOIN LATERAL (SELECT unnest(coalesce(p.proacl, ARRAY[]::aclitem[])) AS acl) a
  JOIN pg_roles r ON r.rolname = split_part(a.acl::text, '=', 1)
  WHERE n.nspname = 'public' AND p.prokind = 'f'
    AND a.acl::text LIKE '%=X%'
    AND r.rolname IN ('anon', 'authenticated', 'service_role')

  -- ═══════════════ 07 · FUNCTION_SRC (poora body) ═════════════════════
  UNION ALL
  SELECT '07 FUNCTION_SRC', p.proname::text, pg_get_functiondef(p.oid)
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.prokind = 'f'
    AND (p.proname ILIKE '%submit%' OR p.proname ILIKE '%rank%'
         OR p.proname ILIKE '%mmh%' OR p.proname ILIKE '%candidate%'
         OR p.proname ILIKE '%question%' OR p.proname ILIKE '%url%')

  -- ═══════════════ 08 · TRIGGER ═══════════════════════════════════════
  UNION ALL
  SELECT '08 TRIGGER', c.relname || ' · ' || t.tgname,
         format('timing=%s  events=%s  fn=%s',
                CASE WHEN t.tgtype & 2 = 2 THEN 'BEFORE' ELSE 'AFTER' END,
                concat_ws(',',
                  CASE WHEN t.tgtype & 4 = 4 THEN 'INS' END,
                  CASE WHEN t.tgtype & 8 = 8 THEN 'DEL' END,
                  CASE WHEN t.tgtype & 16 = 16 THEN 'UPD' END,
                  CASE WHEN t.tgtype & 32 = 32 THEN 'TRUNC.' END),
                p.proname)
  FROM pg_trigger t
  JOIN pg_class c ON c.oid = t.tgrelid
  JOIN pg_namespace n ON n.oid = c.relnamespace
  JOIN pg_proc p ON p.oid = t.tgfoid
  WHERE n.nspname = 'public' AND NOT t.tgisinternal

  -- ═══════════════ 09 · INDEX ═════════════════════════════════════════
  UNION ALL
  SELECT '09 INDEX', tablename || ' · ' || indexname, indexdef
  FROM pg_indexes
  WHERE schemaname = 'public'

  -- ═══════════════ 10 · CONSTRAINT ═════════════════════════════════════
  UNION ALL
  SELECT '10 CONSTRAINT', conrelid::regclass::text || ' · ' || conname,
         format('type=%s  def=%s',
                CASE contype WHEN 'p' THEN 'PRIMARY KEY'
                             WHEN 'u' THEN 'UNIQUE'
                             WHEN 'f' THEN 'FOREIGN KEY'
                             WHEN 'c' THEN 'CHECK'
                             ELSE contype::text END,
                pg_get_constraintdef(oid))
  FROM pg_constraint
  WHERE connamespace = 'public'::regnamespace

  -- ═══════════════ 11 · SEQUENCE ══════════════════════════════════════
  UNION ALL
  SELECT '11 SEQUENCE', sequencename,
         format('type=%s  increment=%s  start=%s  min=%s  max=%s  cycle=%s  owner=%s  last_value=%s',
                data_type, increment_by, start_value, min_value, max_value,
                cycle, sequenceowner, coalesce(last_value::text, 'never used'))
  FROM pg_sequences
  WHERE schemaname = 'public'

  -- ═══════════════ 12 · CRON ══════════════════════════════════════════
  UNION ALL
  SELECT '12 CRON', 'pg_cron installed?',
         CASE WHEN NOT EXISTS (SELECT 1 FROM pg_catalog.pg_class c
                               JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                               WHERE n.nspname = 'cron' AND c.relname = 'job')
              THEN 'NO — cron schema nahi hai (extension installed nahi)'
              WHEN NOT EXISTS (SELECT 1 FROM pg_catalog.pg_class c
                               JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                               WHERE n.nspname = 'cron' AND c.relname = 'job'
                                 AND has_schema_privilege(c.relnamespace, 'USAGE')
                                 AND has_table_privilege(c.oid, 'SELECT'))
              THEN 'installed hai, par padhne ki permission nahi (postgres/owner role se chalao)'
              ELSE 'YES — jobs neeche' END

  -- NOTE: pg_cron na ho to cron schema hi nahi hota. Seedha "FROM cron.job"
  -- likhne se POORI query fail ho jaati hai (table resolve hi nahi hoti).
  -- Isliye dynamic query use ki gayi hai — schema missing ho to 0 rows.
  UNION ALL
  SELECT '12 CRON', 'job · ' || coalesce(jobname, '?'), coalesce(detail, '?')
  FROM xmltable(
         '/table/row'
         PASSING query_to_xml(
             CASE WHEN EXISTS (SELECT 1 FROM pg_catalog.pg_class c
                               JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                               WHERE n.nspname = 'cron' AND c.relname = 'job'
                                 AND has_schema_privilege(c.relnamespace, 'USAGE')
                                 AND has_table_privilege(c.oid, 'SELECT'))
                  THEN 'SELECT jobname AS jobname, '
                       'format(''schedule=%s  active=%s  command=%s'', schedule, active, '
                       'left(regexp_replace(command, ''\s+'', '' '', ''g''), 300)) AS detail '
                       'FROM cron.job ORDER BY jobid'
                  ELSE 'SELECT NULL::text AS jobname, NULL::text AS detail WHERE false'
             END, true, false, '')
         COLUMNS jobname text PATH 'jobname',
                 detail  text PATH 'detail'
       ) AS t

  -- ═══════════════ 13 · PUBLICATION (realtime) ════════════════════════
  UNION ALL
  SELECT '13 PUBLICATION', p.pubname || ' · ' || pt.tablename, 'in realtime publication'
  FROM pg_publication p
  JOIN pg_publication_tables pt ON pt.pubname = p.pubname
  WHERE pt.schemaname = 'public'

  -- ═══════════════ 14 · STORAGE ═══════════════════════════════════════
  -- storage schema Supabase-specific hai — na ho to 0 rows (query fail nahi hoti),
  -- kyunki seedha "FROM storage.buckets" likhne se table resolve hi nahi hoti.
  UNION ALL
  SELECT '14 STORAGE', 'bucket · ' || coalesce(bucket_name, '?'), coalesce(detail, '?')
  FROM xmltable(
         '/table/row'
         PASSING query_to_xml(
             CASE WHEN EXISTS (SELECT 1 FROM pg_catalog.pg_class c
                               JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                               WHERE n.nspname = 'storage' AND c.relname = 'buckets'
                                 AND has_schema_privilege(c.relnamespace, 'USAGE')
                                 AND has_table_privilege(c.oid, 'SELECT'))
                  THEN 'SELECT name AS bucket_name, '
                       'format(''public=%s  size_limit=%s'', '
                       'public, coalesce(file_size_limit::text, ''-'')) AS detail '
                       'FROM storage.buckets ORDER BY name'
                  ELSE 'SELECT NULL::text AS bucket_name, NULL::text AS detail WHERE false'
             END, true, false, '')
         COLUMNS bucket_name text PATH 'bucket_name',
                 detail      text PATH 'detail'
       ) AS t

  -- ═══════════════ 15 · VIEW ══════════════════════════════════════════
  UNION ALL
  SELECT '15 VIEW', c.relname,
         CASE c.relkind WHEN 'v' THEN 'view' ELSE 'materialized view' END
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relkind IN ('v', 'm')

  -- ═══════════════ 16 · SUMMARY (migration ke liye sabse zaroori) ══════
  UNION ALL
  SELECT '16 SUMMARY', 'candidate_submissions',
         CASE WHEN to_regclass('public.candidate_submissions') IS NULL
              THEN 'MISSING'
              ELSE 'exists · ' || coalesce((
                  SELECT string_agg(column_name, ', ' ORDER BY ordinal_position)
                  FROM information_schema.columns
                  WHERE table_schema = 'public' AND table_name = 'candidate_submissions'
              ), '') END

  UNION ALL
  SELECT '16 SUMMARY', 'language column',
         coalesce((
             SELECT 'found: ' || string_agg(column_name || ' (' || data_type || ')', ', ')
             FROM information_schema.columns
             WHERE table_schema = 'public' AND table_name = 'candidate_submissions'
               AND column_name IN ('answer_language', 'paper_language')
         ), 'MISSING — add karna hoga')

  UNION ALL
  SELECT '16 SUMMARY', 'answer_key_urls table',
         CASE WHEN to_regclass('public.answer_key_urls') IS NULL
              THEN 'MISSING — banana hoga'
              ELSE 'exists · ' || coalesce((
                  SELECT string_agg(column_name || ':' || data_type, ', ' ORDER BY ordinal_position)
                  FROM information_schema.columns
                  WHERE table_schema = 'public' AND table_name = 'answer_key_urls'
              ), '') END

  UNION ALL
  SELECT '16 SUMMARY', 'exam_question_stats table',
         CASE WHEN to_regclass('public.exam_question_stats') IS NULL
              THEN 'MISSING' ELSE 'exists' END

  UNION ALL
  SELECT '16 SUMMARY', 'submit_candidate_data',
         coalesce((
             SELECT string_agg('overload ' || ord || ' · ' || nparams || ' params · ' || args, E'\n')
             FROM (
                 SELECT row_number() OVER (ORDER BY pg_get_function_identity_arguments(p.oid)) AS ord,
                        coalesce(cardinality(p.proargnames), 0) AS nparams,
                        pg_get_function_identity_arguments(p.oid) AS args
                 FROM pg_proc p
                 JOIN pg_namespace n ON n.oid = p.pronamespace
                 WHERE n.nspname = 'public' AND p.proname = 'submit_candidate_data'
             ) sub
         ), 'MISSING — banana hoga')

  UNION ALL
  SELECT '16 SUMMARY', 'submit_candidate_data has p_paper_language?',
         CASE WHEN EXISTS (
                  SELECT 1 FROM pg_proc p
                  JOIN pg_namespace n ON n.oid = p.pronamespace
                  WHERE n.nspname = 'public' AND p.proname = 'submit_candidate_data'
                    AND 'p_paper_language' = ANY(coalesce(p.proargnames, ARRAY[]::text[]))
              )
              THEN 'YES — function already updated, dobara banane ki zaroorat NAHI'
              ELSE 'NO — 19th param add karna hoga (warna RANK fail hoga)'
         END

  UNION ALL
  SELECT '16 SUMMARY', 'get_all_ranks',
         coalesce((
             SELECT string_agg(
                        coalesce(cardinality(p.proargnames), 0) || ' params · returns ' ||
                        pg_get_function_result(p.oid) || ' · ' ||
                        CASE WHEN p.prosecdef THEN 'SECURITY DEFINER' ELSE 'invoker' END,
                        E'\n')
             FROM pg_proc p
             JOIN pg_namespace n ON n.oid = p.pronamespace
             WHERE n.nspname = 'public' AND p.proname = 'get_all_ranks'
         ), 'MISSING')

  UNION ALL
  SELECT '16 SUMMARY', 'upsert key on candidate_submissions (exam_id, roll_number)',
         CASE WHEN EXISTS (
                  SELECT 1 FROM pg_constraint
                  WHERE conrelid = to_regclass('public.candidate_submissions')
                    AND contype = 'u'
                    AND pg_get_constraintdef(oid) LIKE '%(exam_id, roll_number)%'
              )
              THEN 'OK — unique constraint hai, ON CONFLICT chalega'
              ELSE 'MISSING — iske bina submit/rank fail hoga' END

  UNION ALL
  SELECT '16 SUMMARY', 'anon privileges on answer_key_urls',
         coalesce((
             SELECT string_agg(DISTINCT privilege_type, ', ')
             FROM information_schema.role_table_grants
             WHERE table_schema = 'public' AND table_name = 'answer_key_urls'
               AND grantee = 'anon'
         ), '— (table missing or no grants)')

  UNION ALL
  SELECT '16 SUMMARY', 'RLS on candidate_submissions',
         coalesce((
             SELECT format('rls_enabled=%s · policies=%s', relrowsecurity,
                           (SELECT count(*) FROM pg_policies
                            WHERE schemaname = 'public' AND tablename = 'candidate_submissions'))
             FROM pg_class WHERE oid = to_regclass('public.candidate_submissions')
         ), '—')

  -- ═══════════ VERDICT: seedha jawab ki kya chalana hai ═══════════
  UNION ALL
  SELECT '16 SUMMARY', '★ VERDICT',
         CASE
           WHEN to_regclass('public.candidate_submissions') IS NULL
             THEN 'Table hi nahi hai → pehle supabase-schema.sql chalao, phir migration.'
           WHEN NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
                            WHERE n.nspname = 'public' AND p.proname = 'submit_candidate_data'
                              AND 'p_paper_language' = ANY(coalesce(p.proargnames, ARRAY[]::text[])))
             THEN 'RANK broken hai → migration-261027.sql (full, 259 lines) chalao. '
                  'Ya sirf column+table chahiye to migration-MINIMAL.sql (45 lines) — par RANK tab bhi nahi aayega.'
           WHEN to_regclass('public.answer_key_urls') IS NULL
             THEN 'Table missing → migration-MINIMAL.sql chalao (rank pehle se theek hai).'
           ELSE 'Sab kuch already set hai → koi migration nahi chahiye.'
         END

) report
ORDER BY section, item;

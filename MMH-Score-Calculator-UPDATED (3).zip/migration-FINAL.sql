-- ═══════════════════════════════════════════════════════════════════════
--  MMH · FINAL MIGRATION  ·  v3
--  Aapke live DB ke hisaab se banaya gaya (CSV report se verified)
--  ─────────────────────────────────────────────────────────────────────
--  LIVE DB ME KYA HAI (verified):
--    ✅ candidate_submissions  — 21 columns, 3144 rows, RLS on
--    ✅ exam_question_stats    — 35662 rows, RLS on
--    ✅ submit_candidate_data  — 18 params  ← p_paper_language MISSING
--    ✅ get_all_ranks          — theek hai, chhedne ki zaroorat nahi
--    ✅ uq_candidate_submission (exam_id, roll_number) — upsert chalega
--    ✅ pg_cron                — installed nahi (koi cron job nahi)
--
--  YE SCRIPT 4 KAAM KARTA HAI:
--    1. candidate_submissions me answer_language column add
--    2. answer_key_urls table (id, exam_id, answer_key_url) + RLS
--    3. submit_candidate_data me p_paper_language param add
--       (iske bina RANK nahi aayega — PGRST202 error)
--    4. get_all_ranks — waisa hi rehta hai, sirf EXECUTE grant confirm
--
--  SAFE: sab IF NOT EXISTS / CREATE OR REPLACE. Dobara chalane se kuch
--        bigdega nahi, purana data safe rahega.
-- ═══════════════════════════════════════════════════════════════════════


-- ═══════════════════════════════════════════════════════════════════════
--  1 · naya column: answer_language  ('HI' | 'EN' | NULL)
-- ═══════════════════════════════════════════════════════════════════════
ALTER TABLE public.candidate_submissions
    ADD COLUMN IF NOT EXISTS answer_language VARCHAR(4);

COMMENT ON COLUMN public.candidate_submissions.answer_language IS
    'Paper ki bhasha: HI ya EN. Detect na ho paaye to NULL. Score par koi asar nahi.';


-- ═══════════════════════════════════════════════════════════════════════
--  2 · naya table: answer_key_urls  (exactly 3 columns)
--      anon sirf INSERT kar sakta hai — padh nahi sakta (URL me EncKey = PII)
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.answer_key_urls (
    id             BIGSERIAL PRIMARY KEY,
    exam_id        VARCHAR(64) NOT NULL,
    answer_key_url TEXT        NOT NULL
);

-- duplicate URL rok — koi extra column nahi, hash index me hi
CREATE UNIQUE INDEX IF NOT EXISTS uq_answer_key_urls_hash
    ON public.answer_key_urls (md5(answer_key_url));

CREATE INDEX IF NOT EXISTS idx_akurl_exam
    ON public.answer_key_urls (exam_id);

ALTER TABLE public.answer_key_urls ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "akurl insert only" ON public.answer_key_urls;
CREATE POLICY "akurl insert only"
    ON public.answer_key_urls FOR INSERT
    TO anon, authenticated
    WITH CHECK (true);

DROP POLICY IF EXISTS "akurl no select" ON public.answer_key_urls;
CREATE POLICY "akurl no select"
    ON public.answer_key_urls FOR SELECT
    TO anon, authenticated
    USING (false);

-- default privileges hatao, phir sirf INSERT do
REVOKE ALL ON public.answer_key_urls FROM anon, authenticated, PUBLIC;
GRANT INSERT ON public.answer_key_urls TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.answer_key_urls_id_seq TO anon, authenticated;
GRANT ALL ON public.answer_key_urls TO service_role;
GRANT ALL ON SEQUENCE public.answer_key_urls_id_seq TO service_role;


-- ═══════════════════════════════════════════════════════════════════════
--  3 · submit_candidate_data — 19th param p_paper_language
--      Bas yahi RANK ko tootne se bachaata hai.
--      Purane 18-param call bhi chalte rahenge (DEFAULT NULL).
-- ═══════════════════════════════════════════════════════════════════════
-- ⚠️ ZAROORI: CREATE OR REPLACE naye signature ke saath purani function ko
--    REPLACE NAHI karta — dono zinda reh jaati hain. Aur phir 18-param call
--    "function is not unique" error deti hai (PostgREST pe PGRST203).
--    Isliye purani 18-param wali pehle hata rahe hain.
DROP FUNCTION IF EXISTS public.submit_candidate_data(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR,
    NUMERIC, INT, INT, INT, INT, INT, INT, JSONB, TEXT, JSONB
);

CREATE OR REPLACE FUNCTION public.submit_candidate_data(
    p_exam_id        VARCHAR,
    p_shift_id       VARCHAR,
    p_roll_number    VARCHAR,
    p_name           VARCHAR,
    p_category       VARCHAR,
    p_gender         VARCHAR,
    p_zone           VARCHAR,
    p_state          VARCHAR,
    p_total_score    NUMERIC,
    p_total_questions INT,
    p_attempted      INT,
    p_correct_count  INT,
    p_wrong_count    INT,
    p_skip_count     INT,
    p_bonus_count    INT,
    p_section_scores JSONB,
    p_answer_key_url TEXT,
    p_questions      JSONB,
    p_paper_language VARCHAR DEFAULT NULL        -- ⭐ NAYA: 'HI' | 'EN' | NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_row_id BIGINT;
    v_lang   VARCHAR(4);
    v_is_new BOOLEAN := FALSE;
    q_elem   JSONB;
    v_qkey   VARCHAR(64);
    v_sec    VARCHAR(64);
    v_status VARCHAR(16);
BEGIN
    -- sirf HI / EN accept karo, baaki kuch bhi aaye to NULL (score par asar nahi)
    v_lang := CASE
                  WHEN upper(coalesce(p_paper_language, '')) IN ('HI', 'EN')
                  THEN upper(p_paper_language)
                  ELSE NULL
              END;

    -- naya candidate hai ya purana?
    SELECT NOT EXISTS (
        SELECT 1 FROM public.candidate_submissions
        WHERE exam_id = p_exam_id AND roll_number = p_roll_number
    ) INTO v_is_new;

    INSERT INTO public.candidate_submissions (
        exam_id, shift_id, roll_number, name, category, gender, zone, state,
        total_score, total_questions, attempted, correct_count, wrong_count,
        skip_count, bonus_count, section_scores, answer_key_url, answer_language,
        created_at, updated_at
    ) VALUES (
        p_exam_id, p_shift_id, p_roll_number, coalesce(p_name, 'Candidate'),
        p_category, p_gender, p_zone, p_state,
        p_total_score, coalesce(p_total_questions, 0), coalesce(p_attempted, 0),
        coalesce(p_correct_count, 0), coalesce(p_wrong_count, 0),
        coalesce(p_skip_count, 0), coalesce(p_bonus_count, 0),
        p_section_scores, p_answer_key_url, v_lang,
        NOW(), NOW()
    )
    ON CONFLICT (exam_id, roll_number) DO UPDATE SET
        shift_id         = EXCLUDED.shift_id,
        name             = EXCLUDED.name,
        category         = EXCLUDED.category,
        gender           = EXCLUDED.gender,
        zone             = EXCLUDED.zone,
        state            = EXCLUDED.state,
        total_score      = EXCLUDED.total_score,
        total_questions  = EXCLUDED.total_questions,
        attempted        = EXCLUDED.attempted,
        correct_count    = EXCLUDED.correct_count,
        wrong_count      = EXCLUDED.wrong_count,
        skip_count       = EXCLUDED.skip_count,
        bonus_count      = EXCLUDED.bonus_count,
        section_scores   = EXCLUDED.section_scores,
        answer_key_url   = EXCLUDED.answer_key_url,
        -- agar naye call me language nahi aayi to purani value bachi rehti hai
        answer_language  = COALESCE(EXCLUDED.answer_language,
                                    candidate_submissions.answer_language),
        updated_at       = NOW()
    RETURNING id INTO v_row_id;

    -- ── Question analytics: sirf naye candidate ke liye (double count nahi) ──
    IF v_is_new AND p_questions IS NOT NULL
       AND jsonb_typeof(p_questions) = 'array' THEN
        FOR q_elem IN SELECT * FROM jsonb_array_elements(p_questions)
        LOOP
            v_qkey := LEFT(coalesce(q_elem->>'q', ''), 64);
            IF v_qkey = '' THEN CONTINUE; END IF;

            v_sec    := LEFT(coalesce(q_elem->>'sec', ''), 64);
            v_status := lower(coalesce(q_elem->>'s', ''));

            INSERT INTO public.exam_question_stats (
                exam_id, shift_id, question_key, section_name,
                correct_count, wrong_count, skip_count
            ) VALUES (
                p_exam_id, p_shift_id, v_qkey, v_sec,
                CASE WHEN v_status = 'correct' THEN 1 ELSE 0 END,
                CASE WHEN v_status = 'wrong'   THEN 1 ELSE 0 END,
                CASE WHEN v_status = 'skipped' THEN 1 ELSE 0 END
            )
            ON CONFLICT (exam_id, shift_id, question_key) DO UPDATE SET
                section_name = EXCLUDED.section_name,
                correct_count = public.exam_question_stats.correct_count
                              + CASE WHEN v_status = 'correct' THEN 1 ELSE 0 END,
                wrong_count   = public.exam_question_stats.wrong_count
                              + CASE WHEN v_status = 'wrong'   THEN 1 ELSE 0 END,
                skip_count    = public.exam_question_stats.skip_count
                              + CASE WHEN v_status = 'skipped' THEN 1 ELSE 0 END;
        END LOOP;
    END IF;

    RETURN jsonb_build_object(
        'ok',      true,
        'is_new',  v_is_new,
        'id',      v_row_id,
        'language', v_lang
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_candidate_data(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR,
    NUMERIC, INT, INT, INT, INT, INT, INT, JSONB, TEXT, JSONB, VARCHAR
) TO anon, authenticated;


-- ═══════════════════════════════════════════════════════════════════════
--  4 · get_all_ranks — aapke DB me pehle se theek hai
--      Sirf EXECUTE grant confirm kar rahe hain. Function chheda nahi.
-- ═══════════════════════════════════════════════════════════════════════
GRANT EXECUTE ON FUNCTION public.get_all_ranks(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, NUMERIC
) TO anon, authenticated;


-- ═══════════════════════════════════════════════════════════════════════
--  5 · VERIFY — chalane ke baad ye teen row zaroor dekhna
-- ═══════════════════════════════════════════════════════════════════════
SELECT '1. answer_language column' AS check_name,
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_schema='public'
                           AND table_name='candidate_submissions'
                           AND column_name='answer_language')
            THEN '✅ OK' ELSE '❌ MISSING' END AS result
UNION ALL
SELECT '2. answer_key_urls table',
       CASE WHEN to_regclass('public.answer_key_urls') IS NOT NULL
            THEN '✅ OK — ' || (SELECT string_agg(column_name, ', ' ORDER BY ordinal_position)
                                FROM information_schema.columns
                                WHERE table_schema='public' AND table_name='answer_key_urls')
            ELSE '❌ MISSING' END
UNION ALL
SELECT '3. p_paper_language param',
       CASE WHEN EXISTS (SELECT 1 FROM pg_proc p
                         JOIN pg_namespace n ON n.oid = p.pronamespace
                         WHERE n.nspname='public' AND p.proname='submit_candidate_data'
                           AND 'p_paper_language' = ANY(coalesce(p.proargnames, ARRAY[]::text[])))
            THEN '✅ OK — RANK chalega'
            ELSE '❌ MISSING — rank nahi aayega' END
UNION ALL
SELECT '4. get_all_ranks',
       CASE WHEN EXISTS (SELECT 1 FROM pg_proc p
                         JOIN pg_namespace n ON n.oid = p.pronamespace
                         WHERE n.nspname='public' AND p.proname='get_all_ranks')
            THEN '✅ OK' ELSE '❌ MISSING' END;

-- ═══════════════════════════════════════════════════════════════════════
--  MMH · MINIMAL MIGRATION  (sirf 2 cheezein: ek column + ek table)
--
--  ⚠️  SIDE EFFECT: full migration na chalane par RANK nahi aayega.
--      Reason: calculator ab submit_candidate_data ko 19th param
--      (p_paper_language) bhejta hai. Purana function sirf 18 leta hai →
--      Supabase PGRST202 deta hai → client ka legacy fallback bhi fail →
--      score dikhega (sahi), par rank card pe "retry" aayega.
--
--      Rank bachana hai to  ->  migration-261027.sql chalao (recommended)
--      Sirf test karna hai  ->  ye file chalao, rank baad me theek karna
-- ═══════════════════════════════════════════════════════════════════════


-- 1) NAYA COLUMN — scorecard ki bhasha (HI / EN / NULL)
ALTER TABLE public.candidate_submissions
    ADD COLUMN IF NOT EXISTS answer_language VARCHAR(4);


-- 2) NAYI TABLE — 3 columns, write-only
CREATE TABLE IF NOT EXISTS public.answer_key_urls (
    id             BIGSERIAL PRIMARY KEY,
    exam_id        VARCHAR(64) NOT NULL,
    answer_key_url TEXT NOT NULL
);

-- same URL dobara aaye to nayi row na bane
CREATE UNIQUE INDEX IF NOT EXISTS uq_answer_key_urls_hash
    ON public.answer_key_urls (md5(answer_key_url));

-- write-only: anon sirf INSERT kar sakta hai, ek bhi row padh nahi sakta
ALTER TABLE public.answer_key_urls ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "akurl_insert_only" ON public.answer_key_urls;
CREATE POLICY "akurl_insert_only"
ON public.answer_key_urls FOR INSERT
TO anon, authenticated
WITH CHECK (true);

REVOKE ALL ON TABLE public.answer_key_urls FROM anon, authenticated, PUBLIC;
GRANT  INSERT ON public.answer_key_urls TO anon, authenticated;
GRANT  USAGE, SELECT ON SEQUENCE public.answer_key_urls_id_seq TO anon, authenticated;

GRANT ALL ON TABLE public.answer_key_urls TO service_role;
GRANT ALL ON SEQUENCE public.answer_key_urls_id_seq TO service_role;

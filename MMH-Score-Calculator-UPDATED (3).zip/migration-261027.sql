-- ═══════════════════════════════════════════════════════════════════════
--  MMH · MIGRATION 261027
--  1) candidate_submissions me "answer_language" column
--  2) answer_key_urls table — WRITE-ONLY (koi bhi ek bhi row padh nahi sakta)
--  3) submit_candidate_data RPC v2 (19 params, p_paper_language add)
--
--  Ye script idempotent hai — dobara chalane pe koi error nahi aayega.
--  Supabase → SQL Editor → paste → Run
-- ═══════════════════════════════════════════════════════════════════════


-- ═══════════════════════════════════════════════════════════════════════
-- 1) NEW COLUMN: answer_language  ('HI' | 'EN' | NULL)
--    Score calculate karte waqt response sheet se detect hoti hai.
--    Detect na ho toh NULL — koi error nahi, sab pehle jaisa chalta hai.
-- ═══════════════════════════════════════════════════════════════════════

ALTER TABLE public.candidate_submissions
    ADD COLUMN IF NOT EXISTS answer_language VARCHAR(4);

-- Purane column naam (agar kisi ne manually add kiya ho) se data copy + drop
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name   = 'candidate_submissions'
          AND column_name  = 'paper_language'
    ) THEN
        EXECUTE 'UPDATE public.candidate_submissions
                    SET answer_language = paper_language
                  WHERE answer_language IS NULL AND paper_language IS NOT NULL';
        EXECUTE 'ALTER TABLE public.candidate_submissions DROP COLUMN paper_language';
    END IF;
END $$;

-- Sirf HI / EN allowed (NULL bhi chalega)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'ck_subm_answer_language'
    ) THEN
        ALTER TABLE public.candidate_submissions
            ADD CONSTRAINT ck_subm_answer_language
            CHECK (answer_language IS NULL OR answer_language IN ('HI', 'EN'));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_subm_lang
    ON public.candidate_submissions (exam_id, answer_language)
    WHERE answer_language IS NOT NULL;


-- ═══════════════════════════════════════════════════════════════════════
-- 2) answer_key_urls  ·  EXACTLY 3 COLUMNS  ·  WRITE-ONLY
--
--    id | exam_id | answer_key_url
--
--    "Write-only" ka matlab:
--      • anon / authenticated  → SIRF INSERT. SELECT kabhi nahi.
--      • RLS SELECT policy      → koi hai hi nahi, aur default DENY hai.
--      • Table privileges me se SELECT/UPDATE/DELETE REVOKE kar diya.
--      • Koi bhi REST call  GET /rest/v1/answer_key_urls?select=*  →
--        401 / 42501 / empty. Students ka URL koi nikal nahi sakta.
--      • Padhna sirf service_role se — i.e. Supabase dashboard / admin.
-- ═══════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.answer_key_urls (
    id             BIGSERIAL PRIMARY KEY,
    exam_id        VARCHAR(64) NOT NULL,
    answer_key_url TEXT NOT NULL
);

-- Duplicate URL → koi nayi row nahi banti (idempotent insert)
CREATE UNIQUE INDEX IF NOT EXISTS uq_answer_key_urls_hash
    ON public.answer_key_urls (md5(answer_key_url));

CREATE INDEX IF NOT EXISTS idx_akurl_exam
    ON public.answer_key_urls (exam_id);

-- RLS ON
ALTER TABLE public.answer_key_urls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answer_key_urls FORCE ROW LEVEL SECURITY;

-- Purani koi bhi permissive policy hatao
DROP POLICY IF EXISTS "Allow public insert to answer key urls"   ON public.answer_key_urls;
DROP POLICY IF EXISTS "Deny public select on answer key urls"    ON public.answer_key_urls;
DROP POLICY IF EXISTS "akurl_insert_only"                        ON public.answer_key_urls;

-- Sirf INSERT allow. SELECT/UPDATE/DELETE ke liye KOI policy nahi = default DENY.
CREATE POLICY "akurl_insert_only"
ON public.answer_key_urls FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- ── Privileges: table-level se bhi SELECT hatao (RLS ke upar extra layer) ──
REVOKE ALL ON TABLE public.answer_key_urls FROM anon, authenticated, PUBLIC;
GRANT  INSERT ON public.answer_key_urls TO anon, authenticated;
GRANT  USAGE, SELECT ON SEQUENCE public.answer_key_urls_id_seq TO anon, authenticated;

-- service_role (dashboard / admin) sab kuch kar sakta hai
GRANT ALL ON TABLE public.answer_key_urls TO service_role;
GRANT ALL ON SEQUENCE public.answer_key_urls_id_seq TO service_role;

COMMENT ON TABLE public.answer_key_urls IS
    'WRITE-ONLY log: exam_id + official answer key URL. Client sirf INSERT kar sakta hai; koi SELECT nahi (candidate PII / EncKey protection).';


-- ═══════════════════════════════════════════════════════════════════════
-- 3) submit_candidate_data  ·  v2  ·  19 params
--    Additive change — purane 18 params wale call bhi kaam karenge
--    (p_paper_language ka DEFAULT NULL).
-- ═══════════════════════════════════════════════════════════════════════

-- purane overload hatao (42725 ambiguity se bachne ke liye)
DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN (
        SELECT pg_get_function_identity_arguments(oid) AS args
        FROM pg_proc
        WHERE proname = 'submit_candidate_data'
          AND pronamespace = 'public'::regnamespace
    ) LOOP
        EXECUTE format('DROP FUNCTION IF EXISTS public.submit_candidate_data(%s) CASCADE;', r.args);
    END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.submit_candidate_data(
    p_exam_id VARCHAR,
    p_shift_id VARCHAR,
    p_roll_number VARCHAR,
    p_name VARCHAR,
    p_category VARCHAR,
    p_gender VARCHAR,
    p_zone VARCHAR,
    p_state VARCHAR,
    p_total_score NUMERIC,
    p_total_questions INT,
    p_attempted INT,
    p_correct_count INT,
    p_wrong_count INT,
    p_skip_count INT,
    p_bonus_count INT,
    p_section_scores JSONB,
    p_answer_key_url TEXT,
    p_questions JSONB,
    p_paper_language VARCHAR DEFAULT NULL          -- ⭐ NAYA ('HI' | 'EN' | NULL)
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_row_id BIGINT;
    v_lang   VARCHAR(4);
    q_elem   JSONB;
    v_qkey   VARCHAR(64);
    v_sec    VARCHAR(64);
    v_status VARCHAR(16);
BEGIN
    -- sirf HI / EN accept karo, baaki NULL
    v_lang := CASE
                WHEN upper(coalesce(p_paper_language, '')) IN ('HI', 'EN')
                THEN upper(p_paper_language)
                ELSE NULL
              END;

    INSERT INTO public.candidate_submissions (
        exam_id, shift_id, roll_number, name, category, gender, zone, state,
        total_score, total_questions, attempted, correct_count, wrong_count,
        skip_count, bonus_count, section_scores, answer_key_url, answer_language,
        created_at, updated_at
    ) VALUES (
        p_exam_id, p_shift_id, p_roll_number, coalesce(p_name, 'Candidate'),
        p_category, p_gender, p_zone, p_state,
        p_total_score, coalesce(p_total_questions, 0), coalesce(p_attempted, 0),
        coalesce(p_correct_count, 0), coalesce(p_wrong_count, 0),
        coalesce(p_skip_count, 0), coalesce(p_bonus_count, 0),
        p_section_scores, p_answer_key_url, v_lang,
        NOW(), NOW()
    )
    ON CONFLICT (exam_id, roll_number) DO UPDATE SET
        shift_id          = EXCLUDED.shift_id,
        name              = EXCLUDED.name,
        category          = EXCLUDED.category,
        gender            = EXCLUDED.gender,
        zone              = EXCLUDED.zone,
        state             = EXCLUDED.state,
        total_score       = EXCLUDED.total_score,
        total_questions   = EXCLUDED.total_questions,
        attempted         = EXCLUDED.attempted,
        correct_count     = EXCLUDED.correct_count,
        wrong_count       = EXCLUDED.wrong_count,
        skip_count        = EXCLUDED.skip_count,
        bonus_count       = EXCLUDED.bonus_count,
        section_scores    = EXCLUDED.section_scores,
        answer_key_url    = EXCLUDED.answer_key_url,
        answer_language   = COALESCE(EXCLUDED.answer_language, candidate_submissions.answer_language),
        updated_at        = NOW()
    RETURNING id INTO v_row_id;

    -- ── Question analytics (aggregate counters, ek row per question per shift) ──
    IF p_questions IS NOT NULL AND jsonb_typeof(p_questions) = 'array' THEN
        FOR q_elem IN SELECT * FROM jsonb_array_elements(p_questions)
        LOOP
            v_qkey := LEFT(coalesce(q_elem->>'q', ''), 64);
            IF v_qkey = '' THEN CONTINUE; END IF;

            v_sec := LEFT(coalesce(q_elem->>'sec', 'Section'), 64);
            v_status := coalesce(q_elem->>'s', 'skipped');

            INSERT INTO public.exam_question_stats (
                exam_id, shift_id, question_key, section_name,
                correct_count, wrong_count, skip_count
            ) VALUES (
                p_exam_id, p_shift_id, v_qkey, v_sec,
                CASE WHEN v_status = 'correct' THEN 1 ELSE 0 END,
                CASE WHEN v_status = 'wrong'   THEN 1 ELSE 0 END,
                CASE WHEN v_status = 'skipped' THEN 1 ELSE 0 END
            )
            ON CONFLICT (exam_id, shift_id, question_key) DO UPDATE SET
                section_name  = COALESCE(EXCLUDED.section_name, exam_question_stats.section_name),
                correct_count = exam_question_stats.correct_count + (CASE WHEN v_status = 'correct' THEN 1 ELSE 0 END),
                wrong_count   = exam_question_stats.wrong_count   + (CASE WHEN v_status = 'wrong'   THEN 1 ELSE 0 END),
                skip_count    = exam_question_stats.skip_count    + (CASE WHEN v_status = 'skipped' THEN 1 ELSE 0 END);
        END LOOP;
    END IF;

    RETURN jsonb_build_object(
        'ok', true,
        'id', v_row_id,
        'answer_language', v_lang
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_candidate_data(
    VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR,
    NUMERIC, INT, INT, INT, INT, INT, INT, JSONB, TEXT, JSONB, VARCHAR
) TO anon, authenticated, service_role;


-- ═══════════════════════════════════════════════════════════════════════
-- 4) VERIFICATION — chalane ke baad ye query chalao
-- ═══════════════════════════════════════════════════════════════════════
-- answer_language column bana?
--   SELECT column_name, data_type FROM information_schema.columns
--    WHERE table_name = 'candidate_submissions' AND column_name = 'answer_language';
--
-- answer_key_urls write-only hai? (anon ke paas sirf INSERT hona chahiye)
--   SELECT privilege_type FROM information_schema.role_table_grants
--    WHERE table_name = 'answer_key_urls' AND grantee = 'anon';
--   Expected output: INSERT   (SELECT nahi hona chahiye)
--
-- RLS policies:
--   SELECT policyname, cmd FROM pg_policies WHERE tablename = 'answer_key_urls';
--   Expected: akurl_insert_only | INSERT

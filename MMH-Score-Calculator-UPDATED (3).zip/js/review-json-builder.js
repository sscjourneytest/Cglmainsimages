/* ═══════════════════════════════════════════════════
   MOCK MATRIX HUB · SCORE CALCULATOR — review-json-builder.js
   Builds a UNIFIED review JSON from raw source HTML for
   BOTH exam families:

     • SSC  (sscexams.cbexams.com ViewCandResponse*.aspx)
     • RRB / TCS-iON / digialm (rrb.digialm.com, g06.tcsion.com)

   This file does NOT touch score-engine.js's parser-ssc.js /
   parser-rrb.js (those stay focused on qno+status for scoring).
   This is a SEPARATE, richer extraction used only by the
   Review Paper page — it pulls full question text, option
   text, and image URLs so the review page can render the
   actual paper.

   ── Unified schema produced ──
   {
     meta: {
       family: 'ssc' | 'rrb',
       examName, rollNo, candidateName, date, shift, centre
     },
     sections: [
       {
         name: "Mathematics",
         questions: [
           {
             qno: 1,
             qId: "4410091631384" | null,
             status: "correct" | "wrong" | "skipped" | "bonus",
             question: { text: "...", images: ["url1", "url2"] },
             options: [
               { label: "A", text: "...", images: [], isCorrect: true, isChosen: false },
               ...
             ]
           }
         ]
       }
     ]
   }

   Image URLs are kept EXACTLY as found in the source HTML
   (SSC's qimg/... relative paths are resolved against the
   known SSC image host; RRB/TCS paths are resolved against
   the page's own origin). No re-upload / Cloudinary needed —
   the review page's <img> tags load them directly.

   ── Math + line breaks (matches rrb.py / test.html exactly) ──
   Formula images (WIRIS, <img data-mathml="...">) are never kept
   as <img> — that data-mathml is an obfuscated MathML tree; the
   img's own `src` is either a huge, useless base64 blob or an
   unsupported "data:image/webcam" MIME the browser can't paint at
   all (that's the "box"/broken-image bug). Instead we decode the
   MathML and emit real inline LaTeX text — "\( ... \)" — the exact
   same delimiters test.html's MathJax config expects, so equations
   render inline as text, not as an image or a scrolling box.
   Only genuine standalone diagram/photo images (real http(s)/relative
   server URLs) are kept as <img> and left pointing at the original
   digialm/SSC URL — no Cloudinary re-upload.
   <br> tags are preserved (as literal "<br>") instead of being
   collapsed to a space, so multi-line questions keep their line
   breaks instead of running on as one sentence.
═══════════════════════════════════════════════════ */

const RSMReviewBuilder = (() => {

  function esc(s) { return (s == null) ? '' : String(s); }

  // Non-whitespace, never-occurs-in-real-text placeholder for <br> —
  // survives the whitespace-collapsing step in decodeEntities() below
  // and is turned back into a literal "<br>" right after.
  const BR_TOKEN = '\u0001BR\u0001';

  // Decode ALL HTML entities (not just a hand-picked few) — same fix
  // already used in test.html's getLangText()/decodeHTML() helper and
  // mirrored server-side by rrb.py's html.unescape(). The old version
  // here only handled &nbsp;/&amp;/&lt;/&gt;/&quot;/&#39;, so anything
  // else the source HTML encoded — &lsquo;/&rsquo; (curly quotes),
  // &zwj; (zero-width joiner, common in Hindi conjuncts), &ndash;,
  // &pi;, &theta;, etc. — was left as literal, unreadable entity text
  // in rendered questions ("&lsquo;salt elbow care&rsquo;", "विस्&zwj;तृत").
  // A <textarea>'s innerHTML→value round-trip decodes via the browser's
  // own full HTML entity table, so every named/numeric entity resolves
  // correctly with no maintenance-prone whitelist to keep extending.
  const _decodeEl = (typeof document !== 'undefined') ? document.createElement('textarea') : null;
  function decodeEntities(s) {
    if (!s) return '';
    let out = s;
    if (_decodeEl) {
      _decodeEl.innerHTML = s;
      out = _decodeEl.value;
    } else {
      // Non-DOM fallback (shouldn't normally be hit in this app).
      out = out
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'");
    }
    return out.replace(/\s+/g, ' ').trim();
  }

  function stripTags(html) {
    // Keep <br> as an actual line break instead of collapsing it to a
    // space — fixes multi-line questions (e.g. coded-relation puzzles)
    // being flattened into a single run-on line.
    let h = (html || '').replace(/<br\s*\/?>/gi, BR_TOKEN);
    h = h.replace(/<[^>]+>/g, ' ');
    h = decodeEntities(h);
    h = h.split(BR_TOKEN).join('<br>');
    return h;
  }

  // ═══════════════════════════════════════════════
  // MathML (WIRIS-encoded) → LaTeX
  // ═══════════════════════════════════════════════
  // Mirrors mathml_to_latex() in rrb.py exactly: digialm/TCS-iON stores
  // each formula as a WIRIS image whose data-mathml="..." attribute
  // holds the real formula, obfuscated (« » stand in for < >, ¨ for ",
  // § for &). We decode that back into real MathML, parse it, and walk
  // the tree emitting \frac{}{}, ^{}, \sqrt{}, etc. — never the alt
  // text (which is just a "spoken" approximation) and never the img's
  // own src (a giant/unsupported-MIME base64 blob).

  const MATHML_DEOBFUSCATE = { '\u00ab': '<', '\u00bb': '>', '\u00a8': '"', '\u00a7': '&' };

  const MO_MAP = {
    '-': '-', '+': '+', '=': '=',
    '\u00d7': '\\times', '\u00f7': '\\div', '\u2212': '-',
    '\u2264': '\\leq', '\u2265': '\\geq', '\u2260': '\\neq',
    '\u00b1': '\\pm', '\u221a': '\\sqrt',
    '(': '(', ')': ')', ',': ',', '%': '\\%',
    '\u00a0': ' '
  };

  // Fallback "spoken alt text" -> symbol cleanup, only used if the
  // MathML fails to decode/parse (mirrors ALT_MAP in rrb.py).
  const ALT_MAP = {
    ' space ': ' ', ' comma ': ', ', ' period ': '.', ' colon ': ': ',
    ' semicolon ': '; ', ' left parenthesis ': '(', ' right parenthesis ': ')',
    ' left bracket ': '[', ' right bracket ': ']',
    ' left brace ': '{', ' right brace ': '}',
    ' vertical line ': '||', ' plus ': '+', ' minus ': '-',
    ' equals ': '=', ' not equals ': '\u2260',
    ' less than ': '<', ' greater than ': '>',
    ' multiplication sign ': '\u00d7', ' division sign ': '\u00f7',
    ' degree ': '\u00b0', ' percent sign ': '%',
    ' square root ': '\u221a', ' squared ': '\u00b2', ' cubed ': '\u00b3',
    ' pi ': '\u03c0', ' alpha ': '\u03b1', ' beta ': '\u03b2', ' theta ': '\u03b8',
    ' newline ': ' ', ' end root ': ''
  };

  function mathmlDeobfuscate(raw) {
    let out = raw || '';
    Object.keys(MATHML_DEOBFUSCATE).forEach(bad => {
      out = out.split(bad).join(MATHML_DEOBFUSCATE[bad]);
    });
    return out;
  }

  function cleanAlt(alt) {
    let t = alt || '';
    Object.keys(ALT_MAP).forEach(k => { t = t.split(k).join(ALT_MAP[k]); });
    return t.replace(/ {2,}/g, ' ').trim();
  }

  function mathmlLocalName(el) {
    const n = el.nodeName || '';
    const i = n.indexOf(':');
    return i === -1 ? n : n.slice(i + 1);
  }

  function mathmlChildren(el) {
    return Array.prototype.filter.call(el.childNodes, n => n.nodeType === 1);
  }

  function mathmlNode(el) {
    const tag = mathmlLocalName(el);
    const text = (el.textContent || '').trim();
    const kids = mathmlChildren(el);
    const childLatex = () => kids.map(mathmlNode).join('');

    switch (tag) {
      case 'math': return childLatex();
      case 'mn': case 'mi': return text;
      case 'mo': return MO_MAP.hasOwnProperty(text) ? MO_MAP[text] : text;
      case 'mtext': return text;
      case 'mrow': return childLatex();
      case 'mfrac': {
        const num = kids[0] ? mathmlNode(kids[0]) : '';
        const den = kids[1] ? mathmlNode(kids[1]) : '';
        return `\\frac{${num}}{${den}}`;
      }
      case 'msup': {
        let base = kids[0] ? mathmlNode(kids[0]) : '';
        const exp = kids[1] ? mathmlNode(kids[1]) : '';
        if (base.length > 1 && !(base.startsWith('(') && base.endsWith(')'))) base = `{${base}}`;
        return `${base}^{${exp}}`;
      }
      case 'msub': {
        const base = kids[0] ? mathmlNode(kids[0]) : '';
        const sub = kids[1] ? mathmlNode(kids[1]) : '';
        return `${base}_{${sub}}`;
      }
      case 'msubsup': {
        const base = kids[0] ? mathmlNode(kids[0]) : '';
        const sub = kids[1] ? mathmlNode(kids[1]) : '';
        const sup = kids[2] ? mathmlNode(kids[2]) : '';
        return `${base}_{${sub}}^{${sup}}`;
      }
      case 'msqrt': return `\\sqrt{${childLatex()}}`;
      case 'mroot': {
        const base = kids[0] ? mathmlNode(kids[0]) : '';
        const idx = kids[1] ? mathmlNode(kids[1]) : '';
        return `\\sqrt[${idx}]{${base}}`;
      }
      case 'mover': {
        const base = kids[0] ? mathmlNode(kids[0]) : '';
        const over = kids[1] ? mathmlNode(kids[1]) : '';
        if (over === '\u00af' || over === '-') return `\\overline{${base}}`;
        return `\\overset{${over}}{${base}}`;
      }
      case 'munder': {
        const base = kids[0] ? mathmlNode(kids[0]) : '';
        const under = kids[1] ? mathmlNode(kids[1]) : '';
        return `\\underset{${under}}{${base}}`;
      }
      case 'mfenced': {
        const opening = el.getAttribute('open') || '(';
        const closing = el.getAttribute('close') || ')';
        const inner = kids.map(mathmlNode).join(',');
        return `${opening}${inner}${closing}`;
      }
      case 'mtable': {
        const rows = kids.map(row => mathmlChildren(row).map(mathmlNode).join(' & '));
        return '\\begin{matrix}' + rows.join(' \\\\ ') + '\\end{matrix}';
      }
      case 'mtr': case 'mtd': case 'mstyle': return childLatex();
      case 'mspace': return ' ';
      default: return childLatex();
    }
  }

  function xmlParseOk(doc) {
    return !!doc && !doc.querySelector('parsererror');
  }

  function mathmlToLatex(rawDataMathml) {
    const decoded = mathmlDeobfuscate(rawDataMathml);
    const parser = new DOMParser();
    let doc = parser.parseFromString(decoded, 'application/xml');
    if (!xmlParseOk(doc)) {
      // Same fallback as rrb.py: escape any stray & that isn't already
      // a valid entity/numeric reference, then retry once.
      const fixed = decoded.replace(/&(?!#?\w+;)/g, '&amp;');
      doc = parser.parseFromString(fixed, 'application/xml');
    }
    if (!xmlParseOk(doc) || !doc.documentElement) return '';
    let latex = mathmlNode(doc.documentElement);
    latex = latex.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    return latex;
  }

  // Converts one <img ...> tag (attrs string, no surrounding < >) into
  // the inline text that should replace it:
  //  - data-mathml present  -> "\( latex \)" (falls back to cleaned alt
  //    text only if the MathML itself fails to decode/parse)
  //  - otherwise a real diagram/photo image -> handled by the caller
  //    (kept as an actual <img>, see resolveInlineContent below)
  function mathImgLatex(attrs) {
    const mathmlM = attrs.match(/data-mathml=["']([^"']*)["']/i);
    if (!mathmlM) return null;
    try {
      const latex = mathmlToLatex(mathmlM[1]);
      if (latex) return ` \\(${latex}\\) `;
    } catch (e) { /* fall through to alt-text fallback */ }
    const altM = attrs.match(/alt=["']([^"']*)["']/i);
    const alt = altM ? decodeEntities(altM[1]) : '';
    const cleaned = cleanAlt(alt);
    return cleaned ? ` ${cleaned} ` : ' ';
  }

  // Shared image/math-aware inline-content resolver used by BOTH the
  // SSC and RRB extractors. Walks every <img> in reading order:
  //   • WIRIS formula (data-mathml) -> inline LaTeX text (no <img>,
  //     no Cloudinary — the formula becomes real text for MathJax)
  //   • real http(s)/relative server image -> kept as a genuine image,
  //     resolved to its original absolute URL and returned via the
  //     `images` array + a {{img:N}} placeholder (same mechanism
  //     review.js already renders)
  //   • unusable inline data: URI with no formula behind it (e.g. a
  //     decorative icon) -> dropped, never queued as a broken <img>
  // <br> tags are preserved as literal "<br>" line breaks throughout.
  function resolveInlineContent(html, baseUrl, resolveFn) {
    const images = [];
    let out = (html || '').replace(/<br\s*\/?>/gi, BR_TOKEN);

    out = out.replace(/<img\b([^>]*)>/gi, (full, attrs) => {
      const mathLatex = mathImgLatex(attrs);
      if (mathLatex !== null) return mathLatex;

      const srcM = attrs.match(/src=["']([^"']*)["']/i);
      const src = srcM ? srcM[1] : '';
      if (!src || /^data:/i.test(src)) return ''; // no usable real image

      const resolved = resolveFn(src, baseUrl);
      if (!resolved) return '';
      images.push(resolved);
      return ` {{img:${images.length - 1}}} `;
    });

    out = out.replace(/<[^>]+>/g, ' ');
    out = decodeEntities(out);
    out = out.split(BR_TOKEN).join('<br>');
    return { text: out, images };
  }

  // ═══════════════════════════════════════════════
  // SSC extraction
  // ═══════════════════════════════════════════════
  // qimg/... paths are relative to whatever host/path the answer-key
  // page actually loaded from — NOT a fixed guessed domain. This
  // mirrors mmhtoolup.py exactly: it resolves every image with
  // urljoin(resp.url, src), where resp.url is the real URL the live
  // session fetched. A hardcoded fallback host is wrong for any
  // exam/session using a different subdomain or path, which silently
  // 404s every SSC image (the broken/blank-option bug). SSC_IMG_BASE
  // below is only a last-resort fallback for the rare case no source
  // URL was available to build() at all.
  const SSC_IMG_BASE = 'https://sscexams.cbexams.com/';

  function sscResolveImg(src, baseUrl) {
    if (!src) return '';
    if (/^https?:\/\//i.test(src) || src.startsWith('data:')) return src;
    try {
      return new URL(src, baseUrl || SSC_IMG_BASE).href;
    } catch (e) {
      if (src.startsWith('/')) return SSC_IMG_BASE.replace(/\/$/, '') + src;
      return SSC_IMG_BASE + src.replace(/^\.?\//, '');
    }
  }

  function sscCandidateInfo(html) {
    const info = {};
    const rollM = html.match(/Roll\s*No[^<]*<\/td>\s*<td[^>]*>:?&nbsp;&nbsp;&nbsp;([^<\s]+)/i);
    if (rollM) info.rollNo = decodeEntities(rollM[1]);
    const nameM = html.match(/Candidate\s*Name[^<]*<\/td>\s*<td[^>]*>:?&nbsp;&nbsp;&nbsp;([^<]+)/i);
    if (nameM) info.candidateName = decodeEntities(nameM[1]);
    const examM = html.match(/<option[^>]*selected[^>]*>([^<]+)<\/option>/i);
    if (examM) info.examName = decodeEntities(examM[1]);
    const dateM = html.match(/Test\s*Date[^<]*<\/td>\s*<td[^>]*>:?&nbsp;&nbsp;&nbsp;([^<]+)/i);
    if (dateM) info.date = decodeEntities(dateM[1]);
    const shiftM = html.match(/Test\s*Time[^<]*<\/td>\s*<td[^>]*>:?&nbsp;&nbsp;&nbsp;([^<]+)/i);
    if (shiftM) info.shift = decodeEntities(shiftM[1]);
    const centreM = html.match(/Centre\s*Name[^<]*<\/td>\s*<td[^>]*>:?&nbsp;&nbsp;&nbsp;([^<]+)/i);
    if (centreM) info.centre = decodeEntities(centreM[1]);
    return info;
  }

  // Parses each "<!-- Option N -->...<!-- Candidate Response -->" block,
  // pulling BOTH the color (for status) and the image/text content.
  function sscParseOptionBlocks(qBlock, baseUrl) {
    const options = [];
    const optRe = /<!--\s*Option\s+(\d+)\s*-->([\s\S]*?)(?=<!--\s*Option\s+\d+\s*-->|<!--\s*Candidate\s*Response|$)/gi;
    let m;
    while ((m = optRe.exec(qBlock)) !== null) {
      const num = parseInt(m[1], 10);
      const block = m[2];
      const bgM = block.match(/<td[^>]*width=['"]2%['"][^>]*bgcolor=['"]([^'"]+)['"][^>]*>/i);
      const color = bgM ? bgM[1].toLowerCase() : null;
      // Option text/images live in the SECOND <td> of the option row
      // (the first <td width='2%'> is just the color marker cell).
      const tdRe = /<td[^>]*width=['"]49%['"][^>]*>([\s\S]*?)<\/td>/i;
      const tdM = block.match(tdRe);
      const contentHtml = tdM ? tdM[1] : block;
      const { text, images } = resolveInlineContent(contentHtml, baseUrl, sscResolveImg);
      options.push({
        label: String.fromCharCode(64 + num), // 1->A, 2->B...
        text,
        images,
        color
      });
    }
    if (options.length < 4) {
      return sscParseOptionBlocksFallback(qBlock, baseUrl);
    }
    return options;
  }

  function sscParseOptionBlocksFallback(qBlock, baseUrl) {
    const options = [];
    const trRe = /<tr[^>]*>[\s\S]*?<td[^>]*width=['"]2%['"][^>]*>([\s\S]*?)<\/td>\s*<td[^>]*width=['"]49%['"][^>]*>([\s\S]*?)<\/td>/gi;
    let m, count = 0;
    while ((m = trRe.exec(qBlock)) !== null && count < 8) {
      const fullTag = m[0];
      const td2 = fullTag.substring(0, fullTag.indexOf("</td>"));
      const bgM = td2.match(/bgcolor=['"]([^'"]+)['"]/i);
      const color = bgM ? bgM[1].toLowerCase() : null;
      const { text, images } = resolveInlineContent(m[2], baseUrl, sscResolveImg);
      options.push({
        label: String.fromCharCode(65 + count),
        text,
        images,
        color
      });
      count++;
    }
    return options;
  }

  // Candidate-response row: SSC has no separate "chosen option" text
  // field like RRB does — status + which option was picked is read
  // PURELY from bgcolor, following parser-ssc.js's own documented rule
  // exactly (this file must never re-derive its own reading of that
  // logic from a single sample — the rule below IS the rule):
  //   1. any option green              → CORRECT  (green = user's pick, and it's right)
  //   2. any option red                → WRONG    (red = user's pick, wrong;
  //                                                 the correct one is shown yellow)
  //   3. any option yellow (no green/red) → SKIPPED (not answered, yellow marks correct)
  //   4. no option has any color at all   → BONUS
  //   5. anything else                    → SKIPPED (safe fallback)
  function sscQuestionStatusAndChosen(options, qBlock) {
    if (qBlock && (
      qBlock.toLowerCase().includes('taken up for challenge by ssc') ||
      /bgcolor=['"]?purple['"]?/i.test(qBlock) ||
      /background-color:\s*purple/i.test(qBlock)
    )) {
      return 'bonus';
    }
    const colors = options.map(o => o.color);
    const hasGreen = colors.includes('green');
    const hasRed = colors.includes('red');
    const hasYellow = colors.includes('yellow');
    const allEmpty = colors.every(c => !c);

    if (hasGreen) return 'correct';
    if (hasRed) return 'wrong';
    if (hasYellow) return 'skipped';
    if (allEmpty) return 'bonus';
    return 'skipped';
  }

  function sscParsePart(html, partNum, baseUrl) {
    let sectionName = `Part ${partNum}`;
    const spanM = html.match(/<span[^>]*id=['"]lblsubject['"][^>]*>([^<]+)<\/span>/i);
    if (spanM) sectionName = decodeEntities(spanM[1]);

    const qPositions = [];
    const qnoRegex = /Q\.No:&nbsp;(\d+)/gi;
    let qm;
    while ((qm = qnoRegex.exec(html)) !== null) {
      qPositions.push({ qno: parseInt(qm[1], 10), pos: qm.index });
    }

    const questions = [];
    qPositions.forEach((qInfo, idx) => {
      const start = qInfo.pos;
      const end = idx + 1 < qPositions.length ? qPositions[idx + 1].pos : html.length;
      const block = html.substring(start, end);

      // Question text/images: the <td width='85%'> right after the Q.No cell.
      const qTdM = block.match(/Q\.No:&nbsp;\d+\s*<\/font>\s*<\/td>\s*<td[^>]*width=['"]85%['"][^>]*>([\s\S]*?)<\/td>/i);
      const qContent = qTdM ? qTdM[1] : '';

      const options = sscParseOptionBlocks(block, baseUrl);
      if (options.length < 4) return; // not a real question block

      const status = sscQuestionStatusAndChosen(options, block);

      // Maps colors -> flags exactly per the rule above:
      //   green  -> isCorrect: true,  isChosen: true   (user picked right)
      //   red    -> isCorrect: false, isChosen: true   (user picked wrong)
      //   yellow -> isCorrect: true,  isChosen: false  (the right answer,
      //             shown whether the question ended up wrong or skipped)
      //   none   -> isCorrect: false, isChosen: false
      const finalOptions = options.map(o => ({
        label: o.label,
        text: o.text,
        images: o.images,
        isCorrect: o.color === 'green' || o.color === 'yellow',
        isChosen: o.color === 'green' || o.color === 'red'
      }));

      questions.push({
        qno: qInfo.qno,
        qId: null,
        status,
        question: resolveInlineContent(qContent, baseUrl, sscResolveImg),
        options: finalOptions
      });
    });

    return { name: sectionName, questions };
  }

  function buildSSC(parts, sourceUrl) {
    const sortedKeys = Object.keys(parts).sort((a, b) => {
      const na = parseInt(a.replace(/\D/g, ''), 10) || 0;
      const nb = parseInt(b.replace(/\D/g, ''), 10) || 0;
      return na - nb;
    });

    let meta = { family: 'ssc' };
    const sections = [];

    sortedKeys.forEach((key, idx) => {
      const html = parts[key];
      if (Object.keys(meta).length <= 1) {
        const info = sscCandidateInfo(html);
        if (Object.keys(info).length) meta = Object.assign(meta, info);
      }
      sections.push(sscParsePart(html, idx + 1, sourceUrl));
    });

    return { meta, sections };
  }

  // ═══════════════════════════════════════════════
  // RRB / TCS-iON / digialm extraction
  // ═══════════════════════════════════════════════

  function rrbResolveImg(src, baseUrl) {
    if (!src) return '';
    if (/^https?:\/\//i.test(src) || src.startsWith('data:')) return src;
    try {
      return new URL(src, baseUrl || 'https://rrb.digialm.com/').href;
    } catch (e) {
      return src;
    }
  }

  function rrbCandidateInfo(html) {
    const info = {};
    const panelM = html.match(/class=["']main-info-pnl["'][\s\S]*?<table[\s\S]*?<\/table>/i);
    const scope = panelM ? panelM[0] : html;
    const grab = (label) => {
      const re = new RegExp(`<td[^>]*>\\s*${label}\\s*<\\/td>\\s*<td[^>]*>([\\s\\S]*?)<\\/td>`, 'i');
      const m = scope.match(re);
      return m ? stripTags(m[1]) : '';
    };
    info.rollNo = grab('Roll\\s*Number');
    info.candidateName = grab('Candidate\\s*Name');
    info.centre = grab('Test\\s*Centre\\s*Name');
    info.date = grab('Test\\s*Date');
    info.shift = grab('Test\\s*Time');
    info.examName = grab('Subject');
    Object.keys(info).forEach(k => { if (!info[k]) delete info[k]; });
    return info;
  }

  function rrbSplitSections(html) {
    const sections = [];
    const lblRegex = /class=["']section-lbl["'][^>]*>([\s\S]*?)<\/div>/gi;
    const labelPositions = [];
    let m;
    while ((m = lblRegex.exec(html)) !== null) {
      const name = stripTags(m[1]).replace(/^Section\s*:?\s*/i, '');
      labelPositions.push({ name: name || 'General', pos: m.index });
    }
    if (labelPositions.length === 0) return [{ name: 'General', html }];
    labelPositions.forEach((lbl, idx) => {
      const end = idx + 1 < labelPositions.length ? labelPositions[idx + 1].pos : html.length;
      sections.push({ name: lbl.name, html: html.substring(lbl.pos, end) });
    });
    return sections;
  }

  // WIRIS/MathJax formula images (<img data-mathml="...">) are decoded to
  // real inline LaTeX text via mathmlToLatex()/resolveInlineContent()
  // above — never rendered as an <img> (their own src is either a huge
  // base64 blob or an unsupported "data:image/webcam" MIME the browser
  // can't paint, which is what produced the broken/boxed formulas).
  // Genuine standalone diagram/photo images are kept as real <img> tags
  // pointing at their original digialm URL. <br> line breaks are kept.
  function rrbCellContent(tdHtml, baseUrl) {
    return resolveInlineContent(tdHtml, baseUrl, rrbResolveImg);
  }

  function rrbNormalizeKey(str) {
    if (!str) return '';
    const s = str.trim().toUpperCase();
    if (s === '1') return 'A';
    if (s === '2') return 'B';
    if (s === '3') return 'C';
    if (s === '4') return 'D';
    if (s === '5') return 'E';
    return s;
  }

  function rrbExtractRightAnswer(block) {
    if (
      block.toLowerCase().includes('question cancelled') ||
      block.toLowerCase().includes('benefit of doubt') ||
      block.toLowerCase().includes('question ignored') ||
      block.toLowerCase().includes('given to all') ||
      block.toLowerCase().includes('taken up for challenge')
    ) {
      return null;
    }
    const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
    let trM;
    while ((trM = trRegex.exec(block)) !== null) {
      const trHtml = trM[1];
      if (/class=["'](?:[^"']*\s+)?rightAns(?:\s+[^"']*)?["']/i.test(trHtml)) {
        const numM = trHtml.match(/\b([A-E1-5])\s*\./i) || trHtml.match(/\b([A-E1-5])\b/i);
        if (numM) return rrbNormalizeKey(numM[1]);
      }
    }
    return null;
  }

  function rrbExtractChosenOption(block) {
    const m = block.match(/Chosen\s*Option\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? stripTags(m[1]).trim() : '';
  }

  function rrbExtractStatus(block) {
    const m = block.match(/Status\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? stripTags(m[1]).trim() : '';
  }

  function rrbExtractQuestionId(block) {
    const m = block.match(/Question\s*ID\s*:\s*<\/td>\s*<td[^>]*>([\s\S]*?)<\/td>/i);
    return m ? stripTags(m[1]).trim() : null;
  }

  function rrbQuestionStatus(qBlock) {
    if (
      qBlock.toLowerCase().includes('question cancelled') ||
      qBlock.toLowerCase().includes('benefit of doubt') ||
      qBlock.toLowerCase().includes('question ignored') ||
      qBlock.toLowerCase().includes('given to all') ||
      qBlock.toLowerCase().includes('taken up for challenge')
    ) {
      return 'bonus';
    }

    const chosenRaw = rrbExtractChosenOption(qBlock);
    const statusText = rrbExtractStatus(qBlock);
    const chosen = rrbNormalizeKey(chosenRaw);
    const rightAns = rrbExtractRightAnswer(qBlock);

    if (!rightAns) return 'bonus';

    const isSkipped = !chosen || chosen === '--' || chosenRaw === '--' || chosenRaw === ' -- ' || statusText === 'Not Answered' || !/^[A-E]$/.test(chosen);
    if (isSkipped) return 'skipped';

    if (chosen === rightAns) return 'correct';
    return 'wrong';
  }

  function rrbParseQuestionBlock(qBlock, baseUrl) {
    // Question text/images: the big <td class="bold" ...> right after the
    // "Q.N" index cell inside the questionRowTbl (before the "Ans" rows).
    const qTextM = qBlock.match(/class=["']bold["'][^>]*style=["'][^"']*text-align:\s*left[^"']*["'][^>]*>([\s\S]*?)<\/td>/i);
    const qContent = qTextM ? qTextM[1] : '';
    const { text: qText, images: qImages } = rrbCellContent(qContent, baseUrl);

    // Options extraction
    let options = [];
    const optRe = /<td[^>]*class=["'](rightAns|wrngAns)["'][^>]*>([\s\S]*?)<\/td>/gi;
    let m;
    while ((m = optRe.exec(qBlock)) !== null) {
      const cls = m[1];
      let cellHtml = m[2];
      cellHtml = cellHtml.replace(/^\s*<img[^>]*>/i, '');
      const letterM = cellHtml.match(/^\s*([A-E1-5])\s*\.\s*/);
      const letter = letterM ? rrbNormalizeKey(letterM[1]) : String.fromCharCode(65 + options.length);
      cellHtml = cellHtml.replace(/^\s*[A-E1-5]\s*\.\s*/, '');
      const { text, images } = rrbCellContent(cellHtml, baseUrl);
      options.push({ label: letter, text, images, isRight: cls === 'rightAns' });
    }

    // Fallback: match standard TCS option rows <tr><td valign="top">N.</td><td ...>text</td></tr>
    if (options.length < 4) {
      options = [];
      const trRegex = /<tr[^>]*>\s*<td[^>]*valign=["']?top["']?[^>]*>\s*([A-E1-5])\s*\.?\s*<\/td>\s*<td([^>]*)>([\s\S]*?)<\/td>\s*<\/tr>/gi;
      while ((m = trRegex.exec(qBlock)) !== null) {
        const rawKey = m[1];
        const tdAttrs = m[2];
        let cellHtml = m[3];
        const isRight = /rightAns/i.test(tdAttrs) || /rightAns/i.test(cellHtml);
        cellHtml = cellHtml.replace(/^\s*<img[^>]*>/i, '');
        const { text, images } = rrbCellContent(cellHtml, baseUrl);
        options.push({ label: rrbNormalizeKey(rawKey), text, images, isRight });
      }
    }

    const rightAns = rrbExtractRightAnswer(qBlock);
    const chosenRaw = rrbExtractChosenOption(qBlock);
    const chosenLetter = rrbNormalizeKey(chosenRaw);
    const status = rrbQuestionStatus(qBlock);

    const finalOptions = options.map(o => ({
      label: o.label,
      text: o.text,
      images: o.images,
      isCorrect: o.isRight || (rightAns ? o.label === rightAns : false),
      isChosen: o.label === chosenLetter && /^[A-E]$/.test(chosenLetter)
    }));

    return {
      qId: rrbExtractQuestionId(qBlock),
      status,
      question: { text: qText, images: qImages },
      options: finalOptions
    };
  }

  /* ─────────────────────────────────────────────────────────────
     TCS / digialm QUESTION SCANNER  (v5)
     Same copy lives in parser-rrb.js AND review-json-builder.js so
     score and review can never disagree.

     A <div class="question-pnl"> block is a QUESTION only if it has:
       1. Question ID : <value>         (any non-empty value)
       2. Option 1..N ID : <value>      (N >= 2, non-empty)
       3. exactly N option rows with class rightAns / wrngAns
     NOT required:
       • Q.<n> label / width="7%"  — if present it gives the number,
         otherwise questions are numbered in order.
       • Chosen Option — missing row, empty value or "--" = skipped.
     Question ID / Option IDs / Chosen Option are read from the
     menu-tbl when it exists; option rows are read only after the
     question-text cell, so a table / "Q1" / "Q.1" inside a question
     can never create a fake question or a fake option.
     A panel that has a Question ID but fails a check is an ERROR
     (score blocked) — it is NEVER turned into a bonus.
     Bonus = valid block whose answer key has zero rightAns rows.
  ───────────────────────────────────────────────────────────── */
  function rrbStrip(s) {
    return String(s || '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;|&#160;/gi, ' ')
      .replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"').replace(/&#39;/gi, "'")
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function rrbMenuField(menu, labelRe) {
    const re = new RegExp('<td\\b[^>]*>\\s*' + labelRe + '\\s*:?\\s*<\\/td>\\s*<td\\b[^>]*>([\\s\\S]*?)<\\/td>', 'i');
    const m = menu.match(re);
    return m ? rrbStrip(m[1]) : null;
  }

  function rrbLabelToIndex(label) {
    if (/^\d{1,2}$/.test(label)) return parseInt(label, 10);
    if (/^[A-Z]$/.test(label)) return label.charCodeAt(0) - 64;
    return 0;
  }

  // Index just after the </td> that closes the <td> opening at tagStart
  // (nested <td>/<table> inside question text are depth-counted).
  function rrbTdEnd(html, tagStart) {
    const re = /<td\b[^>]*>|<\/td\s*>/gi;
    re.lastIndex = tagStart;
    let depth = 0, m;
    while ((m = re.exec(html)) !== null) {
      if (m[0][1] === '/') { depth--; if (depth === 0) return m.index + m[0].length; }
      else depth++;
    }
    return -1;
  }

  // Inspect one question panel.
  // Returns {kind:'question', q} | {kind:'error', reason, qno} | {kind:'ignore', reason}
  function rrbInspectPanel(panel) {
    const menuM = /<table\b[^>]*class\s*=\s*["'][^"']*\bmenu-tbl\b[^"']*["']/i.exec(panel);
    const body = menuM ? panel.slice(0, menuM.index) : panel;     // question + options
    const menu = menuM ? panel.slice(menuM.index) : panel;        // IDs + chosen option

    let qno = null;                      // filled from an optional Q.<n> label below
    const qId = rrbMenuField(menu, 'Question\\s*ID');
    if (qId === null) {
      return /Option\s*\d+\s*ID/i.test(menu)
        ? { kind: 'error', qno, reason: 'Option IDs hain par Question ID nahi mila' }
        : { kind: 'ignore', reason: 'question-pnl bina Question ID' };
    }
    if (!qId) return { kind: 'error', qno, reason: 'Question ID khaali hai' };

    // ── Option IDs ──
    const optionIds = {};
    const optRe = /<td\b[^>]*>\s*Option\s*(\d+)\s*ID\s*:?\s*<\/td>\s*<td\b[^>]*>([\s\S]*?)<\/td>/gi;
    let om;
    while ((om = optRe.exec(menu)) !== null) {
      const k = om[1], v = rrbStrip(om[2]);
      if (optionIds[k] !== undefined) return { kind: 'error', qno: null, reason: 'Option ' + k + ' ID do baar' };
      if (!v) return { kind: 'error', qno: null, reason: 'Option ' + k + ' ID khaali hai' };
      optionIds[k] = v;
    }
    const n = Object.keys(optionIds).length;
    if (n < 2) return { kind: 'error', qno: null, reason: 'Option IDs nahi mile' };

    // ── Content cells before the options (top level only — we never look
    // inside a content cell, so a "Q1"/"Q.1" cell in a question's own table
    // is never seen). Wrapper cells (holding the whole question table) and
    // empty / "Ans" cells are skipped.
    //   • a cell that is exactly "Q.<n>" = question-number label; the next
    //     content cell = question text (comprehension panels have the
    //     passage + "SubQuestion No" cells BEFORE the label).
    //   • no label → the last content cell before the options = question text.
    const cells = [];
    {
      const tdRe = /<td\b[^>]*>/gi;
      let tm;
      while ((tm = tdRe.exec(body)) !== null) {
        if (/\b(rightAns|wrngAns)\b/.test(tm[0])) break;           // reached the options
        const end = rrbTdEnd(body, tm.index);
        const inner = body.slice(tm.index + tm[0].length, end < 0 ? body.length : end);
        // Wrapper cell = holds the question table itself (closes after the
        // menu-tbl, or has questionRowTbl, or holds ALL N option rows) →
        // look inside it. A question-text cell holding a few fake
        // "rightAns" cells is NOT a wrapper.
        const rowsInside = (inner.match(/<td\b[^>]*class\s*=\s*["'][^"']*\b(?:rightAns|wrngAns)\b/gi) || []).length;
        if (end < 0 || /\bquestion(?:Row|Pnl)Tbl\b/.test(inner) || rowsInside >= n) continue;
        const txt = rrbStrip(inner);
        tdRe.lastIndex = end;                                       // never descend into this cell
        if ((txt === '' && !/<img/i.test(inner)) || /^Ans\s*:?$/i.test(txt)) continue;
        cells.push({ start: tm.index, end, inner, txt });
      }
    }
    let textCell = null;
    const labelAt = cells.findIndex(c => /^Q\s*\.?\s*\d+$/i.test(c.txt) && !/<td\b/i.test(c.inner));
    if (labelAt !== -1) {
      qno = parseInt(cells[labelAt].txt.replace(/\D/g, ''), 10);
      textCell = cells[labelAt + 1] || null;
    } else if (cells.length) {
      textCell = cells[cells.length - 1];
    }

    // Options are read only AFTER the question-text cell.
    const textStart = textCell ? textCell.start : -1;
    const textEnd = textCell ? textCell.end : -1;
    const ansStart = textCell ? textCell.end : 0;
    const ansPart = body.slice(ansStart);

    // ── Option rows ──
    const rowStarts = [];
    const rowRe = /<td\b[^>]*class\s*=\s*["']([^"']*)["'][^>]*>/gi;
    let rm;
    while ((rm = rowRe.exec(ansPart)) !== null) {
      const cm = /\b(rightAns|wrngAns)\b/.exec(rm[1]);
      if (cm) rowStarts.push({ cls: cm[1], tagStart: rm.index, start: rm.index + rm[0].length });
    }
    if (rowStarts.length !== n) return { kind: 'error', qno, reason: 'Option rows (' + rowStarts.length + ') != Option IDs (' + n + ')' };

    const rows = rowStarts.map((r, i) => {
      const end = rrbTdEnd(ansPart, r.tagStart);
      const txt = rrbStrip(ansPart.slice(r.start, end < 0 ? ansPart.length : end));
      const lm = /^([A-Z]|\d{1,2})\s*[.)]/.exec(txt);
      const byLabel = lm ? rrbLabelToIndex(lm[1]) : 0;
      return { cls: r.cls, label: lm ? lm[1] : '', idx: byLabel >= 1 && byLabel <= n ? byLabel : i + 1, tagStart: r.tagStart };
    });
    if (new Set(rows.map(r => r.idx)).size !== rows.length) {
      rows.forEach((r, i) => { r.idx = i + 1; });                 // labels clash → plain row order
    }

    // ── Chosen option (optional) ──
    const chosenRaw = rrbMenuField(menu, 'Chosen\\s*Option');
    const chosenTxt = (chosenRaw || '').toUpperCase().replace(/\s+/g, '');
    let chosenIdx = null;
    if (chosenTxt === '' || /^-+$/.test(chosenTxt) || chosenTxt === 'NA' || chosenTxt === 'N/A') {
      chosenIdx = null;                                            // row missing / empty / "--" → skipped
    } else if (/^([A-Z]|\d{1,2})$/.test(chosenTxt)) {
      chosenIdx = rrbLabelToIndex(chosenTxt);
      if (chosenIdx < 1 || chosenIdx > n) return { kind: 'error', qno, reason: 'Chosen Option "' + chosenRaw + '" kisi option se match nahi karta' };
    } else {
      return { kind: 'error', qno, reason: 'Chosen Option padha nahi gaya: "' + chosenRaw + '"' };
    }

    const rightIdx = rows.filter(r => r.cls === 'rightAns').map(r => r.idx).sort((x, y) => x - y);
    let status;
    if (rightIdx.length === 0) status = 'bonus';            // valid block, board gave no key → dropped
    else if (chosenIdx === null) status = 'skipped';
    else status = rightIdx.indexOf(chosenIdx) !== -1 ? 'correct' : 'wrong';

    const letter = i => (i ? String.fromCharCode(64 + i) : null);
    return {
      kind: 'question',
      q: {
        qno, qId, optionIds, status,
        chosen: letter(chosenIdx),
        rightAnswers: rightIdx.map(letter),
        statusText: rrbMenuField(menu, 'Status') || '',
        _qPart: body, _textStart: textStart, _textEnd: textEnd, _ansOffset: ansStart, _rows: rows
      }
    };
  }

  /**
   * @returns {{ sections: Array<{name, questions}>, validation: {ok, found, errors[], warnings[], ignored} }}
   */
  function rrbStrictScan(html) {
    html = String(html || '');
    const errors = [], warnings = [];
    let ignored = 0;

    const labels = [];
    const lblRe = /<div\b[^>]*class\s*=\s*["'][^"']*\bsection-lbl\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/gi;
    let m;
    while ((m = lblRe.exec(html)) !== null) {
      labels.push({ name: rrbStrip(m[1]).replace(/^Section\s*:?\s*/i, '') || 'General', pos: m.index });
    }

    let starts = [];
    const pnlRe = /<div\b[^>]*class\s*=\s*["'][^"']*\bquestion-pnl\b[^"']*["'][^>]*>/gi;
    while ((m = pnlRe.exec(html)) !== null) starts.push(m.index);
    if (starts.length === 0) errors.push('Response sheet me question-pnl block nahi mila');

    const sectionMap = new Map();
    const order = [];
    const seenQid = new Map();
    starts.forEach((start, i) => {
      let end = i + 1 < starts.length ? starts[i + 1] : html.length;
      const nextLbl = labels.find(l => l.pos > start && l.pos < end);
      if (nextLbl) end = nextLbl.pos;
      const panel = html.slice(start, end);
      const lbl = labels.filter(l => l.pos < start).pop();
      const secName = lbl ? lbl.name : 'General';

      const res = rrbInspectPanel(panel);
      if (res.kind === 'ignore') { ignored++; return; }
      if (res.kind === 'error') {
        errors.push((secName ? secName + ' · ' : '') + (res.qno ? 'Q.' + res.qno : 'Question block #' + (i + 1)) + ' — ' + res.reason);
        return;
      }
      const q = res.q;
      if (seenQid.has(q.qId)) {
        const prev = seenQid.get(q.qId);
        if (prev.status === q.status && prev.qno === q.qno) { warnings.push('Q.' + q.qno + ' duplicate block (same Question ID) — ek hi baar gina'); return; }
        errors.push('Question ID ' + q.qId + ' do alag questions me (Q.' + prev.qno + ' / Q.' + q.qno + ')');
        return;
      }
      seenQid.set(q.qId, q);
      if (!sectionMap.has(secName)) { sectionMap.set(secName, []); order.push(secName); }
      const list = sectionMap.get(secName);
      if (q.qno === null) q.qno = list.length ? list[list.length - 1].qno + 1 : 1;   // no Q label → number in order
      list.push(q);
    });

    const sections = order.map(name => ({ name, questions: sectionMap.get(name) }));

    // Numbering sanity: Q numbers must be continuous either across the
    // whole paper (1..N) or inside every section (1..n each).
    sections.forEach(s => {
      const seen = new Set();
      s.questions.forEach(q => {
        if (seen.has(q.qno)) warnings.push(s.name + ' · Q.' + q.qno + ' number do baar aaya (alag Question ID, dono gine gaye)');
        seen.add(q.qno);
      });
    });
    const all = sections.reduce((a, s) => a.concat(s.questions), []);
    const contiguous = arr => arr.every((q, i) => i === 0 || q.qno === arr[i - 1].qno + 1);
    const globalOk = all.length > 0 && all[0].qno === 1 && contiguous(all);
    const perSecOk = sections.every(s => s.questions.length && s.questions[0].qno === 1 && contiguous(s.questions));
    if (all.length && !globalOk && !perSecOk) warnings.push('Question numbering continuous nahi hai (Q label check karo)');
    if (!all.length && !errors.length) errors.push('Response sheet me ek bhi valid question nahi mila');

    return {
      sections,
      validation: { ok: errors.length === 0, found: all.length, errors, warnings, ignored }
    };
  }
  /* ───────────── end strict scanner ───────────── */

  // One review question from a scanned question (same scanner as
  // parser-rrb.js → score and review always show the same questions).
  // Text = the question-text cell found by the scanner; options = only
  // the rightAns/wrngAns rows AFTER that cell (never cells of a table
  // that sits inside the question text).
  function rrbReviewQuestion(q, baseUrl) {
    const part = q._qPart || '';
    let qContent = '';
    if (q._textStart >= 0 && q._textEnd > q._textStart) {
      const openEnd = part.indexOf('>', q._textStart) + 1;
      qContent = part.slice(openEnd, q._textEnd);
    }
    const { text: qText, images: qImages } = rrbCellContent(qContent, baseUrl);

    const ans = part.slice(q._ansOffset || 0);
    const options = (q._rows || []).map(r => {
      const openEnd = ans.indexOf('>', r.tagStart) + 1;
      const end = rrbTdEnd(ans, r.tagStart);
      let cellHtml = ans.slice(openEnd, end < 0 ? ans.length : end);
      cellHtml = cellHtml.replace(/^\s*<img[^>]*>/i, '').replace(/^\s*(?:[A-Z]|\d{1,2})\s*[.)]\s*/, '');
      const { text, images } = rrbCellContent(cellHtml, baseUrl);
      const label = String.fromCharCode(64 + r.idx);
      return { idx: r.idx, label, text, images, isCorrect: r.cls === 'rightAns', isChosen: q.chosen === label };
    }).sort((x, y) => x.idx - y.idx).map(({ idx, ...o }) => o);

    return {
      qno: q.qno,
      qId: q.qId,
      status: q.status,
      question: { text: qText, images: qImages },
      options
    };
  }

  function rrbReviewSections(html, baseUrl) {
    return rrbStrictScan(html).sections
      .map(sec => ({ name: sec.name, questions: sec.questions.map(q => rrbReviewQuestion(q, baseUrl)) }))
      .filter(sec => sec.questions.length > 0);
  }

  function buildRRB(parts, sourceUrl) {
    const html = parts.p1 || Object.values(parts)[0] || '';
    const meta = Object.assign({ family: 'rrb' }, rrbCandidateInfo(html));
    const sections = rrbReviewSections(html, sourceUrl);

    return { meta, sections };
  }

  // ═══════════════════════════════════════════════
  // Blank test-paper extraction ("Attempt as Mock Test")
  // ═══════════════════════════════════════════════
  // Same source HTML, same parsing helpers as build() above (identical
  // MathML→LaTeX, identical real-image handling, identical <br>
  // preservation) — a past candidate's answer-key page already carries
  // every question, option and the correct answer (rightAns/green-yellow),
  // regardless of what that one candidate personally picked. buildBlank()
  // reuses every RRB/SSC helper verbatim and only discards the
  // candidate-specific bits (status, isChosen, rollNo/candidateName)
  // since nobody has attempted THIS run yet — test.js fills those back
  // in locally as the person answers, then hands its OWN attempt off to
  // review.html using this exact same schema, so review.js (solution
  // mode) needs zero changes to display it afterwards.

  function stripToBlankQuestion(q) {
    return {
      qno: q.qno,
      qId: q.qId,
      question: q.question,
      options: (q.options || []).map(o => ({
        label: o.label,
        text: o.text,
        images: o.images,
        isCorrect: !!o.isCorrect
      }))
    };
  }

  function buildBlankRRB(parts, sourceUrl) {
    const html = parts.p1 || Object.values(parts)[0] || '';
    // family + examName only — rollNo/candidateName belong to whichever
    // candidate originally sat THIS paper, not to whoever is about to
    // attempt it fresh as a mock test, so they're deliberately dropped.
    const meta = { family: 'rrb', examName: rrbCandidateInfo(html).examName || '' };
    const sections = rrbReviewSections(html, sourceUrl)
      .map(sec => ({ name: sec.name, questions: sec.questions.map(stripToBlankQuestion) }));

    return { meta, sections };
  }

  function buildBlankSSC(parts, sourceUrl) {
    const sortedKeys = Object.keys(parts).sort((a, b) => {
      const na = parseInt(a.replace(/\D/g, ''), 10) || 0;
      const nb = parseInt(b.replace(/\D/g, ''), 10) || 0;
      return na - nb;
    });

    let examName = '';
    const sections = [];
    sortedKeys.forEach((key, idx) => {
      const html = parts[key];
      if (!examName) examName = sscCandidateInfo(html).examName || '';
      const part = sscParsePart(html, idx + 1, sourceUrl);
      sections.push({ name: part.name, questions: part.questions.map(stripToBlankQuestion) });
    });

    return { meta: { family: 'ssc', examName }, sections: sections.filter(s => s.questions.length > 0) };
  }

  function buildBlank(family, parts, sourceUrl) {
    return family === 'rrb' ? buildBlankRRB(parts, sourceUrl) : buildBlankSSC(parts, sourceUrl);
  }

  // ═══════════════════════════════════════════════
  // Public entry point
  // ═══════════════════════════════════════════════

  /**
   * @param {'ssc'|'rrb'} family
   * @param {Object<string,string>} parts - raw fetched HTML, same shape
   *        score-engine.js already uses ({p1: html, p2: html, ...})
   * @param {string} [sourceUrl] - original answer-key URL, used to resolve
   *        relative image paths for RRB/TCS pages
   * @returns {Object} unified review JSON (see schema at top of file)
   */
  function build(family, parts, sourceUrl) {
    if (family === 'rrb') return buildRRB(parts, sourceUrl);
    return buildSSC(parts, sourceUrl);
  }

  return { build, buildBlank };
})();

if (typeof window !== 'undefined') window.RSMReviewBuilder = RSMReviewBuilder;
if (typeof module !== 'undefined' && module.exports) module.exports = RSMReviewBuilder;





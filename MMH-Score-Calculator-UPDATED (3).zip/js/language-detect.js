/* ═══════════════════════════════════════════════════════════════════════
   MMH · PAPER LANGUAGE DETECTOR  (v2)
   ─────────────────────────────────────────────────────────────────────
   Har response sheet pe paper ki bhasha: 'HI' | 'EN' | 'UNKNOWN'

   ── URL TYPE SE METHOD CHOOSE HOTA HAI (dono alag alag) ──

   A) SSC CBE type URL   (cbexams / ssccbe / ssccbt / ViewCandResponse)
      → VERSION BUTTON method
        • block me "English version" button dikha  → page abhi HINDI hai
        • block me "Hindi version"  button dikha  → page abhi ENGLISH hai
        • fallback: qimg/<id>/HI/ ya /EN/ image path
      → Question text analysis yahan chalti HI NAHI (aapke instruction ke hisaab se:
        "ssccbe type url ke liye version button wala enough hai")

   B) Railway / TCS type URL   (digialm / tcsion)
      → QUESTION TEXT ANALYSIS
        Rule (aapka, exactly):
          1. Har question ka text nikaalo
          2. Gino: kitne questions me Devanagari KAHIN BHI hai (ek bhi char)
          3. Agar  50% se ZYADA questions me Devanagari hai  → HINDI
             warna                                            → ENGLISH
        ⚠️ Ye "50% TEXT hindi ho" NAHI hai — ye "50% QUESTIONS me hindi ho" hai.

   C) Unknown URL type → dono try, pehle SSC-style phir text analysis.

   Kabhi error nahi. Detect na ho → 'UNKNOWN' → sab pehle jaisa chalta hai.
═══════════════════════════════════════════════════════════════════════ */

const MMHLangDetect = (() => {

  const DEV_RE = /[\u0900-\u097F]/;         // Devanagari (presence check)
  const DEV_ALL_RE = /[\u0900-\u097F]/g;    // Devanagari (counting)
  const LAT_ALL_RE = /[A-Za-z]/g;

  /* ── URL type decide ────────────────────────────────────────────── */
  function urlFamily(url) {
    const u = String(url || '');
    if (/cbexams\.com|ssccbe|ssccbt|viewcandresponse/i.test(u)) return 'ssc';
    if (/digialm\.com|tcsion\.com/i.test(u)) return 'tcs';
    return 'unknown';
  }

  function countScript(s) {
    if (!s) return { dev: 0, lat: 0 };
    return {
      dev: (s.match(DEV_ALL_RE) || []).length,
      lat: (s.match(LAT_ALL_RE) || []).length
    };
  }

  function stripHtml(html) {
    return String(html || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&');
  }

  /* ══════════════════════════════════════════════════════════════════
     A) SSC CBE  ·  VERSION BUTTON
     ══════════════════════════════════════════════════════════════════ */
  function detectFromSwitchButton(html) {
    const re = /class=["']language-switch["']/gi;
    const m1 = re.exec(html);
    if (!m1) return null;
    const m2 = re.exec(html);
    const block = html.slice(m1.index, m2 ? m2.index : Math.min(html.length, m1.index + 4000));
    const hasEngBtn = /English\s*version/i.test(block);
    const hasHinBtn = /Hindi\s*version|हिन्दी|हिंदी/i.test(block);
    // Button ulta bata raha hai: "English version" dikha matlab abhi HINDI page hai
    if (hasEngBtn && !hasHinBtn) return 'HI';
    if (hasHinBtn && !hasEngBtn) return 'EN';
    return null;
  }

  function detectFromImagePath(html) {
    const m = /qimg\/\d+\/(HI|EN)\//i.exec(html);
    return m ? m[1].toUpperCase() : null;
  }

  /* ══════════════════════════════════════════════════════════════════
     B) TCS / RAILWAY  ·  QUESTION TEXT ANALYSIS
     Same question regex as review-json-builder.js (RRB path)
     ══════════════════════════════════════════════════════════════════ */
  function extractTcsQuestionTexts(html) {
    const texts = [];
    const panelRe = /<div[^>]*class=["']question-pnl["'][\s\S]*?(?=<div[^>]*class=["']question-pnl["']|$)/gi;
    const panels = html.match(panelRe) || [];

    const qTextRe = /class=["']bold["'][^>]*style=["'][^"']*text-align:\s*left[^"']*["'][^>]*>([\s\S]*?)<\/td>/i;
    const qLblRe = /class=["'][^"']*qstn-lbl[^"']*["'][^>]*>([\s\S]*?)<\/td>/i;

    panels.forEach(p => {
      const m = p.match(qTextRe) || p.match(qLblRe);
      if (m) {
        const txt = stripHtml(m[1]).trim();
        if (txt.length > 0) texts.push(txt);
      }
    });
    return texts;
  }

  // SSC sheets ka question text (sirf tab jab unknown URL type ho)
  function extractSscQuestionTexts(html) {
    const texts = [];
    const qStarts = [];
    const qRe = /Q\.No:&nbsp;(\d+)/gi;
    let m;
    while ((m = qRe.exec(html)) !== null) qStarts.push(m.index);
    qStarts.slice(0, 40).forEach((pos, i) => {
      const end = i + 1 < qStarts.length ? qStarts[i + 1] : Math.min(html.length, pos + 4000);
      const txt = stripHtml(html.slice(pos, end)).trim();
      if (txt.length > 12) texts.push(txt);
    });
    return texts;
  }

  /* ── ★ AAPKA RULE: kitne QUESTIONS me Devanagari hai ──
    50% se ZYADA questions me Devanagari (kahin bhi) → HI
    warna → EN                                    */
  function detectByQuestionMajority(parts) {
    const htmls = Object.keys(parts || {})
      .sort((a, b) => (parseInt(a.replace(/\D/g, ''), 10) || 0) - (parseInt(b.replace(/\D/g, ''), 10) || 0))
      .map(k => parts[k]).filter(Boolean);

    let texts = [];
    htmls.forEach(h => {
      const tcs = extractTcsQuestionTexts(h);
      if (tcs.length) texts = texts.concat(tcs);
      else texts = texts.concat(extractSscQuestionTexts(h));
    });

    // saare questions gino (koi 25 ka cap nahi — poora paper dekho)
    texts = texts.filter(t => t && t.trim().length > 0);
    if (!texts.length) return null;

    let hindiQs = 0;
    let devChars = 0, latChars = 0;
    texts.forEach(t => {
      if (DEV_RE.test(t)) hindiQs++;               // ek bhi Devanagari → ye question HINDI
      const c = countScript(t);
      devChars += c.dev; latChars += c.lat;
    });

    const ratio = hindiQs / texts.length;          // questions ka proportion
    const lang = ratio > 0.5 ? 'HI' : 'EN';        // aapka threshold: 50% se ZYADA

    return {
      lang,
      method: 'question-majority',
      questions: texts.length,
      hindiQuestions: hindiQs,
      ratio: +ratio.toFixed(3),
      dev: devChars,
      lat: latChars
    };
  }

  // last-resort: poora page (sirf jab ek bhi question na mile)
  function detectFromWholePage(html) {
    const c = countScript(stripHtml(html));
    if (c.dev + c.lat < 15) return null;
    return { lang: c.dev > c.lat ? 'HI' : 'EN', dev: c.dev, lat: c.lat };
  }

  const blank = (method) => ({
    lang: 'UNKNOWN', method: method || 'none', confidence: 0,
    dev: 0, lat: 0, questions: 0, hindiQuestions: 0, urlFamily: 'unknown'
  });

  /**
   * @param {Object<string,string>} parts  { p1: html, p2: html, ... }
   * @param {Object} [opts]                { url: '<answer key url>' }
   * @returns {{lang, method, confidence, dev, lat, questions, hindiQuestions, urlFamily}}
   */
  function detect(parts, opts) {
    opts = opts || {};
    const fam = urlFamily(opts.url);

    const htmls = Object.keys(parts || {}).map(k => parts[k]).filter(Boolean);
    if (!htmls.length) { const b = blank(); b.urlFamily = fam; return b; }
    const joined = htmls.join('\n');

    /* ───── A) SSC CBE → sirf version button (+ qimg fallback) ───── */
    if (fam === 'ssc') {
      const sw = detectFromSwitchButton(joined);
      if (sw) return { ...blank('switch-button'), lang: sw, confidence: 1, urlFamily: fam };

      const img = detectFromImagePath(joined);
      if (img) return { ...blank('image-path'), lang: img, confidence: 1, urlFamily: fam };

      // button nahi mila → kuch guess nahi karte. No error, plain UNKNOWN.
      return { ...blank('ssc-no-indicator'), urlFamily: fam };
    }

    /* ───── B) Railway / TCS → question majority ───── */
    if (fam === 'tcs') {
      const q = detectByQuestionMajority(parts);
      if (q) {
        return {
          lang: q.lang, method: q.method, confidence: q.ratio,
          dev: q.dev, lat: q.lat, questions: q.questions,
          hindiQuestions: q.hindiQuestions, urlFamily: fam
        };
      }
      const w = detectFromWholePage(joined);
      if (w) return { ...blank('whole-page'), lang: w.lang, dev: w.dev, lat: w.lat, urlFamily: fam };
      return { ...blank('tcs-no-questions'), urlFamily: fam };
    }

    /* ───── C) Unknown URL type → dono try ───── */
    const sw = detectFromSwitchButton(joined);
    if (sw) return { ...blank('switch-button'), lang: sw, confidence: 1, urlFamily: fam };

    const img = detectFromImagePath(joined);
    if (img) return { ...blank('image-path'), lang: img, confidence: 1, urlFamily: fam };

    const q = detectByQuestionMajority(parts);
    if (q) {
      return {
        lang: q.lang, method: q.method, confidence: q.ratio,
        dev: q.dev, lat: q.lat, questions: q.questions,
        hindiQuestions: q.hindiQuestions, urlFamily: fam
      };
    }

    const w = detectFromWholePage(joined);
    if (w) return { ...blank('whole-page'), lang: w.lang, dev: w.dev, lat: w.lat, urlFamily: fam };

    return { ...blank(), urlFamily: fam };
  }

  return {
    detect,
    urlFamily,
    countScript,
    stripHtml,
    detectByQuestionMajority,
    _extractTcsQuestionTexts: extractTcsQuestionTexts
  };
})();

if (typeof window !== 'undefined') window.MMHLangDetect = MMHLangDetect;
if (typeof module !== 'undefined' && module.exports) module.exports = MMHLangDetect;

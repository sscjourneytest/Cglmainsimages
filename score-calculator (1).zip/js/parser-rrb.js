/* ═══════════════════════════════════════════════════
   MOCK MATRIX HUB · SCORE CALCULATOR — parser-rrb.js  (v5 — question-pnl based)
   Parses the single-page TCS / DigiAlm / Railway response sheet HTML
   into the same { candidateInfo, sections[] } shape the SSC
   parser produces, plus a `validation` report.

   A question = one <div class="question-pnl"> that has a Question ID,
   Option 1..N IDs and exactly N rightAns / wrngAns option rows.
   • Q.<n> label optional (gives the number, else numbered in order).
   • Chosen Option optional — missing / empty / "--" = skipped.
   • A "Q1 / Q.1" cell or a table INSIDE a question can never become a
     question or an option (old bug: Q13 table → 104 Q, 4 fake bonus).
   • A broken question block blocks the score (validation.ok = false) —
     it is NEVER counted as bonus. Bonus = valid block with no rightAns
     row (question dropped by the board). No keyword-based bonus.
═══════════════════════════════════════════════════ */

const RSMParserRRB = (() => {

  function decodeEntities(s) {
    return (s || '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .trim();
  }

  /**
   * Candidate info extraction from .main-info-pnl or top tables.
   */
  function parseCandidateInfo(html) {
    const info = {};
    const panelM = html.match(/class=["']main-info-pnl["'][\s\S]*?<table[\s\S]*?<\/table>/i);
    const scope = panelM ? panelM[0] : html;

    const grab = (patterns) => {
      for (const pat of patterns) {
        const re = new RegExp(`<td[^>]*>\\s*${pat}\\s*<\\/td>\\s*<td[^>]*>([\\s\\S]*?)<\\/td>`, 'i');
        const m = scope.match(re);
        if (m) {
          const val = decodeEntities(m[1].replace(/<[^>]+>/g, '')).trim();
          if (val) return val;
        }
      }
      return '';
    };

    info.rollNo = grab(['Roll\\s*Number', 'Roll\\s*No\\.?', 'Participant\\s*ID', 'Candidate\\s*ID']);
    info.name = grab(['Candidate\\s*Name', 'Participant\\s*Name', 'Applicant\\s*Name']);
    info.registrationNo = grab(['Registration\\s*Number', 'Reg\\s*No\\.?', 'Application\\s*No\\.?']);
    info.community = grab(['Community', 'Category']);
    info.centre = grab(['Test\\s*Centre\\s*Name', 'Centre\\s*Name', 'Center\\s*Name', 'Venue\\s*Name', 'Vanue\\s*Name']);
    info.date = grab(['Test\\s*Date', 'Exam\\s*Date', 'Date']);
    info.shift = grab(['Test\\s*Time', 'Exam\\s*Time', 'Shift']);
    info.exam = grab(['Subject', 'Subject\\s*Name', 'Test', 'Test\\s*Name', 'Post', 'Post\\s*Name', 'Exam\\s*Name']);

    // t268: purana logic roll na nikaal paaye → poore page me "Participant ID"
    // dhoondo (label cell me &nbsp; / : / <b> tag ho, ya value usi cell me ho).
    if (!info.rollNo) info.rollNo = participantIdFallback(html);

    Object.keys(info).forEach(k => { if (!info[k]) delete info[k]; });
    return info;
  }

  function participantIdFallback(html) {
    const lbl = 'Participant(?:\\s|&nbsp;|&#160;)*I\\.?D\\.?';
    const gap = '(?:\\s|&nbsp;|&#160;|:|<[^>]+>)*';
    // 1) <td>Participant ID</td><td>2680…</td>   (label cell → next cell)
    const cellRe = new RegExp('<t[dh][^>]*>' + gap + lbl + gap + '<\\/t[dh]>\\s*<t[dh][^>]*>([\\s\\S]*?)<\\/t[dh]>', 'i');
    const m1 = html.match(cellRe);
    if (m1) {
      const v = decodeEntities(m1[1].replace(/<[^>]+>/g, ' ')).trim().match(/[A-Za-z0-9\/-]{4,}/);
      if (v) return v[0];
    }
    // 2) plain text: "Participant ID : 2680…"  (same cell / span / div)
    const txt = decodeEntities(String(html).replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ');
    const m2 = txt.match(/Participant\s*I\.?D\.?\s*[:\-]?\s*([A-Za-z0-9\/-]{4,})/i);
    return m2 ? m2[1] : '';
  }

  /* ─────────────────────────────────────────────────────────────
     TCS / digialm QUESTION SCANNER  (v5)
     Same copy lives in parser-rrb.js AND review-json-builder.js so
     score and review can never disagree.

     A <div class="question-pnl"> block is a QUESTION only if it has:
       1. Question ID : <value>         (any non-empty value)
       2. Option 1..N ID : <value>      (N >= 2, non-empty)
       3. exactly N option rows with class rightAns / wrngAns
     NOT required:
       • Q.<n> label / width="7%"  — if present it gives the number,
         otherwise questions are numbered in order.
       • Chosen Option — missing row, empty value or "--" = skipped.
     Question ID / Option IDs / Chosen Option are read from the
     menu-tbl when it exists; option rows are read only after the
     question-text cell, so a table / "Q1" / "Q.1" inside a question
     can never create a fake question or a fake option.
     A panel that has a Question ID but fails a check is an ERROR
     (score blocked) — it is NEVER turned into a bonus.
     Bonus = valid block whose answer key has zero rightAns rows.
  ───────────────────────────────────────────────────────────── */
  function rrbStrip(s) {
    return String(s || '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;|&#160;/gi, ' ')
      .replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"').replace(/&#39;/gi, "'")
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function rrbMenuField(menu, labelRe) {
    const re = new RegExp('<td\\b[^>]*>\\s*' + labelRe + '\\s*:?\\s*<\\/td>\\s*<td\\b[^>]*>([\\s\\S]*?)<\\/td>', 'i');
    const m = menu.match(re);
    return m ? rrbStrip(m[1]) : null;
  }

  function rrbLabelToIndex(label) {
    if (/^\d{1,2}$/.test(label)) return parseInt(label, 10);
    if (/^[A-Z]$/.test(label)) return label.charCodeAt(0) - 64;
    return 0;
  }

  // Index just after the </td> that closes the <td> opening at tagStart
  // (nested <td>/<table> inside question text are depth-counted).
  function rrbTdEnd(html, tagStart) {
    const re = /<td\b[^>]*>|<\/td\s*>/gi;
    re.lastIndex = tagStart;
    let depth = 0, m;
    while ((m = re.exec(html)) !== null) {
      if (m[0][1] === '/') { depth--; if (depth === 0) return m.index + m[0].length; }
      else depth++;
    }
    return -1;
  }

  // Inspect one question panel.
  // Returns {kind:'question', q} | {kind:'error', reason, qno} | {kind:'ignore', reason}
  function rrbInspectPanel(panel) {
    const menuM = /<table\b[^>]*class\s*=\s*["'][^"']*\bmenu-tbl\b[^"']*["']/i.exec(panel);
    const body = menuM ? panel.slice(0, menuM.index) : panel;     // question + options
    const menu = menuM ? panel.slice(menuM.index) : panel;        // IDs + chosen option

    let qno = null;                      // filled from an optional Q.<n> label below
    const qId = rrbMenuField(menu, 'Question\\s*ID');
    if (qId === null) {
      return /Option\s*\d+\s*ID/i.test(menu)
        ? { kind: 'error', qno, reason: 'Option IDs hain par Question ID nahi mila' }
        : { kind: 'ignore', reason: 'question-pnl bina Question ID' };
    }
    if (!qId) return { kind: 'error', qno, reason: 'Question ID khaali hai' };

    // ── Option IDs ──
    const optionIds = {};
    const optRe = /<td\b[^>]*>\s*Option\s*(\d+)\s*ID\s*:?\s*<\/td>\s*<td\b[^>]*>([\s\S]*?)<\/td>/gi;
    let om;
    while ((om = optRe.exec(menu)) !== null) {
      const k = om[1], v = rrbStrip(om[2]);
      if (optionIds[k] !== undefined) return { kind: 'error', qno: null, reason: 'Option ' + k + ' ID do baar' };
      if (!v) return { kind: 'error', qno: null, reason: 'Option ' + k + ' ID khaali hai' };
      optionIds[k] = v;
    }
    const n = Object.keys(optionIds).length;
    if (n < 2) return { kind: 'error', qno: null, reason: 'Option IDs nahi mile' };

    // ── Content cells before the options (top level only — we never look
    // inside a content cell, so a "Q1"/"Q.1" cell in a question's own table
    // is never seen). Wrapper cells (holding the whole question table) and
    // empty / "Ans" cells are skipped.
    //   • a cell that is exactly "Q.<n>" = question-number label; the next
    //     content cell = question text (comprehension panels have the
    //     passage + "SubQuestion No" cells BEFORE the label).
    //   • no label → the last content cell before the options = question text.
    const cells = [];
    {
      const tdRe = /<td\b[^>]*>/gi;
      let tm;
      while ((tm = tdRe.exec(body)) !== null) {
        if (/\b(rightAns|wrngAns)\b/.test(tm[0])) break;           // reached the options
        const end = rrbTdEnd(body, tm.index);
        const inner = body.slice(tm.index + tm[0].length, end < 0 ? body.length : end);
        // Wrapper cell = holds the question table itself (closes after the
        // menu-tbl, or has questionRowTbl, or holds ALL N option rows) →
        // look inside it. A question-text cell holding a few fake
        // "rightAns" cells is NOT a wrapper.
        const rowsInside = (inner.match(/<td\b[^>]*class\s*=\s*["'][^"']*\b(?:rightAns|wrngAns)\b/gi) || []).length;
        if (end < 0 || /\bquestion(?:Row|Pnl)Tbl\b/.test(inner) || rowsInside >= n) continue;
        const txt = rrbStrip(inner);
        tdRe.lastIndex = end;                                       // never descend into this cell
        if ((txt === '' && !/<img/i.test(inner)) || /^Ans\s*:?$/i.test(txt)) continue;
        cells.push({ start: tm.index, end, inner, txt });
      }
    }
    let textCell = null;
    const labelAt = cells.findIndex(c => /^Q\s*\.?\s*\d+$/i.test(c.txt) && !/<td\b/i.test(c.inner));
    if (labelAt !== -1) {
      qno = parseInt(cells[labelAt].txt.replace(/\D/g, ''), 10);
      textCell = cells[labelAt + 1] || null;
    } else if (cells.length) {
      textCell = cells[cells.length - 1];
    }

    // Options are read only AFTER the question-text cell.
    const textStart = textCell ? textCell.start : -1;
    const textEnd = textCell ? textCell.end : -1;
    const ansStart = textCell ? textCell.end : 0;
    const ansPart = body.slice(ansStart);

    // ── Option rows ──
    const rowStarts = [];
    const rowRe = /<td\b[^>]*class\s*=\s*["']([^"']*)["'][^>]*>/gi;
    let rm;
    while ((rm = rowRe.exec(ansPart)) !== null) {
      const cm = /\b(rightAns|wrngAns)\b/.exec(rm[1]);
      if (cm) rowStarts.push({ cls: cm[1], tagStart: rm.index, start: rm.index + rm[0].length });
    }
    if (rowStarts.length !== n) return { kind: 'error', qno, reason: 'Option rows (' + rowStarts.length + ') != Option IDs (' + n + ')' };

    const rows = rowStarts.map((r, i) => {
      const end = rrbTdEnd(ansPart, r.tagStart);
      const txt = rrbStrip(ansPart.slice(r.start, end < 0 ? ansPart.length : end));
      const lm = /^([A-Z]|\d{1,2})\s*[.)]/.exec(txt);
      const byLabel = lm ? rrbLabelToIndex(lm[1]) : 0;
      return { cls: r.cls, label: lm ? lm[1] : '', idx: byLabel >= 1 && byLabel <= n ? byLabel : i + 1, tagStart: r.tagStart };
    });
    if (new Set(rows.map(r => r.idx)).size !== rows.length) {
      rows.forEach((r, i) => { r.idx = i + 1; });                 // labels clash → plain row order
    }

    // ── Chosen option (optional) ──
    const chosenRaw = rrbMenuField(menu, 'Chosen\\s*Option');
    const chosenTxt = (chosenRaw || '').toUpperCase().replace(/\s+/g, '');
    let chosenIdx = null;
    if (chosenTxt === '' || /^-+$/.test(chosenTxt) || chosenTxt === 'NA' || chosenTxt === 'N/A') {
      chosenIdx = null;                                            // row missing / empty / "--" → skipped
    } else if (/^([A-Z]|\d{1,2})$/.test(chosenTxt)) {
      chosenIdx = rrbLabelToIndex(chosenTxt);
      if (chosenIdx < 1 || chosenIdx > n) return { kind: 'error', qno, reason: 'Chosen Option "' + chosenRaw + '" kisi option se match nahi karta' };
    } else {
      return { kind: 'error', qno, reason: 'Chosen Option padha nahi gaya: "' + chosenRaw + '"' };
    }

    const rightIdx = rows.filter(r => r.cls === 'rightAns').map(r => r.idx).sort((x, y) => x - y);
    let status;
    if (rightIdx.length === 0) status = 'bonus';            // valid block, board gave no key → dropped
    else if (chosenIdx === null) status = 'skipped';
    else status = rightIdx.indexOf(chosenIdx) !== -1 ? 'correct' : 'wrong';

    const letter = i => (i ? String.fromCharCode(64 + i) : null);
    return {
      kind: 'question',
      q: {
        qno, qId, optionIds, status,
        chosen: letter(chosenIdx),
        rightAnswers: rightIdx.map(letter),
        statusText: rrbMenuField(menu, 'Status') || '',
        _qPart: body, _textStart: textStart, _textEnd: textEnd, _ansOffset: ansStart, _rows: rows
      }
    };
  }

  /**
   * @returns {{ sections: Array<{name, questions}>, validation: {ok, found, errors[], warnings[], ignored} }}
   */
  function rrbStrictScan(html) {
    html = String(html || '');
    const errors = [], warnings = [];
    let ignored = 0;

    const labels = [];
    const lblRe = /<div\b[^>]*class\s*=\s*["'][^"']*\bsection-lbl\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/gi;
    let m;
    while ((m = lblRe.exec(html)) !== null) {
      labels.push({ name: rrbStrip(m[1]).replace(/^Section\s*:?\s*/i, '') || 'General', pos: m.index });
    }

    let starts = [];
    const pnlRe = /<div\b[^>]*class\s*=\s*["'][^"']*\bquestion-pnl\b[^"']*["'][^>]*>/gi;
    while ((m = pnlRe.exec(html)) !== null) starts.push(m.index);
    if (starts.length === 0) errors.push('Response sheet me question-pnl block nahi mila');

    const sectionMap = new Map();
    const order = [];
    const seenQid = new Map();
    starts.forEach((start, i) => {
      let end = i + 1 < starts.length ? starts[i + 1] : html.length;
      const nextLbl = labels.find(l => l.pos > start && l.pos < end);
      if (nextLbl) end = nextLbl.pos;
      const panel = html.slice(start, end);
      const lbl = labels.filter(l => l.pos < start).pop();
      const secName = lbl ? lbl.name : 'General';

      const res = rrbInspectPanel(panel);
      if (res.kind === 'ignore') { ignored++; return; }
      if (res.kind === 'error') {
        errors.push((secName ? secName + ' · ' : '') + (res.qno ? 'Q.' + res.qno : 'Question block #' + (i + 1)) + ' — ' + res.reason);
        return;
      }
      const q = res.q;
      if (seenQid.has(q.qId)) {
        const prev = seenQid.get(q.qId);
        if (prev.status === q.status && prev.qno === q.qno) { warnings.push('Q.' + q.qno + ' duplicate block (same Question ID) — ek hi baar gina'); return; }
        errors.push('Question ID ' + q.qId + ' do alag questions me (Q.' + prev.qno + ' / Q.' + q.qno + ')');
        return;
      }
      seenQid.set(q.qId, q);
      if (!sectionMap.has(secName)) { sectionMap.set(secName, []); order.push(secName); }
      const list = sectionMap.get(secName);
      if (q.qno === null) q.qno = list.length ? list[list.length - 1].qno + 1 : 1;   // no Q label → number in order
      list.push(q);
    });

    const sections = order.map(name => ({ name, questions: sectionMap.get(name) }));

    // Numbering sanity: Q numbers must be continuous either across the
    // whole paper (1..N) or inside every section (1..n each).
    sections.forEach(s => {
      const seen = new Set();
      s.questions.forEach(q => {
        if (seen.has(q.qno)) warnings.push(s.name + ' · Q.' + q.qno + ' number do baar aaya (alag Question ID, dono gine gaye)');
        seen.add(q.qno);
      });
    });
    const all = sections.reduce((a, s) => a.concat(s.questions), []);
    const contiguous = arr => arr.every((q, i) => i === 0 || q.qno === arr[i - 1].qno + 1);
    const globalOk = all.length > 0 && all[0].qno === 1 && contiguous(all);
    const perSecOk = sections.every(s => s.questions.length && s.questions[0].qno === 1 && contiguous(s.questions));
    if (all.length && !globalOk && !perSecOk) warnings.push('Question numbering continuous nahi hai (Q label check karo)');
    if (!all.length && !errors.length) errors.push('Response sheet me ek bhi valid question nahi mila');

    return {
      sections,
      validation: { ok: errors.length === 0, found: all.length, errors, warnings, ignored }
    };
  }
  /* ───────────── end strict scanner ───────────── */

  /**
   * @param {Object<string,string>} parts - TCS / RRB fetcher returns { p1: html }
   * @returns {{ candidateInfo: Object, sections: Array<{name,questions}>, validation: Object }}
   */
  function parse(parts) {
    const html = (parts && (parts.p1 || Object.values(parts)[0])) || '';
    const candidateInfo = parseCandidateInfo(html);
    const scan = rrbStrictScan(html);
    const sections = scan.sections
      .map(sec => ({
        name: sec.name,
        questions: sec.questions.map(q => ({
          qno: q.qno,
          qId: q.qId,
          optionIds: q.optionIds,
          status: q.status,
          chosen: q.chosen,
          rightAnswers: q.rightAnswers
        }))
      }))
      .filter(sec => sec.questions.length > 0);

    return { candidateInfo, sections, validation: scan.validation };
  }

  return { parse, scan: rrbStrictScan };
})();

if (typeof window !== 'undefined') window.RSMParserRRB = RSMParserRRB;
if (typeof module !== 'undefined' && module.exports) module.exports = RSMParserRRB;
